#include "../Application/stdafx.h"

#pragma once
#include <bitset>


enum ButtonID { BT_UP, BT_DOWN, BT_LEFT, BT_RIGHT, 
	BT_MOVE,			// Moves the player forward
	BT_SELECT,			//Selects a menu option
	BT_BACK,			//Returns to previous menu
	BT_RUBY,			//Button associated with Ruby Geodes
	BT_SAPP,			//Button associated with Sapphire Geodes
	BT_DIAM,			//Button associated with Diamond Geodes
	BT_ALL,				//Button associated with All Geodes
	BT_RECALL,			//Button associated with Recalling 
	BT_RECALL_RUBY,
	BT_RECALL_SAPP,
	BT_RECALL_DIAM,
	BT_RECALL_ALL,
	BT_ESC,
	BT_SEND,
	BT_SCROLL_UP,
	BT_SCROLL_DOWN,
	BT_TAB,
	BUTTON_AMOUNT};

#define KEY_AMOUNT 256

class InputManager
{

	std::bitset<BUTTON_AMOUNT+1>	m_Buttons;
	std::bitset<BUTTON_AMOUNT+1>	m_Toggles;

	std::bitset<KEY_AMOUNT+1>		m_Keys;
	std::bitset<KEY_AMOUNT+1>		m_KeyToggles;
	DirectX::XMFLOAT2				m_MousePos;
	DirectX::XMFLOAT2				m_MouseDelta;

private:

	// Press the specified virtual key
	void Press(ButtonID action);
	// Releases the specified virtual key
	void Release(ButtonID action);
	// Toggles the button to the specified value
	void Toggle(ButtonID action, bool value);
public:


	InputManager( );
	~InputManager( );

	// ---------------------
	// --- Query Methods ---
	// ---------------------
	
	// Indicates whether the specified virtual button is pressed or not.
	bool IsPressing(ButtonID action) const;

	// Indicates whether the specified virtual button is toggled or not
	// If the untoggle option is true, the button's toggle will be set to false.
	bool IsToggled(ButtonID action, bool untoggle = true);

	bool KeyboardIsPressing(int vkeycode);
	bool KeyboardIsToggled(int vkeycode, bool untoggle = true);

	DirectX::XMFLOAT2 GetMousePos() const;
	DirectX::XMFLOAT2 GetMouseDelta() const;

	/*
	Returns the ID of the game virtual button assigned to the specified windows virtual key.
	If no game virtual button code is assigned the BUTTON_AMOUNT value is returned.
	vkeycode - windows virtual key code. 
	Return: Assigned game virtual button code.
	*/
	ButtonID TranslateKeyboard(int vkeycode);


	// ---------------------
	// --- Query Methods ---
	// ---------------------
	

	// Releases All keys
	void ReleaseAll();
	void ReleaseAllToggles();

	void KeyboardPress(int vkeycode);
	void KeyboardRelease(int vkeycode);


	// This function is to be called every frame to retrieve the DirectInput state.
	void ReadInput( RAWINPUT rawInput );


};

