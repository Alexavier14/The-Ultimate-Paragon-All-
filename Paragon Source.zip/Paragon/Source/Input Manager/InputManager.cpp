#include "../Application/stdafx.h"

#include "InputManager.h"

using namespace DirectX;

InputManager::InputManager(void) :
m_Buttons(0),
m_Toggles(0),
m_MousePos(0, 0),
m_MouseDelta(0, 0)
{}

InputManager::~InputManager(void)
{}


void InputManager::Press(ButtonID action)
{
	// If the button is not already pressed, m_Toggles the key.
	if ( !m_Buttons[action] )
		m_Toggles.set(action, true);

	m_Buttons.set(action, true);
}

void InputManager::Release(ButtonID action)
{
	m_Buttons.set(action, false);
	//m_Toggles.set(action, false);
}

void InputManager::Toggle(ButtonID action, bool value)
{
	if ( value )
		m_Buttons.set(action, true);
	else
		m_Toggles.set(action, false);
}


void InputManager::ReleaseAll()
{
	m_Buttons = 0;
	m_Toggles = 0;
}

void InputManager::ReleaseAllToggles( )
{
	m_Toggles = 0;
}


bool InputManager::IsPressing(ButtonID action) const
{
	return m_Buttons[action];
}

bool InputManager::IsToggled(ButtonID action, bool untoggle)
{
	bool value = m_Toggles[action];
	if ( untoggle )
		m_Toggles.set(action, false);
	return value;
}

XMFLOAT2 InputManager::GetMousePos() const
{
	return m_MousePos;
}

XMFLOAT2 InputManager::GetMouseDelta() const
{
	return m_MouseDelta;
}

ButtonID InputManager::TranslateKeyboard(int vkeycode)
{

	switch ( vkeycode )
	{
		// Movement
	case VK_UP:
		return BT_UP;
	case VK_DOWN:
		return BT_DOWN;
	case VK_LEFT:
		return BT_LEFT;
	case VK_RIGHT:
		return BT_RIGHT;

		// Actions
	case 'Q':
		return BT_SAPP;
	case 'W':
		return BT_RUBY;
	case 'E':
	case VK_NUMPAD3:
		return BT_DIAM;
	case 'R':
		return BT_ALL;
	case 'A':
		return BT_RECALL_RUBY;
	case 'S':
		return BT_RECALL_SAPP;
	case 'D':
		return BT_RECALL_DIAM;
	case 'F':
		return BT_RECALL_ALL;
	case VK_SPACE:
		return BT_SEND;

		// Other
	case VK_RETURN:
		return BT_SELECT;
	case VK_ESCAPE:
		return BT_ESC;
	case VK_TAB:
		return BT_TAB;
	default:
		return BUTTON_AMOUNT;
	}
}

void InputManager::KeyboardPress(int vkeycode)
{
	if (vkeycode > KEY_AMOUNT)
	{
		PrintConsole("Keycode not supported");
		vkeycode = KEY_AMOUNT;
	}
	if ( !m_Keys[vkeycode] )
		m_KeyToggles.set(vkeycode, true);
	m_Keys.set(vkeycode, true);
	Press(TranslateKeyboard(vkeycode));
}

void InputManager::KeyboardRelease(int vkeycode)
{
	if (vkeycode > KEY_AMOUNT)
	{
		PrintConsole("Keycode not supported");
		vkeycode = KEY_AMOUNT;
	}
	m_Keys.set(vkeycode, false);
	Release(TranslateKeyboard(vkeycode));
}

bool InputManager::KeyboardIsPressing(int vkeycode)
{
	if (vkeycode > KEY_AMOUNT)
	{
		PrintConsole("Keycode not supported");
		vkeycode = KEY_AMOUNT;
	}
	return m_Keys[vkeycode];
}

bool InputManager::KeyboardIsToggled(int vkeycode, bool untoggle)
{
	if (vkeycode > KEY_AMOUNT)
	{
		PrintConsole("Keycode not supported");
		vkeycode = KEY_AMOUNT;
	}
	bool value = m_KeyToggles[vkeycode];
	if ( untoggle )
		m_KeyToggles.set(vkeycode, false);
	return value;
}

void InputManager::ReadInput(RAWINPUT rawInput)
{
	Release(BT_SCROLL_DOWN);
	Release(BT_SCROLL_UP);
	if ( rawInput.header.dwType == RIM_TYPEKEYBOARD )
	{
		USHORT vKey = rawInput.data.keyboard.VKey;
		UINT message = rawInput.data.keyboard.Message;

		if ( WM_KEYDOWN == message )
			KeyboardPress(vKey);
		else if ( WM_KEYUP == message )
			KeyboardRelease(vKey);
		else if ( WM_SYSKEYDOWN == message )
			KeyboardPress(vKey);
		else if ( WM_SYSKEYUP == message )
			KeyboardRelease(vKey);
	}
	else if ( rawInput.header.dwType == RIM_TYPEMOUSE )
	{
		int stuff = rawInput.data.mouse.usFlags;

		if ( rawInput.data.mouse.usFlags == MOUSE_MOVE_ABSOLUTE )
		{
			// Read Mock Message from winproc
			m_MousePos.x = (float) rawInput.data.mouse.lLastX;
			m_MousePos.y = (float) rawInput.data.mouse.lLastY;
		}

		else
		{
			m_MouseDelta.x = (float) rawInput.data.mouse.lLastX;
			m_MouseDelta.y = (float) rawInput.data.mouse.lLastY;

			if ( rawInput.data.mouse.usButtonFlags == RI_MOUSE_LEFT_BUTTON_DOWN )
				Press(BT_MOVE);
			else if ( rawInput.data.mouse.usButtonFlags == RI_MOUSE_LEFT_BUTTON_UP )
				Release(BT_MOVE);

			if ( rawInput.data.mouse.usButtonFlags == RI_MOUSE_RIGHT_BUTTON_DOWN )
				Press(BT_RECALL);
			else if ( rawInput.data.mouse.usButtonFlags == RI_MOUSE_RIGHT_BUTTON_UP )
				Release(BT_RECALL);

			if (rawInput.data.mouse.usButtonFlags == RI_MOUSE_WHEEL)
			{
				if ((short)rawInput.data.mouse.usButtonData > 0)
				{
					Press(BT_SCROLL_UP);
					Release(BT_SCROLL_DOWN);
				}
				else if ((short)rawInput.data.mouse.usButtonData < 0)
				{
					Press(BT_SCROLL_DOWN);
					Release(BT_SCROLL_UP);
				}
			}
		}
	}
}




