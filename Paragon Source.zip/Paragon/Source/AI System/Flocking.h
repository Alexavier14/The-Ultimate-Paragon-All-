#include "../Application/stdafx.h"

#define FLOCKING_H_
#ifdef FLOCKING_H_


using namespace DirectX;

class GameObject;
class TimeManager;

class Flocking
{
	float fAlignmentStrength, fCohesionStrength, fSeparationStrength,
		fFlockRadius;
	XMFLOAT3 AveragePosition;
	XMFLOAT3 AverageForward;
	std::vector<GameObject*> GeodeBoids;
	int FlockNumber;
public:

	Flocking(std::vector<GameObject*> GameObjGeodes);
	~Flocking();
	void Update(GameObject& GO);
	void CalAverages();
	XMVECTOR CalAlignmentAccel(GameObject& Gboid);
	XMVECTOR CalCohesionAccel(GameObject& Gboid);
	XMVECTOR CalSeparationAccel(GameObject& Gboid);
	void SetAlignmentStrength(float ALS) { fAlignmentStrength = ALS; };
	void SetCohesionStrength(float COS) { fCohesionStrength = COS; };
	void SetSeparationStrength(float SPS) { fSeparationStrength = SPS; };
	void SetFlockRadius(float FKR) { fFlockRadius = FKR; };
};

#endif