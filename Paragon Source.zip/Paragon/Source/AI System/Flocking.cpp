#include "../Application/stdafx.h"

#include "Flocking.h"
#include "../Object Manager/GameObject.h"
#include "../Object Manager/AIData.h"
#include "../Util/TimeManager.h"


Flocking::Flocking(std::vector<GameObject*> GameObjGeodes)
{
	GeodeBoids = GameObjGeodes;
	FlockNumber = GameObjGeodes.size();
}

Flocking::~Flocking()
{
}

void Flocking::Update(GameObject& GO)
{

	/*CalAverages();
	AverageForward = GO.GetObjectTranslation();

	for each(GameObject * BOID in GeodeBoids)
	{
		XMVECTOR accel;

		float x = BOID->GetAIData()->fVelocity.x;
		float y = BOID->GetAIData()->fVelocity.y;
		float z = BOID->GetAIData()->fVelocity.z;
		XMVECTOR vel = XMVectorSet(x, y, z, 1.0f);

		accel = CalAlignmentAccel(*BOID);
		accel += CalCohesionAccel(*BOID);
		accel += CalSeparationAccel(*BOID);
		accel *= BOID->GetAIData()->fMaxSpeed * (float)TimeManager::GetTimeDelta();

		vel += accel;

		if (*XMVector3Length(vel).m128_f32 > BOID->GetAIData()->fMaxSpeed)
		{
			vel = XMVector3Normalize(vel);
			vel *= BOID->GetAIData()->fMaxSpeed;
		}

		XMStoreFloat3(&BOID->GetAIData()->fVelocity, vel);
	}*/
	return;
}
void Flocking::CalAverages()
{
	/*AveragePosition = XMFLOAT3(0, 0, 0);
	AverageForward = XMFLOAT3(0, 0, 0);
	for each(GameObject* boid in GeodeBoids)
	{
		AveragePosition.x += boid->GetObjectTranslation().x;
		AveragePosition.y += boid->GetObjectTranslation().y;
		AveragePosition.z += boid->GetObjectTranslation().z;

		AverageForward.x += boid->GetAIData()->fVelocity.x;
		AverageForward.y += boid->GetAIData()->fVelocity.y;
		AverageForward.z += boid->GetAIData()->fVelocity.z;

	}


	float x = AveragePosition.x / FlockNumber;
	float y = AveragePosition.y / FlockNumber;
	float z = AveragePosition.z / FlockNumber;
	XMVECTOR AvgPos = XMVectorSet(x, y, z, 1);

	x = AverageForward.x / FlockNumber;
	y = AverageForward.y / FlockNumber;
	z = AverageForward.z / FlockNumber;
	XMVECTOR AvgForward = XMVectorSet(x, y, z, 1);

	XMStoreFloat3(&AveragePosition, AvgPos);
	XMStoreFloat3(&AverageForward, AvgForward);*/
	return;
}
//
//XMVECTOR Flocking::CalAlignmentAccel(GameObject& Gboid)
//{
//	//XMFLOAT3 finalFloat;
//
//	//float x = AverageForward.x / Gboid.GetAIData()->fMaxSpeed;
//	//float y = AverageForward.y / Gboid.GetAIData()->fMaxSpeed;
//	//float z = AverageForward.z / Gboid.GetAIData()->fMaxSpeed;
//
//	//XMVECTOR Accel = XMVectorSet(x, y, z, 1);
//	//float accelMag = sqrt(x * x + y * y + z * z);
//	//if (accelMag > 1)
//	//	Accel = XMVector3Normalize(Accel);
//	//XMStoreFloat3(&finalFloat, Accel * fAlignmentStrength);
//	return /*Accel **/ fAlignmentStrength;
//
//}
//
//XMVECTOR Flocking::CalCohesionAccel(GameObject& Gboid)
//{
//
//
//	//XMVECTOR AvgPos = XMVectorSet(AveragePosition.x, AveragePosition.y, AveragePosition.z, 1.0f);
//	//XMVECTOR GboidPos = XMVectorSet(Gboid.GetObjectTranslation().x, Gboid.GetObjectTranslation().y, Gboid.GetObjectTranslation().z, 1.0f);
//
//
//
//	//XMVECTOR Cohesion = AvgPos - GboidPos;
//	//XMVECTOR distanceV = XMVector3Length(Cohesion);
//	//float distance;
//	//XMStoreFloat(&distance, distanceV);
//	//Cohesion = XMVector3Normalize(Cohesion);
//
//	//if (distance < fFlockRadius)
//	//{
//	//	Cohesion *= distance / fFlockRadius;
//	//}
//
//	return Cohesion * fCohesionStrength;
//}
//
//XMVECTOR Flocking::CalSeparationAccel(GameObject& Gboid)
//{
//
//	//XMVECTOR sum = XMVECTOR();
//
//	//for each(GameObject* otherBoid in GeodeBoids)
//	//	//foreach(MovingObject otherBoid in Boids)
//	//{
//	//	XMVECTOR GboidPos = XMVectorSet(Gboid.GetObjectTranslation().x, Gboid.GetObjectTranslation().y, Gboid.GetObjectTranslation().z, 1);
//	//	XMVECTOR OtherBoidPos = XMVectorSet(otherBoid->GetObjectTranslation().x, otherBoid->GetObjectTranslation().y, otherBoid->GetObjectTranslation().z, 1);
//
//	//	XMVECTOR vector = GboidPos - OtherBoidPos;
//	//	XMVECTOR distanceV = XMVector3Length(vector);
//	//	float distance = *distanceV.m128_f32;
//
//
//	//	GboidPos = XMVectorSet(Gboid.GetAIData()->fSafeRadius, Gboid.GetAIData()->fSafeRadius, Gboid.GetAIData()->fSafeRadius, 1);
//	//	OtherBoidPos = XMVectorSet(otherBoid->GetAIData()->fSafeRadius, otherBoid->GetAIData()->fSafeRadius, otherBoid->GetAIData()->fSafeRadius, 1);
//	//	float safeDistance = *GboidPos.m128_f32 + *OtherBoidPos.m128_f32;
//
//	//	if (distance < safeDistance)
//	//	{
//	//		vector = XMVector3Normalize(vector);
//	//		distanceV = XMVectorSet((safeDistance - distance) / safeDistance, (safeDistance - distance) / safeDistance, (safeDistance - distance) / safeDistance, 1);
//	//		vector = XMVector3Dot(vector, distanceV);
//	//		sum += vector;
//	//	}
//	//}
//
//	//if (*XMVector3Length(sum).m128_f32 > 1.0f)
//	//	sum = XMVector3Normalize(sum);
//
//	return sum * fSeparationStrength;
//}
