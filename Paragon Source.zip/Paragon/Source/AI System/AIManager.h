#pragma once
#include "../Application/stdafx.h"
#include "../Util/Clock.h"
#include "../Object Manager/AIData.h"
class CoreFacade;

struct EnemyGroup
{
	int nGroupNum = 0;
	unsigned int nGroupSize = 0;
	std::vector<GameObject*>EnemyList;
};

class AIManager
{
private:
	float m_fLeaderTimer, m_fFollowerTimer;
	AIData::EnemyState m_LeaderState, m_FollowerState;
	int m_nCurrRoom, m_nNumRooms, m_nNumGroups;
	bool bNewLeader;
	CoreFacade* pCoreFacade;
	std::vector<EnemyGroup*> groupList;

	void FindNewLeader(int _groupNum);
	void ReactToLeader(GameObject* GO, GameObject* _leader);
	void LeaderBehavior(GameObject* GO);
	void RemoveEnemiesFromGroup(int _groupNum);
	GameObject* m_Leader;

public:
	AIManager(CoreFacade* pFacade);
	~AIManager();
	void Initialize(int _groups);
	void UpdateAI(void);

	void SetNumRooms(int _rooms){ m_nNumRooms = _rooms; }
	void SetCurrRoom(int _room){ m_nCurrRoom = _room; }
	void SetNumGroups(int _groups){ m_nNumGroups = _groups; }

	int GetNumRooms(void){ return m_nNumRooms; }
	int GetCurrRoom(void){ return m_nCurrRoom; }
	int GetNumGroups(void){ return m_nNumGroups; }
};

