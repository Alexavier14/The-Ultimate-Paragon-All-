
#include "../Application/stdafx.h"

#include "AISystem.h"
#include "GeodeBehavior.h"
#include "EnemyBehavior.h"

#include "../Object Manager/AnimComponent.h"
#include "../Object Manager/EventComponent.h"
#include "../Object Manager/AudioComponent.h"
#include "../Particle System/Emitter.h"
#include "../Application/CoreFacade.h"
#include "../Application/GameFacade.h"
#include "../Physics/Physics.h"
#include "../Physics/CollisionShape.h"
#include "../Util/TimeManager.h"
#include "../Util/Util.h"
#include "../Sound/SoundManager.h"
#include "../Sound/Wwise_IDs.h"
#include "../Object Manager/PointLightComponent.h"
#include "Flocking.h"
#include "AIManager.h"


using namespace Physics;

#define RESPAWN_TIMER	90.0f

//Helper Functions
float GetRespawnTimer(CoreFacade * p_mcfacade);

AISystem::AISystem(CoreFacade * p_mcfacade)
{
	this->p_mcfacade = p_mcfacade;
}
AISystem::~AISystem()
{
	Shutdown();
}
void AISystem::Initialize()
{
	ptRootSelector = nullptr;
	p_mcfacade->SetSelectedGeode(GS_NONE);
	m_fSendTimer = 0.0f;
	firstSent = bSwitchGeodeType = false;
	cGeodeB = new GeodeBehavior(p_mcfacade);
	cEnemyB = new EnemyBehavior(p_mcfacade);
}
void AISystem::Shutdown()
{
	//if (ptRootSelector != nullptr)
	//	DestroyTree();

	//delete m_pGeodeFlocking;
	if (cGeodeB != nullptr)
	{
		delete cGeodeB;
		cGeodeB = nullptr;
	}

	if (cEnemyB != nullptr)
	{
		delete cEnemyB;
		cEnemyB = nullptr;
	}
}
void AISystem::CreateTree()
{
	ptRootSelector = new TreeNode;
	ptRootSelector->eNodeBehavior = EnRoot;


	TreeNode * attackNode = new TreeNode;
	attackNode->eNodeBehavior = EnAttack;


	TreeNode * CrowdControlNode = new TreeNode;
	CrowdControlNode->eNodeBehavior = EnDebuff;

	//Build Tree
	ptRootSelector->ptNodeArray.push_back(attackNode);
	ptRootSelector->ptNodeArray.push_back(CrowdControlNode);
	nNumOfNodes += 3;
}
void AISystem::PostOrderTraversal(TreeNode& TrNode)
{
	for (int nChildrenIndex = 0; !TrNode.ptNodeArray.empty(); nChildrenIndex++)
	{
		PostOrderTraversal(*TrNode.ptNodeArray[nChildrenIndex]);

		TreeNode * deleteNode = TrNode.ptNodeArray[nChildrenIndex];
		delete deleteNode;
	}
	return;
}
void AISystem::DestroyTree()
{
	//Post-order traversal deletion
	while (ptRootSelector != nullptr)
	{
		PostOrderTraversal(*ptRootSelector);
		delete ptRootSelector;
		ptRootSelector = nullptr;
	}
}
void AISystem::UpdateTree(GameObject& GO)
{
	//Traverse tree and change behavior
}

ObjectType GetGeodeType(GeodeSelection selection)
{
	switch (selection)
	{
	case GS_RUBY:		return eRUBYGEODE;
	case GS_SAPPHIRE:	return eSAPPHIREGEODE;
	case GS_DIAMOND:	return eDIAMONDGEODE;
	}
	return ObjectType(-1);
}
//Gets the next/prev available geode selection
GeodeSelection AISystem::GetAvailableSelection(GeodeSelection selection, bool next)
{
	for (size_t i = 0;; i++)
	{
		if (next)
			selection = (GeodeSelection)((selection + 1) % 3);
		else
			selection = (GeodeSelection)((selection - 1) % 3);

		int geodeCount = m_GeodesFollowing[selection];
		if (geodeCount > 0)
			return selection;
		if (i >= 3)
			return GS_NONE;
	}
}

void AISystem::UpdateGeodes()
{
	//Get all of the geodes
	vector<GameObject*> Geodes = p_mcfacade->m_ObjectManager->GetGeodes();

	//Get the Player
	GameObject* Player = p_mcfacade->m_ObjectManager->GetPlayer();

	m_fSendTimer += TimeManager::GetTimeDelta();



	//Input Checks
	PlayerComponent* pPlayerComp = Player->GetPlayerComponent();
	GeodeSelection selectedGeode = p_mcfacade->GetSelectedGeode();

	if (p_mcfacade->IsToggled(ButtonID::BT_SCROLL_UP))
		selectedGeode = GetAvailableSelection(selectedGeode, true);

	if (p_mcfacade->IsToggled(ButtonID::BT_SCROLL_DOWN))
		selectedGeode = GetAvailableSelection(selectedGeode, false);

	GeodeSelection keySelection = GS_NONE;
	if (p_mcfacade->IsToggled(ButtonID::BT_RUBY) && m_GeodesFollowing[GS_RUBY] > 0)
	{
		selectedGeode = keySelection = GS_RUBY;
		p_mcfacade->SetSelectedGeode(selectedGeode);
	}
	if (p_mcfacade->IsToggled(ButtonID::BT_SAPP) && m_GeodesFollowing[GS_SAPPHIRE] > 0)
	{
		selectedGeode = keySelection = GS_SAPPHIRE;
		p_mcfacade->SetSelectedGeode(selectedGeode);
	}
	if (p_mcfacade->IsToggled(ButtonID::BT_DIAM) && m_GeodesFollowing[GS_DIAMOND] > 0)
	{
		selectedGeode = keySelection = GS_DIAMOND;
		p_mcfacade->SetSelectedGeode(selectedGeode);
	}


	if (selectedGeode == GS_NONE || m_GeodesFollowing[selectedGeode] == 0)
		selectedGeode = GetAvailableSelection(selectedGeode, true);



	// Get next available geode of the selected type and update the count for followers
	ObjectType selectedType = GetGeodeType(selectedGeode);
	GameObject *pNextGeode = nullptr;
	float distanceToClosest = FLT_MAX;
	ZeroMemory(m_GeodesFollowing, sizeof(m_GeodesFollowing)); // reset counters
	XMVECTOR PlayerPos = Player->GetObjectTranslationVec();
	for (unsigned int index = 0; index < Geodes.size(); index++)
	{
		GameObject* pGeode = Geodes[index];
		AIData* pGeodeAI = pGeode->GetAIData();
		AIData::GeodeState geodeState = pGeodeAI->geodeState;

		if (!pGeode->GetActive()) continue;
		if (geodeState == AIData::GeDeath) continue;
		if (geodeState != AIData::GeFollowing) continue;
		if (geodeState == AIData::GeTrap) continue;
		switch (pGeode->GetType())
		{
		case eRUBYGEODE:		++m_GeodesFollowing[GS_RUBY];		break;
		case eSAPPHIREGEODE:	++m_GeodesFollowing[GS_SAPPHIRE];	break;
		case eDIAMONDGEODE:		++m_GeodesFollowing[GS_DIAMOND];	break;
		}

		if (pGeode->GetType() == selectedType)
		{
			XMVECTOR GeodePos = pGeode->GetObjectTranslationVec();
			float distance = XMCVector3Length(PlayerPos - GeodePos);
			if (distance < distanceToClosest)
			{
				distanceToClosest = distance;
				pNextGeode = pGeode;
			}
		}

	}
	//PrintConsole(FloatToString( (float)m_GeodesFollowing[GS_RUBY] ) + ", "	+
	//			 FloatToString( (float)m_GeodesFollowing[GS_SAPPHIRE] ) + ", "	+	
	//			 FloatToString( (float)m_GeodesFollowing[GS_DIAMOND] ) );	


	static bool directInputMode = true;
	if (p_mcfacade->IsToggledKey(VK_F7))
		directInputMode = !directInputMode;

	bool sendInput = p_mcfacade->IsToggled(BT_SEND) || directInputMode && keySelection != GS_NONE;

	if (sendInput && selectedGeode != GS_NONE && pNextGeode != nullptr)
	{
		//p_mcfacade->GetObjectManager()->GetPlayer()->GetPlayerComponent()->
		m_fSendTimer = 0.0f;

		//p_mcfacade->GetObjectManager()->GetPlayer()->GetPlayerComponent()->SetDestination(XMFLOAT2(p_mcfacade->GetObjectManager()->GetPlayer()->GetObjectTranslation().x, p_mcfacade->GetObjectManager()->GetPlayer()->GetObjectTranslation().z));
		//p_mcfacade->GetObjectManager()->GetPlayer()->GetPhysicsComponent()->SetVelocity(XMFLOAT2(0.0f, 0.0f));
		//p_mcfacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_FX_2D_BEEP);
		//switch (selectedType)
		//{
		//case ObjectType::eDIAMONDGEODE:
		//{
		//	p_mcfacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_ADR_GEODE_DIAMOND_SEND);
		//	break;
		//}
		//case ObjectType::eRUBYGEODE:
		//{
		//	p_mcfacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_ADR_GEODE_RUBY_SEND);
		//	break;
		//}
		//case ObjectType::eSAPPHIREGEODE:
		//{
		//	p_mcfacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_ADR_GEODE_SAFFIRE_SEND);
		//	break;
		//}
		//}

		Player->GetAnimComponent()->SetAnimName(PLAYER_SEND, false);
		// TODO: SendAll logic (?)

		//pNextGeode->GetAIData()->fTargetPos = p_mcfacade->m_ObjectManager->GetReticle()->GetObjectTranslation();

		XMVECTOR PlayerPos = XMCVector3SwizzleXZ( p_mcfacade->m_ObjectManager->GetPlayer()->GetObjectTranslationVec() );
		XMVECTOR ReticlePos = XMCVector3SwizzleXZ( p_mcfacade->m_ObjectManager->GetReticle()->GetObjectTranslationVec() );
		pNextGeode->GetAIData()->fSendDistance = XMCVector2Length(ReticlePos - PlayerPos);

		cGeodeB->SwitchStateGeode(*pNextGeode, AIData::GeSend);
	}


	//}


	//Check to see if we are recalling
	bool RecallSappButtonPressed = false;
	bool RecallRubyButtonPressed = false;
	bool RecallDiamButtonPressed = false;
	bool RecallAllPressed = false;
	for (unsigned int index = 0; index < Geodes.size(); index++)
	{
		//Check inputs - This is because the input system does not store input each frame but in real time ><
		//Make sure the geode is active
		if (Geodes[index]->GetActive() == false || Geodes[index]->GetAIData()->geodeState == AIData::GeDeath
			|| Geodes[index]->GetAIData()->geodeState == AIData::GeTrap)
			continue;

		//Check to see if the geode is following the player
		if (Geodes[index]->GetAIData()->geodeState != AIData::GeFollowing)
		{
			if (p_mcfacade->IsPressing(BT_RECALL))
			{
				if (p_mcfacade->m_ObjectManager->GetReticle()->GetPhysicsComponent()->GetCollisionShape(SU_SCANNER)->Collides(Geodes[index]->GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE)))
				{
					Geodes[index]->GetAIData()->fTargetPos = p_mcfacade->m_ObjectManager->GetPlayer()->GetObjectTranslation();
					cGeodeB->SwitchStateGeode(*Geodes[index], AIData::GeRecall);
				}
				Player->GetAnimComponent()->SetAnimName(PLAYER_RECALL, false);
			}
		}
	}

	//Update Geode States
	for (unsigned int index = 0; index < Geodes.size(); index++)
	{
		XMMATRIX TargetLocation = XMLoadFloat4x4(&Geodes[index]->GetWorldTransform());
		XMVECTOR ForwardVec = XMVector3Normalize(TargetLocation.r[2]);
		ForwardVec = XMCVector2SwizzleXZ(ForwardVec);

		if (Geodes[index]->GetActive())
		{
			cGeodeB->GeodeStates(*Geodes[index]);
			CallStates(*Geodes[index]);
		}
	}
}
void AISystem::UpdateEnemies()
{
	//Get all current Enemies
	vector<GameObject*> Enemies = p_mcfacade->m_ObjectManager->GetAllEnemies();
	
	for (unsigned int index = 0; index < Enemies.size(); index++)
	{
		if (Enemies[index]->GetActive() == false)
			continue;
		cEnemyB->EnemyUpdate(*Enemies[index]);
		//Update Enemey States
		cEnemyB->EnemyStates(*Enemies[index]);
		CallStates(*Enemies[index]);
	}
}

ObjectType GetGeodeTypeFromNode(ObjectType node)
{
	switch (node)
	{
	case eRUBYNODE:		return eRUBYGEODE;
	case eSAPPHIRENODE: return eSAPPHIREGEODE;
	case eDIAMONDNODE:	return eDIAMONDGEODE;
	}
	return ObjectType(-1);
}

void AISystem::UpdateNodesAndGems()
{
#pragma region Node Update
	//Figure out the player's performance and set the respawn timer to be this.
	static float RESPAWN = RESPAWN_TIMER;
	if ((int)this->p_mcfacade->GameTime % 60 == 0 && this->p_mcfacade->GameTime > 0.0f)
		RESPAWN = GetRespawnTimer(this->p_mcfacade);

	vector<GameObject*> &Nodes = p_mcfacade->m_ObjectManager->GetMiningNodes();
	for (size_t i = 0; i < Nodes.size(); i++)
	{
		GameObject* pNode = Nodes[i];
		AIData* pNodeAI = pNode->GetAIData();
		PhysicsComponent* pNodePhysics = pNode->GetPhysicsComponent();

		if (pNodeAI->fActionCooldownD > 0.0f)
		{
			pNodeAI->fActionCooldownD -= TimeManager::GetTimeDelta();
		}
		else
		{
			pNode->GetChildEmitterComponent(eNODE_MINED_DUST)->SetSpawning(false);
		}


		//Node Feedback and Respawn Timer
		if (!pNode->GetActive() /*&& pNodeAI->bIsMined*/)
		{
			pNodeAI->fActionCooldownC += TimeManager::GetTimeDelta();
			if (pNodeAI->fActionCooldownC >= RESPAWN)
			{
				pNode->GetChildEmitterComponent(eNODE_SPARKS_EMITTER)->SetSpawning(true);
				pNode->SetActive(true);
				pNode->GetChildPointLight(0)->SetActive(true);
				pNodeAI->health = 3;
				pNodeAI->fActionCooldownC = 0.0f;
				pNode->SetObjectTranslation(pNodeAI->fTargetPos);
				pNodePhysics->ActivateCollision();
				pNodeAI->bIsMined = false;
			}
			continue;
		}


		//if (pNodeAI->health == 3)
		//	pNode->SetScale(1.0f);
		//if (pNodeAI->health == 2)
		//	pNode->SetScale(0.70f);
		//if (pNodeAI->health == 1)
		//	pNode->SetScale(0.50f);

		if (pNodeAI->health == 0 && pNodeAI->bIsMined == false)
		{
			pNodeAI->fActionCooldownC = 0.0f;
			pNodeAI->bIsMined = true;
			pNode->GetChildEmitterComponent(eNODE_MINED_DUST)->SetSpawning(true);
			pNodeAI->fActionCooldownD = 0.5f;
			//pNode->SetActive(false);
		}

		//Node Feedback and Respawn Timer
		if (pNodeAI->fActionCooldown > 0.0f) //See if the node is shaking
		{
			//Make the Mining Node sink(bake) 'n' shake
			pNodeAI->fActionCooldownB += TimeManager::GetTimeDelta() * 2.0f;

			float intensity = 0.25f;
			float cos_value = cosf(pNodeAI->fActionCooldownB * XM_2PI) * intensity;
			float sin_value = sinf(pNodeAI->fActionCooldownB * XM_2PI) * intensity;

			pNode->SetObjectTranslation(pNodeAI->fTargetPos.x + cos_value,
				pNode->GetObjectTranslation().y,
				pNodeAI->fTargetPos.z + sin_value);

			pNodeAI->fActionCooldown -= TimeManager::GetTimeDelta();
		}

		PlayerComponent* pPlayerComp = p_mcfacade->GetObjectManager()->GetPlayer()->GetPlayerComponent();
		CollisionShape* pNodeBounds = pNodePhysics->GetCollisionShape(SU_BOUNDING_SHAPE);
		CollisionShape* pReticleBounds = p_mcfacade->GetObjectManager()->GetReticle()->GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE);
		ObjectType geodeType = GetGeodeTypeFromNode(pNode->GetType());
		if (pNodeBounds->Collides(pReticleBounds) && pPlayerComp->GetGeodeCount(geodeType) > 0)
			pNode->GetChildEffectComponent(DEFAULT_EFFECT)->isEnabled = true;
		else
			pNode->GetChildEffectComponent(DEFAULT_EFFECT)->isEnabled = false;
	}
#pragma endregion

#pragma region Gem Update
	vector<GameObject*> &Gems = p_mcfacade->m_ObjectManager->GetGems();
	for (unsigned int i = 0; i < Gems.size(); i++)
	{
		GameObject& currentGem = *Gems[i];
		AIData& gemData = *currentGem.GetAIData();
		if (!currentGem.GetActive()) continue;

		if (gemData.fActionCooldownB > 0.0f && currentGem.GetType() != ePARAGON)
		{
			currentGem.GetChildEmitterComponent(0)->SetSpawning(true);
			gemData.fActionCooldownB -= TimeManager::GetTimeDelta();
			float t = gemData.m_fAirTime;
			XMFLOAT3 F;

			//F.x = (gemData.fTempVel.x) * t + gemData.fJumpingPoint.x;
			//F.z = (gemData.fTempVel.y) * t + gemData.fJumpingPoint.z;
			F.y = ((0.5f * -9.8f) * (t * t)) + (gemData.fTempVel.y * t) + gemData.fJumpingPoint.y;
			F.x = currentGem.GetObjectTranslation().x;
			F.z = currentGem.GetObjectTranslation().z;



			if (F.y <= 0.0f || gemData.fActionCooldownB <= 0.0f)// && t > 0.0001f)
			{
				currentGem.GetPhysicsComponent()->SetVelocity(XMFLOAT2(0.0f, 0.0f));
				currentGem.GetPhysicsComponent()->SetForwardVelocity(0.0f);
				currentGem.SetObjectTranslation(F.x, 0.0f, F.z);
				gemData.fTargetPos = currentGem.GetObjectTranslation();
				gemData.m_fAirTime = 0.0f;
				gemData.cAIClockTimer.Start();
			}

			else
			{
				currentGem.GetPhysicsComponent()->SetVelocity(XMFLOAT2(gemData.fTempVel.x, gemData.fTempVel.z));
				currentGem.SetObjectTranslation(F);
			}

			gemData.m_fAirTime += TimeManager::GetTimeDelta();
		}
		else
		{
			if (currentGem.GetType() != ePARAGON)
				currentGem.GetChildPointLight(0)->SetActive(true);
			if ((float)gemData.cAIClockTimer.Watch() >= 20.0f && !gemData.bActionDone) 
			{
				currentGem.GetChildPointLight(0)->SetActive(false);
				currentGem.SetActive(false);
				currentGem.GetChildEmitterComponent(0)->SetSpawning(false);
			}

			gemData.fActionCooldown += TimeManager::GetTimeDelta() * 2;

			float yOffset = sinf(gemData.fActionCooldown) + 1.0f;
			XMFLOAT3 position(currentGem.GetObjectTranslation().x, gemData.fTargetPos.y + yOffset, currentGem.GetObjectTranslation().z);

			XMMATRIX rotation = XMMatrixRotationY(TimeManager::GetTimeDelta());
			XMMATRIX current = currentGem.GetWorldTransformMat();
			currentGem.SetObjectTransform(rotation*current);

			currentGem.SetObjectTranslation(position);
		}

		if (currentGem.GetType() == ePARAGON)
		{
			int collective_health = 0;
			vector<GameObject*> holders = p_mcfacade->GetObjectManager()->GetParagonHolders();

			for (unsigned int i = 0; i < holders.size(); i++)
				collective_health += holders[i]->GetAIData()->health;

			currentGem.GetChildEffectComponent(eWORM_HEALTHBAR_EFFECT)->SetPosition(XMCStoreFloat4(currentGem.GetObjectTranslationVec() + XMCLoadFloat4(0.0f, 15.0f, 0.0f, 0.0f)));
			currentGem.GetChildEffectComponent(eWORM_HEALTHBAR_EFFECT)->ToggleEffect(true);
			currentGem.GetChildEffectComponent(eWORM_HEALTHBAR_EFFECT)->Size = XMFLOAT2(2.f * ((float)collective_health / 75.f), 1.25f);
		}
	}
#pragma endregion
}

void AISystem::Update()
{
	if (p_mcfacade->m_ObjectManager->GetPlayer() != nullptr
		&& p_mcfacade->m_ObjectManager->GetPlayer()->GetPlayerComponent()->GetHealth() > 0)
		UpdateGeodes();
	UpdateEnemies();
	UpdateNodesAndGems();

	//Update the falling rocks
	vector<GameObject*> AllTheRocks = p_mcfacade->m_ObjectManager->GetFallRocks();
	for (size_t RockIndex = 0; RockIndex < AllTheRocks.size(); RockIndex++)
	{
		if (AllTheRocks[RockIndex]->GetTrapComponent()->GetToMove())
			UpdateTraps(*AllTheRocks[RockIndex]);
	}

	//Update the holes
	vector<GameObject*> AllTheHoles = p_mcfacade->m_ObjectManager->GetWormTraps();
	for (size_t TrapIndex = 0; TrapIndex < AllTheHoles.size(); TrapIndex++)
	{
		if (AllTheHoles[TrapIndex]->GetTrapComponent()->GetEnabled())
			UpdateTraps(*AllTheHoles[TrapIndex]);
	}

	//Update the Paragon
	vector<GameObject*> AllTargets = p_mcfacade->m_ObjectManager->GetGeodeTargets();
	int CheckYourself = 0;
	for (size_t TargetIndex = 0; TargetIndex < AllTargets.size(); TargetIndex++)
	{
		if ((AllTargets[TargetIndex]->GetType() == eSAPPHIREHOLDER ||
			AllTargets[TargetIndex]->GetType() == eRUBYHOLDER ||
			AllTargets[TargetIndex]->GetType() == eDIAMONDHOLDER)
			&& AllTargets[TargetIndex]->GetAIData()->health <= 0)
			CheckYourself++;
	}

	if (CheckYourself >= 3)
	{
		XMCClamp(p_mcfacade->m_ObjectManager->GetParagon()->GetAIData()->fActionCooldownB, 0.4f);
		if (p_mcfacade->m_ObjectManager->GetParagon()->GetAIData()->fActionCooldownB == 0.4f)
		{
			p_mcfacade->m_ObjectManager->GetParagon()->GetChildEmitterComponent(0)->SetSpawning(false);
			p_mcfacade->m_ObjectManager->GetParagon()->GetChildEmitterComponent(1)->SetSpawning(false);
			p_mcfacade->m_ObjectManager->GetParagon()->GetChildEmitterComponent(2)->SetSpawning(false);
		}
		p_mcfacade->m_ObjectManager->GetParagon()->SetScale(p_mcfacade->m_ObjectManager->GetParagon()->GetAIData()->fActionCooldownB);
		p_mcfacade->m_ObjectManager->GetParagon()->GetAIData()->fActionCooldownB -= TimeManager::GetTimeDelta();		
	}

}

void AISystem::SteeringBehavior(int nWaypointX, int nWaypointY, GameObject& GO)
{
	//Don't forget to call object avoidance!
	/*GO.TURNTO();
	PHY.OBJAVOID();*/

	PhysicsComponent * physicsEnemy = GO.GetPhysicsComponent();

	XMFLOAT2 objFloat;
	XMMATRIX GOhere = XMLoadFloat4x4(&GO.GetWorldTransform());
	XMVECTOR ObjectSpeed = GOhere.r[2] * 5.0f;
	XMVectorGetZPtr(&objFloat.y, ObjectSpeed);
	XMVectorGetXPtr(&objFloat.x, ObjectSpeed);

}
void AISystem::CallStates(GameObject& GO)
{
	switch (GO.GetType())
	{
	case eSPIDER:
	case eGOLEM:
	case eWORM:
	{
		AIData::GeodeState newGeodeState = GO.GetAIData()->geodeState;


		AIData::EnemyState EnemyCurrentState = GO.GetAIData()->enemyState;

		vector<GameObject*> Targets = GO.GetAIData()->AOETargets;
		for (size_t i = 0; i < Targets.size(); i++)
		{
			GameObject* pGeode = Targets[i];

			switch (newGeodeState) // Safeguard check, should be unnecessary
			{
			case AIData::GeFear:
				break;
			case AIData::GeStun:
				break;
			case AIData::GeKnockback:
				Targets[i]->GetAIData()->ObjTarget = &GO;
				break;
			default:
				continue;
			}
			if (newGeodeState == AIData::GeAttack || GO.GetAIData()->bEnemySpecialA) //bEnemySpecialA Lets the system know that this effect has already happened once by the enemy
				break;
			switch (Targets[i]->GetType())
			{
			case eRUBYGEODE:
			case eSAPPHIREGEODE:
			case eDIAMONDGEODE:
				cGeodeB->SwitchStateGeode(*pGeode, newGeodeState);
			}
		}

		//State to keep the enemies from continously debuffing the geodes when the action has already been done.
		switch (GO.GetType())
		{
		case eSPIDER:
			if (!GO.GetAIData()->bEnemySpecialA && AIData::GeFear == newGeodeState)
				GO.GetAIData()->bEnemySpecialA = true;
			break;
		case eGOLEM:
			//if (!GO.GetAIData()->bEnemySpecialA && AIData::GeStun == newGeodeState)
			//	GO.GetAIData()->bEnemySpecialA = true;
			//break;
		case eWORM:
			//if (!GO.GetAIData()->bEnemySpecialA && AIData::GeKnockback == newGeodeState)
			//	GO.GetAIData()->bEnemySpecialA = true;
			//break;
		default:
			break;
		}

	}
	}

}

void AISystem::UpdateTraps(GameObject &GO)
{
	vector<GameObject*> GeodeTargets = p_mcfacade->m_ObjectManager->GetGeodes();
	GameObject& player = *p_mcfacade->m_ObjectManager->GetPlayer();
	TrapComponent& trap = *GO.GetTrapComponent();

#pragma region Golem Trap Update

	if (trap.GetParent()->GetType() == eGOLEM)
	{
		Telegraph* pAttackTelegraph = GO.GetChildTelegraphComponent(eGOLEM_ATTACK_TELEGRAPH);


		if (trap.GetTimeTillAct() > 0.0f)
		{
			trap.SetTimeTillAct(trap.GetTimeTillAct() - TimeManager::GetTimeDelta() * 1.5f);
			return;
		}

		GO.SetActive(true);
		trap.SetEnabled(true);
		pAttackTelegraph->SetEnabled(true);
		pAttackTelegraph->Update();

		//Warn all geodes the rocks are falling (give warning color)
		XMVECTOR WarningColor = XMCLoadFloat4(0.1f, 0.1f, 0.1f, 1.0f); // Black
		for (unsigned int GeodeIndex = 0; GeodeIndex < GeodeTargets.size(); GeodeIndex++)
		{
			if (GeodeTargets[GeodeIndex]->GetActive()
				&& GO.GetPhysicsComponent()->GetCollisionShape(SU_SCANNER)
				->Collides(GeodeTargets[GeodeIndex]->GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE))
				&& GeodeTargets[GeodeIndex]->GetReactionTime() <= 0.0f)
			{
				GeodeTargets[GeodeIndex]->SetObjectColor(WarningColor);
				GeodeTargets[GeodeIndex]->SetReactionTime(0.333f);
			}
		}


		//Move down or stop moving?
		if (GO.GetObjectTranslation().y <= 2.0f)
			trap.SetToMove(false);
		else
			GO.SetObjectTranslation(GO.GetObjectTranslation().x, GO.GetObjectTranslation().y - TimeManager::GetTimeDelta() * 15.0f, GO.GetObjectTranslation().z);


		//Impacting the ground?
		if (trap.GetToMove() == false)
		{
			//p_mcfacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_SFX_ROCK_LARGE);
			GO.GetAudioComponent()->PlayAudioFollow(PLAY_SFX_ROCK_LARGE);
			//Hits the geode per rock
			for (unsigned int GeodeIndex = 0; GeodeIndex < GeodeTargets.size(); GeodeIndex++)
			{
				if (GeodeTargets[GeodeIndex]->GetActive()
					&& GO.GetPhysicsComponent()->GetCollisionShape(SU_SCANNER)
					->Collides(GeodeTargets[GeodeIndex]->GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE)))
				{
					GeodeTargets[GeodeIndex]->TakeDamage(1);
				}
			}


			//Hits the player per rock
			if (GO.GetPhysicsComponent()->GetCollisionShape(SU_SCANNER)
				->Collides(player.GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE)))
			{
				player.GetPlayerComponent()->HitPlayer(p_mcfacade, 1);
				if (player.GetPlayerComponent()->GetHealth() > 0)
					player.GetAnimComponent()->SetAnimName(PLAYER_HIT, false);
			}

			//trap.SetEnabled(false);
		}


	}
#pragma endregion

#pragma region Worm Trap Update

	else if (trap.GetParent()->GetType() == eWORM && trap.GetTimerEnabled())
	{
		AIData& trap_data = *GO.GetAIData();
		Circle& trap_shape = *dynamic_cast<Circle*>(GO.GetPhysicsComponent()->GetCollisionShape(SU_SCANNER));

		if (trap_shape.IsActive())
		//Find what geodes are falling in.
		for (size_t GeodeIndex = 0; GeodeIndex < GeodeTargets.size(); GeodeIndex++)
		{
			//If the the geode is falling in, let it know that it is falling in.
			if (trap_shape.IsActive() && GeodeTargets[GeodeIndex]->GetActive() && GeodeTargets[GeodeIndex]->GetAIData()->geodeState != AIData::GeDeath
				&& trap_data.m_nAtkNum < 5 && GeodeTargets[GeodeIndex]->GetAIData()->geodeState != AIData::GeTrap
				&& GeodeTargets[GeodeIndex]->GetAIData()->geodeState != AIData::GeKnockback
				&& trap_shape.Collides(GeodeTargets[GeodeIndex]->GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE)))
			{
				GeodeTargets[GeodeIndex]->GetAIData()->geodeState = AIData::GeTrap;
				GeodeTargets[GeodeIndex]->GetAIData()->bEnemySpecialA = true;
				GeodeTargets[GeodeIndex]->GetAIData()->ObjTarget = &GO;
				GeodeTargets[GeodeIndex]->GetPhysicsComponent()->DeactivateCollision();
				trap_data.m_nAtkNum++;
				trap_data.fActionCooldown = 6.0f;
			}
		}

		//See if the player was stupid enough to fall in. Tehe :D
		if (trap_shape.IsActive() && trap_shape.Collides(p_mcfacade->m_ObjectManager->GetPlayer()->GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE)))
		{
			XMVECTOR movePlayer = XMCLoadFloat3(0, 5.0f, 0);
			if (!trap_data.bEnemySpecialA)
			{
				trap_data.bEnemySpecialA = true;
				trap_data.fActionCooldownB = 0.0f;
				player.GetPlayerComponent()->StopPlayer(true, 1.5f);
				player.GetAnimComponent()->SetAnimName(PLAYER_HIT, false);
				player.GetAudioComponent()->PlayAudioFollow(PLAY_ADR_BALIN_HURT);
				player.GetAnimComponent()->SetAnimSpeed(0.75f);
				//p_mcfacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_ADR_BALIN_HURT);
				trap_data.fActionCooldownB = 8.0f;
			}
		}

		if (trap_data.fActionCooldown <= 0.0f && trap_data.m_nAtkNum > 0)
		{
			trap_data.m_nAtkNum--;
			trap_data.fActionCooldown = 6.0f;
		}
		if (trap_data.fActionCooldownB <= 0.0f)
			trap_data.bEnemySpecialA = false;

		if (trap_data.fActionCooldown > 0.0f)
			trap_data.fActionCooldown -= TimeManager::GetTimeDelta();
		if (trap_data.fActionCooldownB > 0.0f)
			trap_data.fActionCooldownB -= TimeManager::GetTimeDelta();


		if (trap.GetTimer() >= 25.0f && trap_data.bEnemySpecialB == false)
		{
			GO.GetPhysicsComponent()->DeactivateCollision();
			GO.GetChildEmitterComponent(eWORM_TRAIL1_EMITTER)->SetSpawnTimer(5.0f);
			GO.GetChildEmitterComponent(eWORM_TRAIL2_EMITTER)->SetSpawnTimer(5.0f);
			trap_data.fActionCooldownC = 1.0f;
			trap_data.bEnemySpecialB = true;
		}
		else if (trap_data.bEnemySpecialB)
		{
			trap_data.fActionCooldownC -= TimeManager::GetTimeDelta() * 0.15f;
			GO.SetScale(trap_data.fActionCooldownC);
			if (trap_data.fActionCooldownC < 0.1f)
			{
				GO.SetActive(false);
				GO.GetTrapComponent()->SetEnabled(false);
			}
		}

	}

#pragma endregion

}

float GetRespawnTimer(CoreFacade * p_mcfacade)
{
#define Y_OFFSET 1.0f
#define X_SHIFT -1.0f
#define MAX_VALUE 1.0f
#define MIN_VALUE 0.16666666666f

	PlayerComponent * pPlayer = p_mcfacade->GetObjectManager()->GetPlayer()->GetPlayerComponent();
	float totalGems = float(pPlayer->GetGemCount(ObjectType::eDIAMONDGEM) + pPlayer->GetGemCount(ObjectType::eRUBYGEM) + pPlayer->GetGemCount(ObjectType::eSAPPHIREGEM));
	float totalGeodes = float(pPlayer->GetGeodeCount(ObjectType::eDIAMONDGEODE) + pPlayer->GetGeodeCount(ObjectType::eRUBYGEODE) + pPlayer->GetGeodeCount(ObjectType::eSAPPHIREGEODE));
	float time = p_mcfacade->GameTime;
	float x_function = 0.0f;
	float result_time = 0.0f, result_totalGG = 0.0f;

	//Solving respawn time based on time left in level
	{
		//Solve for g(x) = x + X_SHIFT
		// x = time
		x_function = time;
		if (x_function <= 0.0f)
			x_function = EPSILON;

		//Solve for the ratio of time.
		//result_time = (2.0f/1215.0f) * x_function + (135.0f/1215.0f);
		result_time = (1.0f / 450.0f) * x_function + (1.0f / 15.0f);
	}

	//Solving respawn time based on sum of Geodes and Gems
	{
		//Solve for g(x) = x + X_SHIFT
		// x = Gems + Geodes
		x_function = totalGems + totalGeodes;
		if (x_function <= 0.0f)
			x_function = EPSILON;

		//Solve for the ratio of time.
		//result_totalGG = (2.0f/87.0f) * x_function + (27.0f/87.0f);
		result_totalGG = (1.0f / 30.0f) * x_function;
	}

	//Clamping values
	XMCClamp(result_time, MIN_VALUE, MAX_VALUE);
	XMCClamp(result_totalGG, MIN_VALUE, MAX_VALUE);

	XMVECTOR left = XMLoadFloat(&result_time);
	XMVECTOR right = XMLoadFloat(&result_totalGG);

	float percent_time = time / 540.0f;
	float final_result = XMVectorGetX(XMVectorLerp(right, left, percent_time));


	//float final_result = max(result_time, result_totalGG);

	return final_result * RESPAWN_TIMER;
}
