#include "../Application/stdafx.h"

#include "../Object Manager/AIData.h"

#ifndef AISYSTEM_H_
#define AISYSTEM_H_


class GameObject;
class CoreFacade;
class Flocking;
class PhysicsComponent;
class TimeManager;
class GeodeBehavior;
class EnemyBehavior;
class AIManager;

enum GeodeSelection;

#define MAXNumNodeCHILDREN 5

using namespace DirectX;
class AISystem
{

	GeodeBehavior * cGeodeB;
	EnemyBehavior * cEnemyB;
	enum eBehaviorState {EnRoot, EnAttack, EnDebuff, EnPatrol, EnTrap};
	struct TreeNode
	{
		std::vector<TreeNode *> ptNodeArray;				//Dynamically allocate as many nodes as needed in array
		eBehaviorState eNodeBehavior;
	};

	void PostOrderTraversal(TreeNode& TrNode);

	//Update Object
	void UpdateGeodes();
	void UpdateEnemies();
	void UpdateNodesAndGems();
	void UpdateTraps(GameObject &GO);

	float m_fSendTimer;

	bool firstSent, bSwitchGeodeType;
	int m_nLastPressed;
	UINT m_GeodesFollowing[3];
	AIManager* pAIMan;

	GeodeSelection GetAvailableSelection(GeodeSelection selection, bool next = true);


public:
	TreeNode* ptRootSelector;
	int nNumOfNodes;
	Flocking * m_pGeodeFlocking;
	CoreFacade * p_mcfacade;
	AISystem(CoreFacade * p_mcfacade);
	~AISystem();
	void Initialize();
	void Shutdown();
	void CreateTree();
	void DestroyTree();
	void UpdateTree(GameObject& GO);
	//void Pathfind(int nWaypointX, int nWaypointY, GameObject& GO);
	//void GeodeFlocking(GameObject& GO);
	void Update();
	void SteeringBehavior(int nWaypointX, int nWaypointY, GameObject& GO);
	void CallStates(GameObject& GO);
};

#endif

