#include "../Application/stdafx.h"
#include "AIManager.h"
#include "../Object Manager/AIData.h"
#include "../Application/CoreFacade.h"
#include "../Object Manager/GameObject.h"
#include "EnemyBehavior.h"

AIManager::AIManager(CoreFacade* pFacade) :
m_fFollowerTimer(4.0f),
m_fLeaderTimer(4.0f),
m_nCurrRoom(0),
m_nNumRooms(0),
bNewLeader(false)
{
	pCoreFacade = pFacade;
	m_Leader = nullptr;
}

AIManager::~AIManager()
{
	
}

void AIManager::Initialize(int _groups)
{
	
	m_nNumGroups = _groups;
	std::vector<GameObject*> enemyList = pCoreFacade->GetObjectManager()->GetAllEnemies();

	if (m_nNumGroups > 0)
	{
		for (unsigned int gIndex = 0; gIndex <= (unsigned int)m_nNumGroups; gIndex++)
		{
			
			std::vector<GameObject*> tempList;
			for (unsigned int eIndex = 0; eIndex < enemyList.size(); eIndex++)
			{
				if (enemyList[eIndex]->GetAIData()->nEnemyGroup == 1 && gIndex == 1)
				{
					tempList.push_back(enemyList[eIndex]);
				}
			}
			
			if (tempList.size() > 0)
			{
				EnemyGroup* tempGroup = new EnemyGroup();
				tempGroup->nGroupNum = gIndex;
				tempGroup->nGroupSize = tempGroup->EnemyList.size();
				tempGroup->EnemyList = tempList;
				groupList.push_back(tempGroup);
			}
		}
	}
}

void AIManager::UpdateAI(void)
{
	int nLeaderGroup = - 1;
	GameObject* pPlayer = pCoreFacade->GetObjectManager()->GetPlayer();
	int temp = m_nNumGroups;
	if (m_nNumGroups > 0)
	{
		for (unsigned int gIndex = 0; gIndex < groupList.size(); gIndex++)
		{
			if (groupList[gIndex]->EnemyList.size() <= 0)
				continue;

			else if (pPlayer->GetPlayerComponent()->GetCurrentRoom() == gIndex + 1 && pPlayer->GetPlayerComponent()->GetCurrentRoom() != 0)
			{
				EnemyGroup* eGroup = groupList[gIndex];

				for (unsigned int eIndex = 0; eIndex < eGroup->EnemyList.size(); eIndex++)
				{
					if (!eGroup->EnemyList[eIndex]->GetActive() || eGroup->EnemyList[eIndex]->GetAIData()->enemyState == AIData::EnDeath)
					{
						if (eGroup->EnemyList[eIndex]->GetAIData()->bLeader)
						{
							bNewLeader = true;
							nLeaderGroup = gIndex;
							eGroup->EnemyList[eIndex]->GetAIData()->bLeaderEngage = false;
							eGroup->EnemyList[eIndex]->GetAIData()->bLeader = false;
							m_Leader = nullptr;
							break;
						}

						else
							continue;
					}

					if (eGroup->EnemyList[eIndex]->GetAIData()->bLeader)
					{
						LeaderBehavior(eGroup->EnemyList[eIndex]);
						m_Leader = eGroup->EnemyList[eIndex];
					}

					else
					{
						if (m_Leader != nullptr)
						{
							if (m_Leader->GetAIData()->bLeaderEngage)
							{
								eGroup->EnemyList[eIndex]->GetAIData()->ObjTarget = m_Leader->GetAIData()->ObjTarget;
								eGroup->EnemyList[eIndex]->GetAIData()->bAtkWithLeader = true;
							}

							else
								eGroup->EnemyList[eIndex]->GetAIData()->bAtkWithLeader = false;

							if (eGroup->EnemyList[eIndex]->GetAIData()->bInRange && eGroup->EnemyList[eIndex]->GetAIData()->bAtkWithLeader)
								ReactToLeader(eGroup->EnemyList[eIndex], m_Leader);
						}
						//if (eGroup->EnemyList[eIndex]->GetAIData()->bInRange)
						//{
							
						//}
					}
				}

				//break;
			}
		}
	}

	if (bNewLeader && nLeaderGroup >= 0)
	{
		FindNewLeader(nLeaderGroup);
		bNewLeader = false;
	}
}

void AIManager::FindNewLeader(int _enemyGroup)
{
	bool anyLeader = false;
	if (groupList[_enemyGroup]->EnemyList.size() > 0)
	{
		std::vector<GameObject*> enemyList = groupList[_enemyGroup]->EnemyList;
		for (unsigned int eIndex = 0; eIndex < enemyList.size(); eIndex++)
		{
			if (enemyList[eIndex]->GetActive() && enemyList[eIndex]->GetAIData()->enemyState != AIData::EnDeath)
			{
				enemyList[eIndex]->GetAIData()->bLeader = true;
				m_Leader = enemyList[eIndex];
				anyLeader = true;
				break;
			}
		}
	}

	if (!anyLeader)
	{
		if (m_Leader != nullptr)
			m_Leader = nullptr;
	}
}

void AIManager::ReactToLeader(GameObject* GO, GameObject* _leader)
{
	switch (_leader->GetAIData()->enemyState)
	{
	case AIData::EnPreJump:
		GO->GetAIData()->enemyState = AIData::EnPreJump;
		GO->GetAIData()->bToSwitchStates = true;
		break;
	case AIData::EnJump:
		break;
	case AIData::EnPatrol:
		break;
	case AIData::EnScan:
		break;
	case AIData::EnReposition:
		break;
	case AIData::EnTrap:
		GO->GetAIData()->enemyState = AIData::EnDebuff;
		GO->GetAIData()->bToSwitchStates = true;
		break;
	case AIData::EnDebuff:
		GO->GetAIData()->enemyState = AIData::EnTrap;
		GO->GetAIData()->bToSwitchStates = true;
		break;
	case AIData::EnAttack:
		break;
	case AIData::EnDeath:
		_leader->GetAIData()->bLeader = false;
		_leader->GetAIData()->bLeaderEngage = false;
		GO->GetAIData()->bLeader = true;
		m_Leader = GO;
		RemoveEnemiesFromGroup(_leader->GetAIData()->nEnemyGroup);
		break;
	default:
		break;
	}
}

void AIManager::LeaderBehavior(GameObject* GO)
{
	
}

void AIManager::RemoveEnemiesFromGroup(int _groupNum)
{
	std::vector<GameObject*> eList = groupList[_groupNum]->EnemyList;
	for (auto iterator = eList.begin(); iterator != eList.end(); iterator++)
	{
		if ((*iterator)->GetAIData()->enemyState == AIData::EnDeath)
		{
			eList.erase(iterator);
		}
	}

	if (eList.size() <= 0)
		eList.clear();
}