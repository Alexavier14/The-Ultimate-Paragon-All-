#include "../Application/stdafx.h"
#include "../Object Manager/AIData.h"
#include "../Application/CoreFacade.h"
#ifndef ENEMYBEHAVIOR_H_
#define ENEMYBEHAVIOR_H_


class GameObject;
class CoreFacade;
extern enum ObjectType;

enum EnemyEffectType {
	//Spider Effects
	eSPIDER_HEALTHBAR_EFFECT = 0, 
	eSPIDER_EFFECT_AMOUNT,

	//Golem Effects
	eGOLEM_HEALTHBAR_EFFECT = 0,
	eGOLEM_EFFECT_AMOUNT,

	//Worm Effects
	eWORM_HEALTHBAR_EFFECT = 0,
	eWORM_EFFECT_AMOUNT,
};

enum EnemyTelegraphType {
	//Spider Telegraphs
	eSPIDER_ATTACK_TELEGRAPH = 0, 
	eSPIDER_FEAR_TELEGRAPH,
	eSPIDER_JUMP_TELEGRAPH,
	eSPIDER_TELEGRAPH_AMOUNT,

	//Golem Telegraphs
	eGOLEM_ATTACK_TELEGRAPH = 0,
	eGOLEM_STUN_TELEGRAPH,
	eGOLEM_TELEGRAPH_AMOUNT,
	
	//Worm Telegraphs
	eWORM_ATTACK_TELEGRAPH = 0,
	eWORM_KNOCKBACK_TELEGRAPH,
	eWORM_EMERGE_TELEGRAPH,
	eWORM_TELEGRAPH_AMOUNT,
};

enum EnemyEmitterType {
	//Spider Emitters
	eSPIDER_ATTACK_EMITTER = 0,
	eSPIDER_EMITTER_AMOUNT,

	//Golem Emitters
	eGOLEM_SMASH_EMITTER = 0,
	eGOLEM_STOMP_EMITTER,
	eGOLEM_EMITTER_AMOUNT,

	//Worm Emitters
	eWORM_TRAIL1_EMITTER = 0,
	eWORM_TRAIL2_EMITTER,
	eWORM_EMITTER_AMOUNT,
};


class EnemyBehavior
{
	CoreFacade * p_mcfacade;
public:
	EnemyBehavior(CoreFacade * p_mcfacade);
	~EnemyBehavior();
	void Initialize(CoreFacade * p_mcfacade);
	void Shutdown();

	//EnemyStates
	void SwitchStateEnemy(GameObject& GO, AIData::EnemyState state);
	void EnemyStates(GameObject& GO);
	void EnemyUpdate(GameObject& GO);
	void EnemyScan(GameObject& GO);
	void EnemyPatrol(GameObject& GO);
	void EnemyReposition(GameObject& GO);
	void EnemyDebuff(GameObject& GO);
	void EnemyAttack(GameObject& GO);
	void EnemyDeath(GameObject& GO);
	void EnemyTrap(GameObject& GO);

	void SpiderAttack(GameObject& GO);
	void SpiderDebuff(GameObject& GO);
	void SpiderTrap(GameObject& GO);

	void GolemAttack(GameObject& GO);
	void GolemDebuff(GameObject& GO);
	void GolemTrap(GameObject& GO);

	void WormAttack(GameObject& GO);
	void WormDebuff(GameObject& GO);
	void WormTrap(GameObject& GO);
	void WormReposition(GameObject& GO);

	void SpiderJump(GameObject& GO);
	void SetSpiderVel(GameObject& GO);
	void SpiderPreJump(GameObject& GO);

	void GolemImpact(GameObject& GO);

	void SetTrapVel(GameObject& GO);
	void TrapMove(GameObject& GO);
private:
	//Spawn Gems Function
	//Pass in the number of Gems To make for each Type
	//Use these #defines to help
	///GEM_NO_SPAWN		- Tells the function not to spawn any gems of that type.
	///GEM_SPAWN_RAND	- Tells the function to spawn a random number of gems of that type.
	///GEM_SPAWN_ONE	- Tells the function to spawn one gem of that type.
	//Pass in the Game Objects position to get the gems to spawn where we want them to.
	void SpawnGems(int _numSapphire, int _numRuby, int _numDiamond, GameObject& GO, bool GemDespTimerINFINATE = false);

	//SpawnGems helper function
	bool SpawnGemType(ObjectType _gemType, XMFLOAT3 _pos, bool GemDespTimerINFINATE = false);

	//Worm Reposition Helper
	void WormCorrection(GameObject& _target, GameObject& _enemy);
};


#endif