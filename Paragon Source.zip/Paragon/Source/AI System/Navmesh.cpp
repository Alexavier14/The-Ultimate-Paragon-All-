#include "../Application/stdafx.h"
#include "NavMesh.h"
#include "../Application/CoreFacade.h"
#include "../Physics/Physics.h"
using namespace Physics;

NavMesh::NavMesh() :
m_TileSize(10.0f, 10.0f)
{
}
NavMesh::~NavMesh(){}

XMSHORT2 NavMesh::GetTile(const XMVECTOR& pos)
{
	return GetTile( XMCStoreFloat2(pos) );
}

XMSHORT2 NavMesh::GetTile(const XMFLOAT2& pos)
{
	XMSHORT2 tile;
	tile.x = short( m_MeshSize.x *  ((pos.x - (m_MapCenter.x - m_MapSize.x*0.5f) )/m_MapSize.x) + 0.5f);
	tile.y = short( m_MeshSize.y *  ((pos.y - (m_MapCenter.y - m_MapSize.y*0.5f) )/m_MapSize.y) + 0.5f);
	return tile;
}

SearchTile& NavMesh::GetTile(const XMSHORT2& tile)
{
	if( tile.x < 0 || tile.y < 0 )
		return invalidTile;
	
	if( tile.x >= m_MeshSize.x || tile.y >= m_MeshSize.y )
		return invalidTile;


	return m_Mesh[tile.x + m_MeshSize.x*tile.y];
}

SearchTile& NavMesh::GetTile(float tileX, float tileY)
{
	return GetTile(XMSHORT2(tileX,tileY));
}

XMFLOAT2 NavMesh::GetPosition( const XMSHORT2& tile )const
{
	XMFLOAT2 position;
	position.x = m_MapCenter.x - m_MapSize.x*0.5f + tile.x*m_TileSize.x;
	position.y = m_MapCenter.y - m_MapSize.y*0.5f + tile.y*m_TileSize.y;
	return position;
}

XMVECTOR NavMesh::GetTileSize() const
{
	return XMLoadFloat2(&m_TileSize);
}


void NavMesh::Initialize(CoreFacade* pCoreFacade)
{
	m_pCoreFacade = pCoreFacade;
	invalidTile.status = TA_BLOCKED | TA_OCCUPIED;
}

void NavMesh::Shutdown( )
{
	if( m_Mesh )
		delete m_Mesh;
}

void NavMesh::CreateMap(const XMSHORT2& meshSize)
{

	if( m_Mesh )
		delete m_Mesh;

	m_MeshSize = meshSize;
	m_MapSize.x = meshSize.x * m_TileSize.x;
	m_MapSize.y = meshSize.y * m_TileSize.y;
	m_Mesh = new SearchTile[meshSize.x*meshSize.y];
	m_MapCenter = XMFLOAT2(0,0);




	auto& Walls = m_pCoreFacade->GetObjectManager()->GetWalls();

	for (size_t iWall = 0; iWall < Walls.size(); iWall++)
	{
		GameObject* pWall = Walls[iWall];
		OrientedBox* pWallBox = dynamic_cast<OrientedBox*>( pWall->GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE) );
		XMVECTOR WallCenter = pWallBox->GetPosition();
		XMVECTOR boxDir = pWallBox->GetDirection();
		XMFLOAT2 halfSize = XMCStoreFloat2(pWallBox->GetHalfSize());
		XMVECTOR extents[3] = { };
		extents[0] = boxDir*halfSize.x;
		extents[1] = XMVector2Orthogonal(boxDir)*halfSize.y;
		extents[2] = XMCLoadFloat3(0, 0, 1);


		//Walls can span multiple tiles
		// Not efficient
		for (short i = 0; i < meshSize.x; i++)
		{
			for (short j = 0; j < meshSize.y; j++)
			{
				XMSHORT2 Tile = XMSHORT2(i, j);
				XMVECTOR TilePos = XMLoadFloat2(&GetPosition(Tile));

				if (IsPointOnOBB(TilePos, WallCenter, extents))
					GetTile(Tile).status |= TA_OCCUPIED;
			}
		}
	}

	vector<GameObject*> Objects;

	auto& Anvils = m_pCoreFacade->GetObjectManager()->GetAnvils();
	Objects.insert(Objects.end(), Anvils.begin(), Anvils.end());

	auto& MiningNodes = m_pCoreFacade->GetObjectManager()->GetMiningNodes();
	Objects.insert(Objects.end(), MiningNodes.begin(), MiningNodes.end());

	for (size_t i = 0; i < Objects.size(); i++)
	{
		GameObject* pObj = Objects[i];
		XMVECTOR objPos = pObj->GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE)->GetPosition();
		XMSHORT2 objTile = GetTile(objPos);

		GetTile(objTile).status |= TA_OCCUPIED;
	}

}


void NavMesh::Update()
{
	// Clear blocks
	for (short i = 0; i < m_MeshSize.x; i++)
		for (short j = 0; j < m_MeshSize.y; j++)
			GetTile(XMSHORT2(i, j)).status &= ~TA_BLOCKED;


	auto& Enemies = m_pCoreFacade->GetObjectManager()->GetAllEnemies();
	for (size_t iEnemies = 0; iEnemies < Enemies.size(); iEnemies++)
	{
		GameObject* pEnemy = Enemies[iEnemies];
		if(!pEnemy->GetActive())
			continue;
		Circle* pEnemyBounds = dynamic_cast<Circle*>(pEnemy->GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE));
		XMVECTOR circleCenter = pEnemyBounds->GetPosition();
		XMSHORT2 centerTile = GetTile(XMCStoreFloat2(circleCenter));


#if 1	// Block the 1 tile on the spiders center
		GetTile(centerTile).status |= TA_BLOCKED;
#else	// Block the tiles whose centers are within the spiders bounds
		float circleRadius = pEnemyBounds->GetRadius();
		XMSHORT2 delta;
		delta.x = short(circleRadius/m_TileSize.x) + 1;
		delta.y = short(circleRadius/m_TileSize.y) + 1;
		float testRadius = circleRadius + max(m_TileSize.x, m_TileSize.y)*0.5f;

		for (short i = centerTile.x - delta.x; i < centerTile.x + delta.x; i++)
		{
			for (short j = centerTile.y - delta.y; j < centerTile.y + delta.y; j++)
			{
				XMSHORT2 currTile = XMSHORT2(i,j);
				XMVECTOR tileCenter = XMLoadFloat2( &GetPosition( currTile ));
				if (IntersectPointCircle(tileCenter, circleCenter, testRadius))
				{
					GetTile(currTile).status |= TA_BLOCKED;

				}
			}
		}
#endif
	}
}