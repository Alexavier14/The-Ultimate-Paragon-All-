#include "../Application/stdafx.h"

#include "GeodeBehavior.h"
#include "../Object Manager/AnimComponent.h"
#include "../Object Manager/PointLightComponent.h"
#include "../Object Manager/AudioComponent.h"
#include "../Object Manager/GameObject.h"
#include "../Application/CoreFacade.h"
#include "../Physics/Physics.h"
#include "../Physics/CollisionShape.h"
#include "../Util/TimeManager.h"
#include "../Util/Util.h"
#include "../Sound/SoundManager.h"
#include "../Sound/Wwise_IDs.h"
#include "../Particle System/Emitter.h"
#include "NavAgent.h"

using namespace Physics;
using namespace DirectX;

#define GEODE_FOLLOW_SPEED		24.0f
#define GEODE_FLEE_SPEED		20.0f
#define GEODE_PICKUP_SPEED		24.0f
#define GEODE_ATTACK_SPEED		1.75f
#define GEODE_ATTACK_MOVE_SPEED	24.0f
#define GEODE_RECALL_SPEED		60.0f
#define GEODE_SEND_SPEED		60.0f
#define GEODE_MINE_SPEED		1.125f
#define GEODE_MINE_MOVE_SPEED	24.0f
#define GEODE_TURN_SPEED		14.0f

#define GEODE_MASS_DEFAULT		1.0f
#define GEODE_MASS_SEND			50.0f
#define GEODE_MASS_ATTACK		9.0f
#define GEODE_MASS_SCAN			100.0f
#define GEODE_COLLISION_TIMER	0.8f

#define DEATH_TIMER				6.0f

// Has to match with define on ReticleComponent.cpp
#define GEODE_SEND_DIST 25.0f

#define GEODE_TRAIL_EMISSION 0
#define GEODE_POPBACK_EMISSION 1

#define GEODE_GROW_TIME 0.75f

//#define VECTOR_CHECK
#ifdef VECTOR_CHECK
void CheckVector(XMVECTOR& in)
{
	for (size_t i = 0; i < 4; i++)
	{
		if (in.m128_f32[i] != in.m128_f32[i])
			OutputDebugStringA("Bad Check");
	}
}
#else
#define CheckVector(m)__noop
#endif

GeodeBehavior::GeodeBehavior(CoreFacade * p_mcfacade)
{
	Initialize(p_mcfacade);
}
GeodeBehavior::~GeodeBehavior()
{
	Shutdown();
}
void GeodeBehavior::Initialize(CoreFacade * p_mcfacade)
{
	//stuckGeode = false;
	this->p_mcfacade = p_mcfacade;
}
void GeodeBehavior::Shutdown()
{
	p_mcfacade = nullptr;
}

void GeodeBehavior::Update(GameObject& GO)
{
	const float MINUMIM_TRAIL_SPEED = 0.5f;

	Emitter* pTrailEmitter = GO.GetChildEmitterComponent(GEODE_TRAIL_EMISSION);

	PhysicsComponent* pPhysics = GO.GetPhysicsComponent();
	float speed = XMCVector2Length(XMLoadFloat2(&pPhysics->GetVelocity()));

	if (speed > MINUMIM_TRAIL_SPEED)
		pTrailEmitter->SetSpawnRate(speed*0.2f);
	else
		pTrailEmitter->SetSpawnRate(0);

	AIData* pGeodeAI = GO.GetAIData();
	if (pGeodeAI->geodeState != AIData::GeDeath && pGeodeAI->health <= 0)
	{
		SwitchStateGeode(GO, AIData::GeDeath);
	}

	//Geode Growing
	if (pGeodeAI->fActionCooldownD > 0)
	{
		float scale = max(0.1f, 1 - pGeodeAI->fActionCooldownD / GEODE_GROW_TIME);
		GO.SetScale(scale);

		pGeodeAI->fActionCooldownD -= TimeManager::GetTimeDelta();
	}

	if (pGeodeAI->geodeState != AIData::GeDeath && pGeodeAI->geodeState != AIData::GeRecall)
	{
		std::vector<GameObject*> trapList = p_mcfacade->GetObjectManager()->GetSpiderTraps();
		for (unsigned int index = 0; index < trapList.size(); index++)
		{
			GameObject* pTrap = trapList[index];

			if (!pTrap->GetTrapComponent()->GetEnabled())
				continue;
			if (pTrap->GetTrapComponent()->GetToMove())
				continue;

			CollisionShape* trapBounds = pTrap->GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE);
			CollisionShape* geodeBounds = GO.GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE);

			if (geodeBounds->Collides(trapBounds))
			{
				SwitchStateGeode(GO, pGeodeAI->GeStuck);
				break;
			}
		}
	}

	GO.GetChildEffectComponent(eGEODE_BARRIER_EFFECT)->GetHolder()->SetObjectColorAlpha(0.0f);

	// Switch to win state
	/* TODO: Switch to events
	EventComponent* pWinEvent = p_mcfacade->GetObjectManager()->GetPlayer()->GetEventComponent();
	if (pWinEvent->Triggered)
	{
	if( pGeodeAI->geodeState != AIData::GeVictory )
	SwitchStateGeode(GO, AIData::GeVictory );

	}
	*/

	bool WinFlag = p_mcfacade->GetObjectManager()->GetPlayer()->GetPlayerComponent()->m_bWinEventStarted;
	if (WinFlag)
	{
		if (pGeodeAI->geodeState != AIData::GeVictory)
		{
			SwitchStateGeode(GO, AIData::GeVictory);
			pGeodeAI->fActionCooldown = 10.0f;
		}
	}
}
void GeodeBehavior::GeodeStates(GameObject& GO)
{
	Update(GO);

	switch (GO.GetAIData()->geodeState)
	{
	case AIData::GeFear:		return GeodeFear(GO);
	case AIData::GeStun:		return GeodeStun(GO);
	case AIData::GeKnockback:	return GeodeKnockback(GO);
	case AIData::GeAttack:		return GeodeAttack(GO);
	case AIData::GePickup:		return GeodePickup(GO);
	case AIData::GeMine:		return GeodeMine(GO);
	case AIData::GeScan:		return GeodeScan(GO);
	case AIData::GeRecall:		return GeodeRecall(GO);
	case AIData::GeSend:		return GeodeSend(&GO);
	case AIData::GeFollowing:	return GeodeFollow(GO);
	case AIData::GeDeath:		return GeodeDeath(GO);
	case AIData::GeStuck:		return GeodeStuck(GO);
	case AIData::GeVictory:		return GeodeVictory(GO);
	case AIData::GeTrap:		return GeodeTrap(GO);
	case AIData::GeIdle:		return GeodeIdle(GO);
	}
}

void GeodeBehavior::GeodeScan(GameObject& GO)
{
	//Start effect here
	///Remove Magic numbers 
	GO.GetChildEffectComponent(eGEODE_SCAN_EFFECT)->ToggleEffect(true);
	GO.GetChildEffectComponent(eGEODE_SCAN_EFFECT)->Position = XMCStoreFloat3(GO.GetObjectTranslationVec() + XMCLoadFloat3(0, 8, 0));

	GO.GetAIData()->ObjTarget = nullptr;

	PhysicsComponent * ScanningObjectsPhysicsComp = GO.GetPhysicsComponent();

	//Get Geodes Targets
	vector<GameObject*> GeodeTargets = p_mcfacade->m_ObjectManager->GetGeodeTargets();

	//CurrentTarget 
	GameObject * CurEnemy = nullptr;
	GameObject * CurNode = nullptr;
	GameObject * CurGem = nullptr;

	if (GO.GetAIData()->cAIClockTimer.Watch() < 1.0f)
	{
		string anim;
		switch (GO.GetType())
		{
		case eRUBYGEODE: anim = RUBY_SCAN; break;
		case eSAPPHIREGEODE: anim = SAPPHIRE_SCAN; break;
		case eDIAMONDGEODE: anim = DIAMOND_SCAN; break;
		}
		GO.GetAnimComponent()->SetAnimName(anim, false);
	}


	if (GO.GetAIData()->cAIClockTimer.Watch() >= 2.0f)
	{
		GO.GetAIData()->cAIClockTimer.Tick();

		for (unsigned int i = 0; i < GeodeTargets.size(); i++)
		{
			//Check to see if we are colliding 
			if (GeodeTargets[i]->GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE)->Collides(ScanningObjectsPhysicsComp->GetCollisionShape(SU_SCANNER)) == false)
				continue;

			//Current GameObject
			GameObject * CurrObjectToCheck = GeodeTargets[i];

			//Check to see if object is active
			if (GeodeTargets[i]->GetActive() == false)
				continue;

			//Check for enemy
			if ((CurrObjectToCheck->GetType() == eSPIDER || CurrObjectToCheck->GetType() == eGOLEM || CurrObjectToCheck->GetType() == eWORM)
				&& CurrObjectToCheck->GetAIData()->health > 0)
			{
				//Distance between old and new
				float CurrentDistance = 0.0f;
				if (CurEnemy != nullptr)
				{
					XMVECTOR TargetPos = XMLoadFloat3(&GeodeTargets[i]->GetObjectTranslation());
					XMVECTOR CurrentEnemyPos = XMLoadFloat3(&CurEnemy->GetObjectTranslation());
					XMVECTOR CurrentScanningObjectPos = XMLoadFloat3(&GO.GetObjectTranslation());

					XMVECTOR OldDistance = TargetPos - CurrentEnemyPos;
					XMVECTOR NewDistance = TargetPos - CurrentScanningObjectPos;

					OldDistance = XMVector3Length(OldDistance);
					NewDistance = XMVector3Length(NewDistance);

					float OldLen = XMVectorGetX(OldDistance);
					float NewLen = XMVectorGetX(NewDistance);

					//Check which is shorter
					if (NewLen <= OldLen)
						CurEnemy = GeodeTargets[i];
				}
				else
				{
					//Not assigned but enemy found
					CurEnemy = GeodeTargets[i];
				}
			}


			//Check to see if the object is a node and that this geode can mine it
			if ((CurrObjectToCheck->GetType() == eRUBYNODE && GO.GetType() == eRUBYGEODE)
				|| (CurrObjectToCheck->GetType() == eSAPPHIRENODE  && GO.GetType() == eSAPPHIREGEODE)
				|| (CurrObjectToCheck->GetType() == eDIAMONDNODE  && GO.GetType() == eDIAMONDGEODE)
				|| CurrObjectToCheck->GetType() == eRUBYHOLDER || CurrObjectToCheck->GetType() == eSAPPHIREHOLDER || CurrObjectToCheck->GetType() == eDIAMONDHOLDER)
			{
				//Check if current is no attacking
				CurNode = GeodeTargets[i];
			}


			if (CurrObjectToCheck->GetType() != ePARAGON && (CurrObjectToCheck->GetType() == eRUBYGEM || CurrObjectToCheck->GetType() == eSAPPHIREGEM || CurrObjectToCheck->GetType() == eDIAMONDGEM)
				&& GeodeTargets[i]->GetAIData()->bAttacked == false)
			{
				CurGem = GeodeTargets[i];
			}

		}

		if (CurEnemy != nullptr)
		{
			this->SwitchStateGeode(GO, AIData::GeAttack);
			GO.GetAIData()->ObjTarget = CurEnemy;
		}
		else if (CurNode != nullptr)
		{
			this->SwitchStateGeode(GO, AIData::GeMine);
			GO.GetAIData()->ObjTarget = CurNode;
		}
		else if (CurGem != nullptr)
		{
			this->SwitchStateGeode(GO, AIData::GePickup);
			GO.GetAIData()->ObjTarget = CurGem;
			CurGem->GetAIData()->bAttacked = true;
		}
		else
		{
			this->SwitchStateGeode(GO, AIData::GeRecall);
		}

	}
	else
		GO.GetPhysicsComponent()->SetVelocity(XMFLOAT2(0.0f, 0.0f));
}
bool CanGather(ObjectType geodeType, ObjectType nodeType)
{
	switch (geodeType)
	{
	case eRUBYGEODE:	return nodeType == eRUBYNODE;
	case eSAPPHIREGEODE:	return nodeType == eSAPPHIRENODE;
	case eDIAMONDGEODE:	return nodeType == eDIAMONDNODE;
	}
	return false;
}
void GeodeBehavior::GeodeSend(GameObject* pGeode)
{

	//Update the staff point light colors
	switch (pGeode->GetType())
	{
	case eRUBYGEODE:		PointLightComponent::RubySent();		break;
	case eSAPPHIREGEODE:	PointLightComponent::SapphireSent();	break;
	case eDIAMONDGEODE:		PointLightComponent::DiamondSent();		break;
	}

	AIData* pGeodeAI = pGeode->GetAIData();
	PhysicsComponent* physicsGeode = pGeode->GetPhysicsComponent();


	//// Plan:
	//// Go towards a point in front the player if the geode is already ahead of the player (hst)
	//// Otherwise go towards a point in a half circle that is centered and aime towards the player
	//// The specific point is chosen based on the angle between the players forward and the vector separation

	//bool& IsSent = pGeodeData->bActionDone;

	//if (!IsSent)
	//{
	//	//float angle = 
	//}

	XMVECTOR OriginPos = XMLoadFloat3(&pGeodeAI->WayPoints[0]);
	XMVECTOR ReticlePos = XMLoadFloat3(&pGeodeAI->WayPoints[1]);
	XMVECTOR CurrPos = pGeode->GetObjectTranslationVec();

	//float maxDistance = XMCVector2Length(ReticlePos - OriginPos);

	float distance = XMCVector3Length(CurrPos - OriginPos);
	float &maxDistance = pGeodeAI->fSendDistance;
	if (distance >= maxDistance)
	{
		SwitchStateGeode(*pGeode, AIData::GeScan);
		pGeodeAI->WayPoints.clear();
		return;
	}

	//pGeode->TurnTo(targetPos, GEODE_TURN_SPEED);
	physicsGeode->SetForwardVelocity(GEODE_SEND_SPEED);

	DetectCollisions(*pGeode);




}
void GeodeBehavior::GeodeFear(GameObject &GO)
{
	AIData* pGeodeAI = GO.GetAIData();
	PhysicsComponent* pGeodePhysics = GO.GetPhysicsComponent();
	GO.GetChildEffectComponent(eGEODE_FEAR_EFFECT)->Position = XMCStoreFloat3(GO.GetObjectTranslationVec() + XMCLoadFloat3(0, 3, -3));
	GO.GetChildEffectComponent(eGEODE_FEAR_EFFECT)->ToggleEffect(true);

	//If the first time through. Store the forward vec so we know its true direction.
	if (pGeodeAI->fActionCooldown <= 0.0f)
	{
		pGeodeAI->fTargetPos = XMCStoreFloat3(-GO.GetWorldTransformMat().r[2]);
		if (rand() % 2 == 0)
			pGeodeAI->fActionCooldownB = -1;
		else
			pGeodeAI->fActionCooldownB = 1;

	}



	pGeodeAI->fActionCooldown += (float)TimeManager::GetTimeDelta();

	if (pGeodeAI->fActionCooldown >= 5.0f)
	{
		pGeodeAI->fActionCooldown = 0.0f;
		pGeodeAI->fActionCooldownB = 0.0f;
		SwitchStateGeode(GO, pGeodeAI->GeAttack);
	}

	GameObject* pEnemy = pGeodeAI->ObjTarget;
	if (pEnemy)
	{
		float time_whole = float((int)TimeManager::GetElapsedTime());
		float time_dec = TimeManager::GetElapsedTime() - time_whole;
		if ((int)time_whole % 2 == 0 && time_dec < 0.5f)
		{
			if (rand() % 2 == 0)
				pGeodeAI->fActionCooldownB = -1;
			else
				pGeodeAI->fActionCooldownB = 1;
		}
		float sin_value = sinf(TimeManager::GetElapsedTime()) * 3.0f * pGeodeAI->fActionCooldownB;
		//if (sin_value > 0)
		//	sin_value = 1.0f;
		//else
		//	sin_value = -1.0f;
		XMVECTOR forward = XMLoadFloat3(&pGeodeAI->fTargetPos);
		XMMATRIX rotation = XMMatrixRotationY(sin_value);
		forward = XMVector3Transform(forward, rotation);

		XMVECTOR geodeVelocity = XMVector3Normalize(forward)*15.0f;
		pGeodePhysics->SetVelocity(XMCVector2GetXZ(geodeVelocity)); // Note: Velocity should be updated every frame, not just first
	}
}
void GeodeBehavior::GeodeStun(GameObject &GO)
{
	GO.GetChildEffectComponent(eGEODE_STUN_EFFECT)->Position = XMCStoreFloat3(GO.GetObjectTranslationVec() + XMCLoadFloat3(0, 3, -3));
	GO.GetChildEffectComponent(eGEODE_STUN_EFFECT)->ToggleEffect(true);

	GO.GetPhysicsComponent()->SetForwardVelocity(0);
	GO.GetAIData()->fActionCooldown += (float)TimeManager::GetTimeDelta();
	if (GO.GetAIData()->fActionCooldown >= 5.0f)
	{
		GO.GetAIData()->fActionCooldown = 0.0f;
		SwitchStateGeode(GO, GO.GetAIData()->GeAttack);
	}
}
void GeodeBehavior::GeodeKnockback(GameObject &GO)
{
	AIData& pGeodeAI = *GO.GetAIData();
	PhysicsComponent& pGeodePhysics = *GO.GetPhysicsComponent();
	GO.GetChildEffectComponent(eGEODE_KNOCKBACK_EFFECT)->Position = XMCStoreFloat3(GO.GetObjectTranslationVec() + XMCLoadFloat3(0, 3, -3));
	GO.GetChildEffectComponent(eGEODE_KNOCKBACK_EFFECT)->ToggleEffect(true);

	if (!pGeodeAI.bEnemySpecialB)
	{
		float g = -9.8f;
		float t = UnitRand() + 1.0f;
		XMVECTOR geodePOS = GO.GetObjectTranslationVec();
		XMVECTOR enemyPOS = pGeodeAI.ObjTarget->GetObjectTranslationVec();
		XMVECTOR toVector = XMVector3Normalize(geodePOS - enemyPOS) * (15.0f + 15.0f * UnitRand());

		XMFLOAT3 P = XMCStoreFloat3(toVector + geodePOS);
		XMFLOAT3 O = GO.GetObjectTranslation();

		XMFLOAT3 Vo;

		pGeodeAI.fJumpingPoint = O;
		Vo.x = (P.x - O.x) / t;
		Vo.z = (P.z - O.z) / t;
		Vo.y = -(P.y + ((0.5f * g) * (t * t)) - O.y) / t;

		pGeodeAI.fTempVel = Vo;
		pGeodeAI.fActionCooldown = t;
		pGeodeAI.bEnemySpecialB = true;
	}
	else if (pGeodeAI.fActionCooldown > 0.0f)
	{
		pGeodeAI.fActionCooldown -= TimeManager::GetTimeDelta();

		float t = pGeodeAI.m_fAirTime;
		XMFLOAT3 F;

		//F.x = (gemData.fTempVel.x) * t + gemData.fJumpingPoint.x;
		//F.z = (gemData.fTempVel.y) * t + gemData.fJumpingPoint.z;
		F.y = ((0.5f * -9.8f) * (t * t)) + (pGeodeAI.fTempVel.y * t) + pGeodeAI.fJumpingPoint.y;
		F.x = GO.GetObjectTranslation().x;
		F.z = GO.GetObjectTranslation().z;

		if ((F.y <= 0.0f || pGeodeAI.fActionCooldown <= 0.0f) && pGeodeAI.m_fAirTime != 0.0f)
		{
			pGeodePhysics.SetVelocity(XMFLOAT2(0.0f, 0.0f));
			pGeodePhysics.SetForwardVelocity(0.0f);
			GO.SetObjectTranslation(F.x, 0.0f, F.z);
			pGeodeAI.fActionCooldown = 0.0f;
			SwitchStateGeode(GO, pGeodeAI.GeAttack);
			pGeodeAI.bEnemySpecialB = false;
			pGeodeAI.m_fAirTime = 0.0f;
		}
		else
		{
			pGeodePhysics.SetVelocity(XMFLOAT2(pGeodeAI.fTempVel.x, pGeodeAI.fTempVel.z));
			GO.SetObjectTranslation(F);
		}

		pGeodeAI.m_fAirTime += TimeManager::GetTimeDelta();

	}

}
void GeodeBehavior::GeodeFollow(GameObject &GO)
{
	PhysicsComponent * physicsGeode = GO.GetPhysicsComponent();
	AIData* pGeodeAI = GO.GetAIData();

	GameObject* pPlayer = p_mcfacade->m_ObjectManager->GetPlayer();
	PlayerComponent* playerComp = pPlayer->GetPlayerComponent();

	XMVECTOR PlayerForward = pPlayer->GetForwardVec();

	short GeodeCount = 0;
	auto Geodes = p_mcfacade->GetObjectManager()->GetGeodes();
	for each (GameObject* pOther in Geodes)
	{
		if (!pOther->GetActive())
			continue;
		AIData* pOtherGeodeAI = pOther->GetAIData();
		if (pOtherGeodeAI->geodeState == AIData::GeFollowing && pOtherGeodeAI->bActionDone)
			GeodeCount++;
	}

	float followRadius = 2.0f + GeodeCount*0.85f;
	float formationOffset = 2.0f + followRadius;

	XMVECTOR GeodePos = GO.GetObjectTranslationVec();
	XMVECTOR PlayerPos = pPlayer->GetObjectTranslationVec();
	XMVECTOR FormationPos = PlayerPos - PlayerForward*formationOffset;
	XMVECTOR ToFormation = FormationPos - GeodePos;
	float distanceToFormation = XMCVector3Length(ToFormation);
	ToFormation /= distanceToFormation;


	//Halfspace to see if we should move with the formation.
	XMVECTOR PlayerForwardVec = pPlayer->GetForwardVec();
	XMVECTOR ToPlayer = PlayerPos - GO.GetObjectTranslationVec();
	XMVECTOR PlayerForwardNormalized = XMVector3Normalize(PlayerForwardVec);
	XMVECTOR DotRes = XMVector3Dot(PlayerForwardNormalized, ToPlayer);
	XMFLOAT3 StoredDotRes;
	XMStoreFloat3(&StoredDotRes, DotRes);

	bool& isInRange = pGeodeAI->bActionDone;

	if (isInRange)
	{
		//if (distanceToFormation > followRadius*1.0f)
		if (distanceToFormation > followRadius * 1.3f)
			isInRange = false;
	}
	else
	{
		if (distanceToFormation < followRadius)
			isInRange = true;
	}

	XMVECTOR GeodeVel = XMVectorZero();

	if (!isInRange)
		GeodeVel += ToFormation * 10.0f;
	//GeodeVel += ToFormation * 28.0f;

	if (distanceToFormation > 60.0f)
		GeodePopBack(GO);


	// Separation Steering
	vector<GameObject*> SeparationObjects = p_mcfacade->GetObjectManager()->GetGeodes();
	GeodeVel += Separation(GO, SeparationObjects, 12, 1.2f, 20); //12
	SeparationObjects.clear();
	SeparationObjects.push_back(pPlayer);
	GeodeVel += Separation(GO, SeparationObjects, 20, 1.5f, 30);

	//GeodeVel += Separation(GO, SeparationObjects, 25, 1.2f, 25); //12
	//SeparationObjects.clear();
	//SeparationObjects.push_back(pPlayer);
	//GeodeVel += Separation(GO, SeparationObjects, 25, 1.8f, 50);

	// Steering - Move with the player if behind the player
	if (StoredDotRes.x >= 0.0f)
	{
		XMVECTOR PlayerVel = XMCVector3LoadXZ(pPlayer->GetPhysicsComponent()->GetVelocity());
		XMVECTOR steeringImpulse = PlayerVel * 0.85f;
		GeodeVel += steeringImpulse;
	}

	
	//Set the Geodes velocity
	physicsGeode->SetVelocity(XMCVector2GetXZ(GeodeVel));

	XMVECTOR geodeForward = GO.GetForwardVec();
	XMVECTOR toPlayer = XMVector3Normalize(PlayerPos - GeodePos);
	XMVECTOR VelDir = XMVector3Normalize(GeodeVel);
	XMVECTOR turnDirection = VelDir * 0.1f + toPlayer * 1.5f + geodeForward * 1.5f;
	//if (!p_mcfacade->GetObjectManager()->GetPlayer()->GetPlayerComponent()->GetElevatorMove())
		GO.TurnTo(GeodePos + turnDirection, 4.0f); // Turn towards movement

	//if( isInRange )
	//	GO.SetObjectColor( XMCLoadFloat4(1,1,1,1), 1);
	//else
	//	GO.SetObjectColor( XMCLoadFloat4(1,1,1,1), 0);

}

void GeodeBehavior::GeodePopBack(GameObject &GO)
{
	XMFLOAT3 PlayerPos = p_mcfacade->m_ObjectManager->GetPlayer()->GetObjectTranslation();
	GO.GetPhysicsComponent()->SetPosition(XMFLOAT2(PlayerPos.x - rand() % 5, PlayerPos.z - rand() % 5));
	Emitter* pPopEmitter = GO.GetChildEmitterComponent(GEODE_POPBACK_EMISSION);
	pPopEmitter->SetSpawnTimer(0.5f);
	GO.GetAudioComponent()->PlayAudioAtSpot(PLAY_SFX_GEM_PICKUP_01);
	//p_mcfacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_SFX_GEM_PICKUP_01);
	GO.GetAIData()->fActionCooldownD = GEODE_GROW_TIME;
	GO.SetScale(0.1f);
}

void GeodeBehavior::GeodeRecall(GameObject &GO)
{
	PhysicsComponent * physicsGeode = GO.GetPhysicsComponent();

	GameObject* pPlayer = p_mcfacade->m_ObjectManager->GetPlayer();
	XMVECTOR PlayerForward = pPlayer->GetForwardVec();

	XMVECTOR PlayerPos = pPlayer->GetObjectTranslationVec();
	XMVECTOR PlayerPositionBehind = PlayerPos - 10 * PlayerForward;
	XMVECTOR GeodePos = GO.GetObjectTranslationVec();
	float distance = XMCVector3Length(PlayerPositionBehind - GeodePos);

	NavAgent* pNavAgent = GO.GetNavAgent();
	pNavAgent->SetMoveSpeed(GEODE_RECALL_SPEED);
	pNavAgent->SetTurnSpeed(GEODE_TURN_SPEED);
	pNavAgent->Update();
	//GO.TurnTo(PlayerPositionBehind, GEODE_TURN_SPEED);

	//XMVECTOR GeodeVel = GO.GetForwardVec()*GEODE_RECALL_SPEED;
	XMVECTOR GeodeVel = XMCVector3LoadXZ(physicsGeode->GetVelocity());

	vector<GameObject*> SeparationObjects = p_mcfacade->GetObjectManager()->GetGeodes();
	GeodeVel += Separation(GO, SeparationObjects);
	SeparationObjects = p_mcfacade->GetObjectManager()->GetAllEnemies();
	GeodeVel += Separation(GO, SeparationObjects, 200);

	//physicsGeode->SetVelocity( XMCVector2GetXZ(GeodeVel) );


	if (!pNavAgent->IsMoving())
		//if (distance <= 6.0f)
		SwitchStateGeode(GO, AIData::GeFollowing);
	//else if (distance > 60.0f)
	//	GeodePopBack(GO);

}
void GeodeBehavior::GeodeAttack(GameObject &GO)
{
	const float MaxAttackDist = 2.0f;
	const float MinAttackDist = 0.5f;
	GameObject* pTarget = GO.GetAIData()->ObjTarget;
	PhysicsComponent * physicsGeode = GO.GetPhysicsComponent();

	if (GO.GetAIData()->ObjTarget == nullptr)
	{
		PrintConsole("A Geode tried to attack a NULL game object");
		SwitchStateGeode(GO, AIData::GeVictory);
		GO.GetAIData()->fActionCooldown = 2.5f;
		return;
	}

	if (GO.GetAIData()->ObjTarget->GetActive() == false)
	{
		SwitchStateGeode(GO, AIData::GeVictory);
		GO.GetAIData()->fActionCooldown = 2.5f;
		return;
	}

	if (GO.GetAIData()->ObjTarget->GetAIData()->health <= 0)
	{
		SwitchStateGeode(GO, AIData::GeVictory);
		GO.GetAIData()->fActionCooldown = 2.5f;
		return;
	}

	GO.TurnTo(GO.GetAIData()->ObjTarget->GetObjectTranslationVec(), 5.0f);

	XMVECTOR TargetPosition = pTarget->GetObjectTranslationVec();
	XMVECTOR GeodePosition = GO.GetObjectTranslationVec();
	float distance = XMCVector3Length(TargetPosition - GeodePosition);
	distance -= dynamic_cast<Circle*>(GO.GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE))->GetRadius();
	distance -= dynamic_cast<Circle*>(pTarget->GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE))->GetRadius();

	XMVECTOR GeodeVel = GO.GetForwardVec() * GEODE_ATTACK_MOVE_SPEED;

	float& attackCooldown = GO.GetAIData()->fActionCooldown; //Geode Attack Cooldown

	bool attackInitiated = attackCooldown == 0;

	bool attackBonus =
		(pTarget->GetType() == eSPIDER && GO.GetType() == eSAPPHIREGEODE)
		|| (pTarget->GetType() == eGOLEM && GO.GetType() == eRUBYGEODE)
		|| (pTarget->GetType() == eWORM && GO.GetType() == eDIAMONDGEODE);

	if (attackBonus)
	{
		float ratio = TimeManager::GetElapsedTime()*3.5f + (float)(int)&GO;
		ratio = (1.0f + sinf(ratio))*0.5f;
		ratio = ratio*0.5f + 0.2f;
		GO.GetChildEffectComponent(eGEODE_BARRIER_EFFECT)->GetHolder()->SetObjectColorAlpha(ratio);
	}
	bool InRange = attackInitiated ? distance <= MaxAttackDist : distance <= MinAttackDist;

	if (InRange)
	{
		GeodeVel = XMVectorZero();

		attackCooldown += (float)TimeManager::GetTimeDelta();

		bool attackReady = attackCooldown >= GEODE_ATTACK_SPEED;




		//Keep them idled when they reach the enemy
		if (attackReady || attackCooldown == 100.0f)
		{

			if (attackCooldown == 100.0f)
				GO.GetAIData()->ObjTarget->TakeDamage(30);
			else
				GO.GetAIData()->ObjTarget->TakeDamage(attackBonus ? 2 : 1);

			GO.GetAIData()->fActionCooldown = 0.0f;

			switch (GO.GetType())
			{
			case eSAPPHIREGEODE:
				GO.GetAudioComponent()->PlayAudioFollow(PLAY_ADR_GEODE_SAFFIRE_ATTACK);
				//p_mcfacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_ADR_GEODE_SAFFIRE_ATTACK);
				if (attackBonus)
					GO.GetAnimComponent()->SetAnimName(SAPPHIRE_HATTACK, false);
				else
					GO.GetAnimComponent()->SetAnimName(SAPPHIRE_ATTACK, false);
				//GO.GetAnimComponent()->SetAnimSpeed(4.0f);
				break;
			case eRUBYGEODE:
				GO.GetAudioComponent()->PlayAudioFollow(PLAY_ADR_GEODE_RUBY_ATTACK);
				//p_mcfacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_ADR_GEODE_RUBY_ATTACK);
				if (attackBonus)
					GO.GetAnimComponent()->SetAnimName(RUBY_HATTACK, false);
				else
					GO.GetAnimComponent()->SetAnimName(RUBY_ATTACK, false);
				//GO.GetAnimComponent()->SetAnimSpeed(3.0f);
				break;
			case eDIAMONDGEODE:
				GO.GetAudioComponent()->PlayAudioFollow(PLAY_ADR_DIAMOND_ATTACK);
				//p_mcfacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_ADR_DIAMOND_ATTACK);
				if (attackBonus)
					GO.GetAnimComponent()->SetAnimName(DIAMOND_HATTACK, false);
				else
					GO.GetAnimComponent()->SetAnimName(DIAMOND_ATTACK, false);
				//GO.GetAnimComponent()->SetAnimSpeed(4.0f);
				break;
			}
		}
		else
		{
			switch (GO.GetType())
			{
			case eSAPPHIREGEODE:
				GO.GetAnimComponent()->SetAnimName(SAPPHIRE_IDLE, true);
				//GO.GetAnimComponent()->SetAnimSpeed(2.5f);
				break;
			case eRUBYGEODE:
				GO.GetAnimComponent()->SetAnimName(RUBY_IDLE, true);
				//GO.GetAnimComponent()->SetAnimSpeed(2.5f);
				break;
			case eDIAMONDGEODE:
				GO.GetAnimComponent()->SetAnimName(DIAMOND_IDLE, true);
				//GO.GetAnimComponent()->SetAnimSpeed(2.5f);
				break;
			}
		}


		///GameObject * attack_effect = GO.GetChildEffectObject(attackBonus ? eGEODE_SUPERATTACK_EFFECT : eGEODE_ATTACK_EFFECT);
		//attack_effect->GetEffectComponent()->Position = XMCStoreFloat3(GO.GetObjectTranslationVec() + XMCLoadFloat3(0, 3, 0));
		//attack_effect->GetEffectComponent()->ToggleEffect(true);
		//float effectRatio = (GEODE_ATTACK_SPEED - GO.GetAIData()->fActionCooldown) / GEODE_ATTACK_SPEED;
		//float colorAlpha = 0.2f + (1.0f - effectRatio)*0.8f;
		//attack_effect->SetObjectColor(XMFLOAT4(0.7f, 0.3f, 0.3f, colorAlpha), effectRatio);


		//if Idle and next to the target make it's look hyper
		//if (GO.GetAnimComponent()->GetAnimName().find_first_of("Idle"))
		//	GO.GetAnimComponent()->SetAnimSpeed(2.0f);
	}
	else
	{
		GO.TurnTo(TargetPosition, GEODE_TURN_SPEED);
		attackCooldown = 0;
	}

	physicsGeode->SetVelocity(XMCVector2GetXZ(GeodeVel));


}
void GeodeBehavior::GeodeMine(GameObject &GO)
{
	PhysicsComponent * physicsGeode = GO.GetPhysicsComponent();
	GameObject* pNode = GO.GetAIData()->ObjTarget;
	if (pNode == nullptr || pNode->GetActive() == false)
	{
		SwitchStateGeode(GO, AIData::GeRecall);
		return;
	}


	XMVECTOR NodePosition = XMLoadFloat3(&GO.GetAIData()->ObjTarget->GetObjectTranslation());
	XMVECTOR GeodePosition = GO.GetObjectTranslationVec();
	float distance = XMCVector3Length(NodePosition - GeodePosition);


	XMVECTOR GeodeVel = GO.GetForwardVec() * GEODE_MINE_MOVE_SPEED;
	if (distance <= 4.5f)
	{
		//Turn to the Mining node
		GO.TurnTo(pNode->GetObjectTranslationVec(), 6.0f);


		//Mining Effects
		//GameObject* mineEffect = GO.GetChildEffectObject(eGEODE_MINING_EFFECT);
		//mineEffect->GetEffectComponent()->ToggleEffect(true);
		//float effectRatio = (GEODE_MINE_SPEED - GO.GetAIData()->fActionCooldown) / GEODE_MINE_SPEED;
		//float colorAlpha = 0.2f + (1.0f - effectRatio)*0.8f;
		//mineEffect->SetObjectColor(XMFLOAT4(0.7f, 0.3f, 0.3f, colorAlpha), effectRatio);
		//mineEffect->SetObjectColor(XMFLOAT4(0.5f, 0.5f, 0.5f, 0.9f), effectRatio);
		//mineEffect->GetEffectComponent()->Position = XMCStoreFloat3(GO.GetObjectTranslationVec() + XMCLoadFloat3(0, 3, -3));

		GeodeVel = XMVectorZero();
		AIData * pNodeAI = pNode->GetAIData();
		GO.GetAIData()->fActionCooldown += (float)TimeManager::GetTimeDelta();
		if (GO.GetAIData()->fActionCooldown >= GEODE_MINE_SPEED)
		{
			//GO.GetChildEffectComponent(2)->Position = XMFLOAT4(GO.GetObjectTranslation().x, GO.GetObjectTranslation().y + 3.0f,
			//	GO.GetObjectTranslation().z - 3.0f, 1.0f);
			//GO.GetChildEffectComponent(2)->SetTotalTime(0.625f);

			pNode->TakeDamage(); // Default damage is 1
			GO.GetAudioComponent()->PlayAudioAtSpot(PLAY_SFX_GEODE_MINE);
			//p_mcfacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_SFX_GEODE_MINE);

			GO.GetAIData()->fActionCooldown = 0.0f;

			//They are mining at this point
			if (GO.GetType() == ObjectType::eSAPPHIREGEODE)
			{
				GO.GetAnimComponent()->SetAnimName(SAPPHIRE_ATTACK, false);
				//GO.GetAnimComponent()->SetAnimSpeed(4.0);
			}
			else if (GO.GetType() == ObjectType::eRUBYGEODE)
			{
				GO.GetAnimComponent()->SetAnimName(RUBY_ATTACK, false);
				//GO.GetAnimComponent()->SetAnimSpeed(3.0f);
			}
			else if (GO.GetType() == ObjectType::eDIAMONDGEODE)
			{
				GO.GetAnimComponent()->SetAnimName(DIAMOND_ATTACK, false);
				//GO.GetAnimComponent()->SetAnimSpeed(4.0);
			}

			//Make the node shake
			pNodeAI->fActionCooldown = 0.5f;

			//Make the node emit gem chunks
			if (pNode->GetType() == eSAPPHIRENODE || pNode->GetType() == eRUBYNODE || pNode->GetType() == eDIAMONDNODE)
			{
				pNode->GetChildEmitterComponent(eNODE_MINED_EMITTER1)->SetSpawnTimer(1.0f);
				pNode->GetChildEmitterComponent(eNODE_MINED_EMITTER2)->SetSpawnTimer(1.0f);
				pNode->GetChildEmitterComponent(eNODE_MINED_EMITTER3)->SetSpawnTimer(1.0f);
				pNode->GetChildEmitterComponent(eNODE_MINED_EMITTER4)->SetSpawnTimer(1.0f);
			}
			else
			{
			}
		}


		else if (pNodeAI->health <= 0.0f)
		{
			//Set Geode to Scan
			///Temporary check till we get effects in.
			if (pNode->GetType() != eSAPPHIREHOLDER && pNode->GetType() != eRUBYHOLDER && pNode->GetType() != eDIAMONDHOLDER &&
				pNode->GetChildPointLight(0) != nullptr && 	pNode->GetChildEmitterComponent(eNODE_SPARKS_EMITTER) != nullptr)
			{
				pNode->GetChildPointLight(0)->SetActive(false);
				pNode->GetChildEmitterComponent(eNODE_SPARKS_EMITTER)->SetSpawning(false);
			}
			else
			{
			}

			SwitchStateGeode(GO, AIData::GeScan);


			/*for (unsigned int i = 0; i < p_mcfacade->m_ObjectManager->GetGems().size(); i++)
			{
			if (((p_mcfacade->m_ObjectManager->GetGems()[i]->GetType() == ObjectType::eRUBYGEM && GO.GetAIData()->ObjTarget->GetType() == ObjectType::eRUBYNODE)
			|| (p_mcfacade->m_ObjectManager->GetGems()[i]->GetType() == ObjectType::eSAPPHIREGEM && GO.GetAIData()->ObjTarget->GetType() == ObjectType::eSAPPHIRENODE)
			|| (p_mcfacade->m_ObjectManager->GetGems()[i]->GetType() == ObjectType::eDIAMONDGEM && GO.GetAIData()->ObjTarget->GetType() == ObjectType::eDIAMONDNODE))
			&& !p_mcfacade->m_ObjectManager->GetGems()[i]->GetActive())
			{
			p_mcfacade->m_ObjectManager->GetGems()[i]->GetChildEmitterComponent(0)->SetSpawnRate(20.0f);
			p_mcfacade->m_ObjectManager->GetGems()[i]->SetActive(true);
			p_mcfacade->m_ObjectManager->GetGems()[i]->SetObjectTranslation(GO.GetAIData()->ObjTarget->GetObjectTranslation().x, 0.0f, GO.GetAIData()->ObjTarget->GetObjectTranslation().z);
			p_mcfacade->m_ObjectManager->GetGems()[i]->GetPhysicsComponent()->ActivateCollision();
			break;
			}
			}

			GO.GetAIData()->ObjTarget->GetChildGemObject()->GetChildEmitterComponent(eGEM_DEFAULT_EMITTER)->SetSpawning(true);
			GO.GetAIData()->ObjTarget->GetChildGemObject()->GetChildEmitterComponent(eGEM_SPAWN_EMITTER)->SetSpawnTimer(1.0f);
			GO.GetAIData()->ObjTarget->GetChildGemObject()->SetActive(true);
			GO.GetAIData()->ObjTarget->GetChildGemObject()->SetObjectTranslation(GO.GetAIData()->ObjTarget->GetObjectTranslation().x, 0.0f, GO.GetAIData()->ObjTarget->GetObjectTranslation().z);
			GO.GetAIData()->ObjTarget->GetChildGemObject()->GetPhysicsComponent()->ActivateCollision();
			GO.GetAIData()->ObjTarget->GetChildGemObject()->GetAIData()->cAIClockTimer.Start();*/

			XMFLOAT3 pos = pNode->GetObjectTranslation();
			pos.y = 0.0f;
			if (pNode->GetType() == eDIAMONDNODE)
				SpawnGemType(eDIAMONDGEM, pos);
			if (pNode->GetType() == eRUBYNODE)
				SpawnGemType(eRUBYGEM, pos);
			if (pNode->GetType() == eSAPPHIRENODE)
				SpawnGemType(eSAPPHIREGEM, pos);

			//Shutdown the node!
			pNode->SetActive(false);
			pNode->GetPhysicsComponent()->DeactivateCollision();

			if (pNode->GetType() != eSAPPHIREHOLDER && pNode->GetType() != eRUBYHOLDER && pNode->GetType() != eDIAMONDHOLDER)
			{
				pNode->GetChildEffectComponent(DEFAULT_EFFECT)->isEnabled = false;
			}
			else
			{


			}

			//if (pNodeAI->ObjTarget && pNodeAI->ObjTarget->GetType() == eWALL)
			//	int breakhere = 0;
		}
		//GO.GetAIData()->ObjTarget->SetAIData(data);

		//if Idle and next to the target make it's look hyper
		else
		{
			if (GO.GetType() == ObjectType::eSAPPHIREGEODE)
			{
				GO.GetAnimComponent()->SetAnimName(SAPPHIRE_IDLE, false);
				//GO.GetAnimComponent()->SetAnimSpeed(2.5);
			}
			else if (GO.GetType() == ObjectType::eRUBYGEODE)
			{
				GO.GetAnimComponent()->SetAnimName(RUBY_IDLE, false);
				//GO.GetAnimComponent()->SetAnimSpeed(2.5f);
			}
			else if (GO.GetType() == ObjectType::eDIAMONDGEODE)
			{
				GO.GetAnimComponent()->SetAnimName(DIAMOND_IDLE, false);
				//GO.GetAnimComponent()->SetAnimSpeed(2.5f);
			}
		}
	}

	//Half-space test?
	//Will be the player's 
	else
	{
		XMMATRIX iden = XMLoadFloat4x4(&pNode->GetWorldTransform());
		GO.TurnTo(&iden, GEODE_TURN_SPEED);

		//-----------------------------------------------------------------------------------------------------			

	}

	physicsGeode->SetVelocity(XMCVector2GetXZ(GeodeVel));
}
void GeodeBehavior::GeodePickup(GameObject &GO)
{
	PhysicsComponent * physicsGeode = GO.GetPhysicsComponent();

	if (GO.GetAIData()->bWaypointIsWaiting) // The geode is waiting at the point
	{
		if (GO.GetAIData()->fActionCooldown < GO.GetAIData()->cAIClockTimer.Watch())
		{
			GO.GetAIData()->fActionCooldown = 0.0f;
			GO.GetAIData()->bWaypointIsWaiting = false; //Geode is no longer waiting at the point to play error.
		}
		else
		{
			switch (GO.GetType())
			{
			case eSAPPHIREGEODE:	GO.GetAnimComponent()->SetAnimName(SAPPHIRE_IDLE, true);	break;
			case eRUBYGEODE:		GO.GetAnimComponent()->SetAnimName(RUBY_IDLE, true);		break;
			case eDIAMONDGEODE:		GO.GetAnimComponent()->SetAnimName(DIAMOND_IDLE, true);		break;
			}
		}

		GO.GetPhysicsComponent()->SetVelocity(XMFLOAT2(0, 0));
		return;
	}


	if (GO.GetAIData()->ObjTarget == nullptr || GO.GetAIData()->ObjTarget->GetActive() == false)
	{
		SwitchStateGeode(GO, AIData::GeRecall);
		return;
	}

	XMVECTOR player = XMLoadFloat3(&GO.GetAIData()->ObjTarget->GetObjectTranslation());
	XMVECTOR objTRAN = XMLoadFloat3(&GO.GetObjectTranslation());
	XMVECTOR distanceV = player - objTRAN;
	distanceV = XMVector3Length(distanceV);
	float distance;
	XMStoreFloat(&distance, distanceV);


	XMVECTOR GeodeVel = GO.GetForwardVec()*GEODE_PICKUP_SPEED;
	if (distance <= 2.0f)
	{
		GeodeVel = XMVectorZero();

		//Used to increase the count of the gems
		if (GO.GetAIData()->ObjTarget->GetType() & 9)
		{
			switch (GO.GetAIData()->ObjTarget->GetType())
			{
			case eRUBYGEM:
			{
				p_mcfacade->m_ObjectManager->GetPlayer()->GetPlayerComponent()->AddGemCount(eRUBYGEM, 1);
				GO.GetAIData()->ObjTarget->GetChildPointLight(0)->SetActive(false);
				if (!p_mcfacade->GetRubyUnlock())
				{
					p_mcfacade->SetRubyUnlock(true);
					vector<GameObject*>& Doors = p_mcfacade->m_ObjectManager->GetDoors();
					for each (GameObject* pDoor in Doors)
					{
						EventComponent* doorEvent = pDoor->GetEventComponent();
						doorEvent->TargetsRemaining--;
						if (doorEvent->TargetsRemaining == 0)
							doorEvent->Triggered = true;
					}
				}

				break;
			}
			case eSAPPHIREGEM:
				p_mcfacade->m_ObjectManager->GetPlayer()->GetPlayerComponent()->AddGemCount(eSAPPHIREGEM, 1);
				GO.GetAIData()->ObjTarget->GetChildPointLight(0)->SetActive(false);
				break;
			case eDIAMONDGEM:
			{
				p_mcfacade->m_ObjectManager->GetPlayer()->GetPlayerComponent()->AddGemCount(eDIAMONDGEM, 1);
				GO.GetAIData()->ObjTarget->GetChildPointLight(0)->SetActive(false);
				if (!p_mcfacade->GetDiamondUnlock())
				{
					p_mcfacade->SetDiamondUnlock(true);
					vector<GameObject*>& Doors = p_mcfacade->m_ObjectManager->GetDoors();
					for each (GameObject* pDoor in Doors)
					{
						EventComponent* doorEvent = pDoor->GetEventComponent();
						doorEvent->TargetsRemaining--;
						if (doorEvent->TargetsRemaining == 0)
							doorEvent->Triggered = true;
					}
				}
				break;
			}
			}

			switch (GO.GetType())
			{
			case eSAPPHIREGEODE:
				GO.GetAudioComponent()->PlayAudioFollow(PLAY_ADR_GEODE_SAFFIRE_COLLECTED_GEM);
				//p_mcfacade->PlaySound(PLAY_ADR_GEODE_SAFFIRE_COLLECTED_GEM);
				break;
			case eRUBYGEODE:
				GO.GetAudioComponent()->PlayAudioFollow(PLAY_ADR_GEODE_RUBY_COLLECTED_GEM);
				//p_mcfacade->PlaySound(PLAY_ADR_GEODE_RUBY_COLLECTED_GEM);
				break;
			case eDIAMONDGEODE:
				GO.GetAudioComponent()->PlayAudioFollow(PLAY_ADR_DIAMOND_COLLECTED_GEM);
				//p_mcfacade->PlaySound(PLAY_ADR_DIAMOND_COLLECTED_GEM);
				break;
			default:
				break;
			}
		}



		GO.GetAIData()->ObjTarget->GetChildEmitterComponent(eGEM_DEFAULT_EMITTER)->SetSpawning(false);
		GO.GetAIData()->ObjTarget->SetActive(false);
		GO.GetAIData()->ObjTarget->GetPhysicsComponent()->DeactivateCollision();
		GO.GetAIData()->ObjTarget = nullptr;

		SwitchStateGeode(GO, AIData::GeRecall);

	}
	//XMStoreFloat2(&objFloat, objVel);

	//Half-space test?
	//Will be the player's 
	else
	{
		XMMATRIX iden = XMLoadFloat4x4(&GO.GetAIData()->ObjTarget->GetWorldTransform());
		GO.TurnTo(&iden, GEODE_TURN_SPEED);


		//-----------------------------------------------------------------------------------------------------			
	}

	physicsGeode->SetVelocity(XMCVector2GetXZ(GeodeVel));
}
void GeodeBehavior::GeodeDeath(GameObject &GO)
{
	AIData * data = GO.GetAIData();
	data->fActionCooldown += TimeManager::GetTimeDelta();

	float fTime = GO.GetAnimComponent()->GetCurrAnimation()->GetAnimTime();
	if (data->fActionCooldown >= fTime)
	{
		GO.SetObjectTranslation(GO.GetObjectTranslation().x, GO.GetObjectTranslation().y - 1.0f * TimeManager::GetTimeDelta(), GO.GetObjectTranslation().z);
	}

	if (data->fActionCooldown >= DEATH_TIMER)
	{
		//Reset to their default state.
		if (GO.GetType() == ObjectType::eSAPPHIREGEODE)
			GO.GetAnimComponent()->SetAnimName(SAPPHIRE_IDLE, true);
		else if (GO.GetType() == ObjectType::eRUBYGEODE)
			GO.GetAnimComponent()->SetAnimName(RUBY_IDLE, true);
		else if (GO.GetType() == ObjectType::eDIAMONDGEODE)
			GO.GetAnimComponent()->SetAnimName(DIAMOND_IDLE, true);

		GO.GetAnimComponent()->SetIsDeathAnim(false);
		GO.GetAIData()->health = 1;
		GO.SetActive(false);
		data->fActionCooldown = 0.0f;
	}
}

void GeodeBehavior::GeodeStuck(GameObject &GO)
{


	//XMMATRIX GOhere = XMLoadFloat4x4(&GO.GetWorldTransform());
	//XMVECTOR geodeSpeed = XMVector3NormalizeEst(GOhere.r[2]) * GEODE_SEND_SPEED;
	//XMFLOAT2 geodeVel = XMCVector2GetXZ(geodeSpeed);
	//geodeVel = XMFLOAT2(0.0f, 0.0f);
	XMFLOAT2 geodeVel = XMFLOAT2(0.0f, 0.0f);
	GO.GetPhysicsComponent()->SetVelocity(geodeVel);
	GO.GetAIData()->fActionCooldown += (float)TimeManager::GetTimeDelta();
	if (GO.GetAIData()->fActionCooldown >= 2.0f)
	{
		//stuckGeode = false;
		GO.GetAIData()->fActionCooldown = 0.0f;
		SwitchStateGeode(GO, GO.GetAIData()->GeRecall);
	}
}

void GeodeBehavior::GeodeVictory(GameObject &GO)
{
	AIData* pGeodeAI = GO.GetAIData();
	CAnimComponent* pGeodeAnim = GO.GetAnimComponent();

	PhysicsComponent* pGeodePhysics = GO.GetPhysicsComponent();
	pGeodePhysics->SetForwardVelocity(0);

	XMVECTOR CameraPos = p_mcfacade->GetCameraPosition();
	CameraPos = XMVectorSetY(CameraPos, 0.0f);
	GO.TurnTo(CameraPos, GEODE_TURN_SPEED);

	pGeodeAI->fActionCooldown += TimeManager::GetTimeDelta();

	if (!pGeodeAI->bEnemySpecialA)
	{
		pGeodeAI->fActionCooldown = 0.0f;
		pGeodeAI->bEnemySpecialA = true;
	}
	//if (pGeodeAI->fActionCooldown > 0)
	//{
	//	XMFLOAT3 GeodePos = GO.GetObjectTranslation();
	//	GeodePos.y = max(0.0f, 4.0f*sin(2.0f*XM_2PI*pGeodeAI->fActionCooldownB) - 1); // Hopping motion
	//	GO.SetObjectTranslation(GeodePos);
	//}
	else if (pGeodeAI->fActionCooldown >= 2.0f)
	{
		XMFLOAT3 GeodePos = GO.GetObjectTranslation();
		GeodePos.y = 0;
		GO.SetObjectTranslation(GeodePos);

		switch (GO.GetType())
		{
		case eSAPPHIREGEODE:	GO.GetAnimComponent()->SetAnimName(SAPPHIRE_IDLE, true);	break;
		case eRUBYGEODE:		GO.GetAnimComponent()->SetAnimName(RUBY_IDLE, true);		break;
		case eDIAMONDGEODE:		GO.GetAnimComponent()->SetAnimName(DIAMOND_IDLE, true);		break;
		}

		SwitchStateGeode(GO, AIData::GeScan);
	}

}

void GeodeBehavior::GeodeTrap(GameObject &GO)
{
	AIData& geode_data = *GO.GetAIData();

	if (geode_data.bEnemySpecialA) //Worm Trap
	{
		XMVECTOR trap_pos = geode_data.ObjTarget->GetObjectTranslationVec();
		XMVECTOR geode_pos = GO.GetObjectTranslationVec();
		XMVECTOR toVector = trap_pos - geode_pos;
		float dist = XMCVector2Dot(XMCVector3SwizzleXZ(toVector), XMCVector3SwizzleXZ(toVector));

		if (dist > 4.0f)
		{
			GO.GetPhysicsComponent()->SetVelocity({ 0, 0 });
			XMVECTOR vel = XMVector3Normalize(toVector) * dist;
			GO.SetObjectTranslation(geode_pos + vel * TimeManager::GetTimeDelta());
		}
		else if (XMVectorGetY(geode_pos) > -10.0f)
		{
			GO.SetObjectTranslation(geode_pos - XMCLoadFloat3(0, 10.0f * TimeManager::GetTimeDelta(), 0));
		}
		else
		{
			GO.TakeDamage();
			SwitchStateGeode(GO, AIData::GeDeath);
		}
	}
}



void GeodeBehavior::SwitchStateGeode(GameObject& GO, AIData::GeodeState state)
{
	AIData& pGeodeAI = *GO.GetAIData();
	PhysicsComponent* pGeodePhysics = GO.GetPhysicsComponent();
	CAnimComponent* pGeodeAnim = GO.GetAnimComponent();
	GO.GetAnimComponent()->SetAnimSpeed(1.0f);
	//pGeodeAI->fActionCooldown = 0.0f;
	pGeodePhysics->SetMass(GEODE_MASS_DEFAULT);

	string animationName = "";
	bool animationLoop = false;

	//Was it picking something up before.
	if (GO.GetAIData()->geodeState == AIData::GePickup && GO.GetAIData()->ObjTarget != nullptr)
	{
		//Forget about picking up the obj and turn the other way.
		GO.GetAIData()->ObjTarget->GetAIData()->bAttacked = false;
		GO.GetAIData()->ObjTarget = nullptr;
	}

	switch (state)
	{
	case AIData::GeAttack:
	{
		GO.GetChildEffectComponent(eGEODE_ENEMYFOUND_EFFECT)->ToggleEffect(true, 1.0f);
		pGeodeAI.fActionCooldown = 0;
		GO.GetPhysicsComponent()->SetMass(GEODE_MASS_ATTACK);
		animationLoop = true;
		switch (GO.GetType())
		{
		case eSAPPHIREGEODE:	animationName = SAPPHIRE_MOVE;	break;
		case eRUBYGEODE:		animationName = RUBY_MOVE;		break;
		case eDIAMONDGEODE:		animationName = DIAMOND_MOVE;	break;
		}
	}
		break;
	case AIData::GeMine:
	{
		//GO.GetChildEffectComponent(eGEODE_NODEFOUND_EFFECT)->ToggleEffect(true, 1.0f);

		animationLoop = true;
		switch (GO.GetType())
		{
		case eSAPPHIREGEODE:	animationName = SAPPHIRE_IDLE;	break;
		case eRUBYGEODE:		animationName = RUBY_IDLE;		break;
		case eDIAMONDGEODE:		animationName = DIAMOND_IDLE;	break;
		}

	}
		break;
	case AIData::GePickup:
	{
		animationLoop = true;
		switch (GO.GetType())
		{
		case eSAPPHIREGEODE:	animationName = SAPPHIRE_IDLE;	break;
		case eRUBYGEODE:		animationName = RUBY_IDLE;		break;
		case eDIAMONDGEODE:		animationName = DIAMOND_IDLE;	break;
		}

		if (GO.GetAIData()->geodeState == AIData::GeScan)
		{
			GO.GetChildEffectComponent(eGEODE_PICKUP_EFFECT)->ToggleEffect(true, 1.0f);

			//Error animation when it found nothing todo
			animationLoop = true;
			switch (GO.GetType())
			{
			case eSAPPHIREGEODE:	animationName = SAPPHIRE_ATTACK;	break;
			case eRUBYGEODE:		animationName = RUBY_ATTACK;		break;
			case eDIAMONDGEODE:		animationName = DIAMOND_ATTACK;		break;
			}

			GO.GetAIData()->cAIClockTimer.Start();
			GO.GetAIData()->bWaypointIsWaiting = true; //Geode is waiting at the point to play error.
			GO.GetAIData()->fActionCooldown = GO.GetAnimComponent()->GetCurrAnimation()->GetAnimTime();
		}

	}
		break;
	case AIData::GeSend:
	{
		GO.SetObjectColor(XMFLOAT4(0.25f, 1.0f, 0.25f, 1.0f));
		GO.SetReactionTime(0.25f);

		GO.GetPhysicsComponent()->SetMass(GEODE_MASS_SEND);
		animationLoop = true;
		switch (GO.GetType())
		{
		case eSAPPHIREGEODE:
			animationName = SAPPHIRE_MOVE;
			GO.GetAudioComponent()->PlayAudioFollow(PLAY_ADR_GEODE_SAFFIRE_SEND);
			//p_mcfacade->PlaySound(PLAY_ADR_GEODE_SAFFIRE_SEND);
			break;
		case eRUBYGEODE:
			animationName = RUBY_MOVE;
			GO.GetAudioComponent()->PlayAudioFollow(PLAY_ADR_GEODE_RUBY_SEND);
			//p_mcfacade->PlaySound(PLAY_ADR_GEODE_RUBY_SEND);
			break;
		case eDIAMONDGEODE:
			animationName = DIAMOND_MOVE;
			GO.GetAudioComponent()->PlayAudioFollow(PLAY_ADR_GEODE_DIAMOND_SEND);
			//p_mcfacade->PlaySound(PLAY_ADR_GEODE_DIAMOND_SEND);
			break;
		}

		GO.GetChildEffectComponent(eGEODE_SEND_EFFECT)->ToggleEffect(true);
		GO.GetChildEffectComponent(eGEODE_SEND_EFFECT)->Position = XMCStoreFloat3(GO.GetObjectTranslationVec() + XMCLoadFloat3(0, 6, 0));




		GameObject* pPlayer = p_mcfacade->GetObjectManager()->GetPlayer();
		GameObject* pReticle = p_mcfacade->GetObjectManager()->GetReticle();
		XMVECTOR PlayerPos = pPlayer->GetObjectTranslationVec();
		XMVECTOR ReticlePos = pReticle->GetObjectTranslationVec();
		XMVECTOR SendDirection = XMVector3Normalize(ReticlePos - PlayerPos);
		XMVECTOR PlayerAhead = PlayerPos + 2.0f*SendDirection;

		pGeodePhysics->SetPosition(XMCVector2GetXZ(PlayerAhead));
		GO.LookAt(SendDirection);
		pGeodePhysics->SetForwardVelocity(GEODE_SEND_SPEED);


		pGeodeAI.WayPoints.clear();
		pGeodeAI.WayPoints.push_back(XMCStoreFloat3(PlayerPos));
		pGeodeAI.WayPoints.push_back(XMCStoreFloat3(ReticlePos));

	}
		break;
	case AIData::GeRecall:
	{
		animationLoop = true;
		switch (GO.GetType())
		{
		case eSAPPHIREGEODE:	animationName = SAPPHIRE_IDLE;	break;
		case eRUBYGEODE:		animationName = RUBY_IDLE;		break;
		case eDIAMONDGEODE:		animationName = DIAMOND_IDLE;	break;
		}
		GameObject* pPlayer = p_mcfacade->m_ObjectManager->GetPlayer();
		XMVECTOR PlayerForward = pPlayer->GetForwardVec();

		XMVECTOR PlayerPos = pPlayer->GetObjectTranslationVec();
		XMVECTOR Destination = PlayerPos - 10 * PlayerForward;
		NavAgent* pNavAgent = GO.GetNavAgent();
		XMVECTOR GeodePos = GO.GetObjectTranslationVec();

		pNavAgent->Begin(XMCVector2GetXZ(GeodePos), XMCVector2GetXZ(Destination));

		if (GO.GetAIData()->geodeState == AIData::GeScan)
		{
			// Need multiple sounds

			GO.GetChildEffectComponent(eGEODE_CONFUSION_EFFECT)->Position = XMCStoreFloat3(GO.GetObjectTranslationVec() + XMCLoadFloat3(0, 6, 0));
			GO.GetChildEffectComponent(eGEODE_CONFUSION_EFFECT)->ToggleEffect(true, 1.0f);
			//GO.GetChildEffectComponent(4)->SetTotalTime(1.0f);

			//Error animation when it found nothing todo
			animationLoop = false;
			switch (GO.GetType())
			{
			case eSAPPHIREGEODE:
				animationName = SAPPHIRE_ATTACK;
				GO.GetAudioComponent()->PlayAudioFollow(PLAY_ADR_GEODE_SAFFIRE_COMMAND_FAILED);
				//p_mcfacade->PlaySound(PLAY_ADR_GEODE_SAFFIRE_COMMAND_FAILED);
				break;
			case eRUBYGEODE:
				animationName = RUBY_ATTACK;
				GO.GetAudioComponent()->PlayAudioFollow(PLAY_ADR_GEODE_RUBY_COMMAND_FAILED);
				//p_mcfacade->PlaySound(PLAY_ADR_GEODE_RUBY_COMMAND_FAILED);
				break;
			case eDIAMONDGEODE:
				animationName = DIAMOND_ATTACK;
				GO.GetAudioComponent()->PlayAudioFollow(PLAY_ADR_GEODE_DIAMOND_COMMAND_FAILED);
				//p_mcfacade->PlaySound(PLAY_ADR_GEODE_DIAMOND_COMMAND_FAILED);
				break;
			}

			GO.GetAIData()->cAIClockTimer.Start();
			GO.GetAIData()->bWaypointIsWaiting = true; //Geode is waiting at the point to play error.
			GO.GetAIData()->fActionCooldown = GO.GetAnimComponent()->GetCurrAnimation()->GetAnimTime();
		}
	}
		break;
	case AIData::GeFollowing:
	{
		//GO.GetPhysicsComponent()->SetMass(10.0f);
		animationLoop = true;
		switch (GO.GetType())
		{
		case eSAPPHIREGEODE:	animationName = SAPPHIRE_IDLE;	break;
		case eRUBYGEODE:		animationName = RUBY_IDLE;		break;
		case eDIAMONDGEODE:		animationName = DIAMOND_IDLE;	break;
		}

	}
		break;
	case AIData::GeFear:
	{
		animationLoop = true;
		pGeodeAI.fActionCooldown = 0.0f;

		switch (GO.GetType())
		{
		case eSAPPHIREGEODE:
			animationName = SAPPHIRE_MOVE;
			//p_mcfacade->PlaySound();
			break;
		case eRUBYGEODE:
			animationName = RUBY_MOVE;
			//p_mcfacade->PlaySound();
			GO.GetAudioComponent()->PlayAudioFollow(PLAY_ADR_GEODE_RUBY_FEARED);
			break;
		case eDIAMONDGEODE:
			animationName = DIAMOND_MOVE;
			//p_mcfacade->PlaySound();
			GO.GetAudioComponent()->PlayAudioFollow(PLAY_ADR_GEODE_DIAMOND_FEARED);
			break;
		}
	}
		break;
	case AIData::GeStun:
	{
		animationLoop = true;
		switch (GO.GetType())
		{
		case eSAPPHIREGEODE:
			animationName = SAPPHIRE_MOVE;
			GO.GetAudioComponent()->PlayAudioFollow(PLAY_ADR_GEODE_SAFFIRE_STUNNED);
			break;
		case eRUBYGEODE:
			animationName = RUBY_MOVE;
			break;
		case eDIAMONDGEODE:
			animationName = DIAMOND_MOVE;
			GO.GetAudioComponent()->PlayAudioFollow(PLAY_ADR_GEODE_DIAMOND_STUNNED);
			break;
		}
	}
		break;
	case AIData::GeKnockback:
	{
		animationLoop = true;
		switch (GO.GetType())
		{
		case eSAPPHIREGEODE:
			animationName = SAPPHIRE_MOVE;
			GO.GetAudioComponent()->PlayAudioFollow(PLAY_ADR_GEODE_SAFFIRE_KNOCKBACK);
			break;
		case eRUBYGEODE:
			animationName = RUBY_MOVE;
			GO.GetAudioComponent()->PlayAudioFollow(PLAY_ADR_GEODE_RUBY_KNOCKBACK);
			break;
		case eDIAMONDGEODE:
			animationName = DIAMOND_MOVE;
			break;
		}
	}
		break;
	case AIData::GeScan:
	{
		GO.GetChildEffectComponent(eGEODE_SEND_EFFECT)->ToggleEffect(false);

		GO.GetPhysicsComponent()->SetMass(GEODE_MASS_SCAN);
		animationLoop = true;
		switch (GO.GetType())
		{
		case eSAPPHIREGEODE:
			animationName = SAPPHIRE_IDLE;
			//p_mcfacade->PlaySound(PLAY_ADR_GEODE_SAFFIRE_IDLE_HOVER);
			break;
		case eRUBYGEODE:
			animationName = RUBY_IDLE;
			//p_mcfacade->PlaySound(PLAY_ADR_GEODE_RUBY_IDLE_HOVER);
			break;
		case eDIAMONDGEODE:
			animationName = DIAMOND_IDLE;
			//p_mcfacade->PlaySound(PLAY_ADR_GEODE_DIAMOND_IDLE_HOVER);
			break;
		}
		GO.GetAIData()->cAIClockTimer.Start();
	}
		break;
	case AIData::GeDeath:
	{
		GO.GetAnimComponent()->StopTransition();
		GO.GetAnimComponent()->SetIsDeathAnim(true);

		pGeodeAI.fActionCooldown = 0.0f;
		GO.GetPhysicsComponent()->SetVelocity(XMFLOAT2(0, 0));

		GO.GetPhysicsComponent()->DeactivateCollision();

		EffectComponent * pGeodeDeathEffect = GO.GetChildEffectComponent(eGEODE_DEATH_EFFECT);
		pGeodeDeathEffect->ToggleEffect(true, 1.0f);

		PlayerComponent* pPlayerComp = p_mcfacade->m_ObjectManager->GetPlayer()->GetPlayerComponent();
		//Used to reduce the count of the geodes
		switch (GO.GetType())
		{
		case eRUBYGEODE:
			animationName = RUBY_DEATH;
			GO.GetAudioComponent()->PlayAudioFollow(PLAY_ADR_GEODE_RUBY_DEATH);
			//p_mcfacade->PlaySound(PLAY_ADR_GEODE_RUBY_DEATH);
			pPlayerComp->AddGeodeCount(eRUBYGEODE, -1);
			break;
		case eSAPPHIREGEODE:
			pPlayerComp->AddGeodeCount(eSAPPHIREGEODE, -1);
			GO.GetAudioComponent()->PlayAudioFollow(PLAY_ADR_GEODE_SAFFIRE_DEATH);
			//p_mcfacade->PlaySound(PLAY_ADR_GEODE_SAFFIRE_DEATH);
			animationName = SAPPHIRE_DEATH;
			break;
		case eDIAMONDGEODE:
			animationName = DIAMOND_DEATH;
			GO.GetAudioComponent()->PlayAudioFollow(PLAY_ADR_GEODE_DIAMOND_DEATH);
			//p_mcfacade->PlaySound(PLAY_ADR_GEODE_DIAMOND_DEATH);
			pPlayerComp->AddGeodeCount(eDIAMONDGEODE, -1);
			break;
		}

	}
		break;
	case AIData::GeStuck:
		GO.GetChildEffectComponent(eGEODE_WEBTRAPPED_EFFECT)->Position = XMCStoreFloat3(GO.GetObjectTranslationVec() + XMCLoadFloat3(0, 3, -3));
		GO.GetChildEffectComponent(eGEODE_WEBTRAPPED_EFFECT)->ToggleEffect(true, 2.0f);
		GO.GetAnimComponent()->SetAnimSpeed(0.0f);
		break;
	case AIData::GeVictory:
		pGeodeAI.fActionCooldown = 0;
		pGeodeAI.bEnemySpecialA = false;
		GO.GetAnimComponent()->StopTransition();
		switch (GO.GetType())
		{
		case eSAPPHIREGEODE:
			animationName = SAPPHIRE_DANCE;
			GO.GetAudioComponent()->PlayAudioFollow(PLAY_ADR_GEODE_SAFFIRE_VICTORY);
			//p_mcfacade->PlaySound(PLAY_ADR_GEODE_SAFFIRE_VICTORY);
			break;
		case eRUBYGEODE:
			animationName = RUBY_DANCE;
			GO.GetAudioComponent()->PlayAudioFollow(PLAY_ADR_GEODE_RUBY_VICTORY);
			//p_mcfacade->PlaySound(PLAY_ADR_GEODE_RUBY_VICTORY);
			break;
		case eDIAMONDGEODE:
			animationName = DIAMOND_DANCE;
			GO.GetAudioComponent()->PlayAudioFollow(PLAY_ADR_GEODE_DIAMOND_VICTORY);
			//p_mcfacade->PlaySound(PLAY_ADR_GEODE_DIAMOND_VICTORY);
			break;
		}
		break;
	}

	if (!animationName.empty())
		pGeodeAnim->SetAnimName(animationName, animationLoop);
	pGeodeAI.geodeState = state;

}


XMVECTOR GeodeBehavior::Separation(GameObject &GO, vector<GameObject*>& objects,
	const float separationStrength,
	const float safeDist,
	const float maxSeparation)
{

	XMVECTOR separationImpulse = XMVectorZero();
	XMVECTOR thisPos = GO.GetObjectTranslationVec();
	float thisRadius = dynamic_cast<Circle*>(GO.GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE))->GetRadius();

	for (size_t i = 0; i < objects.size(); i++)
	{
		GameObject* pObject = objects[i];
		if (pObject == &GO) continue;
		if (pObject->GetActive() == false) continue;


		float otherMass = pObject->GetPhysicsComponent()->GetMass();
		float otherRadius = dynamic_cast<Circle*>(pObject->GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE))->GetRadius();

		XMVECTOR otherPos = XMLoadFloat3(&pObject->GetObjectTranslation());
		XMVECTOR toOther = otherPos - thisPos;
		float separation = XMCVector3Length(toOther);
		if (separation == 0.0f)
			separation = EPSILON;

		toOther /= separation;

		CheckVector(toOther);

		separation -= thisRadius + otherRadius;

		separation = max(EPSILON_DIST, separation);

		// y = a - 2a/s x + a/s2 x2
		// s = safeDist
		// a = maxSeparation

		if (separation < safeDist)
		{
			const float &a = separationStrength, &s = safeDist, &x = separation;
			float I = a - 2 * a*x / s + a*x*x / (s*s);
			separationImpulse -= toOther*I;
		}
	}

	separationImpulse = XMVector3ClampLength(separationImpulse, 0.0f, maxSeparation);

	CheckVector(separationImpulse);

	return separationImpulse;
}


void GeodeBehavior::Avoidance(GameObject& GO)
{
#if 0 //Outdated
	PhysicsComponent* pGeodePhysics = GO.GetPhysicsComponent();
	Segment* lefSegment = dynamic_cast<Segment*>(pGeodePhysi	cs->GetCollisionShape(SU_TURNSEGL));
	Segment* rigSegment = dynamic_cast<Segment*>(pGeodePhysics->GetCollisionShape(SU_TURNSEGR));

	const list<CollisionShape*>& detectedShapesRight = rigSegment->GetDetectedShapes();
	float minDistLeft = FLT_MAX;
	float minDistRight = FLT_MAX;
	for ( auto it = detectedShapesRight.cbegin(); it != detectedShapesRight.cend(); ++it )
	{
		CollisionShape* pDetectedShape = *it;
		if( pDetectedShape->WillResolveWith(rigSegment) == false )
			continue;
		minDistLeft = 0;
		/*
		Circle* pDetectedCircle = dynamic_cast<Circle*>(pDetectedShape);
		GameObject* pDetectedObject = pDetectedShape->GetGameObjectHolder();
		XMVECTOR DetectedPos = pDetectedCircle->GetPosition();
		float DetectedRadius = pDetectedCircle->GetRadius();
		XMVECTOR SegmentDir = XMVector2Normalize( XMCVector3SwizzleXZ(rigSegment->GetRotatedExtent()) );
		XMVECTOR SegmentPos = rigSegment->GetPosition();

		XMVECTOR intersection = IntersectRaySphere(DetectedPos, DetectedRadius,SegmentDir, SegmentPos );

		float distance = XMCVector3Length(intersection - SegmentPos);
		minDistLeft = min(minDistLeft, distance);
		*/
	}

	const list<CollisionShape*>& detectedShapesLeft = lefSegment->GetDetectedShapes();
	for (auto it = detectedShapesLeft.cbegin(); it != detectedShapesLeft.cend(); ++it)
	{
		CollisionShape* pDetectedShape = *it;
		if (pDetectedShape->WillResolveWith(lefSegment) == false)
			continue;
		minDistRight = 0;
	}

	if (minDistRight < minDistLeft)
		GO.TurnRight(GEODE_TURN_SPEED);
	else if (minDistLeft < minDistRight)
		GO.TurnRight(-GEODE_TURN_SPEED);
	else if (minDistLeft != FLT_MAX && minDistRight != FLT_MAX)
		GO.TurnRight(-GEODE_TURN_SPEED);

#endif
}

bool GeodeBehavior::DetectCollisions(GameObject& GO)
{
	GameObject* pGeode = &GO;
	AIData* pGeodeAI = GO.GetAIData();

	if (pGeodeAI->geodeState == AIData::GeDeath)
		return false;

	XMVECTOR targetPos = XMLoadFloat3(&pGeodeAI->fTargetPos);
	XMVECTOR geodePos = XMLoadFloat3(&pGeode->GetObjectTranslation());
	XMVECTOR toTarget = XMVector3Normalize(targetPos - geodePos);

	auto detectedObjects = pGeode->GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE)->GetDetectedShapes();
	GameObject* detectedObject = NULL;

	ObjectType detectedType;
	for (auto it = detectedObjects.cbegin(); it != detectedObjects.cend(); ++it)
	{
		//if bounding shape
		if ((*it)->GetShapeUsage() != SU_BOUNDING_SHAPE)
			continue;

		GameObject* currObject = (*it)->GetGameObjectHolder();
		ObjectType currentType = currObject->GetType();

		if (!currObject->GetActive() && currentType != eWALL)
			continue;

		switch (currentType)
		{
		case ePLAYER:
		case eRUBYGEODE:
		case eSAPPHIREGEODE:
		case eDIAMONDGEODE:
			continue;
		default:
			break;
		}

		detectedObject = currObject;
		detectedType = currObject->GetType();
	}

	if (!detectedObject)
		return false;

	pGeode->GetChildEffectComponent(eGEODE_SEND_EFFECT)->ToggleEffect(false);

	switch (detectedType)
	{
	case eSPIDER:
	case eGOLEM:
	case eWORM:
	{
		pGeode->GetAIData()->fActionCooldown = 100.0f;
		pGeodeAI->ObjTarget = detectedObject;
		SwitchStateGeode(*pGeode, AIData::GeAttack);
		break;
	}
	case eRUBYHOLDER:
	case eSAPPHIREHOLDER:
	case eDIAMONDHOLDER:
	{
		pGeodeAI->ObjTarget = detectedObject;
		SwitchStateGeode(*pGeode, AIData::GeMine);
		break;
	}
	case eRUBYNODE:
	case eSAPPHIRENODE:
	case eDIAMONDNODE:
	{
		if (CanGather(pGeode->GetType(), detectedType))
		{
			pGeodeAI->ObjTarget = detectedObject;
			SwitchStateGeode(*pGeode, AIData::GeMine);
		}
		else
		{
			SwitchStateGeode(*pGeode, AIData::GeRecall);

			pGeode->GetChildEffectComponent(eGEODE_CONFUSION_EFFECT)->Position = XMCStoreFloat3(GO.GetObjectTranslationVec() + XMCLoadFloat3(0, 6, 0));
			pGeode->GetChildEffectComponent(eGEODE_CONFUSION_EFFECT)->ToggleEffect(true, 1.0f);
			//pGeode->GetChildEffectComponent(4)->SetTotalTime(1.0f);

			//Error animation when it found nothing todo
			if (pGeode->GetType() == ObjectType::eSAPPHIREGEODE)
			{
				pGeode->GetAnimComponent()->SetAnimName(SAPPHIRE_ATTACK, false);
				GO.GetAudioComponent()->PlayAudioFollow(PLAY_ADR_GEODE_SAFFIRE_COMMAND_FAILED);
				//p_mcfacade->PlaySound(PLAY_ADR_GEODE_SAFFIRE_COMMAND_FAILED);
			}
			else if (pGeode->GetType() == ObjectType::eRUBYGEODE)
			{
				pGeode->GetAnimComponent()->SetAnimName(RUBY_ATTACK, false);
				GO.GetAudioComponent()->PlayAudioFollow(PLAY_ADR_GEODE_RUBY_COMMAND_FAILED);
				//p_mcfacade->PlaySound(PLAY_ADR_GEODE_RUBY_COMMAND_FAILED);
			}
			else if (pGeode->GetType() == ObjectType::eDIAMONDGEODE)
			{
				pGeode->GetAnimComponent()->SetAnimName(DIAMOND_ATTACK, false);
				GO.GetAudioComponent()->PlayAudioFollow(PLAY_ADR_GEODE_DIAMOND_COMMAND_FAILED);
				//p_mcfacade->PlaySound(PLAY_ADR_GEODE_DIAMOND_COMMAND_FAILED);
				p_mcfacade->GetSoundManager()->GetAudioSystem();
			}
			pGeode->GetAIData()->cAIClockTimer.Start();
			pGeode->GetAIData()->bWaypointIsWaiting = true; //Geode is waiting at the point to play error.
			pGeode->GetAIData()->fActionCooldown = pGeode->GetAnimComponent()->GetCurrAnimation()->GetAnimTime() + 0.5f;
		}
	}break;
	case eRUBYGEM:
	case eSAPPHIREGEM:
	case eDIAMONDGEM:
		pGeodeAI->ObjTarget = detectedObject;
		SwitchStateGeode(*pGeode, AIData::GePickup);
		break;
	case ePLAYER:
	case eRETICLE:
		break;
	case eSPIDER_WEB:
		//geodeVel = XMFLOAT2(0.0f, 0.0f);
		if (detectedObject->GetTrapComponent()->GetEnabled())
			SwitchStateGeode(*pGeode, AIData::GeStuck);
		else
			SwitchStateGeode(*pGeode, AIData::GeRecall);
		break;
	default:

		pGeode->GetChildEffectComponent(eGEODE_CONFUSION_EFFECT)->Position = XMCStoreFloat3(pGeode->GetObjectTranslationVec() + XMCLoadFloat3(0, 6, 0));
		pGeode->GetChildEffectComponent(eGEODE_CONFUSION_EFFECT)->ToggleEffect(true, 1.0f);
		SwitchStateGeode(*pGeode, AIData::GeRecall);
		break;
	}

	return true;
}

void GeodeBehavior::GeodeIdle(GameObject& GO)
{
	CollisionShape* tempShape = p_mcfacade->GetObjectManager()->GetPlayer()->GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE);
	if (GO.GetPhysicsComponent()->GetCollisionShape(SU_SCANNER)->Collides(tempShape) && (!p_mcfacade->GetObjectManager()->GetPlayer()->GetPlayerComponent()->GetElevatorMove()))
	{
		SwitchStateGeode(GO, AIData::GeFollowing);
	}

	else
	{
		GameObject* player = p_mcfacade->GetObjectManager()->GetPlayer();
		GO.GetPhysicsComponent()->SetVelocity(XMFLOAT2(0.0f, 0.0f));
		GO.GetPhysicsComponent()->SetForwardVelocity(0.0f);
		XMFLOAT3 temp;
		//XMVECTOR playerNormF = XMVector3Normalize(player->GetForwardVec());
		XMStoreFloat3(&temp, player->GetForwardVec());
		
		if (p_mcfacade->GetObjectManager()->GetPlayer()->GetPlayerComponent()->GetElevatorMove())
			GO.SetObjectTranslation(player->GetObjectTranslation().x - temp.x, 0.0f, player->GetObjectTranslation().z + temp.z * 10.0f);
	}
}

bool GeodeBehavior::SpawnGemType(ObjectType _gemType, XMFLOAT3 _pos)
{
	vector<GameObject *> gems = p_mcfacade->GetObjectManager()->GetGems();
	for (size_t i = 0; i < gems.size(); i++)
	{
		if (!gems[i]->GetActive() && gems[i]->GetType() == _gemType)
		{
			gems[i]->GetChildPointLight(0)->SetActive(true);
			gems[i]->GetChildEmitterComponent(eGEM_DEFAULT_EMITTER)->SetSpawning(true);
			//gems[i]->GetChildEmitterComponent(eGEM_SPAWN_EMITTER)->SetSpawnTimer(1.0f);
			gems[i]->SetActive(true);
			gems[i]->SetObjectTranslation(_pos);
			gems[i]->GetPhysicsComponent()->ActivateCollision();
			gems[i]->GetAIData()->bAttacked = false;

			float g = -9.8f;
			float t = UnitRand() * 2.0f;
			XMFLOAT3 P = XMFLOAT3(_pos.x + SignedUnitRand() * 5.0f, _pos.y, _pos.z + SignedUnitRand() * 5.0f);
			XMFLOAT3 O = _pos;

			XMFLOAT3 Vo;

			gems[i]->GetAIData()->fJumpingPoint = _pos;
			Vo.x = (P.x - O.x) / t;
			Vo.z = (P.z - O.z) / t;
			Vo.y = -(P.y + ((0.5f * g) * (t * t)) - O.y) / t;

			gems[i]->GetAIData()->fTempVel = Vo;
			gems[i]->GetAIData()->fActionCooldownB = t;

			return true;
		}
	}

	return false;
}