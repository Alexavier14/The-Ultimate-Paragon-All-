#pragma once

#include "../Application/stdafx.h"

using namespace PackedVector;

class CoreFacade;

enum TileAttribute { TA_BLOCKED = 1, TA_OCCUPIED = 2 };
struct SearchTile
{
	// TODO: reduce to 2 bits
	
	// bit 0 = blocked: 0 for free tiles, 1 for blocked tiles (e.g. by walls)
	// bit 1 = occupied: 0 for free tiles, 1 for occupied tiles (e.g. by enemies)
	int status; 
	SearchTile() : status(0) {} 
	void Clear() { status = 0; }
};

class NavMesh
{
	CoreFacade* m_pCoreFacade;

	XMSHORT2 m_MeshSize; // The dimensions of the array of tiles
	const XMFLOAT2 m_TileSize; // The width and height of each tile in world space
	XMFLOAT2 m_MapSize; // The widht and height of the map in world space 
	XMFLOAT2 m_MapCenter; // The center point(x,z) of the map in world space
	SearchTile* m_Mesh;
	SearchTile invalidTile;

	public:
	NavMesh();
	~NavMesh();

	void CreateMap(const XMSHORT2& tileSize);
	void Initialize(CoreFacade* pCoreFacade);
	void Shutdown();
	void Update();
	
	XMSHORT2 GetTile(const XMFLOAT2& pos);
	XMSHORT2 GetTile(const XMVECTOR& pos);
	SearchTile& GetTile(const XMSHORT2& tile);
	SearchTile& GetTile(float tileX, float tileY);
	XMFLOAT2 GetPosition( const XMSHORT2& tile )const;

	XMVECTOR GetTileSize() const;

};

