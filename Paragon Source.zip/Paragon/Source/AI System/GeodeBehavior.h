#ifndef GEODEBEHAVIOR_H_
#define GEODEBEHAVIOR_H_


#include "../Application/stdafx.h"
#include "../Object Manager/AIData.h"


class GameObject;
class CoreFacade;
extern enum ObjectType;

//Geode Effects should be ordered in the same way as the Enums and vice versa
//**WARNING** 
//If enums are not in the same order as the effects
//that are loaded in, then the enums will not
//correspond with the correct effects
enum GeodeEffectType {
eGEODE_SEND_EFFECT,
//eGEODE_ATTACK_EFFECT,
eGEODE_SUPERATTACK_EFFECT,
eGEODE_DEATH_EFFECT,
eGEODE_PICKUP_EFFECT,
//eGEODE_MINING_EFFECT,
eGEODE_STUN_EFFECT,
eGEODE_FEAR_EFFECT,
eGEODE_KNOCKBACK_EFFECT,
eGEODE_SCAN_EFFECT,
eGEODE_CONFUSION_EFFECT,
eGEODE_ENEMYFOUND_EFFECT,
//eGEODE_NODEFOUND_EFFECT,
eGEODE_WEBTRAPPED_EFFECT,
eGEODE_BARRIER_EFFECT,
};
enum NodeEmitterType {
	eNODE_MINED_EMITTER1,
	eNODE_MINED_EMITTER2,
	eNODE_MINED_EMITTER3,
	eNODE_MINED_EMITTER4,
	eNODE_SPARKS_EMITTER,
	eNODE_MINED_DUST,
};

enum GemEmitterType {
	eGEM_DEFAULT_EMITTER,
	eGEM_SPAWN_EMITTER,
};

class GeodeBehavior
{
	CoreFacade * p_mcfacade;
	//bool stuckGeode;
public:
	GeodeBehavior(CoreFacade * p_mcfacade);
	~GeodeBehavior();
	void Initialize(CoreFacade * p_mcfacade);
	void Shutdown();
	void GeodeStates(GameObject& GO);
	void Update(GameObject& GO);
	void SwitchStateGeode(GameObject& GO, AIData::GeodeState state);

private:
	//States
	void GeodeIdle(GameObject& GO);
	void GeodeScan(GameObject& GO);
	void GeodeSend(GameObject* pGeode);
	void GeodeFear(GameObject &GO);
	void GeodeStun(GameObject &GO);
	void GeodeKnockback(GameObject &GO);
	void GeodeFollow(GameObject &GO);
	void GeodeRecall(GameObject &GO);
	void GeodeAttack(GameObject &GO);
	void GeodeMine(GameObject &GO);
	void GeodePickup(GameObject &GO);
	void GeodeDeath(GameObject &GO);
	void GeodeStuck(GameObject &GO);
	void GeodeVictory(GameObject &GO);
	void GeodeTrap(GameObject &GO);

	void GeodePopBack(GameObject &GO);

	//Steering Behaviors
	XMVECTOR Separation(GameObject &GO, vector<GameObject*>& objects, 
	const float separationStrength = 100.0f,
	const float safeDist = 1.0f,
	const float maxSeparation = 20.0f );

	void Avoidance(GameObject& GO);
	bool DetectCollisions(GameObject& GO);

	//SpawnGems helper function
	bool SpawnGemType(ObjectType _gemType, XMFLOAT3 _pos);
};



#endif