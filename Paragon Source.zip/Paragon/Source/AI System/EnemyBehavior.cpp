
#include "../Application/stdafx.h"
#include "EnemyBehavior.h"
#include "GeodeBehavior.h"

#include "../Object Manager/GameObject.h"
#include "../Object Manager/AnimComponent.h"
#include "../Object Manager/GameObject.h"
#include "../Object Manager/EventComponent.h"
#include "../Object Manager/SpawnerComponent.h"
#include "../Object Manager/AudioComponent.h"
#include "../Application/CoreFacade.h"
#include "../Physics/Physics.h"
#include "../Physics/CollisionShape.h"
#include "../Particle System/Emitter.h"
#include "../Util/TimeManager.h"
#include "../Util/Util.h"
#include "../Sound/SoundManager.h"
#include "../Sound/Wwise_IDs.h"

#include <algorithm>

#define ENEMY_CHASE_DIST 30.0f

#define SPIDER_ATTACK_TIME	3.0f
#define SPIDER_DEATH		3.0f

#define GOLEM_ATTACK_TIME 3.0f
#define GOLEM_ATTACK_HIT 2.8f

#define GOLEM_DEBUFF_TIME 2.2f
#define GOLEM_DEBUFF_HIT 1.6f

#define GOLEM_TRAP_TIME 3.0f
#define ROCK_FALL_TIME 8.0f

#define WORM_ATTACK_TIME 2.6f
#define WORM_ATTACK_HIT 1.0f
#define WORM_ATTACK_WINDUP 1.6f
#define WORM_SUBMERGE 3.0f
#define WORM_EMERGE 1.5f
#define WORM_EMERGE_DELAY 1.0f

//Used for spawning gems
#define GEM_NO_SPAWN 0
#define GEM_SPAWN_ONE 1
#define GEM_SPAWN_RAND -1
#define GEM_SPAWN_GEN rand() % 2 - 1
#define GEM_SPAWN_FUNC(x) { rand() % x + 1 }

#define UNVATTACKSET	2.5f
#define UNVTRAPSET		3.3f
#define UNVDEBUFFSET	3.3f

enum ActionState { AS_WINDUP, AS_HIT, AS_END, AS_JUMP };

using namespace Physics;
EnemyBehavior::EnemyBehavior(CoreFacade * p_mcfacade)
{
	Initialize(p_mcfacade);
}
EnemyBehavior::~EnemyBehavior()
{
	Shutdown();

}
void EnemyBehavior::Initialize(CoreFacade * p_mcfacade)
{
	this->p_mcfacade = p_mcfacade;
}
void EnemyBehavior::Shutdown()
{

}
void EnemyBehavior::EnemyStates(GameObject& GO)
{
	//GameObject* tempPlayer;
	if (GO.GetType() == eSPIDER)
	{
		if (GO.GetTag() != "DumbSpider" && !GO.GetAIData()->bWebJump)
		{
			if (p_mcfacade->GetObjectManager()->GetPlayer()->GetPlayerComponent()->GetStuck())
			{
				CollisionShape* playerShape = p_mcfacade->GetObjectManager()->GetPlayer()->GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE);
				for (unsigned int index = 0; index < GO.GetAIData()->m_TrapList.size(); index++)
				{
					if (GO.GetAIData()->m_TrapList[index] == p_mcfacade->GetObjectManager()->GetPlayer()->GetPlayerComponent()->GetStuckTrap())
					{
						if (GO.GetAIData()->enemyState == AIData::EnAttack)
						{
							Telegraph* pAttackTelegraph = GO.GetChildTelegraphComponent(eSPIDER_ATTACK_TELEGRAPH);
							pAttackTelegraph->SetEnabled(false);
						}
						else if (GO.GetAIData()->enemyState == AIData::EnDebuff)
						{
							Telegraph* pAttackTelegraph = GO.GetChildTelegraphComponent(eSPIDER_FEAR_TELEGRAPH);
							pAttackTelegraph->SetEnabled(false);
						}
						GO.GetAIData()->bWebJump = true;
						SwitchStateEnemy(GO, AIData::EnPreJump);
						break;
					}
				}
			}
		}
	}

	if (GO.GetAIData()->bToSwitchStates)
	{
		SwitchStateEnemy(GO, GO.GetAIData()->enemyState);
		GO.GetAIData()->bToSwitchStates = false;
	}

	switch (GO.GetAIData()->enemyState)
	{
		//patrol
		//	Just hard coded cordinates
	case AIData::EnPreJump:
	{
		SpiderPreJump(GO);
		break;
	}
	case AIData::EnJump:
	{
		SpiderJump(GO);
		break;
	}
	case AIData::EnPatrol:
	{
		EnemyPatrol(GO);
		break;
	}
		//scan
	case AIData::EnScan:
	{
		EnemyScan(GO);
		break;
	}
		//attack
		//	prioritize attacking
	case AIData::EnAttack:
	{
		EnemyAttack(GO);
		break;
	}
		//cc
		//	later
	case AIData::EnDebuff:
	{
		EnemyDebuff(GO);
		break;
	}

		//traps
	case AIData::EnTrap:
	{
		EnemyTrap(GO);
		break;
	}

	case AIData::EnReposition:
	{
		if (GO.GetType() == ObjectType::eSPIDER && GO.GetChildEmitterComponent(0)->IsActive())
		{
			Emitter* pTrailEmitter = GO.GetChildEmitterComponent(0);
			pTrailEmitter->SetSpawning(false);
		}

		if (GO.GetType() == ObjectType::eWORM)
			WormReposition(GO);
		else
			EnemyReposition(GO);

		break;
	}

	case AIData::EnDeath:
	{
		EnemyDeath(GO);
		break;
	}
	}

}
void EnemyBehavior::EnemyUpdate(GameObject& GO)
{
	//Make sure the enemy is active 

	GO.GetPhysicsComponent()->SetForwardVelocity(0);
	AIData* pEnemyAI = GO.GetAIData();

	switch (GO.GetType())
	{
		//Update the spider 
	case eSPIDER:
	{
		if (!p_mcfacade->GetObjectManager()->GetPlayer()->GetPlayerComponent()->GetStuck() && GO.GetAIData()->bWebJump)
			GO.GetAIData()->bWebJump = false;
		XMMATRIX TargetLocation = XMLoadFloat4x4(&GO.GetWorldTransform());
		//XMVECTOR ForwardVec = XMVector3Normalize(TargetLocation.r[2]) * SPIDER_Z_OFFSET;
		//ForwardVec = XMCVector3SwizzleXZ(ForwardVec);
		//GO.GetPhysicsComponent()->GetCollisionShape(SU_ATTACK)->SetOffset(ForwardVec);

		GO.GetChildEffectComponent(eSPIDER_HEALTHBAR_EFFECT)->SetPosition(XMCStoreFloat4(GO.GetObjectTranslationVec() + XMCLoadFloat4(0.0f, 4.5f, 0.0f, 0.0f)));

		GO.GetChildEffectComponent(eSPIDER_HEALTHBAR_EFFECT)->ToggleEffect(true);
		GO.GetChildEffectComponent(eSPIDER_HEALTHBAR_EFFECT)->Size = XMFLOAT2(5.f * ((float)pEnemyAI->health / 25.f), 1.25f);

		if (pEnemyAI->fActionCooldownC > 0.0f)
		{
			pEnemyAI->fActionCooldownD += TimeManager::GetTimeDelta() * 10.0f;


			float intensity = 0.25f;
			float sin_value = sinf(pEnemyAI->fActionCooldownD) * intensity + 1.0f;


			XMVECTOR Position = GO.GetObjectTranslationVec();
			Position = XMVectorSetY(Position, sin_value);

			pEnemyAI->fActionCooldownC -= TimeManager::GetTimeDelta();
			if (pEnemyAI->fActionCooldownC <= 0.0f)
			{
				Position = XMVectorSetY(Position, 0);
				pEnemyAI->fActionCooldownD = 0.0f;
			}
			GO.SetObjectTranslation(Position);
		}
	}break;
	case eGOLEM:
	{
		XMMATRIX enemyWorld = GO.GetWorldTransformMat();
		XMVECTOR forwardVec = XMVector3Normalize(enemyWorld.r[2]);
		XMVECTOR rightVec = XMVector3Normalize(enemyWorld.r[0]);
		XMVECTOR offset = forwardVec/**GOLEM_Z_OFFSET*/ + rightVec;// *GOLEM_X_OFFSET;
		GO.GetPhysicsComponent()->GetCollisionShape(SU_ATTACK)->SetOffset(XMCVector3SwizzleXZ(offset));

		GO.GetChildEffectComponent(eGOLEM_HEALTHBAR_EFFECT)->SetPosition(XMCStoreFloat4(GO.GetObjectTranslationVec() + XMCLoadFloat4(0.0f, 15.0f, 0.0f, 0.0f)));
		GO.GetChildEffectComponent(eGOLEM_HEALTHBAR_EFFECT)->ToggleEffect(true);
		GO.GetChildEffectComponent(eGOLEM_HEALTHBAR_EFFECT)->Size = XMFLOAT2(5.f * ((float)pEnemyAI->health / 25.f), 1.25f);
	}break;
	case eWORM:
	{
		//Update Worm Here
		//XMMATRIX enemyWorld = GO.GetWorldTransformMat();
		//XMVECTOR forwardVec = XMVector3Normalize(enemyWorld.r[2]);
		//XMVECTOR rightVec = XMVector3Normalize(enemyWorld.r[0]);
		//XMVECTOR offset = forwardVec*WORM_Z_OFFSET + rightVec*WORM_Z_OFFSET;
		//GO.GetPhysicsComponent()->GetCollisionShape(SU_ATTACK)->SetOffset(XMCVector3SwizzleXZ(offset));

		GO.GetChildEffectComponent(eWORM_HEALTHBAR_EFFECT)->SetPosition(XMCStoreFloat4(GO.GetObjectTranslationVec() + XMCLoadFloat4(0.0f, 15.0f, 0.0f, 0.0f)));
		GO.GetChildEffectComponent(eWORM_HEALTHBAR_EFFECT)->ToggleEffect(true);
		GO.GetChildEffectComponent(eWORM_HEALTHBAR_EFFECT)->Size = XMFLOAT2(5.f * ((float)pEnemyAI->health / 25.f), 1.25f);
	}break;
	}

	if (pEnemyAI->health <= 0 && pEnemyAI->enemyState != AIData::EnDeath)
	{
		SwitchStateEnemy(GO, AIData::EnDeath);
	}
}
void EnemyBehavior::EnemyScan(GameObject& GO)
{

	if (GO.GetType() != eWORM)
		GO.GetAIData()->ObjTarget = 0;
	GO.GetAIData()->AOETargets.clear();

	PhysicsComponent * ScanningObjectsPhysicsComp = GO.GetPhysicsComponent();

	//Check all current geodes and player
	CollisionShape* enemyShape = nullptr;
	vector<GameObject*> CurrentCollisions;
	vector<GameObject*> Geodes = p_mcfacade->m_ObjectManager->GetGeodes();
	vector<GameObject*> enemyList = p_mcfacade->m_ObjectManager->GetAllEnemies();
	GameObject* Player = p_mcfacade->m_ObjectManager->GetPlayer();

	for (unsigned int i = 0; i < Geodes.size(); i++)
	{
		if (Geodes[i]->GetActive() == false || Geodes[i]->GetAIData()->geodeState == AIData::GeDeath)
			continue;

		//Check to see if we are colliding 
		if (Geodes[i]->GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE)->Collides(ScanningObjectsPhysicsComp->GetCollisionShape(SU_SCANNER)) == false)
			continue;
		else
			CurrentCollisions.push_back(Geodes[i]);

	}
	//Check player
	if (Player->GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE)->Collides(ScanningObjectsPhysicsComp->GetCollisionShape(SU_SCANNER)) == true)
		CurrentCollisions.push_back(Player);

	GameObject* ClosestObject = nullptr;
	if (CurrentCollisions.size() > 0)
	{
		GO.GetAIData()->bFirstSight = true;
		GO.GetAIData()->bAggro = true;
		//Check to see which collision object is closest the game object that is scanning

		//Assign the closest object to this
		ClosestObject = CurrentCollisions[0];

		if (GO.GetAIData()->bLeader)
		{
			GO.GetAIData()->bLeaderEngage = true;
		}
	}

	else
	{
		for (unsigned int i = 0; i < enemyList.size(); i++)
		{
			enemyShape = enemyList[i]->GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE);

			if (GO.GetPhysicsComponent()->GetCollisionShape(SU_SCANNER)->Collides(enemyShape) && enemyList[i]->GetAIData()->bAggro && !GO.GetAIData()->bFirstSight)
			{
				GO.GetAIData()->bAggro = true;
				GO.GetAIData()->ObjTarget = enemyList[i]->GetAIData()->ObjTarget;
				break;
			}
		}
	}

	//Asign target
	//See if it is not the worm to set the target.
	if (GO.GetType() != eWORM)
		GO.GetAIData()->ObjTarget = ClosestObject;

	if (CurrentCollisions.size() == 0)
		GO.GetAIData()->enemyState = AIData::EnPatrol;
	else
		GO.GetAIData()->enemyState = AIData::EnReposition;
	/*if (!GO.GetAIData()->bAttacked)
	GO.GetAIData()->enemyState = AIData::EnAttack;
	else if (!GO.GetAIData()->bCCed)
	GO.GetAIData()->enemyState = AIData::EnDebuff;*/

}
void EnemyBehavior::EnemyPatrol(GameObject& GO)
{
	//If the enemy in question is a worm and not submerged, then get it underground.
	if (GO.GetType() == eWORM && !GO.GetAIData()->bSubmerged)
	{
		if (!GO.GetAIData()->bSubmerging)
		{
			GO.GetAIData()->bSubmerging = true;
			GO.GetAIData()->fActionCooldown = p_mcfacade->GetAssetManager()->GetAnimation(WORM_SUBMERGE_ANIM)->GetAnimTime();
			GO.GetChildEmitterComponent(eWORM_TRAIL1_EMITTER)->SetSpawning(true);
			GO.GetChildEmitterComponent(eWORM_TRAIL2_EMITTER)->SetSpawning(true);
		}
		else
			GO.GetAIData()->fActionCooldown -= TimeManager::GetTimeDelta();

		if (GO.GetAIData()->fActionCooldown <= 0.0f)
		{
			GO.GetChildEffectObject(eWORM_HEALTHBAR_EFFECT)->SetActive(false);

			GO.GetAIData()->bSubmerging = false;
			GO.GetAIData()->bSubmerged = true;
			GO.GetAIData()->fActionCooldown = 0.0f;
			GO.GetAnimComponent()->SetAnimSpeed(0.0f);
			GO.GetAnimComponent()->SetKeyTime(p_mcfacade->GetAssetManager()->GetAnimation(WORM_SUBMERGE_ANIM)->GetAnimTime() - 0.0001f);
		}

		WormTrap(GO);
	}
	else if (GO.GetAIData()->WayPoints.size() > 0)
	{
		switch (GO.GetType())
		{
		case eSPIDER:	GO.GetAnimComponent()->SetAnimName(SPIDER_MOVE, true);	break;  
		case eGOLEM:	GO.GetAnimComponent()->SetAnimName(GOLEM_MOVE, true);	break;
		}
		PhysicsComponent * physicsEnemy = GO.GetPhysicsComponent();
		XMVECTOR WayPointPos = XMLoadFloat3(&GO.GetAIData()->WayPoints[GO.GetAIData()->usLastWaypoint]);
		XMVECTOR AIcurrentPos = XMLoadFloat3(&GO.GetObjectTranslation());
		//Pretend the AI is on the plane.
		AIcurrentPos = XMVectorSetY(AIcurrentPos, 0.0f);
		XMVECTOR distanceV = WayPointPos - AIcurrentPos;

		float distance;
		distanceV = XMVector3Length(distanceV);
		XMStoreFloat(&distance, distanceV);


		//Get the velocity for the enemy
		XMFLOAT2 objFloat;
		XMMATRIX GOhere = XMLoadFloat4x4(&GO.GetWorldTransform());
		XMVECTOR ObjectSpeed;

		//Set the Enemy Speed
		switch (GO.GetType())
		{
		case eWORM:   ObjectSpeed = GOhere.r[2] * 25.0f;	break;
		case eSPIDER: ObjectSpeed = GOhere.r[2] * 10.0f;	break;
		case eGOLEM:  ObjectSpeed = GOhere.r[2] * 5.0f;		break;
		}

		XMVectorGetZPtr(&objFloat.y, ObjectSpeed);
		XMVectorGetXPtr(&objFloat.x, ObjectSpeed);

		//Check to see how far we are from current waypoint
		if (distance <= 0.5f)
		{
			GO.GetAIData()->usLastWaypoint++;
			if (GO.GetAIData()->usLastWaypoint >= GO.GetAIData()->WayPoints.size())
				GO.GetAIData()->usLastWaypoint = 0;
		}

		XMMATRIX iden = XMMatrixIdentity();
		iden.r[3].m128_f32[0] = GO.GetAIData()->WayPoints[GO.GetAIData()->usLastWaypoint].x;
		iden.r[3].m128_f32[1] = GO.GetAIData()->WayPoints[GO.GetAIData()->usLastWaypoint].y;
		iden.r[3].m128_f32[2] = GO.GetAIData()->WayPoints[GO.GetAIData()->usLastWaypoint].z;

		GO.TurnTo(&iden, 5.0f);

		physicsEnemy->SetVelocity(objFloat);

	}

	if (GO.GetTag() == "FirstTrapSpider")
	{
		CollisionShape* SpiderEventShape = GO.GetPhysicsComponent()->GetCollisionShape(SU_EVENT);
		CollisionShape*	PlayerShape = p_mcfacade->GetObjectManager()->GetPlayer()->GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE);

		if (GO.GetEventComponent()->Triggered == false)
		{
			CollisionShape* doorShape = nullptr;
			EventComponent* doorEvent = nullptr;
			std::vector<GameObject*> doorList = p_mcfacade->GetObjectManager()->GetDoors();
			for (unsigned int i = 0; i < doorList.size(); i++)
			{
				if (doorList[i]->GetTag() == "DoorCoreShape")
				{
					doorEvent = doorList[i]->GetEventComponent();
					doorShape = doorList[i]->GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE);
					break;
				}
			}

			if (PlayerShape->Collides(doorShape) && doorEvent->targeted == true)
			{
				std::vector<GameObject*> trapList = p_mcfacade->GetObjectManager()->GetSpiderTraps();
				for (unsigned int index = 0; index < trapList.size(); index++)
				{
					if (trapList[index]->GetTrapComponent()->GetParent() == &GO)
					{
						if (trapList[index]->GetActive() == false)
						{
							if (GO.GetEventComponent()->TargetsRemaining > 0)
							{
								GO.GetEventComponent()->TargetsRemaining--;
								if (GO.GetEventComponent()->TargetsRemaining <= 0)
								{
									GO.SetFocused(true);
									GO.GetEventComponent()->Triggered = true;
									p_mcfacade->GetObjectManager()->GetPlayer()->GetPlayerComponent()->SetRoomNumber(1);
								}
							}
						}

						break;
					}
				}
			}
		}
	}
	GO.GetAIData()->enemyState = AIData::EnScan;
}
void EnemyBehavior::EnemyReposition(GameObject& GO)
{
	const float MoveVelocity = 25.0f;
	const float MinAttackDist = 3.5f;
	////int CoinFlip = 0;

	//if (GO.GetType() == eGOLEM)
	//	GO.GetAnimComponent()->SetAnimName(GOLEM_MOVE, true);

	PhysicsComponent * pEnemyPhysics = GO.GetPhysicsComponent();
	CollisionShape* pEnemyBoundingShape = pEnemyPhysics->GetCollisionShape(SU_BOUNDING_SHAPE);
	CollisionShape* pEnemyScannerShape = pEnemyPhysics->GetCollisionShape(SU_SCANNER);
	CollisionShape* pEnemyAttackShape = pEnemyPhysics->GetCollisionShape(SU_ATTACK);

	AIData * pEnemyAI = GO.GetAIData();
	GameObject *& pChaseTarget = pEnemyAI->ObjTarget;

	vector<GameObject*> Geodes = p_mcfacade->m_ObjectManager->GetGeodes();
	vector<GameObject*> ActiveTargets;
	vector<GameObject*> Traps = p_mcfacade->m_ObjectManager->GetSpiderTraps();

	bool stuckGeode = false;
	CollisionShape* trapShape = nullptr;
	for (unsigned int trapI = 0; trapI < GO.GetAIData()->m_TrapList.size(); trapI++)
	{
		trapShape = GO.GetAIData()->m_TrapList[trapI]->GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE);

		if (trapShape)
		{
			for (unsigned int geodeI = 0; geodeI < Geodes.size(); geodeI++)
			{
				if (Geodes[geodeI]->GetAIData()->geodeState == AIData::GeStuck)
				{
					if (Geodes[geodeI]->GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE)->Collides(trapShape))
						pChaseTarget = Geodes[geodeI];
					stuckGeode = true;
					break;
				}

			}
		}
	}

	/*if (GO.GetAIData()->m_nAtkNum == 2 || GO.GetAIData()->health <= 10)
		pChaseTarget = p_mcfacade->m_ObjectManager->GetPlayer();*/

	if (pChaseTarget && stuckGeode == false)
	{

		CollisionShape* pTargetBoundingShape = pChaseTarget->GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE);
		if (!pEnemyScannerShape->Collides(pTargetBoundingShape) && pChaseTarget->GetType() != ePLAYER && !GO.GetAIData()->bAtkWithLeader)
			pChaseTarget = NULL;
	}
	if (!pChaseTarget || pChaseTarget->GetType() == ePLAYER)
	{
		//Find possible targets
		for (unsigned int i = 0; i < Geodes.size(); i++)
		{
			GameObject* pGeode = Geodes[i];
			if (!pGeode->GetActive()) continue;
			if (pGeode->GetAIData()->geodeState != AIData::GeAttack) continue;
			CollisionShape* pGeodeBoundingShape = pGeode->GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE);
			if (pEnemyScannerShape->Collides(pGeodeBoundingShape))
				ActiveTargets.push_back(pGeode);
		}

		if (ActiveTargets.size() == 0)
			ActiveTargets.push_back(p_mcfacade->m_ObjectManager->GetPlayer());

		//Choose target
		//if (GO.GetAIData()->m_nAtkNum > 2 || GO.GetAIData()->health <= 10)
		//	pChaseTarget = p_mcfacade->m_ObjectManager->GetPlayer();
		//else
		pChaseTarget = ActiveTargets[rand() % ActiveTargets.size()];
	}
	PhysicsComponent* pTargetPhysics = pChaseTarget->GetPhysicsComponent();

	XMVECTOR WayPointPos = XMLoadFloat3(&pChaseTarget->GetObjectTranslation());
	XMVECTOR AIcurrentPos = XMLoadFloat3(&GO.GetObjectTranslation());
	float distance = XMCVector3Length(WayPointPos - AIcurrentPos);

	distance -= dynamic_cast<Circle*>(GO.GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE))->GetRadius();
	distance -= dynamic_cast<Circle*>(pChaseTarget->GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE))->GetRadius();

	bool InRange = distance < MinAttackDist;

	if (InRange == true)
	{
		//Set idle animation
		switch (GO.GetType())
		{
		case eSPIDER:  GO.GetAnimComponent()->SetAnimName(SPIDER_IDLE, true);  break;
		case eGOLEM:	GO.GetAnimComponent()->SetAnimName(GOLEM_IDLE, true);  break;
		case eWORM:		 break;
		}
	}
	else
	{
		//Set idle animation
		switch (GO.GetType())
		{
		case eSPIDER:  GO.GetAnimComponent()->SetAnimName(SPIDER_MOVE, true);  break;
		case eGOLEM:	GO.GetAnimComponent()->SetAnimName(GOLEM_MOVE, true);  break;
		case eWORM:		 break;
		}
	}
	//Get the velocity for the enemy

	XMMATRIX EnemyTransform = GO.GetWorldTransformMat();
	XMVECTOR EnemyPos = GO.GetObjectTranslationVec();
	XMVECTOR EnemyRight = XMVector3Normalize(EnemyTransform.r[0]);
	XMVECTOR EnemyForward = XMVector3Normalize(EnemyTransform.r[2]);

	XMMATRIX TargetTransform = pChaseTarget->GetWorldTransformMat();
	XMVECTOR TargetPos = pChaseTarget->GetObjectTranslationVec();
	XMVECTOR toTarget = XMVector3Normalize(TargetPos - EnemyPos);

	bool bTargetAhead = XMCVector3Dot(toTarget, EnemyForward) > 0;

	if (bTargetAhead)
		pEnemyPhysics->SetForwardVelocity(13.0f);
	else
		pEnemyPhysics->SetForwardVelocity(0.0f);

	CollisionShape* pTargetBoundingShape = pTargetPhysics->GetCollisionShape(SU_BOUNDING_SHAPE);

	bool bTargetInSight = XMCVector3Dot(toTarget, EnemyForward) > 0.95f;

	if (GO.GetAIData()->nCoinFlip >= 5 && GO.GetType() == eSPIDER && bTargetInSight && pEnemyAI->AttackCooldownSwitcher <= 0.0f)
	{
		pEnemyPhysics->SetForwardVelocity(0.0f);
		SwitchStateEnemy(GO, AIData::EnPreJump);
		pEnemyAI->AttackCooldownSwitcher = UNVATTACKSET;
	}

	else if (InRange && bTargetInSight)
	{
		pEnemyPhysics->SetForwardVelocity(0.0f);
		pEnemyAI->bInRange = true;
		/*if (GO.GetAIData()->m_nAtkNum == 2 && GO.GetType() == eGOLEM)
			SwitchStateEnemy(GO, AIData::EnTrap);
			else if (!GO.GetAIData()->bAttacked)
			SwitchStateEnemy(GO, AIData::EnAttack);
			else if (!GO.GetAIData()->bCCed)
			SwitchStateEnemy(GO, AIData::EnDebuff);*/
		if (pEnemyAI->AttackCooldownSwitcher <= 0.0f)
		{
			GO.GetAIData()->bFirstSight = true;
			if (GO.GetType() == eSPIDER)
			{
				//int CoinFlip = rand() % 2;
				if (GO.GetAIData()->nCoinFlip < 5)
					SwitchStateEnemy(GO, AIData::EnAttack);
				else
					SwitchStateEnemy(GO, AIData::EnPreJump);

				GO.GetAIData()->nCoinFlip = -1;
			}
			else
				SwitchStateEnemy(GO, AIData::EnAttack);
			pEnemyAI->AttackCooldownSwitcher = UNVATTACKSET;
		}
		else if (pEnemyAI->TrapCooldownSwitcher <= 0.0f)
		{
			if (GO.GetTag() != "DumbSpider")
				SwitchStateEnemy(GO, AIData::EnTrap);
			pEnemyAI->TrapCooldownSwitcher = UNVTRAPSET;
		}
		else if (pEnemyAI->DebuffCooldownSwitcher <= 0.0f)
		{
			SwitchStateEnemy(GO, AIData::EnDebuff);
			pEnemyAI->DebuffCooldownSwitcher = UNVDEBUFFSET;
		}
		else
		{
			pEnemyAI->AttackCooldownSwitcher -= TimeManager::GetTimeDelta() * 1.0f;
			pEnemyAI->TrapCooldownSwitcher -= TimeManager::GetTimeDelta() * 1.0f;
			pEnemyAI->DebuffCooldownSwitcher -= TimeManager::GetTimeDelta() * 1.0f;
		}

		pEnemyAI->bCCed = false;
		pEnemyAI->bAttacked = false;
	}
	else
	{
		if (GO.GetType() == eSPIDER)
			GO.GetAnimComponent()->SetAnimName(SPIDER_MOVE, true);
		GO.TurnTo(TargetPos, 5.0f);
	}

	if (distance > ENEMY_CHASE_DIST && GO.GetAIData()->bFirstSight)
	{
		SwitchStateEnemy(GO, AIData::EnScan);
	}

}
void EnemyBehavior::EnemyDebuff(GameObject& GO)
{
	GO.GetAIData()->AOETargets.clear();

	CollisionShape* pEnemyDebuff = GO.GetPhysicsComponent()->GetCollisionShape(SU_CC); // TODO: Use a separate shape for debuffs

	// Add geodes to targets if they are in attack range
	vector<GameObject*> Geodes = p_mcfacade->m_ObjectManager->GetGeodes();
	for (unsigned int index = 0; index < Geodes.size(); index++)
	{
		GameObject* pGeode = Geodes[index];
		AIData* pGeodeAI = pGeode->GetAIData();
		//Only check active
		if (!pGeode->GetActive()) continue;
		if (pGeodeAI->geodeState == AIData::GeDeath) continue;

		//check for a collision
		CollisionShape* pGeodeBounds = pGeode->GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE);
		if (pEnemyDebuff->Collides(pGeodeBounds))
		{
			GO.GetAIData()->AOETargets.push_back(pGeode);
		}
	}

	GO.GetAIData()->fActionCooldown += (float)TimeManager::GetTimeDelta();

	switch (GO.GetType())
	{
	case eSPIDER:	return SpiderDebuff(GO);
	case eGOLEM:	return GolemDebuff(GO);
	case eWORM:		return WormDebuff(GO);
	}

}
void EnemyBehavior::SpiderDebuff(GameObject& GO)
{
	PhysicsComponent * physicsEnemy = GO.GetPhysicsComponent();
	AIData* pSpiderAI = GO.GetAIData();

	physicsEnemy->SetForwardVelocity(0);

	vector<GameObject*>& Targets = pSpiderAI->AOETargets;

	ActionState actionState;
	if (pSpiderAI->fActionCooldown <= GOLEM_ATTACK_HIT)
		actionState = AS_WINDUP;
	else if (pSpiderAI->fActionCooldown <= GOLEM_ATTACK_TIME)
		actionState = AS_HIT;
	else
		actionState = AS_END;

	XMVECTOR WarningColor = XMCLoadFloat4(0.1f, 0.1f, 0.1f, 1.0f); // Black

	bool RubiesFeared = false;
	bool DiamondsFeared = false;

	for each(GameObject* pTarget in Targets)
	{
		switch (pTarget->GetType())
		{
		case eSAPPHIREGEODE:
			pTarget->GetChildEffectComponent(eGEODE_BARRIER_EFFECT)->GetHolder()->SetObjectColorAlpha(1.0f);
			break;
		case eRUBYGEODE:	RubiesFeared = true;	break;
		case eDIAMONDGEODE: DiamondsFeared = true;	break;
		}
	}
	Targets.erase(std::remove_if(Targets.begin(), Targets.end(), [](GameObject* pTarget)
	{
		return pTarget->GetType() == eSAPPHIREGEODE;
	}), Targets.end());

	switch (actionState)
	{
	case AS_WINDUP:
	{
		if (GO.GetTag() != "DumbSpider")
		{
			for each(GameObject* pTarget in Targets)
			{
				if (pTarget->GetReactionTime() <= 0.0f)
				{
					pTarget->SetObjectColor(WarningColor);
					pTarget->SetReactionTime(0.333f);
				}
			}
		}
		Targets.clear();
		break;
	}
	case AS_HIT:
	{

		if (GO.GetTag() != "DumbSpider")
			pSpiderAI->geodeState = AIData::GeFear;

		if (!pSpiderAI->bCCed)
		{
			GO.GetAudioComponent()->PlayAudioFollow(PLAY_SFX_SPIDER_FEAR);

		}

		pSpiderAI->bCCed = true;
		pSpiderAI->bCCSound = false;

		//Make him jump
		///Replace with animation when we have it.
		GO.GetAIData()->fActionCooldownC = 0.25f;
		for (size_t index = 0; index < Targets.size(); index++)
		{
			GameObject* pTarget = Targets[index];
			pTarget->GetAIData()->ObjTarget = &GO;
		}

		break;
	}
	case AS_END:
	{
		if (GO.GetAIData()->m_nAtkNum == 2)
			SwitchStateEnemy(GO, AIData::EnPreJump);
		else
			SwitchStateEnemy(GO, AIData::EnReposition);
		Targets.clear();
		pSpiderAI->bEnemySpecialA = false;

		break;
	}
	default:
		break;
	}

}
void EnemyBehavior::GolemDebuff(GameObject& GO)
{
	//Animation
	//GO.GetAnimComponent()->SetAnimName(GOLEM_CC, false);



	PhysicsComponent * physicsEnemy = GO.GetPhysicsComponent();
	AIData* pGolemAI = GO.GetAIData();

	AudioSystemWwise* pAudio = p_mcfacade->GetSoundManager()->GetAudioSystem();

	physicsEnemy->SetForwardVelocity(0);

	vector<GameObject*>& Targets = pGolemAI->AOETargets;

	ActionState actionState;
	if (pGolemAI->fActionCooldown <= GOLEM_DEBUFF_HIT)
		actionState = AS_WINDUP;
	else if (pGolemAI->fActionCooldown <= GOLEM_DEBUFF_TIME)
		actionState = AS_HIT;
	else
		actionState = AS_END;


	XMVECTOR WarningColor = XMCLoadFloat4(0.1f, 0.1f, 0.1f, 1.0f); // Black


	bool SapphiresStunned = false;
	bool DiamondsStunned = false;

	for each(GameObject* pTarget in Targets)
	{
		switch (pTarget->GetType())
		{
		case eRUBYGEODE:
			pTarget->GetChildEffectComponent(eGEODE_BARRIER_EFFECT)->GetHolder()->SetObjectColorAlpha(1.0f);
			break;
		case eSAPPHIREGEM:	SapphiresStunned = true;	break;
		case eDIAMONDGEODE: DiamondsStunned = true;	break;
		}
	}
	Targets.erase(std::remove_if(Targets.begin(), Targets.end(), [](GameObject* pTarget)
	{
		return pTarget->GetType() == eRUBYGEODE;
	}), Targets.end());

	switch (actionState)
	{
	case AS_WINDUP:
	{
		//This bool makes sure that the geodes can be stunned.
		pGolemAI->bEnemySpecialA = false;

		if (pGolemAI->bCCSound == false && pGolemAI->fActionCooldown >= 2.5f)
		{
			//pAudio->PostEvent(AK::EVENTS::PLAY_FX_3D_BODYFALL);
			pGolemAI->bCCSound = true;
		}

		if (pGolemAI->fActionCooldown > 2.0f)
		{
			EffectComponent* pTheEffect = GO.GetChildEffectComponent(3);
			pTheEffect->SetPosition(XMCStoreFloat4(GO.GetObjectTranslationVec() + XMCLoadFloat4(0, 4.0f, 4.0f, 0.0f)));

			pTheEffect->ToggleEffect(true, 0.6f);
		}


		//Get the Possible objects to attack
		for (size_t index = 0; index < Targets.size(); index++)
		{
			GameObject* pTarget = Targets[index];

			if (pTarget->GetReactionTime() <= 0.0f)
			{
				pTarget->SetObjectColor(WarningColor);
				pTarget->SetReactionTime(0.333f);
			}
		}
		Targets.clear();
	} break;
	case AS_HIT:
	{
		if (!pGolemAI->bActionDone)
		{
			pGolemAI->bActionDone = true;
			pGolemAI->geodeState = AIData::GeStun;

			GO.GetAudioComponent()->PlayAudioFollow(PLAY_SFX_GOLEM_STUN);

			pGolemAI->bCCed = true;
			pGolemAI->bCCSound = false;

			//Make him jump
			///Replace with animation when we have it.
			pGolemAI->fActionCooldownC = 0.25f;

			GO.GetChildEmitterComponent(eGOLEM_STOMP_EMITTER)->SetSpawnTimer(0.5f);
		}
		else
		{
			Targets.clear();
		}
	} break;
	case AS_END:
	{
		Targets.clear();
		SwitchStateEnemy(GO, AIData::EnReposition);
	} break;
	}

}
void EnemyBehavior::WormDebuff(GameObject& GO)
{
	PhysicsComponent * physicsEnemy = GO.GetPhysicsComponent();
	AIData* pWormAI = GO.GetAIData();

	AudioSystemWwise* pAudio = p_mcfacade->GetSoundManager()->GetAudioSystem();

	physicsEnemy->SetForwardVelocity(0);

	vector<GameObject*>& Targets = pWormAI->AOETargets;

	ActionState actionState;
	if (pWormAI->fActionCooldown <= GOLEM_DEBUFF_HIT)
		actionState = AS_WINDUP;
	else if (pWormAI->fActionCooldown <= GOLEM_DEBUFF_TIME)
		actionState = AS_HIT;
	else
		actionState = AS_END;

	GO.GetAnimComponent()->SetAnimSpeed(p_mcfacade->GetAssetManager()->GetAnimation(WORM_CC)->GetAnimTime() / GOLEM_DEBUFF_TIME);

	XMVECTOR WarningColor = XMCLoadFloat4(0.1f, 0.1f, 0.1f, 1.0f); // Black

	bool SapphiresKnocked = false;
	bool RubiesKnocked = false;

	for each(GameObject* pTarget in Targets)
	{
		switch (pTarget->GetType())
		{
		case eDIAMONDGEODE:
			pTarget->GetChildEffectComponent(eGEODE_BARRIER_EFFECT)->GetHolder()->SetObjectColorAlpha(1.0f);
			break;
		case eSAPPHIREGEODE: SapphiresKnocked = true;	break;
		case eRUBYGEODE:	RubiesKnocked = true;	break;
		}
	}
	Targets.erase(std::remove_if(Targets.begin(), Targets.end(), [](GameObject* pTarget)
	{
		return pTarget->GetType() == eDIAMONDGEODE;
	}), Targets.end());

	switch (actionState)
	{
	case AS_WINDUP:
	{
		//Making sure the geodes can be knockedback.

		if (pWormAI->bCCSound == false && pWormAI->fActionCooldown >= 2.5f)
		{
			pWormAI->bCCSound = true;
		}

		if (pWormAI->fActionCooldown > 2.0f)
		{
			EffectComponent* pTheEffect = GO.GetChildEffectComponent(3);

			pTheEffect->SetPosition(XMCStoreFloat4(GO.GetObjectTranslationVec() + XMCLoadFloat4(0, 4.0f, 4.0f, 0.0f)));
			pTheEffect->ToggleEffect(true, 0.6f);
		}


		//Get the Possible objects to attack
		for (size_t index = 0; index < Targets.size(); index++)
		{
			GameObject* pTarget = Targets[index];

			if (pTarget->GetReactionTime() <= 0.0f)
			{
				pTarget->SetObjectColor(WarningColor);
				pTarget->SetReactionTime(0.333f);
			}
		}
		Targets.clear();
	} break;
	case AS_HIT:
	{
		if (!pWormAI->bActionDone)
		{
			pWormAI->bActionDone = true;
			pWormAI->geodeState = AIData::GeKnockback;

			GO.GetAudioComponent()->PlayAudioFollow(PLAY_SFX_WORM_SWEEP);

			pWormAI->bCCed = true;
			pWormAI->bCCSound = false;
			pWormAI->bAttacked = false;

			//Make him jump
			///Replace with animation when we have it.
			pWormAI->fActionCooldownC = 0.25f;
		}
		else
		{
			Targets.clear();
		}
	} break;
	case AS_END:
	{
		SwitchStateEnemy(GO, AIData::EnReposition);
		Targets.clear();
	} break;
	}


}
void EnemyBehavior::EnemyAttack(GameObject& GO)
{
	//return;
	GO.GetAIData()->AOETargets.clear();

	CollisionShape* pEnemyAttack = GO.GetPhysicsComponent()->GetCollisionShape(SU_ATTACK);

	// Add player to targets if he is in attack range
	GameObject* pPlayer = p_mcfacade->m_ObjectManager->GetPlayer();
	CollisionShape* pPlayerBounds = pPlayer->GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE);
	if (pEnemyAttack->Collides(pPlayerBounds))
	{
		GO.GetAIData()->AOETargets.push_back(pPlayer);
	}

	// Add geodes to targets if they are in attack range
	vector<GameObject*> Geodes = p_mcfacade->m_ObjectManager->GetGeodes();
	for (unsigned int index = 0; index < Geodes.size(); index++)
	{
		GameObject* pGeode = Geodes[index];
		AIData* pGeodeAI = pGeode->GetAIData();
		//Only check active
		if (!pGeode->GetActive()) continue;
		if (pGeodeAI->geodeState == AIData::GeDeath) continue;

		//check for a collision
		CollisionShape* pGeodeBounds = pGeode->GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE);
		if (pEnemyAttack->Collides(pGeodeBounds))
		{
			GO.GetAIData()->AOETargets.push_back(pGeode);
		}
	}

	GO.GetAIData()->fActionCooldown += (float)TimeManager::GetTimeDelta();

	switch (GO.GetType())
	{
	case eSPIDER:	return SpiderAttack(GO);
	case eGOLEM:	return GolemAttack(GO);
	case eWORM:		return WormAttack(GO);
	}

}
void EnemyBehavior::SpiderAttack(GameObject& GO)
{
	AIData* pSpiderAI = GO.GetAIData();
	vector<GameObject*>& Targets = pSpiderAI->AOETargets;
	vector<GameObject*>& trapList = p_mcfacade->GetObjectManager()->GetSpiderTraps();

	ActionState actionState;
	if (pSpiderAI->fActionCooldown <= SPIDER_ATTACK_TIME)
	{
		actionState = AS_WINDUP;

		if (pSpiderAI->fActionCooldown >= 2.0f)
			GO.GetAnimComponent()->SetAnimName(SPIDER_ATTACK, false);
	}
	else
		actionState = AS_END;

	XMVECTOR WarningColor = XMCLoadFloat4(1.0f, 0.1f, 0.1f, 1.0f); // Black

	if (actionState == AS_END)
	{

		for (size_t index = 0; index < Targets.size(); index++)
		{
			GameObject* pTarget = Targets[index];

			//Tell the thing it has taken damage.
			if (pTarget->GetType() == ePLAYER)
			{
				pTarget->GetPlayerComponent()->HitPlayer(p_mcfacade, 1);
				if (pTarget->GetPlayerComponent()->GetHealth() > 0)
					pTarget->GetAnimComponent()->SetAnimName(PLAYER_HIT, false);
			}
			else // is Geode
			{
				pTarget->TakeDamage(1);
				GO.GetAIData()->nUnitsKilled++;
			}
		}

		pSpiderAI->bAttackSound = false;
		//p_mcfacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_SFX_SPIDER_ATTACK);
		GO.GetAudioComponent()->PlayAudioFollow(PLAY_SFX_SPIDER_ATTACK);
		pSpiderAI->bAttacked = true;

		//Make him jump
		///Replace with animation when we have it.

		//Start and play the spider attack animation! 

		GO.GetAIData()->fActionCooldownC = 0.25f;

		GO.GetAIData()->m_nAtkNum++;

		GO.GetAIData()->bStartLeap = false;

		SwitchStateEnemy(GO, AIData::EnReposition);
	}
	else if (actionState == AS_WINDUP)
	{
		//Get the Possible objects to attack
		for (size_t index = 0; index < Targets.size(); index++)
		{
			GameObject* pTarget = Targets[index];

			if (pTarget->GetReactionTime() <= 0.0f && pTarget->GetType() != ePLAYER)
			{
				pTarget->SetObjectColor(WarningColor);
				pTarget->SetReactionTime(0.333f);
			}
		}
		// Replace trap code here if it doesn't work being in SpiderTrap
	}

	Targets.clear();

}
void EnemyBehavior::SpiderPreJump(GameObject& GO)
{
	Telegraph* pAttackTelegraph = GO.GetChildTelegraphComponent(eSPIDER_JUMP_TELEGRAPH);
	// This tracks the player for a moment before leaping to decide where to jump

	SetSpiderVel(GO);

	XMVECTOR swizzle = XMCVector3SwizzleXZ(XMLoadFloat3(&p_mcfacade->GetObjectManager()->GetPlayer()->GetObjectTranslation()));
	pAttackTelegraph->SetPosition(XMCStoreFloat2(swizzle));

	GO.TurnTo(p_mcfacade->GetObjectManager()->GetPlayer()->GetObjectTranslationVec(), 5.0f);
	GO.GetAIData()->fTargetPos = p_mcfacade->GetObjectManager()->GetPlayer()->GetObjectTranslation();

	if (GO.GetAIData()->fActionCooldown >= 1.f)
	{
		GO.TurnTo(p_mcfacade->GetObjectManager()->GetPlayer()->GetObjectTranslationVec(), 5.0f);
		SwitchStateEnemy(GO, AIData::EnJump);
		XMVECTOR swizzle = XMCVector3SwizzleXZ(XMLoadFloat3(&GO.GetAIData()->fTargetPos));
		pAttackTelegraph->SetPosition(XMCStoreFloat2(swizzle));
	}

	GO.GetAIData()->fActionCooldown += (float)TimeManager::GetTimeDelta();
}
void EnemyBehavior::SpiderJump(GameObject& GO)
{
	Telegraph* pAttackTelegraph = GO.GetChildTelegraphComponent(eSPIDER_JUMP_TELEGRAPH);

	XMVECTOR swizzle = XMCVector3SwizzleXZ(XMLoadFloat3(&GO.GetAIData()->fTargetPos));
	pAttackTelegraph->SetPosition(XMCStoreFloat2(swizzle));
	// Step 2 of 2 - Parabolic Arc:
	// This code is responsible for the actual movement of the object
	// DISCLAIMER: F.x and F.z in this code are set equal to the ObjectTranslation.x and ObjectTranslation.z respectively,
	// only for our code
	// F = Destination
	// t = Time in Air
	float t = GO.GetAIData()->m_fAirTime;
	XMFLOAT3 F;

	F.y = ((1.f * -9.8f) * (t * t)) + (GO.GetAIData()->fTempVel.y * t) + GO.GetAIData()->fJumpingPoint.y;
	F.x = GO.GetObjectTranslation().x;
	F.z = GO.GetObjectTranslation().z;

	if (F.y <= 0.0f && t > 0.0f)
	{
		AIData* pSpiderAI = GO.GetAIData();
		vector<GameObject*>& Targets = pSpiderAI->AOETargets;
		GO.GetPhysicsComponent()->SetVelocity(XMFLOAT2(0.0f, 0.0f));
		GO.GetPhysicsComponent()->SetForwardVelocity(0.0f);
		GO.SetObjectTranslation(F.x, 0.0f, F.z);
		GO.GetAIData()->m_fAirTime = 0.0f;
		Emitter* pTrailEmitter = GO.GetChildEmitterComponent(0);
		pTrailEmitter->SetSpawning(true);
		pTrailEmitter->SetSpawnTimer(0.75f);
		pTrailEmitter->SetLifeTime(1.0f);//, false);

		if (pSpiderAI->bWebJump && !p_mcfacade->GetObjectManager()->GetPlayer()->GetPlayerComponent()->GetStuck())
			pSpiderAI->bWebJump = false;
		else
			GO.GetAIData()->m_nAtkNum = 0;

		// Add player to targets if he is in attack range
		CollisionShape* pPlayerBounds = p_mcfacade->m_ObjectManager->GetPlayer()->GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE);
		if (GO.GetPhysicsComponent()->GetCollisionShape(SU_ATTACK)->Collides(pPlayerBounds))
		{
			p_mcfacade->m_ObjectManager->GetPlayer()->GetPlayerComponent()->HitPlayer(p_mcfacade, 1);
			if (p_mcfacade->m_ObjectManager->GetPlayer()->GetPlayerComponent()->GetHealth() > 0)
				p_mcfacade->m_ObjectManager->GetPlayer()->GetAnimComponent()->SetAnimName(PLAYER_HIT, false);
		}

		// Add geodes to targets if they are in attack range
		vector<GameObject*> Geodes = p_mcfacade->m_ObjectManager->GetGeodes();
		for (unsigned int index = 0; index < Geodes.size(); index++)
		{
			//Only check active
			if (!Geodes[index]->GetActive()) continue;
			if (Geodes[index]->GetAIData()->geodeState == AIData::GeDeath) continue;

			//check for a collision
			CollisionShape* pGeodeBounds = Geodes[index]->GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE);
			if (GO.GetPhysicsComponent()->GetCollisionShape(SU_ATTACK)->Collides(pGeodeBounds))
			{
				Geodes[index]->TakeDamage(1);
			}
		}

		pSpiderAI->bAttackSound = false;
		//p_mcfacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_SFX_ROCK_SMALL);
		GO.GetAudioComponent()->PlayAudioFollow(PLAY_SFX_ROCK_SMALL);
		pSpiderAI->bAttacked = true;

		//Make him jump
		///Replace with animation when we have it.
		GO.GetAIData()->fActionCooldownC = 0.25f;

		GO.GetAIData()->bStartLeap = false;

		GO.GetAIData()->m_fAirTime = 0.0f;
		SwitchStateEnemy(GO, AIData::EnReposition);
		pAttackTelegraph->SetEnabled(false);
		//fLifetime = 0.0f;
	}

	else
	{
		GO.GetPhysicsComponent()->SetVelocity(XMFLOAT2(GO.GetAIData()->fTempVel.x, GO.GetAIData()->fTempVel.z));
		GO.SetObjectTranslation(F);
	}

	GO.GetAIData()->m_fAirTime += TimeManager::GetTimeDelta();
	GO.GetAIData()->fActionCooldown += (float)TimeManager::GetTimeDelta();
}
void EnemyBehavior::SetSpiderVel(GameObject& GO)
{
	// Step 1 of 2 - Parabolic Arc:
	// This code is to set an object's Initial Velocity(Vo).
	// Using this velocity, the object will follow a path to the Target Position(P) from the Origin Point(O)
	// The Initial Velocity(Vo) is the result you will use/store. The Time to Impact(t) is how long the moving object
	// will remain in the air for.
	// Store Origin Point(O), Initial Velocity(Vo), and Time to Impact(t) for later use (specifically for use in Step 2 of 2)
	// P  = Target Position
	// O  = Origin Point
	// g  = Gravity
	// Vo = Initial Velocity
	// t  = Time to Impact

	float g, t;
	g = -9.8f;
	t = 1.5f;
	XMFLOAT3 P = XMFLOAT3(p_mcfacade->GetObjectManager()->GetPlayer()->GetObjectTranslation());
	XMFLOAT3 O = XMFLOAT3(GO.GetObjectTranslation());
	XMFLOAT3 Vo;

	GO.GetAIData()->fJumpingPoint = O;
	Vo.x = (P.x - O.x) / t;
	Vo.z = (P.z - O.z) / t;
	Vo.y = -(P.y + ((1.f * g) * (t * t)) - O.y) / t;
	XMFLOAT2 xzVel;
	xzVel.x = Vo.x;
	xzVel.y = Vo.z;

	GO.GetAIData()->fTempVel = Vo;
}
void EnemyBehavior::SetTrapVel(GameObject& GO)
{
	float g, t;
	g = -9.8f;
	t = 1.5f;
	XMFLOAT3 P;
	XMFLOAT3 O = XMFLOAT3(GO.GetObjectTranslation());

	TrapComponent* trapComp = GO.GetTrapComponent();
	XMFLOAT3 Vo;
	XMVECTOR C, Origin;
	Origin = XMLoadFloat3(&O);
	C = (GO.GetTrapComponent()->GetParent()->GetForwardVec() * 20.0f) + Origin;
	XMStoreFloat3(&P, C);
	if (trapComp->GetParent()->GetType() == eSPIDER)
	{

		if (trapComp->GetParent()->GetAIData()->m_nTrapNum == 1)
		{
			P = XMFLOAT3(p_mcfacade->GetObjectManager()->GetPlayer()->GetObjectTranslation());
		}
		else if (trapComp->GetParent()->GetAIData()->m_nTrapNum == 2)
		{
			P.x *= 1.05f;
			P.z *= 1.05f;
		}
		else if (trapComp->GetParent()->GetAIData()->m_nTrapNum == 3)
		{
			P.x *= 0.95f;
			P.z *= 0.95f;
		}
	}

	GO.GetAudioComponent()->PlayAudioFollow(PLAY_SFX_SPIDER_TRAP);

	GO.GetAIData()->fJumpingPoint = O;
	Vo.x = (P.x - O.x) / t;
	Vo.z = (P.z - O.z) / t;
	Vo.y = -(P.y + ((1.0f * g) * (t * t)) - O.y) / t;

	GO.GetAIData()->fTempVel = Vo;
}
void EnemyBehavior::TrapMove(GameObject& GO)
{
	// Step 2 of 2 - Parabolic Arc:
	// This code is responsible for the actual movement of the object
	// DISCLAIMER: F.x and F.z in this code are set equal to the ObjectTranslation.x and ObjectTranslation.z respectively,
	// only for our code
	// F = Destination
	// t = Time in Air
	float t = GO.GetAIData()->m_fAirTime;
	XMFLOAT3 F;

	F.y = ((1.0f * -9.8f) * (t * t)) + (GO.GetAIData()->fTempVel.y * t) + GO.GetAIData()->fJumpingPoint.y;
	F.x = GO.GetObjectTranslation().x;
	F.z = GO.GetObjectTranslation().z;

	if ((F.y <= 0.0f && t > 0.0f)) //|| t >= 0.5f)
	{
		GO.GetPhysicsComponent()->SetVelocity(XMFLOAT2(0.0f, 0.0f));
		GO.GetPhysicsComponent()->SetForwardVelocity(0.0f);
		GO.SetObjectTranslation(F.x, 0.0f, F.z);
		GO.GetAIData()->m_fAirTime = 0.0f;
		GO.GetTrapComponent()->SetToMove(false);
	}

	else
	{
		GO.GetPhysicsComponent()->SetVelocity(XMFLOAT2(GO.GetAIData()->fTempVel.x, GO.GetAIData()->fTempVel.z));
		GO.SetObjectTranslation(F);
	}

	GO.GetAIData()->m_fAirTime += TimeManager::GetTimeDelta();
}
void EnemyBehavior::GolemAttack(GameObject& GO)
{

	AIData* pGolemAI = GO.GetAIData();
	vector<GameObject*>& Targets = pGolemAI->AOETargets;

	ActionState actionState;
	if (pGolemAI->fActionCooldown <= GOLEM_ATTACK_HIT)
		actionState = AS_WINDUP;
	else if (pGolemAI->fActionCooldown <= GOLEM_ATTACK_TIME)
		actionState = AS_HIT;
	else
		actionState = AS_END;


	XMVECTOR WarningColor = XMCLoadFloat4(0.1f, 0.1f, 0.1f, 1.0f); // Black

	switch (actionState)
	{
	case AS_WINDUP:
	{
		if (GO.GetAnimComponent()->GetAnimName() != GOLEM_ATTACK)
		{
			GO.GetAnimComponent()->SetAnimName(GOLEM_ATTACK, false);
			//GO.GetAnimComponent()->SetAnimSpeed(1.2f);
			//GO.GetAnimComponent()->SetAnimationTime(SPIDER_ATTACK_TIME);
		}

		//Get the Possible objects to attack
		for (size_t index = 0; index < Targets.size(); index++)
		{
			GameObject* pTarget = Targets[index];

			if (pTarget->GetReactionTime() <= 0.0f && pTarget->GetType() != ePLAYER)
			{
				pTarget->SetObjectColor(WarningColor);
				pTarget->SetReactionTime(0.333f);
			}
		}
		Targets.clear();
	}
		break;
	case AS_HIT:
	{
		if (!pGolemAI->bActionDone)
		{
			pGolemAI->bActionDone = true;

			for (size_t index = 0; index < Targets.size(); index++)
			{
				GameObject* pTarget = Targets[index];

				//Tell the thing it has taken damage.
				if (pTarget->GetType() == ePLAYER)
				{
					pTarget->GetPlayerComponent()->HitPlayer(p_mcfacade, 1);
					if (pTarget->GetPlayerComponent()->GetHealth() > 0)
						pTarget->GetAnimComponent()->SetAnimName(PLAYER_HIT, false);
				}
				else // is Geode
				{
					pTarget->TakeDamage(1);
					pGolemAI->nUnitsKilled++;
				}
			}

			pGolemAI->bAttackSound = false;
			//p_mcfacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_SFX_GOLEM_ATTACK);
			GO.GetAudioComponent()->PlayAudioFollow(PLAY_SFX_GOLEM_ATTACK);
			pGolemAI->bAttacked = true;

			GO.GetAIData()->m_nAtkNum++;
			//Make him jump
			///Replace with animation when we have it.
			GO.GetAIData()->fActionCooldownC = 0.25f;
			GO.GetChildEmitterComponent(0)->SetSpawning(1.0f);
		}
		else
		{
			Targets.clear();
		}
	}
		break;
	case AS_END:
	{
		GO.GetAIData()->m_nAtkNum++;

		if (GO.GetAIData()->m_nAtkNum > 3)
			GO.GetAIData()->m_nAtkNum = 0;

		GO.SetObjectTranslation(GO.GetObjectTranslation().x, 0, GO.GetObjectTranslation().z);

		SwitchStateEnemy(GO, AIData::EnReposition);
		Targets.clear();
	}
		break;
	}


}
void EnemyBehavior::WormAttack(GameObject& GO)
{
	AIData* pWormAI = GO.GetAIData();
	vector<GameObject*>& Targets = pWormAI->AOETargets;

	//GameObject& AttackCircleGO = *p_mcfacade->GetObjectManager()->GetWormAttack();
	Circle& AttackCircleShape = *dynamic_cast<Circle*>(GO.GetPhysicsComponent()->GetCollisionShape(SU_ATTACK));

	ActionState actionState;
	if (pWormAI->fActionCooldown <= WORM_ATTACK_WINDUP)
	{
		actionState = AS_WINDUP;
		pWormAI->fActionCooldownB = 0.0f;
	}
	else if (pWormAI->fActionCooldownB <= WORM_ATTACK_HIT)
	{
		actionState = AS_HIT;
		pWormAI->fActionCooldownB += TimeManager::GetTimeDelta();
	}
	else if (pWormAI->fActionCooldown > WORM_ATTACK_TIME || pWormAI->fActionCooldownB > WORM_ATTACK_HIT)
		actionState = AS_END;

	GO.GetAnimComponent()->SetAnimSpeed(p_mcfacade->GetAssetManager()->GetAnimation(WORM_ATTACK)->GetAnimTime() / 3.0F);


	XMVECTOR WarningColor = XMCLoadFloat4(0.1f, 0.1f, 0.1f, 1.0f); // Black
	switch (actionState)
	{
	case AS_WINDUP:
	{
		//if (pWormAI->bAttackSound == false && pWormAI->fActionCooldown >= 1.0f)
		//{
		//	//p_mcfacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_FX_3D_BODYFALL);
		//	pWormAI->bAttackSound = true;
		//}

		//Get the Possible objects to attack
		for (size_t index = 0; index < Targets.size(); index++)
		{
			GameObject* pTarget = Targets[index];

			if (pTarget->GetReactionTime() <= 0.0f && pTarget->GetType() != ePLAYER)
			{
				pTarget->SetObjectColor(WarningColor);
				pTarget->SetReactionTime(0.333f);
			}
		}
		Targets.clear();

		//AttackCircleGO.SetObjectTranslation(GO.GetObjectTranslation());
		AttackCircleShape.SetOffset(XMCLoadFloat2(0, 0));
		//AttackCirclePhys.SetVelocity({ 0, 0 });

		float PC = GO.GetChildTelegraphComponent(eWORM_ATTACK_TELEGRAPH)->GetPercentage();
		if (PC >= 0.99f)
			GO.GetChildTelegraphComponent(eWORM_ATTACK_TELEGRAPH)->SetFreeze(true);

	}
		break;
	case AS_HIT:
	{
		//AttackCircleGO.SetActive(true);
		GO.GetChildTelegraphComponent(eWORM_ATTACK_TELEGRAPH)->SetFreeze(true);

		for (size_t index = 0; index < Targets.size(); index++)
		{
			GameObject* pTarget = Targets[index];

			//Tell the thing it has taken damage.
			if (pTarget->GetType() == ePLAYER && !pWormAI->bActionDone)
			{
				pTarget->GetPlayerComponent()->HitPlayer(p_mcfacade, 1);
				if (pTarget->GetPlayerComponent()->GetHealth() > 0)
					pTarget->GetAnimComponent()->SetAnimName(PLAYER_HIT, false);

				pWormAI->bActionDone = true;
			}
			else // is Geode
			{
				pTarget->TakeDamage();
				pWormAI->nUnitsKilled++;
			}
		}

		if (!pWormAI->bAttackSound)
		{
			//p_mcfacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::);
			GO.GetAudioComponent()->PlayAudioFollow(PLAY_SFX_WORM_STRIKE);
			pWormAI->bAttackSound = true;
		}

		XMVECTOR ForwardVec = XMCVector3SwizzleXZ(GO.GetForwardVec());
		XMVECTOR ObjectPosition = XMCVector3SwizzleXZ(GO.GetObjectTranslationVec());
		XMVECTOR ShapePosition = AttackCircleShape.GetPosition();
		XMVECTOR TargetPos = ObjectPosition + ForwardVec * 24;

		XMVECTOR toVector = TargetPos - ObjectPosition;
		float TargetDistance = XMCVector2Dot(toVector, toVector);

		toVector = TargetPos - ShapePosition;
		float ShapeDistance = XMCVector2Dot(toVector, toVector) + AttackCircleShape.GetRadius() /** AttackCircleShape.GetRadius()*/;

		TargetDistance = abs(TargetDistance);
		ShapeDistance = abs(ShapeDistance);

		float speed = 190.0f * (ShapeDistance / TargetDistance);
		if (speed < 0.0f)
			speed = 0.0f;

		XMVECTOR offset = AttackCircleShape.GetOffset() + ForwardVec * speed * TimeManager::GetTimeDelta();
		AttackCircleShape.SetOffset(offset);
		//AttackCircleGO.SetObjectTranslation(XMCVector2SwizzleXZ(AttackCircleShape.GetPosition()));
	}
		break;
	case AS_END:
	{
		pWormAI->m_nAtkNum++;

		if (pWormAI->m_nAtkNum > 2)
		{
			pWormAI->m_nAtkNum = 0;
			pWormAI->bEnemySpecialC = true;
		}
		Targets.clear();

		//AttackCircleGO.SetActive(false);
		//AttackCircleGO.SetObjectTranslation(GO.GetObjectTranslation());
		AttackCircleShape.SetOffset(XMCLoadFloat2(0, 0));
		GO.GetChildTelegraphComponent(eWORM_ATTACK_TELEGRAPH)->SetFreeze(false);
		pWormAI->fActionCooldown = pWormAI->fActionCooldownB = pWormAI->fActionCooldownD = 0.0f;
		pWormAI->fActionCooldownC = 2.0f;
		pWormAI->bAttackSound = false;
		pWormAI->bAttacked = true;
		SwitchStateEnemy(GO, AIData::EnReposition);
	}
		break;
	}


}
void EnemyBehavior::EnemyDeath(GameObject& GO)
{
	float dt = TimeManager::GetTimeDelta();
	AIData * data = GO.GetAIData();
	data->fActionCooldown += dt;
	std::vector<GameObject*> webList = p_mcfacade->GetObjectManager()->GetSpiderTraps();
	std::vector<GameObject*> tunnelList = p_mcfacade->GetObjectManager()->GetWormTraps();



	if (GO.GetType() == eWORM)
	{
		if (XMConvertToDegrees(data->fActionCooldown*5.0f) <= 180.0f)
		{
			XMMATRIX current = GO.GetWorldTransformMat();
			current = XMMatrixRotationZ(dt * 5.0f) * current;
			GO.SetObjectTransform(current);

			GO.SetObjectTranslation(GO.GetObjectTranslation().x, GO.GetObjectTranslation().y + dt * 7.5f, GO.GetObjectTranslation().z);
		}
	}

	//Disable All remaining web traps
	if (GO.GetType() == eSPIDER)
	{
		for (unsigned int i = 0; i < webList.size(); i++)
		{
			if (webList[i]->GetTrapComponent()->GetParent() == &GO && webList[i]->GetActive())
			{
				webList[i]->SetActive(false);
				webList[i]->GetTrapComponent()->SetEnabled(false);
				break;
			}
		}
	}

	//Disable All remaining worm traps
	if (GO.GetType() == eWORM)
	{
		for (unsigned int i = 0; i < tunnelList.size(); i++)
		{
			if (tunnelList[i]->GetTrapComponent()->GetParent() == &GO && tunnelList[i]->GetActive() && !tunnelList[i]->GetTrapComponent()->GetTimerEnabled())
			{
				tunnelList[i]->GetTrapComponent()->SetTimerEnabled(true);
				tunnelList[i]->GetAIData()->bEnemySpecialB = true;
				tunnelList[i]->GetAIData()->fActionCooldownC = 1.0f;
				tunnelList[i]->GetPhysicsComponent()->DeactivateCollision();
				tunnelList[i]->GetChildEmitterComponent(0)->SetSpawnTimer(5.0f);
				tunnelList[i]->GetChildEmitterComponent(1)->SetSpawnTimer(5.0f);
				break;
			}
		}
	}

	if ((GO.GetType() == eGOLEM && data->fActionCooldown >= p_mcfacade->GetAssetManager()->GetAnimation(GOLEM_DEATH_ANIM)->GetAnimTime()) ||
		(GO.GetType() == eSPIDER && data->fActionCooldown >= p_mcfacade->GetAssetManager()->GetAnimation(SPIDER_DEATH_ANIM)->GetAnimTime()) ||
		(GO.GetType() == eWORM && data->fActionCooldown >= SPIDER_DEATH))
	{
		GO.SetActive(false);
		//Update Doors

		switch (GO.GetType())
		{
		case eGOLEM:
		{
			//p_mcfacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::);
			GO.GetAudioComponent()->PlayAudioFollow(PLAY_SFX_GOLEM_DEATH);
			break;
		}
		case eSPIDER:
		{
			//p_mcfacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::);
			GO.GetAudioComponent()->PlayAudioFollow(PLAY_SFX_SPIDER_DEATH);
			break;
		}
		case eWORM:
		{
			//p_mcfacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::);
			GO.GetAudioComponent()->PlayAudioFollow(PLAY_SFX_GOLEM_DEATH);
			break;
		}
		default:
			break;
		}

		GO.SetObjectTranslation(GO.GetObjectTranslation().x, GO.GetObjectTranslation().y - dt * 4.0f, GO.GetObjectTranslation().z);

		if ((GO.GetType() == eGOLEM && !p_mcfacade->GetDiamondUnlock()) || GO.GetTag() == "DumbSpider")
			return;

		vector<GameObject*>& Doors = p_mcfacade->m_ObjectManager->GetDoors();
		for each (GameObject* pDoor in Doors)
		{
			EventComponent* doorEvent = pDoor->GetEventComponent();
			doorEvent->TargetsRemaining--;
			if (doorEvent->TargetsRemaining == 0)
				doorEvent->Triggered = true;
		}

		for (size_t i = 0; i < p_mcfacade->m_ObjectManager->GetSpawners().size(); i++)
		{
			p_mcfacade->m_ObjectManager->GetSpawners()[i]->GetSpawnerComponent()->TotalLeft--;
			p_mcfacade->m_ObjectManager->GetSpawners()[i]->GetSpawnerComponent()->GrandTotal++;
		}

		for (size_t i = 0; i < p_mcfacade->m_ObjectManager->GetTorches().size(); i++)
		{
			if (p_mcfacade->m_ObjectManager->GetTorches()[i]->GetChildPointLight(0)->GetTag() == "DoorTorch")
				p_mcfacade->m_ObjectManager->GetTorches()[i]->GetEventComponent()->TargetsRemaining--;
		}

	}
}
void EnemyBehavior::EnemyTrap(GameObject& GO)
{
	switch (GO.GetType())
	{
	case eSPIDER:	return SpiderTrap(GO);
	case eGOLEM:	return GolemTrap(GO);
	case eWORM:		return WormTrap(GO);
	}
}
void EnemyBehavior::SpiderTrap(GameObject& GO)
{
	//if (GO.GetTag() != "DumbSpider" && GO.GetAIData()->m_nAtkNum < 2 && GO.GetTag() != "FearSpider" && GO.GetAIData()->fActionCooldown >= 0.01f)
	//{
	//	GO.GetAIData()->m_nTrapNum = 0;
	//	for (unsigned int index = 0; index < trapList.size(); index++)
	//	{
	//		if (trapList[index]->GetTrapComponent()->GetParent() == &GO)
	//		{
	//			GO.GetAIData()->m_nTrapNum++;
	//			if (trapList[index]->GetActive() == false)
	//			{
	//				trapList[index]->GetTrapComponent()->SetOffset(XMFLOAT3(0.0f, 0.0f, 0.0f));
	//				trapList[index]->SetObjectTranslation(GO.GetObjectTranslation());
	//				trapList[index]->SetActive(true);
	//				trapList[index]->GetTrapComponent()->SetEnabled(true);
	//				trapList[index]->GetTrapComponent()->SetToMove(true);
	//				SetTrapVel(*trapList[index]);
	//				//TrapMove(*trapList[index]);
	//			}
	//
	//			if (trapList[index]->GetTrapComponent()->GetToMove())
	//				TrapMove(*trapList[index]);
	//		}
	//
	//		if (GO.GetAIData()->m_nTrapNum == 3)
	//			break;
	//	}
	//}
	ActionState actionState;
	if (GO.GetAIData()->fActionCooldown <= SPIDER_ATTACK_TIME)
		actionState = AS_WINDUP;
	else
		actionState = AS_END;
	vector<GameObject*>& trapList = GO.GetAIData()->m_TrapList;
	if (actionState == AS_END)
	{
		SwitchStateEnemy(GO, AIData::EnReposition);
	}
	else if (actionState == AS_WINDUP)
	{

		if (GO.GetTag() != "DumbSpider" /*&& GO.GetAIData()->m_nAtkNum < 2 && GO.GetAIData()->fActionCooldown >= 0.01f*/)
		{
			GO.GetAIData()->fActionCooldown += TimeManager::GetTimeDelta();
			GO.GetAIData()->m_nTrapNum = 0;
			for (unsigned int index = 0; index < trapList.size(); index++)
			{
				if (trapList[index]->GetTrapComponent()->GetParent() == &GO)
				{
					GO.GetAIData()->m_nTrapNum++;
					if (trapList[index]->GetActive() == false)
					{
						trapList[index]->GetTrapComponent()->SetOffset(XMFLOAT3(0.0f, 0.0f, 0.0f));
						trapList[index]->SetObjectTranslation(GO.GetObjectTranslation());
						trapList[index]->SetActive(true);
						trapList[index]->GetTrapComponent()->SetEnabled(true);
						trapList[index]->GetTrapComponent()->SetToMove(true);
						SetTrapVel(*trapList[index]);
					}

					if (trapList[index]->GetTrapComponent()->GetToMove())
						TrapMove(*trapList[index]);
				}
			}
		}
	}
}
void EnemyBehavior::GolemTrap(GameObject& GO)
{
	AIData * pGolemAI = GO.GetAIData();

	//Random Positions around the Golem
	XMVECTOR RandomVec = XMCRandomUnitVector2() * 4.0f;
	RandomVec *= UnitRand() * 4.0f;
	XMFLOAT2 RandVecFloat2;
	XMStoreFloat2(&RandVecFloat2, RandomVec);

	XMFLOAT3 RockPos1 = GO.GetObjectTranslation();
	RockPos1.z += 16.0f;
	RockPos1.x += RandVecFloat2.x;
	RockPos1.z += RandVecFloat2.y;

	//--------------------------------------------------------
	RandomVec = XMCRandomUnitVector2() * 4.0f;
	RandomVec *= UnitRand() * 4.0f;
	XMStoreFloat2(&RandVecFloat2, RandomVec);

	XMFLOAT3 RockPos2 = GO.GetObjectTranslation();
	RockPos2.x += 12.0f;
	RockPos2.z += 12.0f;
	RockPos2.x += RandVecFloat2.x;
	RockPos2.z += RandVecFloat2.y;

	//--------------------------------------------------------
	RandomVec = XMCRandomUnitVector2() * 4.0f;
	RandomVec *= UnitRand() * 4.0f;
	XMStoreFloat2(&RandVecFloat2, RandomVec);

	XMFLOAT3 RockPos3 = GO.GetObjectTranslation();
	RockPos3.x += 16.0f;
	RockPos3.x += RandVecFloat2.x;
	RockPos3.z += RandVecFloat2.y;

	//--------------------------------------------------------
	RandomVec = XMCRandomUnitVector2() * 4.0f;
	RandomVec *= UnitRand() * 4.0f;
	XMStoreFloat2(&RandVecFloat2, RandomVec);

	XMFLOAT3 RockPos4 = GO.GetObjectTranslation();
	RockPos4.x += 12.0f;
	RockPos4.z += -12.0f;
	RockPos4.x += RandVecFloat2.x;
	RockPos4.z += RandVecFloat2.y;

	//--------------------------------------------------------
	RandomVec = XMCRandomUnitVector2() * 4.0f;
	RandomVec *= UnitRand() * 4.0f;
	XMStoreFloat2(&RandVecFloat2, RandomVec);

	XMFLOAT3 RockPos5 = GO.GetObjectTranslation();
	RockPos5.z += -16.0f;
	RockPos5.x += RandVecFloat2.x;
	RockPos5.z += RandVecFloat2.y;


	//--------------------------------------------------------
	RandomVec = XMCRandomUnitVector2() * 4.0f;
	RandomVec *= UnitRand() * 4.0f;
	XMStoreFloat2(&RandVecFloat2, RandomVec);

	XMFLOAT3 RockPos6 = GO.GetObjectTranslation();
	RockPos6.x += -12.0f;
	RockPos6.z += -12.0f;
	RockPos6.x += RandVecFloat2.x;
	RockPos6.z += RandVecFloat2.y;

	//--------------------------------------------------------
	RandomVec = XMCRandomUnitVector2() * 4.0f;
	RandomVec *= UnitRand() * 4.0f;
	XMStoreFloat2(&RandVecFloat2, RandomVec);

	XMFLOAT3 RockPos7 = GO.GetObjectTranslation();
	RockPos7.x += -16.0f;
	RockPos7.x += RandVecFloat2.x;
	RockPos7.z += RandVecFloat2.y;

	//--------------------------------------------------------
	RandomVec = XMCRandomUnitVector2() * 4.0f;
	RandomVec *= UnitRand() * 4.0f;
	XMStoreFloat2(&RandVecFloat2, RandomVec);

	XMFLOAT3 RockPos8 = GO.GetObjectTranslation();
	RockPos8.x += -12.0f;
	RockPos8.z += 12.0f;
	RockPos8.x += RandVecFloat2.x;
	RockPos8.z += RandVecFloat2.y;


	//---------------------------------------------------------




	ActionState actionState;
	if (pGolemAI->fActionCooldown <= GOLEM_TRAP_TIME)
		actionState = AS_WINDUP;
	else
		//else if (pGolemAI->fActionCooldown <= (GOLEM_TRAP_TIME * 2.0f))
		actionState = AS_HIT;
	//else
	//	actionState = AS_END;

	if (actionState == AS_WINDUP)
	{
		GO.GetAnimComponent()->SetAnimSpeed(1.7f);
	}


	if (actionState == AS_HIT)
	{
		//p_mcfacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::);
		GO.GetAudioComponent()->PlayAudioFollow(PLAY_SFX_GOLEM_SMASH);
		int UpdateMax = 8;
		int UpdateCurrent = 0;

		vector<GameObject*> AllTheRocks = p_mcfacade->m_ObjectManager->GetFallRocks();

		for (unsigned int RockIndex = 0; RockIndex < AllTheRocks.size(); RockIndex++)
		{
			if (AllTheRocks[RockIndex]->GetTrapComponent()->GetParent() != &GO)
				continue;

			Telegraph* pAttackTelegraph = AllTheRocks[RockIndex]->GetChildTelegraphComponent(eGOLEM_ATTACK_TELEGRAPH);

			//Setup if you are not moving
			if (AllTheRocks[RockIndex]->GetActive() == false && pAttackTelegraph->GetEnabled() == false)
			{
				UpdateCurrent++;

				float tillAct = (float)(rand() % 4);


				if (UpdateCurrent == 1)
				{
					AllTheRocks[RockIndex]->SetObjectTranslation(RockPos1.x, 60.0f, RockPos1.z);
					AllTheRocks[RockIndex]->GetTrapComponent()->SetTimeTillAct(0.0f);
				}
				else if (UpdateCurrent == 2)
				{
					AllTheRocks[RockIndex]->SetObjectTranslation(RockPos2.x, 60.0f, RockPos2.z);
					AllTheRocks[RockIndex]->GetTrapComponent()->SetTimeTillAct(1.0f);
				}
				else if (UpdateCurrent == 3)
				{
					AllTheRocks[RockIndex]->SetObjectTranslation(RockPos3.x, 60.0f, RockPos3.z);
					AllTheRocks[RockIndex]->GetTrapComponent()->SetTimeTillAct(2.5f);
				}
				else if (UpdateCurrent == 4)
				{
					AllTheRocks[RockIndex]->SetObjectTranslation(RockPos4.x, 60.0f, RockPos4.z);
					AllTheRocks[RockIndex]->GetTrapComponent()->SetTimeTillAct(3.0f);
				}
				else if (UpdateCurrent == 5)
				{
					AllTheRocks[RockIndex]->SetObjectTranslation(RockPos5.x, 60.0f, RockPos5.z);
					AllTheRocks[RockIndex]->GetTrapComponent()->SetTimeTillAct(4.5f);
				}
				else if (UpdateCurrent == 6)
				{
					AllTheRocks[RockIndex]->SetObjectTranslation(RockPos6.x, 60.0f, RockPos6.z);
					AllTheRocks[RockIndex]->GetTrapComponent()->SetTimeTillAct(5.0f);
				}
				else if (UpdateCurrent == 7)
				{
					AllTheRocks[RockIndex]->SetObjectTranslation(RockPos7.x, 60.0f, RockPos7.z);
					AllTheRocks[RockIndex]->GetTrapComponent()->SetTimeTillAct(2.8f);
				}
				else if (UpdateCurrent == 8)
				{
					AllTheRocks[RockIndex]->SetObjectTranslation(RockPos8.x, 60.0f, RockPos8.z);
					AllTheRocks[RockIndex]->GetTrapComponent()->SetTimeTillAct(0.6f);
				}


				AllTheRocks[RockIndex]->SetActive(false);
				AllTheRocks[RockIndex]->GetTrapComponent()->SetEnabled(true);
				AllTheRocks[RockIndex]->GetTrapComponent()->SetToMove(true);

				//pAttackTelegraph->SetOffset(AllTheRocks[RockIndex]->GetObjectTranslation().x, AllTheRocks[RockIndex]->GetObjectTranslation().z);
				pAttackTelegraph->SetEnabled(false);
				pAttackTelegraph->SetTime(ROCK_FALL_TIME);
				//pAttackTelegraph->Update();
			}

			if (UpdateCurrent == UpdateMax)
				break;
		}

		GO.GetAIData()->m_nAtkNum++;
		SwitchStateEnemy(GO, AIData::EnReposition);
	}

	pGolemAI->fActionCooldown += TimeManager::GetTimeDelta();

}
void EnemyBehavior::WormTrap(GameObject& GO)
{
	AIData& wormData = *GO.GetAIData();
	GameObject* trap = wormData.ObjTarget;

	if (trap == nullptr && wormData.bEnemySpecialB)
	{
		//Grab the first available trap
		vector<GameObject*> worm_traps = p_mcfacade->GetObjectManager()->GetWormTraps();
		GameObject * available = nullptr;
		for (size_t i = 0; i < worm_traps.size(); i++)
		{
			if (!worm_traps[i]->GetActive() && worm_traps[i]->GetTrapComponent()->GetParent() == &GO)
			{
				available = worm_traps[i];
				break;
			}
		}

		//Return if no traps are available
		if (available == nullptr)
			return;

		//Set up the trap 
		XMVECTOR pos = GO.GetObjectTranslationVec();
		wormData.ObjTarget = available;
		pos = XMVectorSetY(pos, 1.0f);
		available->SetObjectTranslation(pos);
		available->SetActive(true);
		available->GetTrapComponent()->SetEnabled(true);
		available->GetTrapComponent()->SetTimerEnabled(false);
		available->GetPhysicsComponent()->DeactivateCollision();
		available->GetAIData()->bEnemySpecialA = false;
		available->GetAIData()->m_nAtkNum = 0;
		available->SetScale(0.1f);

		trap = available;
		GO.GetAudioComponent()->PlayAudioFollow(PLAY_SFX_WORM_BURROW);
		//p_mcfacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::);
		return;
	}

	if (trap == nullptr)
		return;



	//Make sure it's not emerging if it says it is submerged
	if (trap->GetTrapComponent() != nullptr && wormData.bSubmerged && !wormData.bEnemySpecialB)
	{
		trap->GetTrapComponent()->SetTimerEnabled(true);
		trap->GetAIData()->fActionCooldownC = 1.0f;
		trap->GetPhysicsComponent()->ActivateCollision();
		trap->GetAIData()->bEnemySpecialB = false;
		wormData.ObjTarget = nullptr;

		return;
	}
	else
	{
		if (trap->GetAIData()->fActionCooldownC < 1.0f)
		{
			trap->GetAIData()->fActionCooldownC += TimeManager::GetTimeDelta() * 1.5f;
			XMCClamp(trap->GetAIData()->fActionCooldownC);
			trap->SetScale(trap->GetAIData()->fActionCooldownC);
		}
	}


}
void EnemyBehavior::WormReposition(GameObject& GO)
{
	//Grab AI Data for the worm
	AIData& wormData = *GO.GetAIData();
	GameObject& player = *p_mcfacade->GetObjectManager()->GetPlayer();

	//See if the worm is submerged from patrolling and emerge the worm here.
	if ((wormData.bSubmerged || wormData.bSubmerging) && !wormData.bEnemySpecialC)
	{
		//Emerge from the ground.
		if (!wormData.bEnemySpecialB)
		{
			wormData.bEnemySpecialB = true;
			wormData.fActionCooldown = p_mcfacade->GetAssetManager()->GetAnimation(WORM_EMERGE_ANIM)->GetAnimTime();
			GO.GetChildEmitterComponent(eWORM_TRAIL1_EMITTER)->SetSpawning(false);
			GO.GetChildEmitterComponent(eWORM_TRAIL2_EMITTER)->SetSpawning(false);
			GO.GetChildEmitterComponent(eWORM_TRAIL1_EMITTER)->SetSpawnTimer(wormData.fActionCooldown);
			GO.GetChildEmitterComponent(eWORM_TRAIL2_EMITTER)->SetSpawnTimer(wormData.fActionCooldown);
			GO.GetAnimComponent()->SetAnimName(WORM_EMERGE_ANIM, false);
			WormCorrection(GO, GO);
		}
		else
		{
			wormData.fActionCooldown -= TimeManager::GetTimeDelta();

			XMFLOAT3 offset = GO.GetChildEmitterComponent(eWORM_TRAIL1_EMITTER)->GetPositionOffset();
			offset.y += (60.0f * TimeManager::GetTimeDelta());
			XMCClamp(offset.y, 0.0f, 40.0f);
			GO.GetChildEmitterComponent(eWORM_TRAIL1_EMITTER)->SetPositionOffset(offset);

			offset = GO.GetChildEmitterComponent(eWORM_TRAIL2_EMITTER)->GetPositionOffset();
			offset.y += (60.0f * TimeManager::GetTimeDelta());
			XMCClamp(offset.y, 0.0f, 40.0f);
			GO.GetChildEmitterComponent(eWORM_TRAIL2_EMITTER)->SetPositionOffset(offset);

			WormTrap(GO);
		}

		if (wormData.fActionCooldown <= 0.0f)
		{
			GO.GetChildEffectObject(eWORM_HEALTHBAR_EFFECT)->SetActive(true);
			GO.GetChildEmitterComponent(eWORM_TRAIL1_EMITTER)->SetSpawning(false);
			GO.GetChildEmitterComponent(eWORM_TRAIL2_EMITTER)->SetSpawning(false);
			GO.GetChildEmitterComponent(eWORM_TRAIL1_EMITTER)->SetPositionOffset({ 0, 0, 0 });
			GO.GetChildEmitterComponent(eWORM_TRAIL2_EMITTER)->SetPositionOffset({ 0, 0, 0 });
			wormData.bSubmerged = wormData.bSubmerging = false;
			wormData.bEnemySpecialB = false;
			wormData.fActionCooldown = 0.0f;

		}

		return;
	}

	//Update the our trap 
	WormTrap(GO);

	//If the worm is already emerged then find out if it needs repositioning.
	//Grab Player Data
	//Grab Worm Range Check.
	Circle& wormRangedScan = *dynamic_cast<Circle*>(GO.GetPhysicsComponent()->GetCollisionShape(SU_RANGEDATTACK));

	//List of targets in range of the worm
	vector<GameObject*> Targets_inRange;

	//Bool: Player is in range
	bool playerInRange = false;
	//Bool: Attacking Target in range
	bool AttkTarget = false;

	//Have a target area to be facing.
	XMVECTOR avgAttkPos = XMVectorZero();
	int numOfAttks = 0;

	//Tell me all the objects in range.
	list<CollisionShape*> stuff = wormRangedScan.GetDetectedShapes();
	auto itter = stuff.begin();
	for (; itter != stuff.end(); itter++)
	{
		if ((*itter)->GetShapeUsage() != SU_BOUNDING_SHAPE)
			continue;

		GameObject& current = *(*itter)->GetGameObjectHolder();

		if (IsGeode((*itter)->GetGameObjectHolder()))
			Targets_inRange.push_back((*itter)->GetGameObjectHolder());
		else if (current.GetType() == ePLAYER)
			playerInRange = true;
	}

	//Now See if any of those targets are attacking
	for (size_t i = 0; i < Targets_inRange.size(); i++)
	{
		AIData& geodeData = *Targets_inRange[i]->GetAIData();

		if (geodeData.geodeState == AIData::GeAttack && geodeData.ObjTarget == &GO)
		{
			AttkTarget = true;
			numOfAttks++;

			avgAttkPos += Targets_inRange[i]->GetObjectTranslationVec();
		}
	}

#pragma region Face your enemies
	//Look towards something, if we're not submerging.
	if (!wormData.bEnemySpecialC)
	{
		GO.GetAnimComponent()->SetAnimName(WORM_IDLE, true);
		XMVECTOR rightVec = XMVector3Normalize(GO.GetWorldTransformMat().r[0]);
		XMVECTOR forwardVec = XMVector3Normalize(GO.GetWorldTransformMat().r[2]);
		XMMATRIX rotation = XMMatrixIdentity();
		XMVECTOR toVector;
		float dot_turn, dot_front;

		if (AttkTarget && numOfAttks > 0)
		{
			avgAttkPos /= float(numOfAttks);
			toVector = XMVector3Normalize(avgAttkPos - GO.GetObjectTranslationVec());

			dot_turn = XMCVector3Dot(rightVec, toVector);
			dot_front = XMCVector3Dot(forwardVec, toVector);
		}
		else
		{
			toVector = XMVector3Normalize(player.GetObjectTranslationVec() - GO.GetObjectTranslationVec());

			dot_turn = XMCVector3Dot(rightVec, toVector);
			dot_front = XMCVector3Dot(forwardVec, toVector);
		}

		if (!(dot_turn >= -0.1f && dot_turn <= 0.1f) || !(dot_front > 0.9f))
			rotation = XMMatrixRotationY(TimeManager::GetTimeDelta() * 5.0f * dot_turn);


		GO.SetWorldTransform(rotation * GO.GetWorldTransformMat());

		if ((AttkTarget || playerInRange) && dot_turn >= -0.1f && dot_turn <= 0.1f && dot_front > 0.9f)
		{
			/*wormData.fActionCooldownD = 0.0f;

			if (wormData.bAttacked && numOfAttks > 1)
			SwitchStateEnemy(GO, AIData::EnDebuff);
			else if (wormData.fActionCooldownC <= 0.0f)
			{
			wormData.fActionCooldownC = 0.0f;
			wormData.bAttacked = false;
			SwitchStateEnemy(GO, AIData::EnAttack);
			}
			else
			{
			wormData.fActionCooldownC -= TimeManager::GetTimeDelta();
			}*/
			if (wormData.AttackCooldownSwitcher <= 0.0f)
			{
				SwitchStateEnemy(GO, AIData::EnAttack);
				wormData.AttackCooldownSwitcher = UNVATTACKSET;
			}
			else if (wormData.TrapCooldownSwitcher <= 0.0f)
			{
				SwitchStateEnemy(GO, AIData::EnReposition);
				AttkTarget = true;
				wormData.TrapCooldownSwitcher = UNVTRAPSET;
			}
			else if (wormData.DebuffCooldownSwitcher <= 0.0f)
			{
				SwitchStateEnemy(GO, AIData::EnDebuff);
				wormData.DebuffCooldownSwitcher = UNVDEBUFFSET;
			}
			else
			{
				wormData.AttackCooldownSwitcher -= TimeManager::GetTimeDelta() * 2.0f;
				wormData.TrapCooldownSwitcher -= TimeManager::GetTimeDelta() * 2.0f;
				wormData.DebuffCooldownSwitcher -= TimeManager::GetTimeDelta() * 2.0f;
			}
		}

		wormData.fActionCooldownC = 2.0f; //Used to keep the worm above ground for combat so it gives time for a geode to attack him.
	}
#pragma endregion


	//If nothing is in range. See if the player is in range.
	if (!AttkTarget && !playerInRange && wormData.fActionCooldownC < 0.0f)
	{
		//How far is the player
		XMVECTOR distanceVEC = XMCVector3SwizzleXZ(player.GetObjectTranslationVec()) - XMCVector3SwizzleXZ(GO.GetObjectTranslationVec());
		float dot_result = XMCVector2Dot(distanceVEC, distanceVEC);
		float rad_sq = (wormRangedScan.radius + 15.0f) * (wormRangedScan.radius + 15.0f);
		if (dot_result >= rad_sq)
		{
			//Add Fix to get the worm back above ground if player gets out of range while submerging.7
			wormData.fActionCooldownC = 2.0f;
			wormData.fActionCooldownD = wormData.fActionCooldownB = wormData.fActionCooldown = 0.0f;
			wormData.bEnemySpecialA = wormData.bEnemySpecialB = wormData.bEnemySpecialC = false;

			SwitchStateEnemy(GO, AIData::EnPatrol);
			return;
		}
	}


#pragma region Submerge and Emerge Code

	//Only Move if nothing is in range of the worm.
	if ((!AttkTarget && !playerInRange && wormData.fActionCooldownD > 3.0f) || wormData.bEnemySpecialC)
	{
		//   Variables				|	 What they are
		//		bEnemySpecialA		|		Submerge bool
		//		bEnemySpecialB		|		Emerge bool
		//		fActionCooldownD	|		Reposition Timer
		wormData.bEnemySpecialC = true;
		XMVECTOR wormPos = GO.GetObjectTranslationVec();

		//First see if the Worm is submerged and has not already emerged. If it has not submerged than we're going to submerge it.
		if (!wormData.bEnemySpecialA && !wormData.bEnemySpecialB)
		{
			if (!wormData.bSubmerging)
			{
				wormData.bSubmerging = true;
				wormData.fActionCooldown = p_mcfacade->GetAssetManager()->GetAnimation(WORM_SUBMERGE_ANIM)->GetAnimTime();
				GO.GetAnimComponent()->StopTransition();
				GO.GetAnimComponent()->SetAnimName(WORM_SUBMERGE_ANIM, false);
				GO.GetChildEmitterComponent(eWORM_TRAIL1_EMITTER)->SetSpawning(true);
				GO.GetChildEmitterComponent(eWORM_TRAIL2_EMITTER)->SetSpawning(true);
			}
			else
				wormData.fActionCooldown -= TimeManager::GetTimeDelta();

			//Start moving down to Submerge
			if (wormData.fActionCooldown < 0.0f)
			{
				wormData.bSubmerging = false;
				wormData.bEnemySpecialA = wormData.bSubmerged = true;
				GO.GetChildEffectObject(eWORM_HEALTHBAR_EFFECT)->SetActive(false);
				GO.GetPhysicsComponent()->DeactivateCollision();
				wormData.fActionCooldownB = wormData.fActionCooldown = 0.0f;

				//Turn on effects for awesomeness.

				GO.GetAnimComponent()->SetAnimSpeed(0.0f);
				GO.GetAnimComponent()->SetKeyTime(p_mcfacade->GetAssetManager()->GetAnimation(WORM_SUBMERGE_ANIM)->GetAnimTime() - 0.001f);
			}


		}

		//Spend some time underground so you can reposition the worm under the player the best you can.
		if (wormData.bEnemySpecialA && !wormData.bEnemySpecialB)
		{

			wormData.fActionCooldownB += TimeManager::GetTimeDelta();

			if (wormData.fActionCooldownB >= WORM_EMERGE)
			{
				wormData.bEnemySpecialB = true;
				wormData.fActionCooldownB = 0.0f;
				wormData.fTargetPos = player.GetObjectTranslation(); //This will be the last known position of the player.
			}
			else
			{
				//Get player's position
				XMVECTOR playerPOS = player.GetObjectTranslationVec();

				//Now move the worm under the player.
				GO.SetObjectTranslation(XMVectorSetY(playerPOS, GO.GetObjectTranslation().y));

				//Activate the telegraph if we haven't already.
				GO.GetChildTelegraphComponent(eWORM_EMERGE_TELEGRAPH)->SetEnabled(true);
				//Make it follow the player.

				//Correct the worm if it is on top of traps to keep the traps from overlapping.
				WormCorrection(player, GO);
			}
		}

		//Time to strike! Emerge from the ground of where you think the player is.
		if (wormData.bEnemySpecialA && wormData.bEnemySpecialB)
		{
			wormData.fActionCooldownB += TimeManager::GetTimeDelta();

			if (wormData.fActionCooldownB >= WORM_EMERGE_DELAY)
			{

				if (!wormData.bEnemySpecialD)
				{
					wormData.bEnemySpecialD = true;
					wormData.fActionCooldown = p_mcfacade->GetAssetManager()->GetAnimation(WORM_EMERGE_ANIM)->GetAnimTime();
					GO.GetChildEmitterComponent(eWORM_TRAIL1_EMITTER)->SetSpawning(false);
					GO.GetChildEmitterComponent(eWORM_TRAIL2_EMITTER)->SetSpawning(false);
					GO.GetChildEmitterComponent(eWORM_TRAIL1_EMITTER)->SetSpawnTimer(wormData.fActionCooldown);
					GO.GetChildEmitterComponent(eWORM_TRAIL2_EMITTER)->SetSpawnTimer(wormData.fActionCooldown);
					GO.GetAnimComponent()->SetAnimName(WORM_EMERGE_ANIM, false);
				}
				else
				{
					wormData.fActionCooldown -= TimeManager::GetTimeDelta();

					XMFLOAT3 offset = GO.GetChildEmitterComponent(eWORM_TRAIL1_EMITTER)->GetPositionOffset();
					offset.y += (60.0f * TimeManager::GetTimeDelta());
					XMCClamp(offset.y, 0.0f, 40.0f);
					GO.GetChildEmitterComponent(eWORM_TRAIL1_EMITTER)->SetPositionOffset(offset);

					offset = GO.GetChildEmitterComponent(eWORM_TRAIL2_EMITTER)->GetPositionOffset();
					offset.y += (60.0f * TimeManager::GetTimeDelta());
					XMCClamp(offset.y, 0.0f, 40.0f);
					GO.GetChildEmitterComponent(eWORM_TRAIL2_EMITTER)->SetPositionOffset(offset);
				}

				if (wormData.fActionCooldown <= 0.0f)
				{
					wormPos = XMVectorSetY(wormPos, 0.0f);
					GO.GetPhysicsComponent()->ActivateCollision();
					GO.GetChildEffectObject(eWORM_HEALTHBAR_EFFECT)->SetActive(true);

					wormData.bEnemySpecialA = wormData.bEnemySpecialB = wormData.bEnemySpecialC = wormData.bEnemySpecialD = false;
					wormData.fActionCooldown = wormData.fActionCooldownD = 0.0f;
					GO.GetChildEmitterComponent(eWORM_TRAIL1_EMITTER)->SetSpawning(false);
					GO.GetChildEmitterComponent(eWORM_TRAIL2_EMITTER)->SetSpawning(false);
					GO.GetChildEmitterComponent(eWORM_TRAIL1_EMITTER)->SetPositionOffset({ 0, 0, 0 });
					GO.GetChildEmitterComponent(eWORM_TRAIL2_EMITTER)->SetPositionOffset({ 0, 0, 0 });
					//Just in case it decided to go to patrol state while submerging.
					wormData.bSubmerged = wormData.bSubmerging = false;
				}


				if (GO.GetPhysicsComponent()->GetCollisionShape(SU_ATTACK)->Collides(player.GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE)) && !player.GetPlayerComponent()->GetKnockback())
				{
					player.GetPlayerComponent()->SetKnockBack(true);
					player.GetPlayerComponent()->StopPlayer(true, 0.5f);
					player.GetPlayerComponent()->SetKnockbackDir3(player.GetObjectTranslationVec(), GO.GetObjectTranslationVec());
				}

				//GO.GetPhysicsComponent()->SetVelocity({ 0, 0 });
				//wormData.ObjTarget->GetPhysicsComponent()->SetVelocity({ 0, 0 });
			}

			GO.GetChildTelegraphComponent(eWORM_EMERGE_TELEGRAPH)->Update();
		}
	}
#pragma endregion

	wormData.fActionCooldownD += TimeManager::GetTimeDelta();
	wormData.fActionCooldownC -= TimeManager::GetTimeDelta();
}

void EnemyBehavior::SwitchStateEnemy(GameObject& GO, AIData::EnemyState state)
{
	AIData* pEnemyAI = GO.GetAIData();

	string animationName = "";
	bool animationLoop = false;

	if (GO.GetType() != eWORM)
		pEnemyAI->ObjTarget = NULL;
	//if (state == AIData::EnJump && GO.GetAIData()->m_nAtkNum == 2)
	//	pEnemyAI->fActionCooldown = pEnemyAI->fActionCooldown;
	//else
	//	pEnemyAI->fActionCooldown = 0.0f;
	//if (state != AIData::EnJump)
	pEnemyAI->fActionCooldown = 0.0f;
	pEnemyAI->bActionDone = false;
	GO.GetAnimComponent()->SetAnimSpeed(1.0f);

	if (GO.GetType() == eGOLEM)
	{
		GO.GetChildEmitterComponent(0)->SetSpawning(0.0f);
		GO.GetChildEmitterComponent(2)->SetSpawning(0.0f);
	}

	switch (state)
	{
	case AIData::EnJump:
	{
		break;
	}
	case AIData::EnRoot:
		break;
	case AIData::EnPreJump:
	{
		//p_mcfacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_FX_2D_WEAPONWHOOSH);
		Telegraph* pAttackTelegraph = GO.GetChildTelegraphComponent(eSPIDER_JUMP_TELEGRAPH);
		pAttackTelegraph->SetEnabled(true);
		pAttackTelegraph->SetTime(SPIDER_ATTACK_TIME);
		pAttackTelegraph->Update();

		break;
	}
	case AIData::EnAttack:
	{
		if (GO.GetType() == eSPIDER)
		{

			//p_mcfacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_FX_2D_WEAPONWHOOSH);
			Telegraph* pAttackTelegraph = GO.GetChildTelegraphComponent(eSPIDER_ATTACK_TELEGRAPH);
			pAttackTelegraph->SetEnabled(true);
			pAttackTelegraph->SetTime(SPIDER_ATTACK_TIME);
			pAttackTelegraph->Update();
		}
		if (GO.GetType() == eGOLEM)
		{
			//p_mcfacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_FX_3D_LEVER_SWITCH);
			Telegraph* pAttackTelegraph = GO.GetChildTelegraphComponent(eGOLEM_ATTACK_TELEGRAPH);
			pAttackTelegraph->SetEnabled(true);
			pAttackTelegraph->SetTime(GOLEM_ATTACK_TIME);
			pAttackTelegraph->Update();
		}
		if (GO.GetType() == eWORM)
		{
			//p_mcfacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_FX_2D_WEAPONWHOOSH);
			Telegraph* pAttackTelegraph = GO.GetChildTelegraphComponent(eWORM_ATTACK_TELEGRAPH);
			pAttackTelegraph->SetEnabled(true);
			pAttackTelegraph->SetTime(WORM_ATTACK_WINDUP);
			pAttackTelegraph->Update();
			animationLoop = false;
			animationName = WORM_ATTACK;
		}
		break;
	}
	case AIData::EnDebuff:
	{
		pEnemyAI->enemyState = state;
		animationLoop = false;
		if (GO.GetType() == eSPIDER && GO.GetTag() == "DumbSpider")
		{
			animationName = SPIDER_IDLE;
			animationLoop = true;
		}

		if (GO.GetType() == eSPIDER && GO.GetTag() != "DumbSpider")
		{
			//p_mcfacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_FX_2D_MENUBACKUP);
			Telegraph* pFearTelegraph = GO.GetChildTelegraphComponent(eSPIDER_FEAR_TELEGRAPH);
			pFearTelegraph->SetEnabled(true);
			pFearTelegraph->Update();
			animationName = SPIDER_CC;

		}
		else if (GO.GetType() == eGOLEM)
		{
			//p_mcfacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_FX_2D_MENUPAUSE);
			Telegraph* pStunTelegraph = GO.GetChildTelegraphComponent(eGOLEM_STUN_TELEGRAPH);
			pStunTelegraph->SetEnabled(true);
			pStunTelegraph->SetTime(GOLEM_DEBUFF_HIT);
			pStunTelegraph->Update();
			animationName = GOLEM_CC;
			GO.GetAnimComponent()->StopTransition();
		}
		else if (GO.GetType() == eWORM)
		{
			//p_mcfacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_FX_3D_WATERSPLASH);
			Telegraph* pKnockBackTelegraph = GO.GetChildTelegraphComponent(eWORM_KNOCKBACK_TELEGRAPH);
			pKnockBackTelegraph->SetEnabled(true);
			pKnockBackTelegraph->SetTime(GOLEM_DEBUFF_HIT);
			pKnockBackTelegraph->Update();
			animationName = WORM_CC;
		}
		break;
	}
	case AIData::EnPatrol:
	{
		//Walk Animations
		animationLoop = true;
		switch (GO.GetType())
		{
		case eSPIDER:			animationName = SPIDER_MOVE;			break;
		case eGOLEM:		    animationName = GOLEM_MOVE;				break;
		case eWORM:
		{
			animationName = WORM_SUBMERGE_ANIM;
			animationLoop = false;
			break;
		}
		}
		break;
	}
	case AIData::EnTrap:
	{
		switch (GO.GetType())
		{
		case eSPIDER:	(GO.GetTag() != "DumbSpider") ? animationName = SPIDER_WEB_LAUNCH : animationName = SPIDER_IDLE; break;
		case eGOLEM:
		{
			animationName = GOLEM_TRAP;
			break;
		}
			//case eDIAMONDGEODE:		animationName = DIAMOND_IDLE;	break;
		}
		//if (GO.GetType() == eGOLEM)
		pEnemyAI->enemyState = state;
		break;
	}

	case AIData::EnScan:
	{
		switch (GO.GetType())
		{
		case eSPIDER:			animationName = SPIDER_IDLE;	break;
		case eGOLEM:		    animationName = GOLEM_IDLE;		break;
			//case eDIAMONDGEODE:		animationName = DIAMOND_IDLE;	break;
		}
		break;
	}
	case AIData::EnReposition:
	{
		animationLoop = true;
		switch (GO.GetType())
		{
		case eSPIDER:			animationName = SPIDER_MOVE;	break;
		case eGOLEM:		    animationName = GOLEM_MOVE;	GO.GetChildEmitterComponent(2)->SetSpawning(1.0f);		break;
		case eWORM:
		{
			if (GO.GetAnimComponent()->GetCurrAnimation()->GetAnimTag() == WORM_SUBMERGE_ANIM)
			{
				animationName = WORM_EMERGE_ANIM;
				animationLoop = false;
			}
			else if (GO.GetAnimComponent()->GetCurrAnimation()->GetAnimTag() == WORM_ATTACK
				|| GO.GetAnimComponent()->GetCurrAnimation()->GetAnimTag() == WORM_CC)
				animationName = WORM_IDLE;
			break;
		}
		}
		//pEnemyAI->ObjTarget = NULL; 

		if (GO.GetType() == eSPIDER)
		{
			GO.GetAIData()->nCoinFlip = rand() % 10;
		}
		break;
	}
	case AIData::EnDeath:
	{
		//They're dead and they don't need to be playing any previous animations.
		GO.GetAnimComponent()->StopTransition();
		switch (GO.GetType())
		{
		case eSPIDER:
		{
			for (size_t i = 0; i < eSPIDER_EFFECT_AMOUNT; i++)
				GO.GetChildEffectComponent(i)->ToggleEffect(false);
			for (size_t i = 0; i < eSPIDER_TELEGRAPH_AMOUNT; i++)
				GO.GetChildTelegraphComponent(i)->SetEnabled(false);
			for (size_t i = 0; i < eSPIDER_EMITTER_AMOUNT; i++)
				GO.GetChildEmitterComponent(i)->SetSpawning(false);
			GO.GetAudioComponent()->PlayAudioFollow(PLAY_SFX_SPIDER_DEATH);
			GO.GetAnimComponent()->SetAnimName(SPIDER_DEATH_ANIM, false);
			//p_mcfacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::);
		} break;
		case eGOLEM:
		{
			for (size_t i = 0; i < eGOLEM_EFFECT_AMOUNT; i++)
				GO.GetChildEffectComponent(i)->ToggleEffect(false);
			for (size_t i = 0; i < eGOLEM_TELEGRAPH_AMOUNT; i++)
				GO.GetChildTelegraphComponent(i)->SetEnabled(false);
			for (size_t i = 0; i < eGOLEM_EMITTER_AMOUNT; i++)
				GO.GetChildEmitterComponent(i)->SetSpawning(false);
			GO.GetAudioComponent()->PlayAudioFollow(PLAY_SFX_ROCK_SMALL);
			//p_mcfacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_SFX_ROCK_SMALL);
			GO.GetAnimComponent()->SetAnimationTime(0.0f);
			GO.GetAnimComponent()->SetAnimName(GOLEM_DEATH_ANIM, false);

		} break;
		}
		//Update Doors

		PlayerComponent* playerComp = p_mcfacade->GetObjectManager()->GetPlayer()->GetPlayerComponent();
		playerComp->SetEnemiesKilled(playerComp->GetEnemiesKilled() + 1);

		//Temporary till death animation is in.

		if (GO.GetTag() == "DumbSpider")
		{
			SpawnGems(GEM_SPAWN_RAND, GEM_SPAWN_ONE, GEM_NO_SPAWN, GO, true);
		}
		else if (GO.GetType() == ObjectType::eGOLEM)
		{
			if (!p_mcfacade->GetDiamondUnlock())
			{
				SpawnGems(GEM_SPAWN_RAND, GEM_NO_SPAWN, GEM_SPAWN_ONE, GO, true);
				//p_mcfacade->SetDiamondUnlock(true);
			}
			else
				SpawnGems(GEM_SPAWN_RAND, GEM_SPAWN_GEN, GEM_SPAWN_RAND, GO);
		}
		else if (GO.GetType() == ObjectType::eWORM)
		{
			SpawnGems(GEM_SPAWN_GEN, GEM_SPAWN_RAND, GEM_SPAWN_RAND, GO);
		}
		else
		{
			SpawnGems(GEM_SPAWN_RAND, GEM_SPAWN_RAND, GEM_NO_SPAWN, GO);
		}


		GO.GetAIData()->fActionCooldown = -1.5f;
		//Spawn Gem

		GO.GetPhysicsComponent()->DeactivateCollision();
		//GameObject * GemDrop = GO.GetChildGemObject();

		//GemDrop->GetAIData()->cAIClockTimer.Start();
		//GemDrop->GetChildEmitterComponent(eGEM_DEFAULT_EMITTER)->SetSpawning(true);
		//GemDrop->GetChildEmitterComponent(eGEM_SPAWN_EMITTER)->SetSpawnTimer(1.0f);
		//GemDrop->SetObjectTranslation(GO.GetObjectTranslation());
		//GemDrop->SetActive(true);
		break;
	}
	default:
		break;
	}

	CAnimComponent* pEnemyAnim = GO.GetAnimComponent();
	if (!animationName.empty() && pEnemyAnim != nullptr)
	{
		pEnemyAnim->SetAnimName(animationName, animationLoop);
	}
	else if (pEnemyAnim == nullptr)
		PrintConsole("Current enemy we are trying to set an animation for does not have an anim comp");

	pEnemyAI->enemyState = state;

}
//Spawn Gems Function
//Pass in the number of Gems To make for each Type
//Use these #defines to help
//GEM_NO_SPAWN		- Tells the function not to spawn any gems of that type.
//GEM_SPAWN_RAND	- Tells the function to spawn a random number of gems of that type.
//GEM_SPAWN_ONE		- Tells the function to spawn one gem of that type.
//Pass in the Game Objects position to get the gems to spawn where we want them to.
void EnemyBehavior::SpawnGems(int _numSapphire, int _numRuby, int _numDiamond, GameObject & GO, bool GemDespTimerINFINATE)
{
#define MAX_SPAWN 5

	//#define ALPHA sqrtf(4.0f)
	//#define G(x)  (x - ALPHA) * (x - ALPHA) + 1.0f 
	//#define F(x)  2.0f * sinf((G(x) - 5) * XM_PI) + 5.0f 

	//Figure out how many of each type of geode he has.
	//Figure out how many geodes the spider killed.
	//PlayerComponent& player = *p_mcfacade->GetObjectManager()->GetPlayer()->GetPlayerComponent();
	int overall_loss = (int)p_mcfacade->GetObjectManager()->GetPlayer()->GetPlayerComponent()->GetNumGeodesLost();
	int current_loss = GO.GetAIData()->nUnitsKilled;

	static int performance = 0;

	int reward_amount = 0;
	int& max_reward = reward_amount;
	int spawn_amount = 0;

	//Figure out the reward for this fight
	if (current_loss <= 1)
		reward_amount = 3;
	else if (current_loss == 2)
		reward_amount = 2;
	else if (current_loss <= 4 || current_loss == 6)
		reward_amount = 1;
	else if (current_loss == 7)
		reward_amount = 2;
	else if (current_loss > 7)
		reward_amount = 3;

	//Figure out the modifier for the overall level
	if (overall_loss >= 5 && overall_loss < 10)
		reward_amount += 1;
	else if (overall_loss >= 10 && overall_loss < 15)
		reward_amount += 2;
	else if (overall_loss >= 15)
		reward_amount += 3;

	//Do a modifier if the player has improved to reap the benifits to losing too many geodes.
	if (current_loss <= 2 && overall_loss > 15)
		performance++;
	else if (current_loss >= 7 && overall_loss > 15)
		performance--;

	if (performance > 3)
		performance = 3;
	else if (performance < 0)
		performance = 0;

	reward_amount -= performance;


	//Don't spawn Sapphires if there is none to spawn.
	if (_numSapphire != GEM_NO_SPAWN)
	{
		//Spawn in one Sapphire.
		if (_numSapphire == GEM_SPAWN_ONE)
		{
			SpawnGemType(ObjectType::eSAPPHIREGEM, GO.GetObjectTranslation(), GemDespTimerINFINATE);
		}

		//Spawn in random number of Sapphires
		else if (_numSapphire == GEM_SPAWN_RAND)
		{
			_numSapphire = GEM_SPAWN_FUNC(reward_amount);
			while (_numSapphire-- > 0 && spawn_amount++ < max_reward)
				SpawnGemType(ObjectType::eSAPPHIREGEM, GO.GetObjectTranslation());
		}

		//Spawn in specified number of Sappires.
		else
		{
			while (_numSapphire-- > 0)
				SpawnGemType(ObjectType::eSAPPHIREGEM, GO.GetObjectTranslation());
		}
	}

	//Don't spawn Rubies if there is none to spawn.
	if (_numRuby != GEM_NO_SPAWN/* && p_mcfacade->GetRubyUnlock()*/)
	{
		//Spawn in one Ruby.
		if (_numRuby == GEM_SPAWN_ONE)
		{
			SpawnGemType(ObjectType::eRUBYGEM, GO.GetObjectTranslation(), GemDespTimerINFINATE);
		}

		//Spawn in random number of Rubies
		else if (_numRuby == GEM_SPAWN_RAND)
		{
			_numRuby = GEM_SPAWN_FUNC(reward_amount);
			while (_numRuby-- > 0 && spawn_amount++ < max_reward)
				SpawnGemType(ObjectType::eRUBYGEM, GO.GetObjectTranslation());
		}

		//Spawn in specified number of Rubies.
		else
		{
			while (_numRuby-- > 0)
				SpawnGemType(ObjectType::eRUBYGEM, GO.GetObjectTranslation());
		}
	}

	//Don't spawn Diamonds if there is none to spawn.
	if (_numDiamond != GEM_NO_SPAWN/* && p_mcfacade->GetDiamondUnlock()*/)
	{
		//Spawn in one Diamonds.
		if (_numDiamond == GEM_SPAWN_ONE)
		{
			SpawnGemType(ObjectType::eDIAMONDGEM, GO.GetObjectTranslation(), GemDespTimerINFINATE);
		}

		//Spawn in random number of Diamonds
		else if (_numDiamond == GEM_SPAWN_RAND)
		{
			_numDiamond = GEM_SPAWN_FUNC(reward_amount);
			while (_numDiamond-- > 0 && spawn_amount++ < max_reward)
				SpawnGemType(ObjectType::eDIAMONDGEM, GO.GetObjectTranslation());
		}

		//Spawn in specified number of Diamonds.
		else
		{
			while (_numDiamond-- > 0)
				SpawnGemType(ObjectType::eDIAMONDGEM, GO.GetObjectTranslation());
		}
	}
}
bool EnemyBehavior::SpawnGemType(ObjectType _gemType, XMFLOAT3 _pos, bool GemDespTimerINFINATE)
{
	vector<GameObject *> gems = p_mcfacade->GetObjectManager()->GetGems();
	for (size_t i = 0; i < gems.size(); i++)
	{
		if (!gems[i]->GetActive() && gems[i]->GetType() == _gemType)
		{
			gems[i]->GetChildPointLight(0)->SetActive(true);
			gems[i]->GetChildEmitterComponent(eGEM_DEFAULT_EMITTER)->SetSpawning(true);
			//gems[i]->GetChildEmitterComponent(eGEM_SPAWN_EMITTER)->SetSpawnTimer(1.0f);
			gems[i]->SetActive(true);
			gems[i]->SetObjectTranslation(_pos);
			gems[i]->GetPhysicsComponent()->ActivateCollision();
			gems[i]->GetAIData()->bAttacked = false;


			float g = -9.8f;
			float t = UnitRand() * 5.0f;
			XMFLOAT3 P = XMFLOAT3(_pos.x + SignedUnitRand() * 5.0f, _pos.y, _pos.z + SignedUnitRand() * 5.0f);
			XMFLOAT3 O = _pos;

			XMFLOAT3 Vo;

			gems[i]->GetAIData()->fJumpingPoint = _pos;
			Vo.x = (P.x - O.x) / t;
			Vo.z = (P.z - O.z) / t;
			Vo.y = -(P.y + ((0.5f * g) * (t * t)) - O.y) / t;

			gems[i]->GetAIData()->fTempVel = Vo;
			gems[i]->GetAIData()->fActionCooldownB = t;
			if (GemDespTimerINFINATE)
				gems[i]->GetAIData()->bActionDone = true;

			return true;
		}
	}

	return false;
}
void EnemyBehavior::WormCorrection(GameObject& _target, GameObject& _enemy)
{
	AIData& wormData = *_enemy.GetAIData();

	//Make it react to other holes 
	XMVECTOR trap_position = XMVectorZero();
	XMVECTOR toVector = XMVectorZero();
	XMVECTOR total = XMVectorZero();
	int counter = 0;
	Circle* trap_circle = nullptr;
	Circle* worm_circle = dynamic_cast<Circle*>(_enemy.GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE));
	vector<GameObject*> trap_list = p_mcfacade->GetObjectManager()->GetWormTraps();
	for (unsigned int index = 0; index < trap_list.size(); index++)
	{
		GameObject* trap = trap_list[index];
		if (!trap->GetActive() || trap == wormData.ObjTarget)
			continue;

		trap_circle = dynamic_cast<Circle*>(trap->GetPhysicsComponent()->GetCollisionShape(SU_SCANNER));
		trap_position = trap->GetObjectTranslationVec();

		//Get the vector from the trap to the worm
		toVector = XMVectorSetY(_enemy.GetObjectTranslationVec(), 0.0f) - trap_position;
		//Get the distance of the worm and the trap
		float dist = XMCVector3Dot(toVector, toVector);
		float radsq = (trap_circle->GetRadius() + worm_circle->GetRadius() + 2.5f) * (trap_circle->GetRadius() + worm_circle->GetRadius() + 2.5f);
		if (dist < radsq)
		{
			//Now change the distance b/w the two points to the distance it needs to travel to not be overlapping.
			dist = (trap_circle->GetRadius() + 2.0f) *  2.0f;

			//Get the vector of the trap towards the target.
			toVector = XMVectorSetY(_target.GetObjectTranslationVec(), 0.0f) - trap_position;

			//Normalize the toVector to have a direction it needs to go to be out of the trap
			toVector = XMVector3Normalize(toVector) * dist;
			//printConsole("Worm trap moving by ", XMCStoreFloat3(toVector));
			trap_position += toVector;

			total += trap_position;
			counter++;
		}
	}

	//If we are overlapping, then we need reposition the worm.
	if (counter > 0)
	{
		total /= float(counter);
		_enemy.SetObjectTranslation(XMVectorSetY(total, _enemy.GetObjectTranslation().y));
	}
}
