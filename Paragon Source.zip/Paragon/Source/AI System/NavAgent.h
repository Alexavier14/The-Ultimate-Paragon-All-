#pragma once

class CoreFacade;
class GameObject;
class NavMesh;

using namespace PackedVector;

#include <queue>
#include <unordered_map>

struct PlannerNode
{
	PlannerNode* parent;
	XMSHORT2 searchTile;

	float heuristicCost;
	float givenCost;
	float finalCost;

	
	PlannerNode(XMSHORT2 searchTile , PlannerNode* parent ) : searchTile( searchTile ), parent(parent) {}
	~PlannerNode( ) {}
};

class NavAgent
{
	CoreFacade* m_pCoreFacade;
	NavMesh* pNavMesh;

	queue<PlannerNode*> searchQueue;
	
	// Stores the Nodes already visited in the algorithm. The key is the location of the tile in the array (Use XMSHORT::v)
	unordered_map< uint32_t, const PlannerNode*> visitedMap;
	
	XMFLOAT2 m_GoalPos; // Specifies the tile to be reached
	

	XMFLOAT2 m_AgentPos;
	float m_AgentRadius;

	list<PlannerNode*> m_FinalPath;

	bool m_bPathFinding;
	bool m_bMoving;
	bool m_bUnreachableGoal;
	bool m_bGraphicsDebug;
	bool m_bSkipToGoal;

	GameObject* m_Holder;

	float m_MoveSpeed;
	float m_TurnSpeed;

	public:
	NavAgent(GameObject* pHolder);
	~NavAgent();

	void Initialize(CoreFacade* pCoreFacade);

	void Update();

	void Begin(const XMFLOAT2& iniPos, const XMFLOAT2& endPos );
	void End();

	bool DestinationReached() const { return !m_bPathFinding && m_FinalPath.empty(); }
	XMFLOAT2 GetNextWaypoint() const;
	void PopWaypoint();

	bool IsDone() const { return !m_bPathFinding; }
	bool IsMoving() const { return m_bMoving; }

	void SetMoveSpeed(float moveSpeed);
	void SetTurnSpeed(float turnSpeed);
	void SetSkipToGoal(bool skipToGoal);
	private:

	// Builds up the search queue, one iteration per call. 
	// Returns true when the goal is reached.
	bool Pathfind();

	void TileDebugColors();

	void EnqueueNode( PlannerNode* pPNode);
	PlannerNode* DequeueNode();

	void MoveToTile();

	bool HasReachedNextTile();
	void SteerToNextTile();
	void SteerToGoal();
	void PathFunnel();
	bool CheckFreePath(XMSHORT2 startTile,XMSHORT2 endTile);
};

