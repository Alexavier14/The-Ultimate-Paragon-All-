#include "../Application/stdafx.h"
#include "NavAgent.h"
#include "NavMesh.h"
#include "../Application/CoreFacade.h"
#include "../Physics/Physics.h"
#include "../Physics/PhysicsSystem.h"
#include "../Object Manager/GameObject.h"


using namespace Physics;

// XMSHORT2 Helper functions

XMSHORT2 Add(const XMSHORT2& a, const XMSHORT2& b)
{
	return XMSHORT2(short(a.x + b.x), short(a.y + b.y));
}

bool Equals(const XMSHORT2& a, const XMSHORT2& b)
{
	return a.x == b.x && a.y == b.y;
}

XMSHORT2 Short2(int a, int b)
{
	return XMSHORT2( (short)a, (short)b );
}



NavAgent::NavAgent(GameObject* pHolder)
{
	m_bGraphicsDebug = false;
	m_Holder = pHolder;
	bool m_bSkipToGoal = false;
}


NavAgent::~NavAgent()
{
	End();
}

void NavAgent::SetMoveSpeed(float moveSpeed)
{
	m_MoveSpeed = moveSpeed;
}
void NavAgent::SetTurnSpeed(float turnSpeed)
{
	m_TurnSpeed = turnSpeed;
}
void NavAgent::EnqueueNode(PlannerNode* pPNode)
{
	visitedMap[pPNode->searchTile.v] = pPNode;
	searchQueue.push( pPNode );
}
PlannerNode* NavAgent::DequeueNode()
{
	PlannerNode* node = searchQueue.front( );
	searchQueue.pop( );
	return node;
}
XMFLOAT2 NavAgent::GetNextWaypoint() const
{
	PlannerNode* nextNode = m_FinalPath.front();
	return pNavMesh->GetPosition(nextNode->searchTile);
}

void NavAgent::SetSkipToGoal(bool skipToGoal)
{
	m_bSkipToGoal = skipToGoal;
}


void NavAgent::Update()
{
	PhysicsComponent& physics = *m_Holder->GetPhysicsComponent();
	Circle* agentBounds = dynamic_cast<Circle*>( physics.GetCollisionShape(SU_BOUNDING_SHAPE) );
	m_AgentPos = XMCStoreFloat2(agentBounds->GetPosition());
	m_AgentRadius = agentBounds->GetRadius();


	if( m_pCoreFacade->IsToggledKey( VK_F10 ) )
		m_bGraphicsDebug = !m_bGraphicsDebug;

	if( m_bGraphicsDebug )
		TileDebugColors();

	if (m_bPathFinding)
	{
		for (size_t i = 0; i < 100; i++)
		{
			if (Pathfind())
			{
				if(!m_bUnreachableGoal)
					m_bMoving = true;
				break;
			}

		}
	}

	if(m_bMoving)
		MoveToTile();
	else
	{
		PhysicsComponent& physics = *m_Holder->GetPhysicsComponent();
		physics.SetForwardVelocity(0);
	}
}

void NavAgent::Initialize(CoreFacade* pCoreFacade)
{
	m_pCoreFacade = pCoreFacade;
	pNavMesh = pCoreFacade->GetNavMesh();
	m_bPathFinding = false;

	Segment* rayTester = pCoreFacade->GetPhysicsSystem()->MakeSegmentShape(RT_NONE);
	rayTester->SetRotating(false);
	m_Holder->GetPhysicsComponent()->SetCollisionShape(rayTester,SU_NAVTESTER);
}

void NavAgent::Begin(const XMFLOAT2& iniPos, const XMFLOAT2& endPos )
{
	End();

	XMSHORT2 endTile = pNavMesh->GetTile(endPos);

	m_bPathFinding = true;
	m_bUnreachableGoal = false;

	XMSHORT2 iniTile = pNavMesh->GetTile(iniPos);
	PlannerNode* startNode = new PlannerNode(iniTile, NULL);
	EnqueueNode(startNode);
	m_GoalPos = endPos;

	m_FinalPath.clear();
}
void NavAgent::End()
{
	m_bPathFinding = false;
	for each ( auto pair in visitedMap )
	{
		const PlannerNode* node = pair.second;
		delete node;
	}
	visitedMap.clear();
	m_FinalPath.clear();

	while (!searchQueue.empty())
		searchQueue.pop();
}


bool NavAgent::Pathfind()
{
	if(!m_FinalPath.empty())
		return true;

	if (searchQueue.empty() )
	{
		m_bUnreachableGoal = true;
		return true; // No possible path
	}

	PlannerNode* currentNode = DequeueNode( );
	
	XMSHORT2 goalTile = pNavMesh->GetTile(m_GoalPos);
	if ( Equals(currentNode->searchTile, goalTile) )
	{
		// build path
		m_FinalPath.clear();
		while (currentNode)
		{
			m_FinalPath.push_front(currentNode);
			currentNode = currentNode->parent;
		}
		m_bPathFinding = false;
		return true;
	}
	
	// Search adjacent tiles
	static const XMSHORT2 offsets[4] =
	{
		Short2(+1,0),
		Short2(-1,0),
		Short2(0,+1),
		Short2(0,-1),
	};

	for ( size_t i = 0; i < 4; i++ )
	{
		XMSHORT2 adjacentTile = Add(currentNode->searchTile, offsets[i]);
		
		if ( visitedMap.find( adjacentTile.v ) == visitedMap.end( ) ) // If not visited
		{
			if (!Equals(adjacentTile, goalTile))
			{
				if (pNavMesh->GetTile(adjacentTile).status & TA_OCCUPIED) // Ignore if occupied
					continue;
				if (pNavMesh->GetTile(adjacentTile).status & TA_BLOCKED) // Ignore if blocked
					continue;
			}
			PlannerNode* successorNode = new PlannerNode( adjacentTile, currentNode );
			EnqueueNode( successorNode );
		}
	}
	
	return false;

}




void NavAgent::PopWaypoint()
{
	m_FinalPath.pop_front();
}


//--- Walk through path ---

void NavAgent::MoveToTile()
{
	if (!IsDone())
		return;

	if (m_bSkipToGoal)
	{
		SteerToGoal();
	}
	else
	{
		PathFunnel();

		if (!m_FinalPath.empty() && HasReachedNextTile())
			PopWaypoint();

		if (m_FinalPath.size() == 1) //If going to the last tile, skip and go straight to goal
			PopWaypoint();

		if (DestinationReached()) // Reached final tile
			SteerToGoal();
		else
			SteerToNextTile();
	}
	PhysicsComponent& physics = *m_Holder->GetPhysicsComponent();
	
	float distanceToGoal = XMCVector2Length( XMLoadFloat2(&m_GoalPos) - XMLoadFloat2(&m_AgentPos) );
	float speed = m_MoveSpeed;
	const float slowingDist = 5.0f;
	if( distanceToGoal < slowingDist )
		speed *= 1 - 0.7f*(slowingDist - EPSILON_DIST - distanceToGoal) / slowingDist;	//Arrival slowdown
	physics.SetForwardVelocity(speed);



}//
bool NavAgent::HasReachedNextTile()
{	
	XMVECTOR agentPos = XMLoadFloat2(&m_AgentPos);

	XMFLOAT2 nextWayPoint = GetNextWaypoint();
	XMVECTOR tilePos = XMLoadFloat2(&nextWayPoint);
	XMVECTOR tileExtents = pNavMesh->GetTileSize()*0.5f;

	if (IntersectCircleAABB(agentPos, 0, tilePos, tileExtents))
	{
		PrintConsole("Reached Node: " + VectorToString(tilePos)  + ", " + VectorToString(agentPos) );
		return true;
	}
	return false;

}
void NavAgent::SteerToNextTile()
{
	XMFLOAT2 agentForward = XMCVector2GetXZ(m_Holder->GetForwardVec());

	XMFLOAT2 nextWayPoint = GetNextWaypoint();
	XMFLOAT2 tileExtents = XMCStoreFloat2(pNavMesh->GetTileSize()*0.5f);

	if (!IntersectRayAABB(m_AgentPos, agentForward, nextWayPoint, tileExtents))
		m_Holder->TurnTo(XMCVector3LoadXZ(nextWayPoint),m_TurnSpeed);
}
void NavAgent::SteerToGoal()
{
	XMVECTOR agentPos = XMLoadFloat2(&m_AgentPos);
	XMVECTOR goalPos = XMLoadFloat2(&m_GoalPos);
	if (IntersectPointCircle(goalPos, agentPos, m_AgentRadius))
	{
		m_bMoving = false;
		End();
		return;
	}
	m_Holder->TurnTo(XMCVector3LoadXZ(m_GoalPos),m_TurnSpeed);
}
void NavAgent::PathFunnel()
{
	XMSHORT2 startTile = pNavMesh->GetTile(m_AgentPos);

	int freeIndex = 0;
	int counter = 0;
	for (auto it = m_FinalPath.begin(); it != m_FinalPath.cend(); ++it)
	{
		XMSHORT2 currTile = (*it)->searchTile;
		if(CheckFreePath(startTile,currTile))
			freeIndex = counter;
		counter++;
	}

	for (short i = 0; i < freeIndex; i++)
		PopWaypoint();

}
bool NavAgent::CheckFreePath(XMSHORT2 startTile, XMSHORT2 endTile)
{
	XMFLOAT2 rayStart = pNavMesh->GetPosition(startTile);
	XMFLOAT2 rayEnd = pNavMesh->GetPosition(endTile);
	XMVECTOR rayVec = XMLoadFloat2(&rayEnd) - XMLoadFloat2(&rayStart);
	XMFLOAT2 rayDir = XMCStoreFloat2( XMVector2Normalize(rayVec) );

	XMFLOAT2 tileExtents = XMCStoreFloat2(pNavMesh->GetTileSize()*0.5f);

	XMSHORT2 delta;
	delta.x = endTile.x > startTile.x ? 1 : -1;
	delta.y = endTile.y > startTile.y ? 1 : -1;

#if 1 // Test against tiles
	for (short i = startTile.x; delta.x*(endTile.x - i) >= 0; i += delta.x )
	{
		for (short j = startTile.y; delta.y*(endTile.y - j) >= 0; j += delta.y )
		{
			XMSHORT2 currTile(i,j);
			if( Equals(currTile,startTile) )
				continue;

			XMFLOAT2 tilePos = pNavMesh->GetPosition(currTile);
			if (IntersectRayAABB(rayStart, rayDir, tilePos, tileExtents) )
			{
				if( pNavMesh->GetTile(currTile).status & TA_OCCUPIED
				   || pNavMesh->GetTile(currTile).status & TA_BLOCKED )
				   return false;
			}


		}
	}
#else // test against collision shapes

	Segment* rayTester = dynamic_cast<Segment*>( m_Holder->GetPhysicsComponent()->GetCollisionShape(SU_NAVTESTER) );
	rayTester->SetExtent(XMCStoreFloat2(rayVec));

	m_pCoreFacade->GetPhysicsSystem()->CheckAllColisions(rayTester);
	auto DetectedShapes = rayTester->GetDetectedShapes();
	DetectedShapes.remove_if([](CollisionShape* detected) {
		switch (detected->GetGameObjectHolder()->GetType())
		{
			case ePLAYER:
			case eRETICLE:
			case eSAPPHIREGEODE:
			case eRUBYGEODE:
			case eDIAMONDGEODE:
				return true;
			default: return false;
		}
	});
	if (!DetectedShapes.empty())
		return false;
#endif

	return true;

}


// --- Debug ---

void NavAgent::TileDebugColors()
{
	//if( m_Holder->GetType() != eSAPPHIREGEODE)
	//	return;

	// Find level tiles and colour them.
	auto& levelObjs = m_pCoreFacade->GetObjectManager()->GetLevelObjects();
	for (size_t i = 0; i < levelObjs.size(); i++)
	{
		if (levelObjs[i]->GetType() != eLEVEL)
			continue;

		GameObject* pFloor = levelObjs[i];

		XMVECTOR FloorPos = pFloor->GetObjectTranslationVec();
		XMSHORT2 FloorTile = pNavMesh->GetTile(XMCVector2GetXZ(FloorPos));
		
		XMFLOAT4 color(0, 0, 0, 0);
		
		if (visitedMap.find(FloorTile.v) == visitedMap.end()) // If not visited
			color = { 0, 0, 0, 0 };
		else
			color = { 1, 0, 0, 0.3f };


		for (auto it = m_FinalPath.cbegin(); it != m_FinalPath.cend(); ++it)
		{
			PlannerNode* nodeIt = *it;
			if (Equals(nodeIt->searchTile, FloorTile))
			{
				color = { 1, 0, 1, 0.3f };
				break;
			}
		}

		if (pNavMesh->GetTile(FloorTile).status & TA_OCCUPIED) // Occuppied
			color = { 0.2f, 0.2f, 0.2f, 0.8f };
		else if (pNavMesh->GetTile(FloorTile).status & TA_BLOCKED) // Blocked
			color = { 0.2f, 0.0f, 0.0f, 0.8f };


		//XMSHORT2 goalTile = NavMesh.GetTile(m_GoalPos);
		//if( Equals( goalTile, FloorTile ) ) // Goal
		//	color = { 0, 1, 0, 0.3f };

		pFloor->SetObjectColor(color, color.w);

	}

}
