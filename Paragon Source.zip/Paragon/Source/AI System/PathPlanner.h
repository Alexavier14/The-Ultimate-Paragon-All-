#pragma once

// Currently unused

class PathPlanner
{
	public:
	PathPlanner();
	~PathPlanner();

};

