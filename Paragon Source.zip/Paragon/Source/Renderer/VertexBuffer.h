#pragma once

//Skeleton class for the layout of a vertex buffer. 
//These will be created on a per render set basis (At load time) 
//Can be added to
//Do I need can be removed from?
//Debating on creating a manager class for each vert buffer or allowing the render sets to maintain theses

class VertexBuffer
{
public:
	VertexBuffer();
	~VertexBuffer();
};

