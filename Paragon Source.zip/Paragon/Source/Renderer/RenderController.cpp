#include "../Application/stdafx.h"
#include "../Object Manager/RendererComponent.h"
#include "DepthStencilStateManager.h"
#include "RenderController.h"
#include "RenderSet.h"
#include "ConstantBuffers.h"
#include "GraphicsDebugEvent.h"

#define RENDER_DEBUG_BUFFERS 1

RenderController::RenderController()
{
	Base_Ghost_Static_Geometry = nullptr;
	Base_Static_Geometry = nullptr;
	Base_Animated_Geometry = nullptr;
	Emissive_Geometry = nullptr;
	HUD_Unlit_Geometry = nullptr;
	Effect_Unlit_Geometry = nullptr;
	Particle_Unlit_Geometry = nullptr;
	Telegraph_Unlit_Geometry = nullptr;
	PointLight_Context = nullptr;
	Text_Unlit_Geometry = nullptr;
	GhostObjects_AnimGeometry = nullptr;
	GhostObjects_StaticGeometry = nullptr;
	Transition_Screen_Geonetry = nullptr;
	VerticalGlowBlurTarget = nullptr;
	HorizontalGlowBlurTarget = nullptr;
}
RenderController::~RenderController(){}

void RenderController::Initialize(HWND hWnd, HINSTANCE hInst, bool IsWindowed)
{
	CurrentWindow = hWnd;
	CurrentWindowsInstance = hInst;
	this->IsWindowed = !IsWindowed;

	Renderer = new D_Renderer();
	Renderer->Initialize(hWnd, hInst, IsWindowed);
	CreateRenderContexts();
	CreateViewPorts();
	CreateRenderTargets();
	InitializeTextureSamplers();

	Shaders::Initialize();
	ConstantBuffers::GetInstance()->Initialize();
	DepthStencilStateManager::Initialize();
	BlendStateManager::Initialize();
}
void RenderController::Shutdown()
{
	//Clear Render Sets
	ClearAllRenderSets();

	Renderer->pContext->ClearState();

	Shaders::Shutdown();
	ConstantBuffers::Shutdown();
	DepthStencilStateManager::ShutDown();
	BlendStateManager::Shutdown();

	if (SceneTarget)
		SceneTarget->Shutdown();

	if (gBufferRenderTarget)
		gBufferRenderTarget->Shutdown();


	if (HDRTarget7)
		HDRTarget7->Shutdown();

	if (FXAATarget)
		FXAATarget->Shutdown();

	if (VerticalGlowBlurTarget)
		VerticalGlowBlurTarget->Shutdown();

	if (HorizontalGlowBlurTarget)
		HorizontalGlowBlurTarget->Shutdown();

	SAFE_DELETE(HorizontalGlowBlurTarget);
	SAFE_DELETE(VerticalGlowBlurTarget);
	SAFE_DELETE(FXAATarget);
	SAFE_DELETE(SceneTarget);
	SAFE_DELETE(gBufferRenderTarget);
	SAFE_DELETE(HDRTarget7);

	//Clear Samplers
	for (unsigned int i = 0; i < Samplers.size(); i++)
	{
		(Samplers[i].Release());
	}

	//Clean up Render Context Objects
	SAFE_DELETE(Base_Static_Geometry);
	SAFE_DELETE(Base_Animated_Geometry);
	SAFE_DELETE(Emissive_Geometry);
	SAFE_DELETE(HUD_Unlit_Geometry);
	SAFE_DELETE(Effect_Unlit_Geometry);
	SAFE_DELETE(Particle_Unlit_Geometry);
	SAFE_DELETE(Telegraph_Unlit_Geometry);
	SAFE_DELETE(PointLight_Context);
	SAFE_DELETE(Text_Unlit_Geometry);
	SAFE_DELETE(Transition_Screen_Geonetry);
	SAFE_DELETE(GhostObjects_AnimGeometry);
	SAFE_DELETE(GhostObjects_StaticGeometry);
	SAFE_DELETE(Base_Ghost_Static_Geometry);

	Renderer->ShutDown();
	SAFE_DELETE(Renderer);
}

void RenderController::CreateRenderContexts()
{
	PrintConsole("Creating Render Contexts");

	//Create a context for point lights
	PointLight_Context = new RenderContext(Context_Type::CT_POINT);

	//Create a context for Emissive_Geometry
	Emissive_Geometry = new RenderContext(Context_Type::CT_EMISS_GEOM);

	//Create a context for the second pass of the static ghost objects
	Base_Ghost_Static_Geometry = new RenderContext(Context_Type::CT_STATIC_GEOM);

	//Create a context for Base Static Geometry
	Base_Static_Geometry = new RenderContext(Context_Type::CT_STATIC_GEOM);

	//Create a context for Base Animated Geometry
	Base_Animated_Geometry = new RenderContext(Context_Type::CT_ANIM_GEOM);

	//Create a context for Unlit HUD elements
	HUD_Unlit_Geometry = new RenderContext(Context_Type::CT_HUD);

	//Create a context for Effect / Billboard elements
	Effect_Unlit_Geometry = new RenderContext(Context_Type::CT_BILLBOARD);

	//Create a context for Telegraphs
	Telegraph_Unlit_Geometry = new RenderContext(Context_Type::CT_TELE);

	//Create a context for particles
	Particle_Unlit_Geometry = new RenderContext(Context_Type::CT_PARTICLE);

	//Create a context for Text Elements
	Text_Unlit_Geometry = new RenderContext(Context_Type::CT_TEXT);

	//Create a context for Transparent objects

	//Create a context for Transistion Screen
	Transition_Screen_Geonetry = new RenderContext(Context_Type::CT_HUD);

	//Create a context for the Ghost objects to see them through walls
	GhostObjects_AnimGeometry = new RenderContext(Context_Type::CT_GHOST_ANIM);
	GhostObjects_StaticGeometry = new RenderContext(Context_Type::CT_GHOST_STATIC);


}
void RenderController::CreateRenderTargets()
{
	PrintConsole("Creating Render Targets");
	SceneTarget = new RenderTarget();
	gBufferRenderTarget = new RenderTarget();
	HDRTarget7 = new RenderTarget();
	FXAATarget = new RenderTarget();
	VerticalGlowBlurTarget = new RenderTarget();
	HorizontalGlowBlurTarget = new RenderTarget();


	//Scene Render Target Surface and View
	//SceneTarget->Create(D_Renderer::pDepthStencilView, D_Renderer::pDepthStencilBuffer);
	SceneTarget->Create(D_Renderer::GetScreenWidth(), D_Renderer::GetScreenHeight(), DXGI_FORMAT_D32_FLOAT_S8X24_UINT, "Scene Target");
	SceneTargetView.Create(D_Renderer::GetScreenWidth(), D_Renderer::GetScreenHeight(), "Scene Target View", DXGI_FORMAT_R32G32B32A32_FLOAT);
	SceneTarget->AddTarget(&SceneTargetView);

	//FXAA Target to print to
	FXAATarget->Create(D_Renderer::GetScreenWidth(), D_Renderer::GetScreenHeight(), DXGI_FORMAT_D32_FLOAT_S8X24_UINT, "FXAA");
	FXAATargetView.Create(D_Renderer::GetScreenWidth(), D_Renderer::GetScreenHeight(), "FXAA Target View", DXGI_FORMAT_R32G32B32A32_FLOAT);
	FXAATarget->AddTarget(&FXAATargetView);

	//Glow Vertical Target print to
	VerticalGlowBlurTarget->Create(D_Renderer::GetScreenWidth(), D_Renderer::GetScreenHeight(), DXGI_FORMAT_D32_FLOAT_S8X24_UINT, "VerticalGlow");
	VerticalGlowBlurTargetView.Create(D_Renderer::GetScreenWidth(), D_Renderer::GetScreenHeight(), "VerticalGlow View", DXGI_FORMAT_R32G32B32A32_FLOAT);
	VerticalGlowBlurTarget->AddTarget(&VerticalGlowBlurTargetView);

	//Glow Horizontal Target print to 
	HorizontalGlowBlurTarget->Create(D_Renderer::GetScreenWidth(), D_Renderer::GetScreenHeight(), DXGI_FORMAT_D32_FLOAT_S8X24_UINT, "HorizontalGlow");
	HorizontalGlowBlurTargetView.Create(D_Renderer::GetScreenWidth(), D_Renderer::GetScreenHeight(), "HorizontalGlow View", DXGI_FORMAT_R32G32B32A32_FLOAT);
	HorizontalGlowBlurTarget->AddTarget(&HorizontalGlowBlurTargetView);

	//gBuffer Render Target Views and Surface
	//gBufferRenderTarget->Create(D_Renderer::pDepthStencilView, D_Renderer::pDepthStencilBuffer);
	gBufferRenderTarget->Create(D_Renderer::GetScreenWidth(), D_Renderer::GetScreenHeight(), DXGI_FORMAT_D32_FLOAT_S8X24_UINT, "GBuffers");
	gBufferDiffuseTargetView.Create(D_Renderer::GetScreenWidth(), D_Renderer::GetScreenHeight(), "GBufferDiffuse", DXGI_FORMAT_R32G32B32A32_FLOAT);
	gBufferRenderTarget->AddTarget(&gBufferDiffuseTargetView);

	gBufferNormalsTargetView.Create(D_Renderer::GetScreenWidth(), D_Renderer::GetScreenHeight(), "GBufferNormals", DXGI_FORMAT_R10G10B10A2_UNORM);
	gBufferRenderTarget->AddTarget(&gBufferNormalsTargetView);

	gBufferSpecularTargetView.Create(D_Renderer::GetScreenWidth(), D_Renderer::GetScreenHeight(), "GBufferSpecular", DXGI_FORMAT_R10G10B10A2_UNORM);
	gBufferRenderTarget->AddTarget(&gBufferSpecularTargetView);

	gBufferDepthTargetView.Create(D_Renderer::GetScreenWidth(), D_Renderer::GetScreenHeight(), "GBufferDepths", DXGI_FORMAT_R32_FLOAT);
	gBufferRenderTarget->AddTarget(&gBufferDepthTargetView);

	gBufferGlowTargetView.Create(D_Renderer::GetScreenWidth(), D_Renderer::GetScreenHeight(), "GBufferGlow", DXGI_FORMAT_R32G32B32A32_FLOAT);
	gBufferRenderTarget->AddTarget(&gBufferGlowTargetView);

}

void RenderController::SetResolution(unsigned int height, unsigned int width, bool IsWindowed)
{
	Renderer->SetResolution(width, height, IsWindowed);
	this->IsWindowed = IsWindowed;

	//Resize all of the render target buffers
	if (SceneTarget)
		SceneTarget->Shutdown();

	if (gBufferRenderTarget)
		gBufferRenderTarget->Shutdown();

	if (HDRTarget7)
		HDRTarget7->Shutdown();

	if (FXAATarget)
		FXAATarget->Shutdown();

	if (VerticalGlowBlurTarget)
		VerticalGlowBlurTarget->Shutdown();

	if (HorizontalGlowBlurTarget)
		HorizontalGlowBlurTarget->Shutdown();

	SAFE_DELETE(HorizontalGlowBlurTarget);
	SAFE_DELETE(VerticalGlowBlurTarget);
	SAFE_DELETE(FXAATarget);
	SAFE_DELETE(SceneTarget);
	SAFE_DELETE(gBufferRenderTarget);
	SAFE_DELETE(HDRTarget7);

	CreateRenderTargets();
}

void RenderController::InitializeTextureSamplers()
{
	//Using the same samplers are the ED engine. TODO::Look more into the differences in between these and why you would use one over another.
	ID3D11SamplerState * samplers[7];
	D3D11_SAMPLER_DESC desc;
	//anisoWrapSampler
	desc.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR; // D3D11_FILTER_ANISOTROPIC;
	desc.AddressU = D3D11_TEXTURE_ADDRESS_WRAP;
	desc.AddressV = D3D11_TEXTURE_ADDRESS_WRAP;
	desc.AddressW = D3D11_TEXTURE_ADDRESS_WRAP;
	desc.MipLODBias = 0.0f;
	desc.MaxAnisotropy = 4;
	desc.ComparisonFunc = D3D11_COMPARISON_NEVER;
	desc.BorderColor[0] = desc.BorderColor[1] = desc.BorderColor[2] = desc.BorderColor[3] = 0;
	desc.MinLOD = -FLT_MAX;
	desc.MaxLOD = FLT_MAX;
	D_Renderer::pDevice->CreateSamplerState(&desc, &samplers[0]);
	Samplers.push_back(samplers[0]);

	//Point Sampler
	desc.Filter = D3D11_FILTER_ANISOTROPIC;
	desc.AddressU = D3D11_TEXTURE_ADDRESS_CLAMP;
	desc.AddressV = D3D11_TEXTURE_ADDRESS_CLAMP;
	desc.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;
	desc.MaxAnisotropy = 4;
	D_Renderer::pDevice->CreateSamplerState(&desc, &samplers[1]);
	Samplers.push_back(samplers[1]);

	//pointWrapSampler
	desc.Filter = D3D11_FILTER_MIN_MAG_MIP_POINT;
	desc.AddressU = D3D11_TEXTURE_ADDRESS_WRAP;
	desc.AddressV = D3D11_TEXTURE_ADDRESS_WRAP;
	desc.AddressW = D3D11_TEXTURE_ADDRESS_WRAP;
	D_Renderer::pDevice->CreateSamplerState(&desc, &samplers[2]);
	Samplers.push_back(samplers[2]);

	//pointClampSampler
	desc.Filter = D3D11_FILTER_MIN_MAG_MIP_POINT;
	desc.AddressU = D3D11_TEXTURE_ADDRESS_CLAMP;
	desc.AddressV = D3D11_TEXTURE_ADDRESS_CLAMP;
	desc.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;
	D_Renderer::pDevice->CreateSamplerState(&desc, &samplers[3]);
	Samplers.push_back(samplers[3]);

	//linearWrapSampler
	desc.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
	desc.AddressU = D3D11_TEXTURE_ADDRESS_WRAP;
	desc.AddressV = D3D11_TEXTURE_ADDRESS_WRAP;
	desc.AddressW = D3D11_TEXTURE_ADDRESS_WRAP;
	D_Renderer::pDevice->CreateSamplerState(&desc, &samplers[4]);
	Samplers.push_back(samplers[4]);

	//LinearClampSampler
	desc.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
	desc.AddressU = D3D11_TEXTURE_ADDRESS_CLAMP;
	desc.AddressV = D3D11_TEXTURE_ADDRESS_CLAMP;
	desc.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;
	D_Renderer::pDevice->CreateSamplerState(&desc, &samplers[5]);
	Samplers.push_back(samplers[5]);

	desc.Filter = D3D11_FILTER_COMPARISON_MIN_MAG_LINEAR_MIP_POINT;
	desc.AddressU = D3D11_TEXTURE_ADDRESS_BORDER;
	desc.AddressV = D3D11_TEXTURE_ADDRESS_BORDER;
	desc.AddressW = D3D11_TEXTURE_ADDRESS_BORDER;
	desc.ComparisonFunc = D3D11_COMPARISON_LESS;
	desc.MinLOD = 0;
	desc.MaxLOD = 0;
	D_Renderer::pDevice->CreateSamplerState(&desc, &samplers[6]);
	Samplers.push_back(samplers[6]);

	D_Renderer::pContext->PSSetSamplers(0, 7, &samplers[0]);

	for (size_t i = 0; i < 7; i++)
	{
		ReleaseCOM(samplers[i]);
	}
}
void RenderController::RenderDebugBuffers()
{
#ifdef _DEBUG
	MarkEvent(L"Debug Buffers");
	//Here we will render all of the buffers after the geometry pass to the view ports

#endif
}
void RenderController::CreateViewPorts()
{
#ifdef _DEBUG
	//Create viewports for each buffer

#endif
}

//Renders all stages
void RenderController::Render()
{
	//D_Renderer::pContext->ClearDepthStencilView(D_Renderer::pDepthStencilView, D3D11_CLEAR_DEPTH, 1, 0);

	//Activate the main screen RT for now
	D_Renderer::pContext->PSSetSamplers(0, 1, &Samplers[5].p);
	D_Renderer::pContext->RSSetViewports(1, &D_Renderer::ScreenViewport);


	//Clear the screen buffer
	float ClearColor[4] = { 0.0f, 0.0f, 0.0f, 1.0f };

	D_Renderer::pContext->OMSetRenderTargets(1, &D_Renderer::pRenderTargetView.p, D_Renderer::pDepthStencilView);
	D_Renderer::pContext->ClearRenderTargetView(D_Renderer::pRenderTargetView, ClearColor);
	D_Renderer::pContext->ClearDepthStencilView(D_Renderer::pDepthStencilView, D3D11_CLEAR_DEPTH, 1, 0);

	GeometryFirstPass();
	GeometryAmbPass();
	RenderPointLights();
	GeometryMaterialPass();
	PostProcessRender();
	RenderUnlitGeometry();
	RenderDebugBuffers();

	//Present
#if _DEBUG
	D_Renderer::pSwapChain->Present(0, 0);
#else
	//D_Renderer::pSwapChain->Present(0, DXGI_PRESENT_RESTART);
	D_Renderer::pSwapChain->Present(0, 0);
#endif
	D_Renderer::pContext->ClearState();
}

void RenderController::ClearandResetBaseContext()
{
	float ClearColor[4] = { 0.0f, 0.0f, 0.0f, 1.0f };

	//Clear conext
	D_Renderer::pContext->ClearState();

	//Bind Sampler
	D_Renderer::pContext->PSSetSamplers(0, 1, &Samplers[0].p);

	//Bind the View Port
	D_Renderer::pContext->RSSetViewports(1, &D_Renderer::ScreenViewport);

	D_Renderer::pContext->OMSetRenderTargets(1, &D_Renderer::pRenderTargetView.p, D_Renderer::pDepthStencilView);
}

void RenderController::PostProcessRender()
{
	MarkEvent(L"Post Process");
	ClearandResetBaseContext();

	//Set the Samplers
	D_Renderer::pContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_POINTLIST);
	D_Renderer::pContext->PSSetSamplers(0, 1, &Samplers[1].p);
	D_Renderer::pContext->PSSetSamplers(1, 1, &Samplers[5].p);

	//Get the final render SRV
	ID3D11ShaderResourceView * Render_SRV = SceneTargetView.GetSRV();
	ID3D11ShaderResourceView *const pSRV[1] = { NULL };
	DepthStencilStateManager::ApplyState(DSStates::DSS_NoDepth);
	ConstantBuffers::GetInstance()->cbBind_Screen_Buffer(1);

	//FXAA Pass
	Shaders::Bind_Lum_Final_Pass();
	FXAATarget->ActivateRenderTargets();
	//D_Renderer::pContext->OMSetRenderTargets(1, &FXAATarget->Get, FXAATargetView);
	D_Renderer::pContext->PSSetShaderResources(0, 1, &Render_SRV);
	D_Renderer::pContext->Draw(1, 0);

 
	//Bind the sceen buffer for the Geo Shader
	ConstantBuffers::GetInstance()->cbBind_Geom_Screen_Buffer(1);

	//Vertical Glow Blur Pass
	Shaders::Bind_Vertical_Glow_Shaders();
	ConstantBuffers::GetInstance()->cbUpdate_Bind_Direction_Buffer(XMFLOAT2(1.0f, 0.0f));
	VerticalGlowBlurTarget->ActivateRenderTargets();
	ID3D11ShaderResourceView * Glow_SRV = gBufferGlowTargetView.GetSRV();
	D_Renderer::pContext->PSSetShaderResources(0, 1, &Glow_SRV);
	D_Renderer::pContext->Draw(1, 0);

	//Horizontal Glow Blur Pass
	Shaders::Bind_Horizontal_Glow_Shaders();
	ConstantBuffers::GetInstance()->cbUpdate_Bind_Direction_Buffer(XMFLOAT2(0.0f, 1.0f));
	HorizontalGlowBlurTarget->ActivateRenderTargets();
	ID3D11ShaderResourceView * Vertical_Blurred_Glow_SRV = VerticalGlowBlurTargetView.GetSRV();
	D_Renderer::pContext->PSSetShaderResources(0, 1, &Vertical_Blurred_Glow_SRV);
	D_Renderer::pContext->Draw(1, 0);

	//BlendStateManager::ApplyState(B_State::BS_ADD);

	//Apply the blur!
	Shaders::Bind_Apply_Glow_Shaders();
	D_Renderer::pContext->OMSetRenderTargets(1, &D_Renderer::pRenderTargetView.p, D_Renderer::pDepthStencilView);
	ID3D11ShaderResourceView * FinalImage_SRV = FXAATargetView.GetSRV();
	ID3D11ShaderResourceView * FinalBlurredGlow = HorizontalGlowBlurTargetView.GetSRV(); // HorizontalGlowBlurTargetView.GetSRV();
	D_Renderer::pContext->PSSetShaderResources(0, 1, &FinalImage_SRV);
	D_Renderer::pContext->PSSetShaderResources(1, 1, &FinalBlurredGlow);
	D_Renderer::pContext->Draw(1, 0);
}

//Rendering Geom data to Gbuffers
void RenderController::GeometryFirstPass()
{
	MarkEvent(L"Geometry First Pass");

	//Set the Render Stage to GBUFFERS 
	//--Renders all of the lit geometry data to the buffers
	//--NOTE - This will be handling materials as well until we switch to deferred lighting. 

	float ClearColor[4] = { 0.0f, 0.0f, 0.0f, 1.0f };

	//Bind the 4 Render Targets
 	if (gBufferRenderTarget != nullptr)
	{
		gBufferRenderTarget->ActivateRenderTargets();
		gBufferRenderTarget->ClearRenderTargetView(ClearColor);
		gBufferRenderTarget->ClearDepthStencilView(D3D11_CLEAR_DEPTH);

		D_Renderer::Render(Base_Static_Geometry);
		gBufferRenderTarget->ActivateRenderTargets(D_Renderer::pDepthStencilView);
		D_Renderer::Render(GhostObjects_AnimGeometry);
		D_Renderer::Render(GhostObjects_StaticGeometry);
		gBufferRenderTarget->ActivateRenderTargets(gBufferRenderTarget->DepthStencilView);
		D_Renderer::Render(Base_Animated_Geometry);
		D_Renderer::Render(Base_Ghost_Static_Geometry);
		D_Renderer::Render(Telegraph_Unlit_Geometry);
		D_Renderer::Render(Emissive_Geometry);
	}

}
void RenderController::SetAndBindGBuffers()
{
	ClearandResetBaseContext();

	//No Depth
	DepthStencilStateManager::ApplyState(DSStates::DSS_NoDepth);

	//Bind the Gbuffers for the lights to use
	ID3D11ShaderResourceView * D_SRV = gBufferDiffuseTargetView.GetSRV();
	ID3D11ShaderResourceView * N_SRV = gBufferNormalsTargetView.GetSRV();
	ID3D11ShaderResourceView * S_SRV = gBufferSpecularTargetView.GetSRV();
	ID3D11ShaderResourceView * DE_SRV = gBufferDepthTargetView.GetSRV();

	D_Renderer::pContext->PSSetShaderResources(5, 1, &D_SRV);
	D_Renderer::pContext->PSSetShaderResources(6, 1, &N_SRV);
	D_Renderer::pContext->PSSetShaderResources(7, 1, &S_SRV);
	D_Renderer::pContext->PSSetShaderResources(8, 1, &DE_SRV);

	//Bind the Correct Sampler
    D_Renderer::pContext->PSSetSamplers(2, 1, &Samplers[5].p);

	//Bind the Render - RenderTarget
	float ClearColor[4] = { 0.0f, 0.0f, 0.0f, 1.0f };
	SceneTarget->ActivateRenderTargets();
	SceneTarget->ClearRenderTargetView(ClearColor);
	//SceneTarget->ClearDepthStencilView(D3D11_CLEAR_DEPTH);
}

void RenderController::GeometryAmbPass()
{
	MarkEvent(L"Geometry Amb Pass");
	//Render a fullscreen quad with the base scene color and amb lighting
	SetAndBindGBuffers();
	Shaders::Bind_Amb_Light_Pass();
	D_Renderer::pContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_POINTLIST);
	D_Renderer::pContext->Draw(1, 0);
}

void RenderController::RenderPointLights()
{
	MarkEvent(L"Render Point Lights");

	//--Renders all of the lighting data to the buffers using the geom data
	D_Renderer::Render(PointLight_Context);

}
void RenderController::GeometryMaterialPass()
{
	MarkEvent(L"Render Materials");
	//Render the lit geometry again with materials. (Deferred Lighting Stage) -- TODO at a later point after deferred shading is complete
}

void RenderController::RenderUnlitGeometry()
{
	MarkEvent(L"Render Unlit Geometry");
	//Set the render stage to Unlit
	//--Renders all of the geometry in the scene that will not have to go through the main, more complex pipeline. 
	ClearandResetBaseContext();

	//Bind the Debug View Port Textures
#if RENDER_DEBUG_BUFFERS == 1

#endif
	//D_Renderer::Render(Telegraph_Unlit_Geometry);
	D_Renderer::Render(Effect_Unlit_Geometry);
	D_Renderer::pContext->OMSetRenderTargets(1, &D_Renderer::pRenderTargetView.p, gBufferRenderTarget->DepthStencilView);
	D_Renderer::Render(Particle_Unlit_Geometry);
	D_Renderer::pContext->OMSetRenderTargets(1, &D_Renderer::pRenderTargetView.p, D_Renderer::pDepthStencilView);
	//D_Renderer::Render(GhostObjects_Geometry);
	D_Renderer::Render(HUD_Unlit_Geometry);
	D_Renderer::Render(Text_Unlit_Geometry);
	D_Renderer::Render(Transition_Screen_Geonetry);
}

void RenderController::ClearAllRenderSets()
{
  	PrintConsole("Clearing Render Sets");
	GhostObjects_AnimGeometry->ClearRenderSet();
	GhostObjects_StaticGeometry->ClearRenderSet();
	Transition_Screen_Geonetry->ClearRenderSet();
	HUD_Unlit_Geometry->ClearRenderSet();
	Effect_Unlit_Geometry->ClearRenderSet();
	Particle_Unlit_Geometry->ClearRenderSet();
	Telegraph_Unlit_Geometry->ClearRenderSet();
	PointLight_Context->ClearRenderSet();
	Base_Animated_Geometry->ClearRenderSet();
	Base_Static_Geometry->ClearRenderSet();
	Base_Ghost_Static_Geometry->ClearRenderSet();
	Text_Unlit_Geometry->ClearRenderSet();
	Emissive_Geometry->ClearRenderSet();
}

void RenderController::CreateRenderSets(ObjectManager * OM)
{
	ClearAllRenderSets();

	//Loop through all objects and create render sets
	for (unsigned int i = 0; i < OM->GetRenderSet().size(); i++)
	{
		GameObject * CurObject = OM->GetRenderSet()[i];
		if (CurObject == nullptr)
			continue;
		CurObject->GetRendererComponent()->CreateAndSetRenderNode(CurObject);

		//Check if HUD
		if (CurObject->GetType() == eHUD)
		{
			HUD_Unlit_Geometry->AddRenderNode(CurObject->GetRendererComponent()->GetRenderNode(0));
			continue;
		}

		//Check Transition
		if (CurObject->GetType() == eTRANSITION)
		{
			Transition_Screen_Geonetry->AddRenderNode(CurObject->GetRendererComponent()->GetRenderNode(0));
			continue;
		}

		//Check if Billboarded Effect
		if (CurObject->GetType() == eEFFECT)
		{
			Effect_Unlit_Geometry->AddRenderNode(CurObject->GetRendererComponent()->GetRenderNode(0));
			continue;
		}

		//Check if Emitter
		if (CurObject->GetType() == eEMITTER)
		{
#if _DEBUG == 0
			Particle_Unlit_Geometry->AddRenderNode(CurObject->GetRendererComponent()->GetRenderNode(0));
#endif
			continue;
		}

		//Check if Telegraph
		if (CurObject->GetType() == eTELEGRAPH)
		{
			Telegraph_Unlit_Geometry->AddRenderNode(CurObject->GetRendererComponent()->GetRenderNode(0));
			continue;
		}

		//Check if Point Light
		if (CurObject->GetType() == ePOINTLIGHT)
		{
			PointLight_Context->AddRenderNode(CurObject->GetRendererComponent()->GetRenderNode(0));
			continue;
		}

		//Check if Text
		if (CurObject->GetType() == eTEXTBOX)
		{
			Text_Unlit_Geometry->AddRenderNode(CurObject->GetRendererComponent()->GetRenderNode(0));
			continue;
		}
		//Adds anim objects that we need to ghost
		if (CurObject->GetType() == ePLAYER || IsGeode(CurObject) || CurObject->GetType() == eSPIDER || CurObject->GetType() == eGOLEM)
		{
#if _DEBUG == 0
			GhostObjects_AnimGeometry->AddRenderNode(CurObject->GetRendererComponent()->GetRenderNode(1));
#endif
			Base_Animated_Geometry->AddRenderNode(CurObject->GetRendererComponent()->GetRenderNode(0));
			continue;
		}
		if (CurObject->GetType() == eROCK_TRAP)// || CurObject->GetType() == eGOLEM)
		{
#if _DEBUG == 0
			GhostObjects_StaticGeometry->AddRenderNode(CurObject->GetRendererComponent()->GetRenderNode(1));
#endif
			Base_Ghost_Static_Geometry->AddRenderNode(CurObject->GetRendererComponent()->GetRenderNode(0));
			continue;
		}

		//Check if Animated object
		if (CurObject->IsAnimated() == true)
		{
			Base_Animated_Geometry->AddRenderNode(CurObject->GetRendererComponent()->GetRenderNode(0));
			continue;
		}

		//Must be a game object
		//if (CurObject->GetType() != eWALL)
		Base_Static_Geometry->AddRenderNode(CurObject->GetRendererComponent()->GetRenderNode(0));

	}

}

void RenderController::UpdateCinematicCamera(XMFLOAT3 WaypointPos, XMFLOAT3 DoorLocation)
{
	Renderer->GetMainCamera()->UpdateCinematicCamera(WaypointPos, DoorLocation);
	ConstantBuffers::GetInstance()->cbUpdate_Camera_Proj();
}

void RenderController::UpdateMainCamera(XMFLOAT3 FollowPosition)
{
	if (Renderer->GetMainCamera() != nullptr)
	{
		Renderer->GetMainCamera()->Update(FollowPosition);
		ConstantBuffers::GetInstance()->cbUpdate_Camera_Proj();
	}
	else
		PrintConsole("Render Controller tried to update a camera that does not exist!");
}

ID3D11Device * RenderController::GetDevice()
{
	return Paragon_Renderer::D_Renderer::pDevice;
}
XMFLOAT4X4& RenderController::GetViewMatrix()
{
	return Renderer->GetMainCamera()->GetViewMatrix();
}
XMFLOAT4X4& RenderController::GetProjMatrix()
{
	return Renderer->GetProjectionMatrix();
}
XMVECTOR RenderController::GetCameraPosition()
{
	return XMLoadFloat4( &Renderer->GetMainCamera()->GetCameraPos() );
}
bool	RenderController::IsEmmisiveActive() const
{
	return EmmisiveActive;
}
int		RenderController::GetAAValue() const
{
	return AA_Value;
}
float	RenderController::GetGammaValue() const
{
	return GammaValue;
}

void RenderController::SetCameraPosition(XMFLOAT3 location)
{
	Renderer->GetMainCamera()->SetCameraPos(location);
}
void RenderController::SetEmmisiveActive(bool active)
{
	EmmisiveActive = active;
}
void RenderController::SetAAValue(int value)
{
	AA_Value = value;
}
void RenderController::SetGammaValue(float value)
{
	GammaValue = value;
}
