#include "../Application/stdafx.h"
#include "DepthStencilStateManager.h"
#include "D_Renderer.h"

namespace Paragon_Renderer
{
	CComPtr<ID3D11DepthStencilState> DepthStencilStateManager::DepthStates[DSS_AMOUNT];

	DepthStencilStateManager::DepthStencilStateManager(){}
	DepthStencilStateManager::~DepthStencilStateManager(){}

	void DepthStencilStateManager::Initialize()
	{

		for (size_t i = 0; i < DSS_AMOUNT; i++)
		{
			DSStates state = DSStates(i);
			//Create and apply new state
			D3D11_DEPTH_STENCIL_DESC dssDesc = CD3D11_DEPTH_STENCIL_DESC(CD3D11_DEFAULT());
			dssDesc.DepthEnable = TRUE;
			dssDesc.StencilEnable = FALSE;
			switch (state)
			{
				case Paragon_Renderer::DSS_Default:
				{
					dssDesc.DepthEnable = TRUE;
					dssDesc.DepthFunc = D3D11_COMPARISON_LESS;
					dssDesc.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ALL;
					break;
				}
				case Paragon_Renderer::DSS_LessEqual:
				{
					dssDesc.DepthEnable = TRUE;
					break;
				}
				case Paragon_Renderer::DSS_NoDepth:
				{
					dssDesc.DepthEnable = FALSE;
					dssDesc.DepthFunc = D3D11_COMPARISON_ALWAYS;
					dssDesc.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ZERO;

					break;
				}
				case Paragon_Renderer::DSS_Particle:
				{
					dssDesc = { };
					dssDesc.DepthEnable = TRUE;
					dssDesc.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ZERO;
					dssDesc.DepthFunc = D3D11_COMPARISON_LESS;
					break;
				}
				default:
					break;
			}

			DepthStates[state].Release();
			D_Renderer::pDevice->CreateDepthStencilState(&dssDesc, &DepthStates[state]);

		}

	}

	void DepthStencilStateManager::ShutDown()
	{
		for (size_t i = 0; i < DSS_AMOUNT; i++)
			DepthStates[i].Release();
	}

	void DepthStencilStateManager::ApplyState(DSStates state)
	{
		D_Renderer::pContext->OMSetDepthStencilState(DepthStates[state], 1);
	}

}