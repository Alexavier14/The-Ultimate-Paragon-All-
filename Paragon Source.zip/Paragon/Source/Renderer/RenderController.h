#pragma once

//Class that will be used to interface with the renderer
#include "../Object Manager/ObjectManager.h"
#include "D_Renderer.h"
#include "RenderContext.h"
#include "ConstantBuffers.h"
#include "Shaders.h"
#include "BlendStateManager.h"
#include "RenderSet.h"
#include "Camera.h"
#include "RenderTarget.h"
#include <atlcomcli.h>
using namespace Paragon_Renderer;

class RenderController
{
private:
	D_Renderer * Renderer;

	//Create Render Conntexts from each state 
	 RenderContext * Base_Static_Geometry;
	 RenderContext * Base_Animated_Geometry;
	 RenderContext * Emissive_Geometry;
	 RenderContext * HUD_Unlit_Geometry;
	 RenderContext * Effect_Unlit_Geometry;
	 RenderContext * Particle_Unlit_Geometry;
	 RenderContext * Telegraph_Unlit_Geometry;
	 RenderContext * PointLight_Context;
	 RenderContext * Text_Unlit_Geometry;
	 RenderContext * Transition_Screen_Geonetry;
	 RenderContext * GhostObjects_AnimGeometry;
	 RenderContext * GhostObjects_StaticGeometry;
	 RenderContext * Base_Ghost_Static_Geometry;



	//RenderTargets
	RenderTarget * gBufferRenderTarget;	
	RenderTarget * SceneTarget;
	RenderTarget * FXAATarget;
	RenderTarget * VerticalGlowBlurTarget;
	RenderTarget * HorizontalGlowBlurTarget;

	//RenderTarget * HDRTarget2;
	//RenderTarget * HDRTarget3;
	//RenderTarget * HDRTarget4;
	//RenderTarget * HDRTarget5;
	//RenderTarget * HDRTarget6;
	RenderTarget * HDRTarget7;

	//RenderTargetSurface ToneTargetViewPass1;
	//RenderTargetSurface ToneTargetViewPass2;
	//RenderTargetSurface ToneTargetViewPass3;
	//RenderTargetSurface ToneTargetViewPass4;
	//RenderTargetSurface ToneTargetViewPass5;
	//RenderTargetSurface ToneTargetViewPass6;
	RenderTargetSurface ToneTargetViewPass7;
	RenderTargetSurface gBufferDiffuseTargetView;
	RenderTargetSurface gBufferNormalsTargetView;
	RenderTargetSurface gBufferSpecularTargetView;
	RenderTargetSurface gBufferDepthTargetView;
	RenderTargetSurface gBufferGlowTargetView;
	RenderTargetSurface SceneTargetView;
	RenderTargetSurface FXAATargetView;
	RenderTargetSurface VerticalGlowBlurTargetView;
	RenderTargetSurface HorizontalGlowBlurTargetView;

	//Texture Samplers
	std::vector<CComPtr<ID3D11SamplerState>> Samplers;

	//Setting Values
	bool	EmmisiveActive;
	int		AA_Value;
	float	GammaValue;

	//Render Stage functions
	void GeometryFirstPass();
	void GeometryAmbPass();
	void RenderPointLights();
	void GeometryMaterialPass();
	void RenderUnlitGeometry();
	void RenderDebugBuffers();
	void PostProcessRender();
	void ClearandResetBaseContext();
	void SetAndBindGBuffers();
	

	//Initialize Functions
	void CreateRenderContexts();
	void CreateRenderTargets();
	void CreateViewPorts();
	void InitializeTextureSamplers();
	
	//Debug information
	ID3D11Debug * Debugger;
public:
	HWND CurrentWindow;
	HINSTANCE CurrentWindowsInstance; 
	bool IsWindowed;

	RenderController();
	~RenderController();

	//Camera Functions
	void UpdateMainCamera(XMFLOAT3 FollowPosition);
	void UpdateCinematicCamera(XMFLOAT3 WaypointPos, XMFLOAT3 DoorLocation);

	//Accessors
	ID3D11Device * GetDevice();
	XMFLOAT4X4& GetViewMatrix();
	XMFLOAT4X4& GetProjMatrix();
	XMVECTOR GetCameraPosition();
	bool IsEmmisiveActive() const;
	int GetAAValue() const;
	float GetGammaValue() const;

	//Mutators
	void SetCameraPosition(XMFLOAT3 location);
	void SetResolution(unsigned int height, unsigned int width, bool IsWindowed);
	void SetEmmisiveActive(bool active);
	void SetAAValue(int value);
	void SetGammaValue(float value);

	//Base Functions
	void Initialize(HWND hWnd, HINSTANCE hInst, bool IsWindowed);
	void Shutdown();
	void Render();
	void CreateRenderSets(ObjectManager * OM);
	void ClearAllRenderSets();

};

