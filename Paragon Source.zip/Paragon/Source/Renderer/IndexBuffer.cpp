#include "../Application/stdafx.h"
#include "IndexBuffer.h"


IndexBuffer::IndexBuffer()
{
}


IndexBuffer::~IndexBuffer()
{
}
