#pragma once
#include "ConstantBuffers.h"

class RenderNode;

namespace Paragon_Renderer
{
	class RenderSet
	{
	private:
		RenderNode * HeadNode;
		RenderNode * TailNode;

	public:
		RenderSet();
		~RenderSet();

		RenderNode * GetHeadPointer();
		void AddRenderNode(RenderNode * NodeToAdd);
		void ClearRenderSet();
	};
}

