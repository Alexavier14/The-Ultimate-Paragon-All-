#include "../Application/stdafx.h"
#include "D_Renderer.h"
#include "RenderContext.h"
#include "Shaders.h"
#include "ConstantBuffers.h"
#include "BlendStateManager.h"
#include "DepthStencilStateManager.h"

namespace Paragon_Renderer
{
	RenderContext::RenderContext(Context_Type Type)
	{
		this->CurrentRenderSet = new RenderSet;
		ContextType = Type;
	}
	RenderContext::~RenderContext()
	{
		//Clean up the current render set
		SAFE_DELETE(CurrentRenderSet);
	}

	void RenderContext::BindContext()
	{
		switch (ContextType)
		{
		case Paragon_Renderer::CT_STATIC_GEOM:
			Bind_StaticGeometry();
			break;
		case Paragon_Renderer::CT_ANIM_GEOM:
			Bind_AnimatedGeometry();
			break;
		case Paragon_Renderer::CT_EMISS_GEOM:
			Bind_EmissiveGeometry();
			break;
		case Paragon_Renderer::CT_HUD:
			Bind_HUD_Elements();
			break;
		case Paragon_Renderer::CT_BILLBOARD:
			Bind_Effect_Billboard_Elements();
			break;
		case Paragon_Renderer::CT_PARTICLE:
			Bind_Particle_Elements();
			break;
		case Paragon_Renderer::CT_TELE:
			Bind_Telegraph_Elements();
			break;
		case Paragon_Renderer::CT_POINT:
			Bind_PointLight_Elements();
			break;
		case Paragon_Renderer::CT_TEXT:
			Bind_Text_Elements();
			break;
		case Paragon_Renderer::CT_GHOST_ANIM:
			Bind_Ghost_Animation();
			break;
		case Paragon_Renderer::CT_GHOST_STATIC:
			Bind_Ghost_Static();
			break;
		default:
			break;
		}
	}

	void RenderContext::Bind_PointLight_Elements()
	{
		BlendStateManager::ApplyState(B_State::BS_LIGHT);
		D_Renderer::pContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
		Shaders::Bind_PointLight_Shaders();
	}
	void RenderContext::Bind_StaticGeometry()
	{
   		DepthStencilStateManager::ApplyState(DSS_Default);
		BlendStateManager::ApplyState(B_State::BS_DEFUALT);
		Shaders::Bind_StaticGeom_Shader();
		D_Renderer::pContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
	}
	void RenderContext::Bind_AnimatedGeometry()
	{
   		DepthStencilStateManager::ApplyState(DSS_Default);
		BlendStateManager::ApplyState(B_State::BS_DEFUALT);
		Shaders::Bind_Animation_VertexShader();
		D_Renderer::pContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
	}
	void RenderContext::Bind_EmissiveGeometry()
	{
		//TODO - After renderer is working
	}
	void RenderContext::Bind_HUD_Elements()
	{
		DepthStencilStateManager::ApplyState(DSS_NoDepth);
		BlendStateManager::ApplyState(B_State::BS_ALPA);
		Shaders::Bind_HUD_Shaders();
		D_Renderer::pContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_POINTLIST);
	}
	void RenderContext::Bind_Text_Elements()
	{
		DepthStencilStateManager::ApplyState(DSS_NoDepth);
		BlendStateManager::ApplyState(B_State::BS_ALPA);
		Shaders::Bind_Text_Shaders();
		D_Renderer::pContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_LINELIST);
	}
	void RenderContext::Bind_Effect_Billboard_Elements()
	{
		DepthStencilStateManager::ApplyState(DSStates::DSS_NoDepth);
		BlendStateManager::ApplyState(B_State::BS_ADD);
		Shaders::Bind_Billboard_Shaders();
		D_Renderer::pContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_POINTLIST);
	}
	void RenderContext::Bind_Particle_Elements()
	{
		DepthStencilStateManager::ApplyState(DSS_Particle);
		BlendStateManager::ApplyState(B_State::BS_ALPA);
		Shaders::Bind_Particle_Shaders();
		D_Renderer::pContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_POINTLIST);
	}
	void RenderContext::Bind_Telegraph_Elements()
	{
		DepthStencilStateManager::ApplyState(DSStates::DSS_Particle);
		BlendStateManager::ApplyState(B_State::BS_ALPA);
		Shaders::Bind_Telegraph_Shaders();
		D_Renderer::pContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_POINTLIST);
	}

	void RenderContext::Bind_Ghost_Static()
	{
		DepthStencilStateManager::ApplyState(DSS_NoDepth);
		BlendStateManager::ApplyState(B_State::BS_DEFUALT);
		Shaders::Bind_Ghost_Static_Pass();
		D_Renderer::pContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

	}
	void RenderContext::Bind_Ghost_Animation()
	{
		DepthStencilStateManager::ApplyState(DSS_Default);
		BlendStateManager::ApplyState(B_State::BS_DEFUALT);
		Shaders::Bind_Ghost_Anim_Pass();
		D_Renderer::pContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
	}

	//Updates the render set that holds this context
	void RenderContext::AddRenderNode(RenderNode * RN)
	{
		CurrentRenderSet->AddRenderNode(RN);
	}
	void RenderContext::ClearRenderSet()
	{
		CurrentRenderSet->ClearRenderSet();
	}
	RenderSet * RenderContext::GetRenderset()
	{
		return CurrentRenderSet;
	}

}