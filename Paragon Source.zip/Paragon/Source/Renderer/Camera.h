#include "../Application/stdafx.h"
#ifndef CAMERA_H
#define CAMERA_H

#define BRIDGE 0.8123421f

#include "../Object Manager/GameObject.h"
#include <math.h>

class Camera
{
private:
	XMFLOAT4X4 ViewMatrix;
	XMFLOAT4X4 CameraWorld;
	void UpdateCameraPosition(XMFLOAT3 PlayerPos);

public:
	void Initialize();
	void Update(XMFLOAT3 Player);
	void UpdateCinematicCamera(XMFLOAT3 WaypointLoc, XMFLOAT3 DoorLocation);
	
	XMFLOAT4 GetCameraPos();
	XMFLOAT4X4 GetRendererViewMat();
	XMFLOAT4X4 GetViewMatrix();

	void SetCameraPos(XMFLOAT3 location);

	void UpdateDebugCameraPosition();

	Camera();
	~Camera();
};

#endif