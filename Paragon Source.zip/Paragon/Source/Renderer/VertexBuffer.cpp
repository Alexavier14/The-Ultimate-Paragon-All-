#include "../Application/stdafx.h"
#include "VertexBuffer.h"


VertexBuffer::VertexBuffer()
{
}


VertexBuffer::~VertexBuffer()
{
}
