#include "../Application/stdafx.h"
#pragma once

struct ID3DUserDefinedAnnotation;

#if _DEBUG
#define MarkEvent(str) 		GraphicsDebugEvent gdEvent; gdEvent.MarkEventCall(str);
#else
#define MarkEvent __noop
#endif

class GraphicsDebugEvent
{
	ID3DUserDefinedAnnotation * pPerf;
	
	public:
	GraphicsDebugEvent();
	~GraphicsDebugEvent();

	// use MarkEvent macro to avoid string operations
	void MarkEventCall(wstring eventName);
	void MarkEventCall(string eventName);

};

