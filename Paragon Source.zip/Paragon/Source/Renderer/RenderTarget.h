#pragma once
#include <atlcomcli.h>

namespace Paragon_Renderer
{
	//A class to represent each Render Targer
	class RenderTargetSurface
	{
	private:
		CComPtr<ID3D11Resource> CurrentTexture;
		CComPtr<ID3D11ShaderResourceView> SRV;
		CComPtr<ID3D11RenderTargetView> RTV;

		UINT Width;
		UINT Height;

	public:
		string RTSName;

		RenderTargetSurface();
		~RenderTargetSurface();

		void Create(UINT width, UINT height, const char * name, DXGI_FORMAT format = DXGI_FORMAT_D32_FLOAT_S8X24_UINT);
		void Create();
		void Shutdown();

		CComPtr<ID3D11Resource> GetTextutre();
		CComPtr<ID3D11RenderTargetView> GetRenderTargetView();
		CComPtr<ID3D11ShaderResourceView> GetSRV();
		UINT GetHeight();
		UINT GetWidth();

	};

	//A class that acts more as a manager to all render targets
	class RenderTarget
	{
	private:
		std::vector<RenderTargetSurface*> RenderTargets;

	public:
		void Create(UINT _width, UINT _height, DXGI_FORMAT format, string RTName);
		//void Create(ID3D11DepthStencilView * DSV, ID3D11Texture2D * DSBuffer);
		void Shutdown();

		CComPtr<ID3D11DepthStencilView> DepthStencilView;
		CComPtr<ID3D11Texture2D> DepthStencilBuffer;
		CComPtr<ID3D11ShaderResourceView> DepthBufferSRV;
		CComPtr<ID3D11ShaderResourceView> GetDepthSRV();
		RenderTargetSurface* ActiveTarget;
		RenderTargetSurface* GetRenderTargetSurface(int index = 0);
		
		void CreateRenderTarget(UINT width, UINT Height, DXGI_FORMAT format, const char * name);
		void AddTarget(RenderTargetSurface* RTS);
		void ClearRenderTargetView(float ClearColor[4]);
		void ClearDepthStencilView(UINT clearFlags, float depth = 1.0f);
		void ActivateRenderTarget(RenderTargetSurface * RTS);
		void ActivateRenderTargets();
		void ActivateRenderTargets(ID3D11DepthStencilView * DSV);

		RenderTarget();
		~RenderTarget();
	};
}

