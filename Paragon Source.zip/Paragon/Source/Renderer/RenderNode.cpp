#include "../Application/stdafx.h"
#include "../Object Manager/RendererComponent.h"
#include "../Object Manager/GameObject.h"
#include "../Object Manager/EffectComponent.h"
#include "../Object Manager/PointLightComponent.h"
#include "../Particle System/Emitter.h"
#include "RenderNode.h"
#include "D_Renderer.h"
#include "ConstantBuffers.h"
#include "../Util/Util.h"
#include "GraphicsDebugEvent.h"
//This will be used to store the per object render functions

void RenderNode::RenderProcess(Paragon_Renderer::Context_Type PerObjectType)
{
	switch (PerObjectType)
	{
	case Paragon_Renderer::CT_STATIC_GEOM:
		Static_Geom_Render();
		break;
	case Paragon_Renderer::CT_ANIM_GEOM:
		Anim_Geom_Render();
		break;
	case Paragon_Renderer::CT_EMISS_GEOM:
		Emiss_Geom_Render();
		break;
	case Paragon_Renderer::CT_HUD:
		HUD_Ulit_Render();
		break;
	case Paragon_Renderer::CT_BILLBOARD:
		Billboard_Effect_Unlit_Render();
		break;
	case Paragon_Renderer::CT_PARTICLE:
		Particle_Render();
		break;
	case Paragon_Renderer::CT_TELE:
		Telegraph_Unlit_Render();
		break;
	case Paragon_Renderer::CT_POINT:
		PointLight_Render();
		break;
	case Paragon_Renderer::CT_TEXT:
		Text_Ulit_Render();
		break;
	case Paragon_Renderer::CT_GHOST_ANIM:
		Anim_Geom_Render();
		break;
	case Paragon_Renderer::CT_GHOST_STATIC:
		Static_Geom_Render();
		break;

	default:
		PrintConsole("Unfamiliar Render Type passed into " + this->ObjectData->GetTag() + " render process function");
		break;
	}
}

void RenderNode::Static_Geom_Render()
{
	if (ObjectData->GetActive() == true)
	{
		//Index and vertex buffer will be bound on a per set level when changes are made
		CMesh * CurrentMesh = ObjectData->GetRendererComponent()->m_RenderMesh;
		UINT offsetSB = 0;
		UINT strideSB = sizeof(CMesh::tStatic_Tan_Verts);

		Paragon_Renderer::D_Renderer::pContext->IASetVertexBuffers(0, 1, CurrentMesh->GetVertexBuffer(), &strideSB, &offsetSB);
		Paragon_Renderer::D_Renderer::pContext->IASetIndexBuffer(CurrentMesh->GetIndexArray(), DXGI_FORMAT_R16_UINT, offsetSB);

		//Update Constant Buffers
		Paragon_Renderer::ConstantBuffers::GetInstance()->cbUpdate_Bind_Static_Geom(ObjectData);

		//Set Per object SRV
		Paragon_Renderer::D_Renderer::pContext->PSSetShaderResources(0, 1, &ObjectData->GetRendererComponent()->DiffuseTexture);
		Paragon_Renderer::D_Renderer::pContext->PSSetShaderResources(1, 1, &ObjectData->GetRendererComponent()->NormalMap);
		Paragon_Renderer::D_Renderer::pContext->PSSetShaderResources(2, 1, &ObjectData->GetRendererComponent()->SpecularMap);
		Paragon_Renderer::D_Renderer::pContext->PSSetShaderResources(3, 1, &ObjectData->GetRendererComponent()->EmisiveMap);

		//Draw
		Paragon_Renderer::D_Renderer::pContext->DrawIndexed(CurrentMesh->GetIndexSize(), 0, 0);
	}
}
void RenderNode::Anim_Geom_Render()
{
	if (ObjectData->GetActive() == true)
	{
		//Index and vertex buffer will be bound on a per set level when changes are made
		CMesh * CurrentMesh = ObjectData->GetRendererComponent()->m_RenderMesh;
		UINT offsetSB = 0;
		UINT strideSB = sizeof(CMesh::tAnimated_Verts);
		Paragon_Renderer::D_Renderer::pContext->IASetVertexBuffers(0, 1, CurrentMesh->GetVertexBuffer(), &strideSB, &offsetSB);
		Paragon_Renderer::D_Renderer::pContext->IASetIndexBuffer(CurrentMesh->GetIndexArray(), DXGI_FORMAT_R16_UINT, offsetSB);

		//Update Constant Buffers
		Paragon_Renderer::ConstantBuffers::GetInstance()->cbUpdate_Bind_Animated_Geom(ObjectData);
		Paragon_Renderer::ConstantBuffers::GetInstance()->cbUpdate_Bind_Ghost_Color_Buffer(ObjectData);

		//Per Object SRV
		Paragon_Renderer::D_Renderer::pContext->PSSetShaderResources(0, 1, &ObjectData->GetRendererComponent()->DiffuseTexture);
		Paragon_Renderer::D_Renderer::pContext->PSSetShaderResources(1, 1, &ObjectData->GetRendererComponent()->NormalMap);
		Paragon_Renderer::D_Renderer::pContext->PSSetShaderResources(2, 1, &ObjectData->GetRendererComponent()->SpecularMap);
		Paragon_Renderer::D_Renderer::pContext->PSSetShaderResources(3, 1, &ObjectData->GetRendererComponent()->EmisiveMap);

		//Draw
		Paragon_Renderer::D_Renderer::pContext->DrawIndexed(CurrentMesh->GetIndexSize(), 0, 0);
	}
}
void RenderNode::Emiss_Geom_Render()
{

}
void RenderNode::HUD_Ulit_Render()
{
	if (ObjectData->GetActive() == true && ObjectData->GetHUDComponent()->isEnabled == true)
	{
		//Contant Buffers
		Paragon_Renderer::ConstantBuffers::GetInstance()->cbUpdate_Bind_HUD_Geom(ObjectData);

		//Per Object SRV
		Paragon_Renderer::D_Renderer::pContext->PSSetShaderResources(0, 1, &ObjectData->GetRendererComponent()->DiffuseTexture);

		//Draw
		Paragon_Renderer::D_Renderer::pContext->Draw(1, 0);
	}
}
void RenderNode::Text_Ulit_Render()
{
	if (ObjectData->GetTextComponent()->IsActive() == true && ObjectData->GetActive() == true)
	{
		size_t TextLen = Paragon_Renderer::ConstantBuffers::GetInstance()->cbUpdate_Bind_Text_Geom(ObjectData);
		if (TextLen == 0)
			return;

		ID3D11ShaderResourceView* pGlyphTexture = ObjectData->GetTextComponent()->GetFont()->GetGlyphTexture();
		ID3D11ShaderResourceView* pOutlineTexture = ObjectData->GetTextComponent()->GetFont()->GetOutlineTexture();
		Paragon_Renderer::D_Renderer::pContext->PSSetShaderResources(0, 1, &pGlyphTexture);
		Paragon_Renderer::D_Renderer::pContext->PSSetShaderResources(1, 1, &pOutlineTexture);

		Paragon_Renderer::D_Renderer::pContext->Draw(TextLen * 2, 0);
	}

}
void RenderNode::Telegraph_Unlit_Render()
{
	if (ObjectData->GetTelegraphComponent()->GetEnabled() == true)
	{
		//Contant Buffers
		Paragon_Renderer::ConstantBuffers::GetInstance()->cbUpdate_Bind_Telegraph_Geom(ObjectData);

		//Per Object SRV
		Paragon_Renderer::D_Renderer::pContext->PSSetShaderResources(0, 1, &ObjectData->GetRendererComponent()->DiffuseTexture);

		//Draw
		Paragon_Renderer::D_Renderer::pContext->Draw(1, 0);
	}
}
void RenderNode::Billboard_Effect_Unlit_Render()
{
	if (ObjectData->GetActive() == true && ObjectData->GetEffectComponent()->isEnabled == true)
	{
		//Contant Buffers
		Paragon_Renderer::ConstantBuffers::GetInstance()->cbUpdate_Bind_Effect_Geom(ObjectData);

		//Per Object SRV
		Paragon_Renderer::D_Renderer::pContext->PSSetShaderResources(0, 1, &ObjectData->GetRendererComponent()->DiffuseTexture);
		//Paragon_Renderer::D_Renderer::pContext->PSSetShaderResources(1, 1, &ObjectData->GetRendererComponent()->NormalMap);
		//Paragon_Renderer::D_Renderer::pContext->PSSetShaderResources(2, 1, &ObjectData->GetRendererComponent()->SpecularMap);
		//Paragon_Renderer::D_Renderer::pContext->PSSetShaderResources(3, 1, &ObjectData->GetRendererComponent()->EmisiveMap);

		//Draw
		MarkEvent(ObjectData->GetTag());
		Paragon_Renderer::D_Renderer::pContext->Draw(1, 0);
	}
}
void RenderNode::PointLight_Render()
{
	//Clear the depth stencil view
	if (ObjectData->GetActive())
	{
		CMesh * CurrentMesh = ObjectData->GetRendererComponent()->m_RenderMesh;
		UINT offsetSB = 0;
		UINT strideSB = sizeof(CMesh::tStatic_Verts);

		if (ObjectData->GetPointLightComponent()->AddFlicker == true)
		{
			Paragon_Renderer::D_Renderer::pContext->PSSetShaderResources(0, 1, &ObjectData->GetRendererComponent()->DiffuseTexture);
			if (ObjectData->GetPointLightComponent()->FlickerTimer > 0.05f)
			{
				ObjectData->GetPointLightComponent()->PointLightData.isTorch = (rand() % (10 - 1 + 1) * 0.1f);
				ObjectData->GetPointLightComponent()->FlickerTimer = 0.0f;
			}
		}
		else
		{
			ObjectData->GetPointLightComponent()->PointLightData.isTorch = 0.0f;
		}
		Paragon_Renderer::D_Renderer::pContext->IASetVertexBuffers(0, 1, CurrentMesh->GetVertexBuffer(), &strideSB, &offsetSB);
		Paragon_Renderer::D_Renderer::pContext->IASetIndexBuffer(CurrentMesh->GetIndexArray(), DXGI_FORMAT_R16_UINT, offsetSB);
		Paragon_Renderer::ConstantBuffers::GetInstance()->cbUpdate_Bind_Point_Light(ObjectData);
		Paragon_Renderer::D_Renderer::pContext->DrawIndexed(CurrentMesh->GetIndexSize(), 0, 0);
	}
}
void RenderNode::Particle_Render()
{
	//if (ObjectData->GetEmitterComponent()->IsActive() == true)
	//{
		//Contant Buffers
		Paragon_Renderer::ConstantBuffers::GetInstance()->cbUpdate_Bind_Particle_Geom(ObjectData);

		//Per Object SRV
		Paragon_Renderer::D_Renderer::pContext->PSSetShaderResources(0, 1, &ObjectData->GetEmitterComponent()->m_pParticleTexture);

		//Draw
		Paragon_Renderer::D_Renderer::pContext->Draw(ObjectData->GetEmitterComponent()->GetParticles().size(), 0);
	// }
}
