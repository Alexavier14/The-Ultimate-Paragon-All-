#include "../Application/stdafx.h"
#include "ConstantBuffers.h"
#include "D_Renderer.h"
#include "../Object Manager/EffectComponent.h"
#include "../Object Manager/AnimComponent.h"
#include "../Object Manager/PointLightComponent.h"
#include "../Object Manager/RendererComponent.h"
#include "../Particle System/ParticleSystem.h"
namespace Paragon_Renderer
{
	ConstantBuffers::ConstantBuffers() 
	{
		pParticleVertBuffer = nullptr;
		ObjectTransformBuffer = nullptr;
		ViewProjectionBuffer = nullptr;
		HUDQuadDataBuffer = nullptr;
		EffectDataBuffer = nullptr;
		//pCollisionVertBuffer = nullptr;
		//pCollisionColorBuffer = nullptr;
		pTextVertBuffer = nullptr;
		pTextColorBuffer = nullptr;
		pAnimBuffer = nullptr;
		pTelegraphBuffer = nullptr;
		pPointLightBuffer = nullptr;
		pParticleEmitterBuffer = nullptr;
		pReactionEffectBuffer = nullptr;
		pScreenDataBuffer = nullptr;
		//FullScreenQuadVertBuffer = nullptr;
		pGhostColorBuffer = nullptr;
		pTextureFlagBuffer = nullptr;
		pBlurDirectionBuffer = nullptr;
		
	}
	ConstantBuffers::~ConstantBuffers()	{}

	//Init Static Memebers
	ConstantBuffers * ConstantBuffers::pInstance = nullptr;

	ConstantBuffers * ConstantBuffers::GetInstance()
	{
		if (!pInstance)
		{
			pInstance = new ConstantBuffers();
		}		
		return pInstance;
	}

	void ConstantBuffers::cbUpdate_Screen_Quad_Buffer(unsigned int ScreenWidth, unsigned int ScreenHeight)
	{
		cbSCREEN CurrentScreen; 
		CurrentScreen.height = (float)D_Renderer::GetScreenHeight();
		CurrentScreen.width = (float)D_Renderer::GetScreenWidth();

		if (pScreenDataBuffer == nullptr)
			CreateConstantBuffer(&pScreenDataBuffer, &CurrentScreen);
		else
			UpdateConstantBuffer(pScreenDataBuffer, CurrentScreen);
	}

	void ConstantBuffers::cbBind_Geom_Screen_Buffer(int slot)
	{
		D_Renderer::pContext->GSSetConstantBuffers(1, 1, &pScreenDataBuffer);
	}
	void ConstantBuffers::cbBind_Screen_Buffer(int slot)
	{
		D_Renderer::pContext->PSSetConstantBuffers(1, 1, &pScreenDataBuffer);
	}

	//This function is used to call create on all of the constant buffers
	void ConstantBuffers::Initialize()
	{
		// --- Create the vertex buffer to store particle vertex points
		D3D11_BUFFER_DESC particleBufferDesc;
		ZeroMemory(&particleBufferDesc, sizeof(D3D11_BUFFER_DESC));
		particleBufferDesc.ByteWidth = sizeof(Particle) * ParticleSystem::MAX_PARTICLES;
		particleBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
		particleBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
		particleBufferDesc.BindFlags = D3D11_BIND_VERTEX_BUFFER;
		D_Renderer::pDevice->CreateBuffer(&particleBufferDesc, NULL, &pParticleVertBuffer);

		// --- Create Const Buffers
		//Effect Defaults
		cbEFFECT_DATA EData;
		EData.Position = XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f);
		EData.Size = XMFLOAT2(1.0f, 1.0f);
		CreateConstantBuffer(&EffectDataBuffer, &EData);

		//Ghost Color Buffer
		cbGHOSTCOLOR gColor;
		gColor.GhostColor = XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f);
		CreateConstantBuffer(&pGhostColorBuffer, &gColor);

		//Create flag buffer
		cbTEXTUREFLAGS tf;
		tf.UseEmisTex = false;
		tf.UseSpecTex = false;
		tf.UseNormalTex = false;
		tf.ApplyNormals = false;
		XMFLOAT4 TextureFlagFloat = XMFLOAT4(0.0f, 0.0f, 0.0f, 0.0f);
		CreateConstantBuffer(&pTextureFlagBuffer, &TextureFlagFloat);

		XMFLOAT2 Direction = XMFLOAT2(0.0f, 0.0f);
		CreateConstantBuffer(&pBlurDirectionBuffer, &Direction);

		//HUD Defualts
		cbHUD_DATA HudD;
		HudD.height = 5.0f;
		HudD.width = 5.0f;
		HudD.PosX = 0.0f;
		HudD.PosY = 0.0f;
		CreateConstantBuffer(&HUDQuadDataBuffer, &HudD);

		//Object Defaults
		cbOBJECT StoreWorld;
		XMStoreFloat4x4(&StoreWorld.world, XMMatrixIdentity());
		CreateConstantBuffer(&ObjectTransformBuffer, &StoreWorld);

		//Scene Defaults
		cbSCENE StoreScene;
		XMStoreFloat4x4(&StoreScene.Proj, XMMatrixIdentity());
		XMStoreFloat4x4(&StoreScene.View, XMMatrixIdentity());
		XMStoreFloat4x4(&StoreScene.CameraPos, XMMatrixIdentity());
		CreateConstantBuffer(&ViewProjectionBuffer, &StoreScene);

		//Telegraph Defualts
		cbTELEGRAPH Tele;
		Tele.Color = XMFLOAT3(1.0f, 1.0f, 1.0f);
		Tele.Position = XMFLOAT2(1.0f, 1.0f);
		Tele.Scale = XMFLOAT2(1.0f, 1.0f);
		Tele.Radius = 1.0f;
		Tele.Type = 0;
		Tele.PercentComplete = 0.1f;
		CreateConstantBuffer(&pTelegraphBuffer, &Tele);

		//Animation Defualts
		cbANIM_DATA anim;
		CreateConstantBuffer(&pAnimBuffer, &anim);

		//Lighting Defualts
		cbPOINT_LIGHT PointLight;
		PointLight.diffuseColor = XMFLOAT3(1.0f, 1.0f, 1.0f);
		PointLight.position = XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f);
		PointLight.ambientColor = XMFLOAT3(1.0f, 1.0f, 1.0f);
		PointLight.attenuation = XMFLOAT3(1.0f, 1.0f, 1.0f);
		PointLight.specularColor = XMFLOAT3(1.0f, 1.0f, 1.0f);
		PointLight.range = 1.0f;
		PointLight.specularIntensity = 1.0f;
		PointLight.specularPower = 1.0f;
		CreateConstantBuffer(&pPointLightBuffer, &PointLight);

		//Create constant buffer for circle verts
		//XMFLOAT3 Default = XMFLOAT3(1.0f, 1.0f, 1.0f);
		//XMFLOAT3 Circle[360];
		//for (unsigned int i = 0; i < 360; i++)
		//{
		//	Circle[i] = Default;
		//}
		//CreateConstantBuffer(&pCollisionVertBuffer, &Circle[0], (UINT)360);

		//Create Collision Vertex Buffer
		//XMFLOAT4 Filler = XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f);
		//CreateConstantBuffer(&pCollisionColorBuffer, &Filler);

		//Particle emiiter buffer
		cbEMITTER_DATA ED;
		CreateConstantBuffer(&pParticleEmitterBuffer, &ED);

		//Flash Color
		XMFLOAT4X4 Color;
		CreateConstantBuffer(&pReactionEffectBuffer, &Color);

		//Text
		//Create the vertex buffer to store the info for letter quads
		D3D11_BUFFER_DESC textBufferDesc;
		ZeroMemory(&textBufferDesc, sizeof(D3D11_BUFFER_DESC));
		textBufferDesc.ByteWidth = sizeof(TEXT_VERT) * TextBox::MAX_CHARACTERS * 2;
		textBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
		textBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
		textBufferDesc.BindFlags = D3D11_BIND_VERTEX_BUFFER;

		//Create the buffer of text verts
		D_Renderer::pDevice->CreateBuffer(&textBufferDesc, NULL, &pTextVertBuffer);


		//Create the constant buffer for text Colors
		D3D11_BUFFER_DESC textColorBufferDesc;
		ZeroMemory(&textColorBufferDesc, sizeof(D3D11_BUFFER_DESC));
		textColorBufferDesc.ByteWidth = sizeof(TEXT_COLOR);
		textColorBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
		textColorBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
		textColorBufferDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;

		//Create text Colors Constant Buffer
		D_Renderer::pDevice->CreateBuffer(&textColorBufferDesc, NULL, &pTextColorBuffer);

		//Create screen data buffer
		cbSCREEN CurrentScreen;
		CurrentScreen.height = (float)D_Renderer::GetScreenHeight();
		CurrentScreen.width = (float)D_Renderer::GetScreenWidth();
		if (nullptr == pScreenDataBuffer)
		{
			CreateConstantBuffer(&pScreenDataBuffer, &CurrentScreen);
		}

		SetD3DName(pParticleVertBuffer, "Particle Vert Buffer")
		SetD3DName(ObjectTransformBuffer, "Object Transform Buffer")
		SetD3DName(ViewProjectionBuffer, "ViewProjBuffer")
		SetD3DName(HUDQuadDataBuffer, "HUD Qaud Buffer")
		SetD3DName(EffectDataBuffer, "Effect Data Buffer")
		//SetD3DName(pCollisionVertBuffer, "Collision Vert Buffer")
		//SetD3DName(pCollisionColorBuffer, "Collision Color Buffer")
		SetD3DName(pTextVertBuffer, "Text Vert Buffer")
		SetD3DName(pTextColorBuffer, "Text Color Buffer")
		SetD3DName(pAnimBuffer, "Anim Buffer")
		SetD3DName(pTelegraphBuffer, "Telegraph buffer")
		SetD3DName(pPointLightBuffer, "Point Light Buffer")
		SetD3DName(pParticleEmitterBuffer, "Particle Emitter Buffer")
		SetD3DName(pReactionEffectBuffer, "Reaction Effect Buffer")
		SetD3DName(pGhostColorBuffer, "Ghost Color Buffer")
		SetD3DName(pTextureFlagBuffer, "Texture Flag Buffer")
		SetD3DName(pScreenDataBuffer, "Screen Data Buffer")
		SetD3DName(pBlurDirectionBuffer, "Blur Direction Buffer")
		//SetD3DName(FullScreenQuadVertBuffer, "Screen Data Buffer")
	}

	//Clean up the 
	void ConstantBuffers::Shutdown()
	{ 
		if (pInstance)
		{
			ReleaseCOM(pInstance->ObjectTransformBuffer);
			ReleaseCOM(pInstance->ViewProjectionBuffer);
			ReleaseCOM(pInstance->HUDQuadDataBuffer);
			ReleaseCOM(pInstance->EffectDataBuffer);
			//ReleaseCOM(pInstance->pCollisionVertBuffer);
			//ReleaseCOM(pInstance->pCollisionColorBuffer);
			ReleaseCOM(pInstance->pTextVertBuffer);
			ReleaseCOM(pInstance->pTextColorBuffer);
			ReleaseCOM(pInstance->pAnimBuffer);
			ReleaseCOM(pInstance->pTelegraphBuffer);
			ReleaseCOM(pInstance->pPointLightBuffer);
			ReleaseCOM(pInstance->pReactionEffectBuffer);
			ReleaseCOM(pInstance->pParticleVertBuffer);
			ReleaseCOM(pInstance->pParticleEmitterBuffer);
			ReleaseCOM(pInstance->pGhostColorBuffer);
			ReleaseCOM(pInstance->pTextureFlagBuffer);
			ReleaseCOM(pInstance->pScreenDataBuffer);
			ReleaseCOM(pInstance->pBlurDirectionBuffer);
			//ReleaseCOM(pInstance->FullScreenQuadVertBuffer);
		}

		SAFE_DELETE(pInstance);
	}

	template<class TYPE>
	void ConstantBuffers::CreateConstantBuffer(ID3D11Buffer ** ConstantBuffer, TYPE * data)
	{
		//Get the size in multiple of 16
		int DataSize = sizeof(*data);
		int FourByteCount = DataSize / 16;
		int ByteWidth = FourByteCount * 16;
		if (ByteWidth < DataSize)
			ByteWidth += 16;

		D3D11_BUFFER_DESC Const_Buffer_Desc;
		ZeroMemory(&Const_Buffer_Desc, sizeof(Const_Buffer_Desc));
		Const_Buffer_Desc.ByteWidth = ByteWidth;
		Const_Buffer_Desc.Usage = D3D11_USAGE_DYNAMIC;
		Const_Buffer_Desc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
		Const_Buffer_Desc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;

		//Sub resource for CB data
		D3D11_SUBRESOURCE_DATA Const_Buffer_Data;
		Const_Buffer_Data.pSysMem = data;
		Const_Buffer_Data.SysMemPitch = 0;
		Const_Buffer_Data.SysMemSlicePitch = 0;

		//Create the current CB
		D_Renderer::pDevice->CreateBuffer(&Const_Buffer_Desc, &Const_Buffer_Data, ConstantBuffer);
	}

	template<class TYPE>
	void ConstantBuffers::CreateConstantBuffer(ID3D11Buffer ** ConstantBuffer, TYPE * data, UINT ObjectCount)
	{
		//Get the size in multiple of 16
		int DataSize = sizeof(*data);
		int FourByteCount = DataSize / 16;
		int ByteWidth = FourByteCount * 16;
		if (ByteWidth < DataSize)
			ByteWidth += 16;

		D3D11_BUFFER_DESC Const_Buffer_Desc;
		ZeroMemory(&Const_Buffer_Desc, sizeof(Const_Buffer_Desc));
		Const_Buffer_Desc.ByteWidth = (ByteWidth * ObjectCount);
		Const_Buffer_Desc.Usage = D3D11_USAGE_DYNAMIC;
		Const_Buffer_Desc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
		Const_Buffer_Desc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;

		//Sub resource for CB data
		D3D11_SUBRESOURCE_DATA Const_Buffer_Data;
		Const_Buffer_Data.pSysMem = data;
		Const_Buffer_Data.SysMemPitch = 0;
		Const_Buffer_Data.SysMemSlicePitch = 0;

		//Create the current CB
		D_Renderer::pDevice->CreateBuffer(&Const_Buffer_Desc, &Const_Buffer_Data, ConstantBuffer);
	}

	template<class TYPE>
	void ConstantBuffers::UpdateConstantBuffer(ID3D11Buffer * ConstantBuffer, const TYPE& data)
	{
		D3D11_MAPPED_SUBRESOURCE MappedResource;
		D_Renderer::pContext->Map(ConstantBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &MappedResource);
		memcpy_s(MappedResource.pData, sizeof(data), &data, sizeof(data));
		D_Renderer::pContext->Unmap(ConstantBuffer, 0);
	}

	template<class TYPE>
	void ConstantBuffers::UpdateConstantBuffer(ID3D11Buffer * ConstantBuffer, const TYPE& data, UINT Size)
	{
		D3D11_MAPPED_SUBRESOURCE MappedResource;
		D_Renderer::pContext->Map(ConstantBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &MappedResource);
		memcpy_s(MappedResource.pData, Size, &data, sizeof(data));
		D_Renderer::pContext->Unmap(ConstantBuffer, 0);
	}

#pragma region Specific Buffer Updates and Binds
	void ConstantBuffers::cbUpdate_Camera_Proj()
	{
		cbSCENE svp_local;
		svp_local.View = D_Renderer::GetMainCamera()->GetRendererViewMat();
		svp_local.Proj = D_Renderer::GetProjectionMatrix();

		XMMATRIX UpdatedCamera = XMLoadFloat4x4(&svp_local.View);
		UpdatedCamera = XMMatrixInverse(0, UpdatedCamera);
		XMStoreFloat4x4(&svp_local.CameraPos, UpdatedCamera);

		XMMATRIX CameraToUpdate = XMLoadFloat4x4(&svp_local.View);
		XMMATRIX ProjToUpdate = XMLoadFloat4x4(&svp_local.Proj);
		XMMATRIX ViewProj = CameraToUpdate * ProjToUpdate;
		XMMATRIX InvViewProj = XMMatrixInverse(0, ViewProj);
		XMStoreFloat4x4(&svp_local.InvViewProj, InvViewProj);

		UpdateConstantBuffer(ViewProjectionBuffer, svp_local);

	}
	void ConstantBuffers::cbUpdate_Bind_Static_Geom(GameObject * GO)
	{
		//Update the Transform Buffer
		XMMATRIX WorldTransform = XMLoadFloat4x4(&GO->GetWorldTransform());
		if (GO->GetType() != eWALL)
			WorldTransform = XMMatrixMultiply(XMMatrixRotationY(XM_PI), WorldTransform);
		XMFLOAT4X4 correctedPos;
		XMStoreFloat4x4(&correctedPos, WorldTransform);
		UpdateConstantBuffer(ObjectTransformBuffer, correctedPos);

		//Update the Collision Color buffer
		UpdateConstantBuffer(pReactionEffectBuffer, GO->GetObjectColor());

		//Update Texture Flags
		cbUpdate_Bind_Texture_Flag_Buffer(GO);

		//Bind to pipeline
		D_Renderer::pContext->VSSetConstantBuffers(0, 1, &ObjectTransformBuffer);
		D_Renderer::pContext->VSSetConstantBuffers(1, 1, &ViewProjectionBuffer);
		//D_Renderer::pContext->PSSetConstantBuffers(2, 1, &pPointLightBuffer);
		D_Renderer::pContext->PSSetConstantBuffers(2, 1, &pReactionEffectBuffer);
	}
	void ConstantBuffers::cbUpdate_Bind_Animated_Geom(GameObject * GO)
	{
		//Update static side
		//GO->GetRendererComponent()->TextureFlags.ApplyNormals = false;
		cbUpdate_Bind_Static_Geom(GO);

		//Update the Constant buffer
		tKeyFrame CurrentKey = GO->GetAnimComponent()->GetInterpolatedFrame();
		cbANIM_DATA AnimBufferData;
		for (size_t i = 0; i < CurrentKey.m_Bones.size(); i++)
			AnimBufferData.joints[i] = CurrentKey.m_Bones[i]->GetWorldMat();

		UpdateConstantBuffer(this->pAnimBuffer, AnimBufferData);

		//Bind to the pipeline
		D_Renderer::pContext->VSSetConstantBuffers(2, 1, &pAnimBuffer);

	}
	void ConstantBuffers::cbUpdate_Bind_Telegraph_Geom(GameObject * GO)
	{
		////Update the buffer
		//XMFLOAT2 Position = XMFLOAT2(GO->GetTelegraphComponent()->PosX, GO->GetTelegraphComponent()->PosZ);
		//XMFLOAT2 Scale = XMFLOAT2(GO->GetTelegraphComponent()->StartScale, GO->GetTelegraphComponent()->EndScale);
		//cbTELEGRAPH CurrentTele;
		//CurrentTele.IsFear = GO->GetTelegraphComponent()->IsFear;
		//CurrentTele.Position = Position;
		//CurrentTele.Scale = Scale;
		//CurrentTele.Color1 = GO->GetTelegraphComponent()->Color1;
		//CurrentTele.Color2 = GO->GetTelegraphComponent()->Color2;
		//CurrentTele.Color3 = GO->GetTelegraphComponent()->Color3;
		//CurrentTele.PercentComplete = GO->GetTelegraphComponent()->PercentComplete;

		//if (GO->GetTelegraphComponent()->IsFear == true)
		//{
		//	CurrentTele.IsFear = 1.0f;
		//}
		//else
		//	CurrentTele.IsFear = 0.0f;

		UpdateConstantBuffer(pTelegraphBuffer, GO->GetTelegraphComponent()->GetTelegraphBuffer());
		
		//Bind to the pipeline
		D_Renderer::pContext->GSSetConstantBuffers(0, 1, &pTelegraphBuffer);
		D_Renderer::pContext->GSSetConstantBuffers(1, 1, &ViewProjectionBuffer);
		D_Renderer::pContext->PSSetConstantBuffers(0, 1, &pTelegraphBuffer);
	}
	void ConstantBuffers::cbUpdate_Bind_HUD_Geom(GameObject * GO)
	{
		//static int HitCount = 0;
		//HitCount++;
		//string HitCountStr = std::to_string(HitCount);
		//WriteToThreadLog(HitCountStr.c_str());

		//Update the buffer
		cbHUD_DATA CurrentHudElement;
		CurrentHudElement.height = GO->GetHUDComponent()->m_Height;
		CurrentHudElement.width = GO->GetHUDComponent()->m_Width;
		CurrentHudElement.PosX = GO->GetHUDComponent()->m_XSceenPos;
		CurrentHudElement.PosY = GO->GetHUDComponent()->m_YScreenPos;
		UpdateConstantBuffer(HUDQuadDataBuffer, CurrentHudElement);

		tObjectColor HudColor = GO->GetObjectColor();
		UpdateConstantBuffer(pReactionEffectBuffer, HudColor);

		//Bind to Pipeline
		D_Renderer::pContext->GSSetConstantBuffers(2, 1, &HUDQuadDataBuffer);
		D_Renderer::pContext->PSSetConstantBuffers(3, 1, &pReactionEffectBuffer);
	}
	void ConstantBuffers::cbUpdate_Bind_Effect_Geom(GameObject * GO)
	{
		//Update Effect 
		cbEFFECT_DATA CurrentEffect;
		XMFLOAT3& Pos = GO->GetEffectComponent()->Position;
		CurrentEffect.Position = XMFLOAT4(Pos.x, Pos.y, Pos.z, 1.0f);
		CurrentEffect.Size = GO->GetEffectComponent()->Size;
		UpdateConstantBuffer(EffectDataBuffer, CurrentEffect);
		UpdateConstantBuffer(pReactionEffectBuffer, GO->GetObjectColor());

		//Bind to Pipeline
		D_Renderer::pContext->GSSetConstantBuffers(0, 1, &ViewProjectionBuffer);
		D_Renderer::pContext->GSSetConstantBuffers(1, 1, &EffectDataBuffer);
		D_Renderer::pContext->PSSetConstantBuffers(0, 1, &pReactionEffectBuffer);
	}
	void ConstantBuffers::cbUpdate_Bind_Particle_Geom(GameObject * GO)
	{
		//Update cbuffers
		UINT offset = 0;
		UINT stride = sizeof(Particle);
		const vector<Particle>& particles = GO->GetEmitterComponent()->GetParticles();

	
		D3D11_MAPPED_SUBRESOURCE MappedResource;
		D_Renderer::pContext->Map(pParticleVertBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &MappedResource);
		memcpy_s(MappedResource.pData, sizeof(Particle) * particles.size(), &particles[0], sizeof(Particle) * particles.size());
		D_Renderer::pContext->Unmap(pParticleVertBuffer, 0);

		//UpdateConstantBuffer(pParticleVertBuffer, particles[0], sizeof(Particle) * particles.size());
		D_Renderer::pContext->IASetVertexBuffers(0, 1, &pParticleVertBuffer, &stride, &offset);

		int EDSIZE = sizeof(GO->GetEmitterComponent()->GetEmitterData());
		UpdateConstantBuffer(pParticleEmitterBuffer, GO->GetEmitterComponent()->GetEmitterData());

		//Bind to pipeline
		D_Renderer::pContext->VSSetConstantBuffers(0, 1, &ViewProjectionBuffer);
		D_Renderer::pContext->GSSetConstantBuffers(0, 1, &ViewProjectionBuffer);
		D_Renderer::pContext->VSSetConstantBuffers(2, 1, &pParticleEmitterBuffer);
		D_Renderer::pContext->GSSetConstantBuffers(2, 1, &pParticleEmitterBuffer);
		D_Renderer::pContext->PSSetConstantBuffers(2, 1, &pParticleEmitterBuffer);
	}
	size_t ConstantBuffers::cbUpdate_Bind_Text_Geom(GameObject * GO)
	{
		//Base
		const TEXT_VERT* textVerts = GO->GetTextComponent()->GetTextVerts();
		size_t textLen = GO->GetTextComponent()->GetText().size();
		if (textLen == 0)
			return textLen;

		//Update Vertex Buffer
		D3D11_MAPPED_SUBRESOURCE MappedResource;
		D_Renderer::pContext->Map(pTextVertBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &MappedResource);
		memcpy_s(MappedResource.pData, sizeof(TEXT_VERT) * textLen * 2, textVerts, sizeof(TEXT_VERT) * textLen * 2);
		D_Renderer::pContext->Unmap(pTextVertBuffer, 0);

		UINT offset = 0;
		UINT stride = sizeof(TEXT_VERT);
		D_Renderer::pContext->IASetVertexBuffers(0, 1, &pTextVertBuffer, &stride, &offset);


		TEXT_COLOR textColor = *GO->GetTextComponent()->GetTextColor();
		UpdateConstantBuffer(pTextColorBuffer, textColor);
		D_Renderer::pContext->PSSetConstantBuffers(0, 1, &pTextColorBuffer);
		return textLen;
	}
	void ConstantBuffers::cbUpdate_Bind_Point_Light(GameObject * GO)
	{
		//Update buffer
		UpdateConstantBuffer(pPointLightBuffer, GO->GetPointLightComponent()->PointLightData);

		//Update Object Data
		XMMATRIX WorldTransform = XMLoadFloat4x4(&GO->GetWorldTransform());
		XMFLOAT4X4 correctedPos;
		XMStoreFloat4x4(&correctedPos, WorldTransform);
		UpdateConstantBuffer(ObjectTransformBuffer, correctedPos);

		//Bind buffer
		D_Renderer::pContext->VSSetConstantBuffers(0, 1, &ObjectTransformBuffer);
		D_Renderer::pContext->VSSetConstantBuffers(1, 1, &ViewProjectionBuffer);
		D_Renderer::pContext->PSSetConstantBuffers(1, 1, &ViewProjectionBuffer);
		D_Renderer::pContext->PSSetConstantBuffers(2, 1, &pPointLightBuffer);
	}
	void ConstantBuffers::cbUpdate_Bind_Lum_Quad_Buffer()
	{
		D_Renderer::pContext->GSSetConstantBuffers(0, 1, &ViewProjectionBuffer);
	}
	void ConstantBuffers::cbUpdate_Bind_Emissive_Geom(GameObject * GO)
	{
		//TODO::
	}
	void ConstantBuffers::cbUpdate_Bind_Ghost_Color_Buffer(GameObject * GO)
	{
		UpdateConstantBuffer(pGhostColorBuffer, GO->GhostColor);
		D_Renderer::pContext->PSSetConstantBuffers(4, 1, &pGhostColorBuffer);
	}

	void ConstantBuffers::cbUpdate_Bind_Texture_Flag_Buffer(GameObject * GO)
	{
		if (GO->GetRendererComponent()->TextureFlags.ApplyNormals == true)
			int breakheretest = 0;

		XMFLOAT4 FlagFloat;
		FlagFloat.x = GO->GetRendererComponent()->TextureFlags.UseNormalTex;
		FlagFloat.y = GO->GetRendererComponent()->TextureFlags.UseSpecTex;
		FlagFloat.z = GO->GetRendererComponent()->TextureFlags.UseEmisTex;
		FlagFloat.w = GO->GetRendererComponent()->TextureFlags.ApplyNormals;

		UpdateConstantBuffer(pTextureFlagBuffer, FlagFloat);
		D_Renderer::pContext->PSSetConstantBuffers(0, 1, &pTextureFlagBuffer);
	}

	void ConstantBuffers::cbUpdate_Bind_Direction_Buffer(XMFLOAT2 Direction)
	{
		UpdateConstantBuffer(pBlurDirectionBuffer, Direction);
		D_Renderer::pContext->GSSetConstantBuffers(2, 1, &pBlurDirectionBuffer);
	}

#pragma endregion 
}

