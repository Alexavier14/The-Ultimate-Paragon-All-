#include "../Application/stdafx.h"
#pragma once
// Author : Daniel Stover

#define CURRENT_SAMPLE_COUNT 1
#define USING_MSAA 0

using namespace DirectX;

#include "../Util/Util.h"
#include "../Object Manager/ObjectManager.h"
#include "../Object Manager/GameObject.h"
#include "../Physics/PhysicsSystem.h"
#include "RenderContext.h"
#include "Camera.h"
#include <atlcomcli.h>


namespace Paragon_Renderer
{
	//Renderer Class
	class D_Renderer
	{
	public:
		//Base Directx Pointers
		static  CComPtr<ID3D11Device 			> pDevice;
		static  CComPtr<ID3D11DeviceContext 	> pContext;
		static  CComPtr<IDXGISwapChain 			> pSwapChain;
		static  CComPtr<ID3D11RenderTargetView 	> pRenderTargetView;
		static  CComPtr<ID3D11Texture2D 		> pBackBuffer;
		static  CComPtr<ID3D11Texture2D 		> pDepthStencilBuffer;
		static  CComPtr<ID3D11DepthStencilView  > pDepthStencilView;
		static  D3D11_VIEWPORT			 ScreenViewport;
		//static D3D11_VIEWPORT			 DiffuseViewport;
		//static D3D11_VIEWPORT			 NormalViewPort;
		//static D3D11_VIEWPORT			 SpecViewPort;
		//static D3D11_VIEWPORT			 DepthViewPort;

		static void Render(RenderContext * CurRC);

		D_Renderer();
		~D_Renderer();

		void Initialize(HWND hWnd, HINSTANCE hInstance, bool bIsWindowed);
		void ShutDown();

		void ResizeBuffers(unsigned int width, unsigned int height);
		void SetResolution(unsigned int width, unsigned int height,bool IsWindowed);

		static unsigned int GetSampleQuality();
		static unsigned int GetSamepleCount();
		static unsigned int GetScreenHeight();
		static unsigned int GetScreenWidth();
		static Camera *		GetMainCamera();
		static XMFLOAT4X4&  GetProjectionMatrix();

	private:
		static unsigned int ScreenHeight;
		static unsigned int ScreenWidth;
		static unsigned int SampleQuality;

		static Camera * MainCamera;
		static XMFLOAT4X4 ProjectionMatrix;

	};
}