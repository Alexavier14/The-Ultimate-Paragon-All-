#pragma once
#include <atlcomcli.h>

namespace Paragon_Renderer
{
	enum DSStates{DSS_Default = 0, DSS_LessEqual, DSS_NoDepth, DSS_Particle, DSS_AMOUNT};


	class DepthStencilStateManager
	{
	private:
		static CComPtr<ID3D11DepthStencilState> DepthStates[DSS_AMOUNT];

	public:
		static void ApplyState(DSStates state);
		static void Initialize();
		static void ShutDown();

		DepthStencilStateManager();
		~DepthStencilStateManager();
	};

}

