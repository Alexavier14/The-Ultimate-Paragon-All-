#pragma once
#include <atlcomcli.h>

namespace Paragon_Renderer
{
	enum InputLayoutType { IL_POS_UV_NORM, IL_POS_UV, IL_POS, IL_ANIMATION, IL_TEXT, IL_PARTICLES };

	class Shaders
	{
	private:
		//Shader Input Layouts
		static CComPtr<ID3D11InputLayout> p_Pos_UV_Norm_InputLayout;
		static CComPtr<ID3D11InputLayout> p_Pos_UV_InputLayout;
		static CComPtr<ID3D11InputLayout> p_Pos_InputLayout;
		static CComPtr<ID3D11InputLayout> p_Animation_InputLayout;
		static CComPtr<ID3D11InputLayout> p_Text_InputLayout;
		static CComPtr<ID3D11InputLayout> p_ParticleInputLayout;
		static CComPtr<ID3D11InputLayout> p_ScreenInputLayout;
		static CComPtr<ID3D11InputLayout> p_FullScreenQuadInputLayout;



		//Shaders
		static CComPtr<ID3D11PixelShader> BasicPixelShader;
		static CComPtr<ID3D11VertexShader> BasicVertexShader;
		static CComPtr<ID3D11PixelShader> GBufferPixelShader;
		static CComPtr<ID3D11PixelShader> pGhostPixelShader;
			   
		static CComPtr<ID3D11VertexShader> pAnimVertexShader;
			   
		static CComPtr<ID3D11PixelShader> HUD_PixelShader;
		static CComPtr<ID3D11VertexShader> HUD_VertexShader;
		static CComPtr<ID3D11GeometryShader> HUD_GeomShader;
			  
		static CComPtr<ID3D11PixelShader> EffectPixelShader;
		static CComPtr<ID3D11VertexShader> EffectVertexShader;
		static CComPtr<ID3D11GeometryShader> EffectGeomShader;
			  
		static CComPtr<ID3D11PixelShader> pCollisionPixelShader;
		static CComPtr<ID3D11VertexShader> pCollisionVertexShader;
 			   
		static CComPtr<ID3D11VertexShader> pTextVertexShader;
		static CComPtr<ID3D11GeometryShader> pTextGeomShader;
		static CComPtr<ID3D11PixelShader> pTextPixelShader;
			   
		static CComPtr<ID3D11PixelShader>    TeleGPixelShader;
		static CComPtr<ID3D11VertexShader>   TeleGVertexShader;
		static CComPtr<ID3D11GeometryShader> TeleGGeomShader;
			   
		static CComPtr<ID3D11VertexShader>		m_pParticleVertexShader;
		static CComPtr<ID3D11GeometryShader>	m_pParticleGeomShader;
		static CComPtr<ID3D11PixelShader>		m_pParticlePixelShader;
			  
		static CComPtr<ID3D11PixelShader> m_PointLightPixel;
		static CComPtr<ID3D11VertexShader> m_PointLightVertex;
		static CComPtr<ID3D11GeometryShader> m_FullScreenQuadGeomShader;
			  
		static CComPtr<ID3D11PixelShader> m_LumFirstPassPS;
		static CComPtr<ID3D11PixelShader> m_LumThreeByThreePS;
		static CComPtr<ID3D11PixelShader> m_LumFinalPassPS;
			  
		static CComPtr<ID3D11PixelShader> m_AmbLightPS;

		static CComPtr<ID3D11PixelShader> m_GlowVerticalBlend;
		static CComPtr<ID3D11PixelShader> m_GlowHorizontalBlend;
		static CComPtr<ID3D11PixelShader> m_ApplyGlowPS;

			   
		static CComPtr<ID3D11VertexShader> m_FullScreenVertexShader;
		static CComPtr<ID3D11GeometryShader> m_FullScreenBlurShaderGS;


	public:

		Shaders();
		~Shaders();

		static void Initialize();
		static void Shutdown();
		ID3D11InputLayout * GetInputLayout(InputLayoutType Type);

		//Set Shader Calls
		static void Bind_Apply_Glow_Shaders();
		static void Bind_Horizontal_Glow_Shaders();
		static void Bind_Vertical_Glow_Shaders();
		static void Bind_HUD_Shaders();
		static void Bind_Billboard_Shaders();
		static void Bind_Text_Shaders();
		static void Bind_Telegraph_Shaders();
		static void Bind_Animation_VertexShader();
		static void Bind_Ghost_Anim_Pass();
		static void Bind_Ghost_Static_Pass();
		static void Bind_StaticGeom_Shader();
		static void Bind_Particle_Shaders();
		static void Bind_PointLight_Shaders();
		static void Bind_Lum_First_Pass();
		static void Bind_Lum_Second_Pass();
		static void Bind_Lum_Final_Pass();
		static void Bind_Amb_Light_Pass();
	};
}