#include "../Application/stdafx.h"
#include "../Particle System/EmitterData.h"
#pragma once

namespace Paragon_Renderer
{
	class ConstantBuffers
	{
	private:
		ConstantBuffers();
		~ConstantBuffers();
		static ConstantBuffers * pInstance;

		//Buffers
		ID3D11Buffer * ObjectTransformBuffer;
		ID3D11Buffer * ViewProjectionBuffer;
		ID3D11Buffer * HUDQuadDataBuffer;
		ID3D11Buffer * EffectDataBuffer;

		ID3D11Buffer * pTextVertBuffer;
		ID3D11Buffer * pTextColorBuffer;
		ID3D11Buffer * pAnimBuffer;
		ID3D11Buffer * pTelegraphBuffer;
		ID3D11Buffer * pPointLightBuffer;
		ID3D11Buffer * pParticleEmitterBuffer;
		ID3D11Buffer * pReactionEffectBuffer; 
		ID3D11Buffer * pScreenDataBuffer;
		//ID3D11Buffer * FullScreenQuadVertBuffer;
		ID3D11Buffer * pGhostColorBuffer;
		ID3D11Buffer * pTextureFlagBuffer;
		ID3D11Buffer * pBlurDirectionBuffer;


		//Vertex buffer for particles - TODO:: Try and find another way to do this. 
		ID3D11Buffer * pParticleVertBuffer;
		//ID3D11Buffer * pCollisionVertBuffer;
		//ID3D11Buffer * pCollisionColorBuffer;

	public:
		static ConstantBuffers *GetInstance();
		static void Shutdown();
		void Initialize();

		template<class TYPE>
		static void UpdateConstantBuffer(ID3D11Buffer * ConstantBuffer, const TYPE& data);

		template<class TYPE>
		static void UpdateConstantBuffer(ID3D11Buffer * ConstantBuffer, const TYPE& data, UINT Size);

		template<class TYPE>
		static void CreateConstantBuffer(ID3D11Buffer ** ConstantBuffer, TYPE * data);

		template<class TYPE>
		static void CreateConstantBuffer(ID3D11Buffer ** ConstantBuffer, TYPE * data, UINT ObjectCount);

		//Update and Bind Functions
		void cbUpdate_Camera_Proj();
		void cbUpdate_Screen_Quad_Buffer(unsigned int ScreenWidth, unsigned int ScreenHeight);
		void cbBind_Screen_Buffer(int slot);
		void cbBind_Geom_Screen_Buffer(int slot);
		void cbUpdate_Bind_Static_Geom(GameObject * GO);
		void cbUpdate_Bind_Animated_Geom(GameObject * GO);
		void cbUpdate_Bind_Telegraph_Geom(GameObject * GO);
		void cbUpdate_Bind_HUD_Geom(GameObject * GO);
		void cbUpdate_Bind_Effect_Geom(GameObject * GO);
		void cbUpdate_Bind_Particle_Geom(GameObject * GO);
		void cbUpdate_Bind_Point_Light(GameObject * GO);
		void cbUpdate_Bind_Emissive_Geom(GameObject * GO);
		void cbUpdate_Bind_Lum_Quad_Buffer();
		void cbUpdate_Bind_Ghost_Color_Buffer(GameObject * GO);
		void cbUpdate_Bind_Texture_Flag_Buffer(GameObject * GO);
		void cbUpdate_Bind_Direction_Buffer(XMFLOAT2 Direction);
		size_t cbUpdate_Bind_Text_Geom(GameObject * GO);
	};


	//---Structs to be used to update the constant buffers
	//Per Object Transform Buffer
	struct ScreenQuadVert
	{
		XMFLOAT2 Position;
		XMFLOAT2 UV;
	};

	struct cbSCREEN
	{
		float width;
		float height;
	};

	struct cbOBJECT
	{
		XMFLOAT4X4 world;
	};

	//View and Projection matrices and camera Position
	struct cbSCENE
	{
		XMFLOAT4X4 View;
		XMFLOAT4X4 Proj;
		XMFLOAT4X4 CameraPos;
		XMFLOAT4X4 InvViewProj;
	};

	//Object Animation Data
	struct cbANIM_DATA
	{
		XMFLOAT4X4 joints[100];
	};

	//Lighting Data - 
	struct cbPOINT_LIGHT
	{
		XMFLOAT4 position;
		XMFLOAT3 diffuseColor;
		float specularIntensity;
		XMFLOAT3 ambientColor;
		float range;
		XMFLOAT3 specularColor;
		float specularPower;
		XMFLOAT3 attenuation;
		float isTorch;
	};

	struct cbHUD_DATA
	{
		float width;
		float height;
		float PosX;
		float PosY;
	};

	struct cbEFFECT_DATA
	{
		XMFLOAT4 Position;
		XMFLOAT2 Size;
	};

	struct cbTELEGRAPH
	{
		XMFLOAT2 Position;
		XMFLOAT2 ForwardVec;
		XMFLOAT3 Color;
		float Radius;
		XMFLOAT2 Scale;
		float Angle;
		float PercentComplete;
		unsigned int Type;
		XMFLOAT3 Padding;
	};

	struct cbGHOSTCOLOR
	{
		XMFLOAT4 GhostColor;
	};

	struct cbTEXTUREFLAGS
	{
		bool UseNormalTex;
		bool UseSpecTex;
		bool UseEmisTex;
		bool ApplyNormals;
	};
}
