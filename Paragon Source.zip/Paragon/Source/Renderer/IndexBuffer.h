#pragma once

// Class will be used as an index buffer for all of the geometry added to any one of the given vertex buffers
// Only one index buffer will be created per renderer 
// Can be a singleton? 

class IndexBuffer
{
public:
	IndexBuffer();
	~IndexBuffer();
};

