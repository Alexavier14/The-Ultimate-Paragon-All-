#include "../Application/stdafx.h"
//
//// Author      : Daniel Stover
//// Last Edited : 8/15/2014
//
//#pragma once
//
////Include DX files
//
////DXLib
//
//using namespace DirectX;
//
//#include "../Object Manager/ObjectManager.h"
//#include "../Object Manager/GameObject.h"
//#include "../Physics/PhysicsSystem.h"
//#include "Camera.h"
//
////Macro to clean up com objects
//#define ReleaseCOM(x) { if(x){ x->Release(); x = 0; } }
//
//class Renderer
//{
//private:
//	//Base DirectX
//	ID3D11DeviceContext * pContext;
//	IDXGISwapChain * pSwapChain;
//	ID3D11RenderTargetView * pRenderTargetView;
//	ID3D11Texture2D * pBackBuffer;
//	ID3D11Texture2D * pDepthStencilBuffer;
//	ID3D11DepthStencilView  * pDepthStencilView;
//	D3D11_VIEWPORT ScreenViewport;
//	ID3D11InputLayout * pInputLayout;
//	ID3D11InputLayout * pHUDInputLayout;
//	ID3D11InputLayout * pCollisionInputLayout;
//	ID3D11InputLayout * pTextInputLayout;
//	ID3D11InputLayout * pAnimInputLayout;
//	ID3D11InputLayout *	m_pParticleInputLayout;
//
//
//
//	//Buffers
//	ID3D11Buffer * ObjectTransformBuffer;
//	ID3D11Buffer * ViewProjectionBuffer;
//	ID3D11Buffer * HUDQuadDataBuffer;
//	ID3D11Buffer * EffectDataBuffer;
//	ID3D11Buffer * pCollisionVertBuffer;
//	ID3D11Buffer * pCollisionColorBuffer;
//	ID3D11Buffer * pTextVertBuffer;
//	ID3D11Buffer * pTextColorBuffer;
//	ID3D11Buffer * pAnimBuffer;
//	ID3D11Buffer * pReactionEffectBuffer;
//	ID3D11Buffer * pTelegraphBuffer;
//	ID3D11Buffer * DirectionalLightBuffer;
//	ID3D11Buffer *	m_pParticleVertBuffer;
//	ID3D11Buffer *	m_pParticleEmitterBuffer;
//
//	//3D particle stuff	
//	//ID3D11Buffer *	m_p3DParticleEmitterBuffer;
//	//ID3D11ShaderResourceView * m_pParticleEmitterSRV;
//	//ID3D11VertexShader * m_pParticle3DVertexShader;
//
//	//Shaders
//	ID3D11PixelShader * BasicPixelShader;
//	ID3D11VertexShader * BasicVertexShader;
//	ID3D11PixelShader * HUD_PixelShader;
//	ID3D11VertexShader * HUD_VertexShader;
//	ID3D11GeometryShader * HUD_GeomShader;
//	ID3D11PixelShader * EffectPixelShader;
//	ID3D11VertexShader * EffectVertexShader;
//	ID3D11GeometryShader * EffectGeomShader;
//	ID3D11PixelShader * pCollisionPixelShader;
//	ID3D11VertexShader * pCollisionVertexShader;
//	ID3D11VertexShader * pTextVertexShader;
//	ID3D11GeometryShader * pTextGeomShader;
//	ID3D11PixelShader * pTextPixelShader;
//	ID3D11VertexShader * pAnimVertexShader;
//	ID3D11VertexShader *	m_pParticleVertexShader;
//	ID3D11GeometryShader *	m_pParticleGeomShader;
//	ID3D11PixelShader *		m_pParticlePixelShader;
//	ID3D11PixelShader *    TeleGPixelShader;
//	ID3D11VertexShader *   TeleGVertexShader;
//	ID3D11GeometryShader * TeleGGeomShader;
//
//	//Sample State
//	ID3D11SamplerState * pSamplerState;
//
//	//BlendState
//	ID3D11BlendState * pBlendState;
//
//	// No Depth testing state
//	ID3D11DepthStencilState* pDepthStateNoZ;
//	ID3D11DepthStencilState * m_pParticleDepthStencilState;
//
//
//	//Screen Size
//	unsigned int CurrentScreenHeight;
//	unsigned int CurrentScreenWidth;
//
//	unsigned int CurrentScreenResWidth;
//	unsigned int CurrentScreenResHeight;
//
//	bool IsFullScreen;
//
//	Camera * MainCamera;
//	XMFLOAT4X4 ProjectionMatrix;
//
//	//World Marix Storage
//	struct OBJECT
//	{
//		XMFLOAT4X4 world;
//	};
//
//	//View and Projection Matrix Storage
//	struct SCENE
//	{
//		XMFLOAT4X4 view;
//		XMFLOAT4X4 proj;
//		XMFLOAT4X4 InvViewProj;
//	};
//
//	struct HUD_DATA
//	{
//		float width;
//		float height;
//		float PosX;
//		float PosY;
//	};
//
//	struct EFFECT_DATA
//	{
//		XMFLOAT4 Position;
//		XMFLOAT2 Size;
//	};
//
//	struct TELEGRAPH
//	{
//		float PercentComplete;
//		float IsFear;
//
//		XMFLOAT2 Position;
//		XMFLOAT2 Scale;
//
//		XMFLOAT3 Color1;
//		XMFLOAT3 Color2;
//		XMFLOAT3 Color3;
//	};
//
//	struct DIR_LIGHT
//	{
//		XMFLOAT4 lightPos;
//		XMFLOAT4 lightColor;
//	};
//		
//	struct ANIM_DATA
//	{
//		XMFLOAT4X4 joints[100];
//	};
//
//public:
//	struct SPHERE
//	{
//		std::vector<int> Indicies;
//		std::vector<XMFLOAT3> Verts;
//	};
//
//	ID3D11Device * pDevice;
//	bool Initialize(HWND hWnd, HINSTANCE hInstance, int nWidth, int nHeight, bool bIsWindowed);
//
//	void Shutdown();
//	void Update(CoreFacade* pCoreFacade);
//	void ToggleFullScreen(HWND hWnd);
//	XMFLOAT4X4 & GetViewMatrix() const;
//	XMFLOAT4X4 GetProjectionMatrix();
//
//	ID3D11Device* GetRenderDevice();
//	ID3D11DeviceContext* GetRenderDeviceContext();
//
//	template<class TYPE>
//	void UpdateConstantBuffer(ID3D11Buffer * ConstantBuffer, TYPE data);
//
//	template<class TYPE>
//	void CreateConstantBuffer(ID3D11Buffer ** ConstantBuffer, TYPE * data);
//
//	//void SetCameraFollowObject(GameObject* Player);
//	Renderer();
//	~Renderer();
//};
//
