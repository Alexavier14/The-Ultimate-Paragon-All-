#include "../Application/stdafx.h"
#include "RenderTarget.h"
#include "D_Renderer.h"
#include <string>
using namespace std;


namespace Paragon_Renderer
{
	RenderTarget::RenderTarget()
	{
		this->DepthStencilBuffer = nullptr; 
		this->DepthStencilView = nullptr; 
		this->ActiveTarget = nullptr; 
	}
	RenderTargetSurface::RenderTargetSurface()
	{ 
		this->SRV = nullptr; 
		this->RTV = nullptr; 
		Height = 0; 
		Width = 0; 
		CurrentTexture = nullptr;
	}

	RenderTarget::~RenderTarget(){}
	RenderTargetSurface::~RenderTargetSurface(){}

	//Render Target Surface Functions

	void RenderTargetSurface::Create(UINT width, UINT height, const char * name, DXGI_FORMAT format)
	{
		Shutdown();

		this->Width = width;
		this->Height = height;
		
		RTSName = name;

		D3D11_TEXTURE2D_DESC tDesc;
		ZeroMemory(&tDesc, sizeof(tDesc));
		tDesc.Width = (UINT)width;
		tDesc.Height = (UINT)height;
		tDesc.MipLevels = 1;
		tDesc.ArraySize = 1;
		tDesc.Format = format;
		tDesc.SampleDesc.Count = D_Renderer::GetSamepleCount();
		tDesc.SampleDesc.Quality = D_Renderer::GetSampleQuality();
		tDesc.Usage = D3D11_USAGE_DEFAULT;
		tDesc.BindFlags = D3D11_BIND_RENDER_TARGET | D3D11_BIND_SHADER_RESOURCE;
		tDesc.CPUAccessFlags = 0;
		tDesc.MiscFlags = 0;

		D_Renderer::pDevice->CreateTexture2D(&tDesc, NULL, (ID3D11Texture2D **)&CurrentTexture);
		SetD3DName(CurrentTexture, name);
	}
	void RenderTargetSurface::Shutdown()
	{
		SRV.Release();
		RTV.Release();
		CurrentTexture.Release();
	}
	CComPtr<ID3D11Resource> RenderTargetSurface::GetTextutre()
	{
		return CurrentTexture;
	}
	CComPtr<ID3D11RenderTargetView> RenderTargetSurface::GetRenderTargetView()
	{
		//Check to see if we have an RTV. If not, create one.
		if (RTV == nullptr)
		{
			D_Renderer::pDevice->CreateRenderTargetView(CurrentTexture, 0, &RTV);
			string NameUpdate = RTSName + " RTV";
			SetD3DName(RTV, NameUpdate.c_str());
		}
		return RTV;
	}
	CComPtr<ID3D11ShaderResourceView> RenderTargetSurface::GetSRV()
	{
		//Check to see if we have an SRV. IF not, create one
		if (SRV == nullptr)
		{
			//D3D11_SHADER_RESOURCE_VIEW_DESC SRV_DESC;
			//SRV_DESC.ViewDimension = D3D11_DSV_DIMENSION_TEXTURE2DMS;
			D_Renderer::pDevice->CreateShaderResourceView(CurrentTexture, 0, &SRV);
		}
		return SRV;
	}
	UINT RenderTargetSurface::GetHeight()
	{
		return Height;
	}
	UINT RenderTargetSurface::GetWidth()
	{
		return Width;
	}

	//Render Target Functions
	void RenderTarget::Create(UINT width, UINT height, DXGI_FORMAT format, string RTName)
	{
		//if (this != nullptr)
		Shutdown();

		//Text Desc for Z-Buffer
		D3D11_TEXTURE2D_DESC tDesc;
		ZeroMemory(&tDesc, sizeof(tDesc));
		tDesc.Width = width;
		tDesc.Height = height;
		tDesc.MipLevels = 1;
		tDesc.ArraySize = 1;
		tDesc.Format = format;
#if USING_MSAA == 1
		tDesc.SampleDesc.Count = CURRENT_SAMPLE_COUNT;
		tDesc.SampleDesc.Quality = D_Renderer::GetSampleQuality();
#else
		tDesc.SampleDesc.Count = 1;
		tDesc.SampleDesc.Quality = 0;
#endif
		tDesc.Usage = D3D11_USAGE_DEFAULT;
		tDesc.BindFlags = D3D11_BIND_DEPTH_STENCIL;
		tDesc.CPUAccessFlags = 0;
		tDesc.MiscFlags = 0;

		string ObjectName = RTName;
		D_Renderer::pDevice->CreateTexture2D(&tDesc, NULL, &DepthStencilBuffer);
		SetD3DName(DepthStencilBuffer, "Depth Stencil View");

		D3D11_DEPTH_STENCIL_VIEW_DESC descDSV;
		ZeroMemory(&descDSV, sizeof(descDSV));
		descDSV.Format = format;
#if USING_MSAA == 1
		descDSV.ViewDimension = D3D11_DSV_DIMENSION_TEXTURE2DMS;
#else 
		descDSV.ViewDimension = D3D11_DSV_DIMENSION_TEXTURE2D;
#endif
		descDSV.Texture2D.MipSlice = 0;

		D_Renderer::pDevice->CreateDepthStencilView(DepthStencilBuffer, &descDSV, &DepthStencilView);
		ObjectName += " Depth Stencil Buffer";
		SetD3DName(DepthStencilView, ObjectName.c_str());
	}

	//void RenderTarget::Create(ID3D11DepthStencilView * DSV, ID3D11Texture2D * DSBuffer)
	//{
	//	DepthStencilView = DSV;
	//	DepthStencilBuffer = DSBuffer;
	//}

	void RenderTarget::Shutdown()
	{
		for (unsigned int i = 0; i < RenderTargets.size(); i++)
		{
			RenderTargets[i]->Shutdown();
			RenderTargets[i] = nullptr;
		}
		DepthStencilView.Release();
		DepthStencilBuffer.Release();
		DepthBufferSRV.Release();
		ActiveTarget = nullptr;
	}
	CComPtr<ID3D11ShaderResourceView> RenderTarget::GetDepthSRV()
	{
		if (DepthBufferSRV == nullptr)
		{
			D_Renderer::pDevice->CreateShaderResourceView(DepthStencilBuffer, 0, &DepthBufferSRV);
		}
		return DepthBufferSRV;
	}
	void RenderTarget::AddTarget(RenderTargetSurface* RTS)
	{
		RenderTargets.push_back(RTS);
	}
	RenderTargetSurface* RenderTarget::GetRenderTargetSurface(int index)
	{
		return RenderTargets[index];
	}
	void RenderTarget::CreateRenderTarget(UINT Width, UINT Height, DXGI_FORMAT format, const char * name)
	{
		RenderTargetSurface * NewSurface = new RenderTargetSurface;
		NewSurface->Create(Width, Height, name, format);
		RenderTargets.push_back(NewSurface);
	}
	void RenderTarget::ClearRenderTargetView(float ClearColor[4])
	{
		for (size_t i = 0; i < RenderTargets.size(); i++)
		{
			D_Renderer::pContext->ClearRenderTargetView(RenderTargets[i]->GetRenderTargetView(), ClearColor);
		}
	}
	void RenderTarget::ClearDepthStencilView(UINT clearFlags, float depth)
	{
		D_Renderer::pContext->ClearDepthStencilView(DepthStencilView, D3D11_CLEAR_DEPTH, depth, 0);
	}
	void RenderTarget::ActivateRenderTarget(RenderTargetSurface * RTS)
	{
		//ActiveTarget = RenderTargets[index];
		ID3D11RenderTargetView * RTV = RTS->GetRenderTargetView();
		D_Renderer::pContext->OMSetRenderTargets(1, &RTV, this->DepthStencilView);
	}
	void RenderTarget::ActivateRenderTargets()
	{
		ID3D11RenderTargetView * RTV_Arr[D3D11_SIMULTANEOUS_RENDER_TARGET_COUNT];
		UINT count = 0;
		for (auto iter = RenderTargets.begin(); iter != RenderTargets.end(); iter++)
		{
			RTV_Arr[count] = (*iter)->GetRenderTargetView();
			count++;
		}
		D_Renderer::pContext->OMSetRenderTargets(count, RTV_Arr, this->DepthStencilView);
	}

	void RenderTarget::ActivateRenderTargets(ID3D11DepthStencilView * DSV)
	{
		ID3D11RenderTargetView * RTV_Arr[D3D11_SIMULTANEOUS_RENDER_TARGET_COUNT];
		UINT count = 0;
		for (auto iter = RenderTargets.begin(); iter != RenderTargets.end(); iter++)
		{
			RTV_Arr[count] = (*iter)->GetRenderTargetView();
			count++;
		}
		D_Renderer::pContext->OMSetRenderTargets(count, RTV_Arr, DSV);
	}
}