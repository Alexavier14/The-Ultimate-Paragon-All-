#include "../Application/stdafx.h"
#include "GraphicsDebugEvent.h"
#include <d3d11_1.h>
#include "D_Renderer.h"

GraphicsDebugEvent::GraphicsDebugEvent()
{
	pPerf = NULL;
	HRESULT hr = Paragon_Renderer::D_Renderer::pContext->QueryInterface( __uuidof(pPerf), reinterpret_cast<void**>(&pPerf) );
	if(FAILED(hr))
		pPerf = NULL;
}


GraphicsDebugEvent::~GraphicsDebugEvent()
{
	if(pPerf)
		pPerf->EndEvent();
	ReleaseCOM(pPerf);
}

void GraphicsDebugEvent::MarkEventCall(wstring eventName)
{
	if(pPerf)
		pPerf->BeginEvent(eventName.c_str());
}

void GraphicsDebugEvent::MarkEventCall(string eventName)
{
	MarkEventCall( to_wstring( eventName ) );
}

