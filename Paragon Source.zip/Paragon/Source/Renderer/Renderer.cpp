#include "../Application/stdafx.h"
//
//// Author      : Daniel Stover
//// Last Edited : 8/15/2014
//#include "Renderer.h"
//#include "../Application/CoreFacade.h"
//#include "../Object Manager/RendererComponent.h"
//#include "../Object Manager/AnimComponent.h"
//#include "../Text Manager/Font.h"
//#include "../Text Manager/TextBox.h"
//#include "../Physics/Physics.h"
//#include "../Particle System/ParticleSystem.h"
//
//#pragma region Shader Includes
//#include "../../Shaders/VertexShader.csh"
////#include "../../Shaders/PixelShader.csh"
//#include "../../Shaders/HUDGeometryShader.csh"
//#include "../../Shaders/HUDVertexShader.csh"\
////#include "../../Shaders/HUDPixelShader.csh"
//#include "../../Shaders/EffectBillboardGeomShader.csh"
//#include "../../Shaders/EffectBillboardPixelShader.csh"
//#include "../../Shaders/EffectBillboardVertexShader.csh"
//#include "../../Shaders/CirclePixelShader.csh"
//#include "../../Shaders/CircleVertexShader.csh"
//#include "../../Shaders/TextVertexShader.csh"
//#include "../../Shaders/TextGeometryShader.csh"
//#include "../../Shaders/TextPixelShader.csh"
//#include "../../Shaders/AnimationVertexShader.csh"
//#include "../../Shaders/TelegraphVertexShader.csh"
//#include "../../Shaders/TelegraphPixelShader.csh"
//#include "../../Shaders/TelegraphGeometryShader.csh"
//#include "../../Shaders/ParticleVertexShader.csh"
//#include "../../Shaders/ParticlePixelShader.csh"
//#include "../../Shaders/ParticleGeometryShader.csh"
//#pragma endregion
//
//#ifdef _DEBUG
//#define RENDER_CIRCLE_COL_SHAPES
//#define SHOW_BOUNDING_ONLY
//#define RENDER_BOX_COL_SHAPES
//#define RENDER_SEGMENT_COL_SHAPES
//#else
////#define RENDER_CIRCLE_COL_SHAPES
////#define RENDER_BOX_COL_SHAPES
////#define RENDER_SEGMENT_COL_SHAPES
//#endif
//
//#define CURRENT_SAMPLE_COUNT 8
//
//void SetDisplayMode(int iWidth, int iHeight);
//
//Renderer::Renderer(){}
//Renderer::~Renderer(){}
//void Renderer::ToggleFullScreen(HWND hWnd)
//{
//	static WINDOWPLACEMENT wp = { 0 };
//	if (IsFullScreen == true)
//	{
//		// Remember the window position.
//		wp.length = sizeof(WINDOWPLACEMENT);
//		GetWindowPlacement(hWnd, &wp);
//		// Remove the window's title bar.
//		SetWindowLongPtr(hWnd, GWL_STYLE, WS_POPUP);
//
//		// Put the changes to the window into effect.
//		SetWindowPos(hWnd, 0, 0, 0, 0, 0,
//			SWP_FRAMECHANGED | SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER);
//
//		// Switch to the requested display mode.
//#if SCREEN_RES_TEST_MACHINE == 1
//		SetDisplayMode(1024, 768);
//#else
//		SetDisplayMode(CurrentScreenWidth, CurrentScreenHeight);
//#endif
//
//		// Position the window to cover the entire screen.
//		SetWindowPos(hWnd, HWND_TOPMOST, 0, 0,GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN),	SWP_SHOWWINDOW);
//
//		// Remove the cursor.
//		// ShowCursor(FALSE);
//
//	}
//	else
//	{
//		// Restore the window's title bar.
//		SetWindowLongPtr(hWnd, GWL_STYLE, WS_OVERLAPPEDWINDOW & (~WS_THICKFRAME) & (~WS_MAXIMIZEBOX));
//		// Put the changes to the window into effect.
//		SetWindowPos(hWnd, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_FRAMECHANGED | SWP_NOMOVE | SWP_NOSIZE);
//		// Restore the display mode.
//		SetDisplayMode(0, 0);
//		// Restore the window's original position.
//		SetWindowPlacement(hWnd, &wp);
//		// Restore the cursor.
//		ShowCursor(TRUE);
//
//	}
//}
//
//bool Renderer::Initialize(HWND hWnd, HINSTANCE hInstance, int nWidth, int nHeight, bool bIsWindowed)
//{
//	CurrentScreenResWidth = 1024;
//	CurrentScreenResHeight = 768;
//
//	CurrentScreenHeight = nHeight;
//	CurrentScreenWidth = nWidth;
//
//	IsFullScreen = !bIsWindowed;
//
//	// Data to create Dev and SwapChain
//	const D3D_FEATURE_LEVEL FlagEleven = D3D_FEATURE_LEVEL_11_0;
//	const D3D_FEATURE_LEVEL FL = D3D_FEATURE_LEVEL_10_1;
//	D3D11_CREATE_DEVICE_FLAG flag;
//
//#if _DEBUG
//	flag = D3D11_CREATE_DEVICE_DEBUG;
//#else 
//	flag = D3D11_CREATE_DEVICE_SINGLETHREADED;
//#endif
//
//	DXGI_SWAP_CHAIN_DESC SC;
//	ZeroMemory(&SC, sizeof(SC));
//	SC.BufferCount = 1;
//	SC.BufferDesc.Width = (UINT)CurrentScreenWidth;
//	SC.BufferDesc.Height = (UINT)CurrentScreenHeight;
//	SC.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
//	SC.BufferDesc.RefreshRate.Numerator = 60;
//	SC.BufferDesc.RefreshRate.Denominator = 1;
//	SC.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
//	SC.OutputWindow = hWnd;
//	SC.SampleDesc.Count = 1;
//	SC.SampleDesc.Quality = 0;
//	SC.Windowed = TRUE;
//
//	D3D_FEATURE_LEVEL pFeatureLevel;
//
//	// Data to create Dev and SwapChain
//	D3D11CreateDeviceAndSwapChain(
//		NULL,
//		D3D_DRIVER_TYPE_HARDWARE,
//		0,
//		flag,
//		&FlagEleven,
//		1,
//		D3D11_SDK_VERSION,
//		&SC,
//		&pSwapChain,
//		&pDevice,
//		&pFeatureLevel,
//		&pContext);
//
//	UINT Samp_Count = CURRENT_SAMPLE_COUNT;
//	UINT QualityLevel = 0;
//	pDevice->CheckMultisampleQualityLevels(DXGI_FORMAT_R8G8B8A8_UNORM, Samp_Count, &QualityLevel);
//
//	//Update the quality levels
//	if (QualityLevel > 0)
//		--QualityLevel;
//	SC.SampleDesc.Count = Samp_Count;
//	SC.SampleDesc.Quality = QualityLevel;
//
//	//Release device and swapchain to create another
//	ReleaseCOM(pDevice);
//	ReleaseCOM(pContext);
//	ReleaseCOM(pSwapChain);
//
//	//Recreate Device and swapchain with the new quality levels
//	D3D11CreateDeviceAndSwapChain(
//		NULL,
//		D3D_DRIVER_TYPE_HARDWARE,
//		0,
//		flag,
//		&FL,
//		1,
//		D3D11_SDK_VERSION,
//		&SC,
//		&pSwapChain,
//		&pDevice,
//		&pFeatureLevel,
//		&pContext);
//
//	//Get the Back Buffer
//	pSwapChain->GetBuffer(0, __uuidof(pBackBuffer), reinterpret_cast<void**>(&pBackBuffer));
//
//	//Create the render target
//	pDevice->CreateRenderTargetView(pBackBuffer, NULL, &pRenderTargetView);
//
//	// Create the Z-Buffer Texture and the Depth Stencil View
//	//Text Desc for Z-Buffer
//	D3D11_TEXTURE2D_DESC tDesc;
//	ZeroMemory(&tDesc, sizeof(tDesc));
//	tDesc.Width = (UINT)nWidth;
//	tDesc.Height = (UINT)nHeight;
//	tDesc.MipLevels = 1;
//	tDesc.ArraySize = 1;
//	tDesc.Format = DXGI_FORMAT_D32_FLOAT_S8X24_UINT;
//	tDesc.SampleDesc.Count = Samp_Count;
//	tDesc.SampleDesc.Quality = QualityLevel;
//	tDesc.Usage = D3D11_USAGE_DEFAULT;
//	tDesc.BindFlags = D3D11_BIND_DEPTH_STENCIL;
//	tDesc.CPUAccessFlags = 0;
//	tDesc.MiscFlags = 0;
//
//	// Create the ZBuffer - 
//	pDevice->CreateTexture2D(&tDesc, NULL, &pDepthStencilBuffer);
//
//	D3D11_DEPTH_STENCIL_VIEW_DESC descDSV;
//	ZeroMemory(&descDSV, sizeof(descDSV));
//	descDSV.Format = DXGI_FORMAT_D32_FLOAT_S8X24_UINT;
//	descDSV.Texture2D.MipSlice = 0;
//
//#if USING_MSAA == 1
//	descDSV.ViewDimension = D3D11_DSV_DIMENSION_TEXTURE2DMS;
//#else
//	descDSV.ViewDimension = D3D11_DSV_DIMENSION_TEXTURE2D;
//#endif
//
//
//	pDevice->CreateDepthStencilView(pDepthStencilBuffer, &descDSV, &pDepthStencilView);
//
//	// Create the Sampler State to Render Textures
//
//	//Sample Desc
//	D3D11_SAMPLER_DESC Samp_Desc;
//	ZeroMemory(&Samp_Desc, sizeof(Samp_Desc));
//	Samp_Desc.MinLOD = 0;
//	Samp_Desc.MaxLOD = D3D11_FLOAT32_MAX;
//	Samp_Desc.AddressU = D3D11_TEXTURE_ADDRESS_WRAP;
//	Samp_Desc.AddressV = D3D11_TEXTURE_ADDRESS_WRAP;
//	Samp_Desc.AddressW = D3D11_TEXTURE_ADDRESS_WRAP;
//	Samp_Desc.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
//	Samp_Desc.ComparisonFunc = D3D11_COMPARISON_NEVER;
//
//	//Texure Sampler
//	//Device->CreateSamplerState(&Samp_Desc,&pSamplerState)
//
//	//Camera Matrix
//	MainCamera = new Camera();
//	MainCamera->Initialize();
//
//	//Projection Matrix
//	XMMATRIX matProjection = XMMatrixPerspectiveFovLH(XMConvertToRadians(45), (float)(nWidth / nHeight), 0.1f, 1000.0f);
//	XMStoreFloat4x4(&ProjectionMatrix, matProjection);
//
//	// --- Create Const Buffers
//	//Temp Effect
//	EFFECT_DATA EData;
//	EData.Position = XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f);
//	EData.Size = XMFLOAT2(1.0f, 1.0f);
//	CreateConstantBuffer(&EffectDataBuffer, &EData);
//
//	//Temp HUD
//	HUD_DATA HudD;
//	HudD.height = 5.0f;
//	HudD.width = 5.0f;
//	HudD.PosX = 0.0f;
//	HudD.PosY = 0.0f;
//	CreateConstantBuffer(&HUDQuadDataBuffer, &HudD);
//
//	//Temp World
//	OBJECT sW;
//	XMMATRIX tempWorld = XMMatrixIdentity();
//	XMStoreFloat4x4(&sW.world, tempWorld);
//	CreateConstantBuffer(&ObjectTransformBuffer, &sW);
//
//	//Temp VP Matrix
//	SCENE sPV;
//	sPV.proj = ProjectionMatrix;
//	sPV.view = MainCamera->GetRendererViewMat();
//	CreateConstantBuffer(&ViewProjectionBuffer, &sPV);
//
//	//Temp Tele
//	TELEGRAPH Tele;
//	Tele.Color1 = XMFLOAT3(1.0f, 1.0f, 1.0f);
//	Tele.Color2 = XMFLOAT3(1.0f, 1.0f, 1.0f);
//	Tele.Color3 = XMFLOAT3(1.0f, 1.0f, 1.0f);
//	Tele.IsFear = 1.0f;
//	Tele.PercentComplete = 0.1f; 
//	Tele.Position = XMFLOAT2(1.0f, 1.0f);
//	Tele.Scale = XMFLOAT2(1.0f, 1.0f);
//	CreateConstantBuffer(&pTelegraphBuffer, &Tele);
//
//	//Temp Animation
//	ANIM_DATA anim;
//	CreateConstantBuffer(&pAnimBuffer, &anim);
//
//	//Dir Light
//	DIR_LIGHT DirectionalLight;
//	DirectionalLight.lightColor = XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f);
//	DirectionalLight.lightPos = MainCamera->GetCameraPos();
//	CreateConstantBuffer(&DirectionalLightBuffer, &DirectionalLight);
//
//
//	//Create constant buffer for circle verts
//	XMFLOAT3 Circle[360];
//	for (unsigned int i = 0; i < 360; i++)
//	{
//		Circle[i].x = 1.0f;
//		Circle[i].z = 1.0f;
//		Circle[i].y = 1.0f;
//	}
//	//Create the constant buffer for the proj and view matrices
//	D3D11_BUFFER_DESC Col_Buffer_Dest;
//	ZeroMemory(&Col_Buffer_Dest, sizeof(Col_Buffer_Dest));
//	Col_Buffer_Dest.ByteWidth = sizeof(XMFLOAT3) * 360;
//	Col_Buffer_Dest.Usage = D3D11_USAGE_DYNAMIC;
//	Col_Buffer_Dest.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
//	Col_Buffer_Dest.BindFlags = D3D11_BIND_VERTEX_BUFFER;
//
//	//Sub resource for pj buffer
//	D3D11_SUBRESOURCE_DATA ColData;
//	ColData.pSysMem = &Circle[0];
//	ColData.SysMemPitch = 0;
//	ColData.SysMemSlicePitch = 0;
//
//	//Create Collision Vertex Buffer
//	pDevice->CreateBuffer(&Col_Buffer_Dest, &ColData, &pCollisionVertBuffer);
//
//	D3D11_BUFFER_DESC Colission_Color_Buffer_Desc;
//	ZeroMemory(&Colission_Color_Buffer_Desc, sizeof(Colission_Color_Buffer_Desc));
//	Colission_Color_Buffer_Desc.ByteWidth = sizeof(XMFLOAT4);
//	Colission_Color_Buffer_Desc.Usage = D3D11_USAGE_DYNAMIC;
//	Colission_Color_Buffer_Desc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
//	Colission_Color_Buffer_Desc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
//
//	//Create Collision Vertex Buffer
//	pDevice->CreateBuffer(&Colission_Color_Buffer_Desc, NULL, &pCollisionColorBuffer);
//
//	//Create Reaction Effect Buffer for the pixel shader. It is the same size as the previous buffer.
//	Colission_Color_Buffer_Desc.ByteWidth = sizeof(tObjectColor);
//	pDevice->CreateBuffer(&Colission_Color_Buffer_Desc, NULL, &pReactionEffectBuffer);
//
//	//Create Shaders
//	pDevice->CreateVertexShader(VertexShader, sizeof(VertexShader), NULL, &BasicVertexShader);
//	//pDevice->CreatePixelShader(PixelShader, sizeof(PixelShader), NULL, &BasicPixelShader);
//	pDevice->CreateVertexShader(HUDVertexShader, sizeof(HUDVertexShader), NULL, &HUD_VertexShader);
//	//pDevice->CreatePixelShader(HUDPixelShader, sizeof(HUDPixelShader), NULL, &HUD_PixelShader);
//	pDevice->CreateGeometryShader(HUDGeometryShader, sizeof(HUDGeometryShader), NULL, &HUD_GeomShader);
//	pDevice->CreateVertexShader(EffectBillboardVertexShader, sizeof(EffectBillboardVertexShader), NULL, &EffectVertexShader);
//	pDevice->CreatePixelShader(EffectBillboardPixelShader, sizeof(EffectBillboardPixelShader), NULL, &EffectPixelShader);
//	pDevice->CreateGeometryShader(EffectBillboardGeomShader, sizeof(EffectBillboardGeomShader), NULL, &EffectGeomShader);
//	pDevice->CreateVertexShader(CircleVertexShader, sizeof(CircleVertexShader), NULL, &pCollisionVertexShader);
//	pDevice->CreatePixelShader(CirclePixelShader, sizeof(CirclePixelShader), NULL, &pCollisionPixelShader);
//	pDevice->CreateVertexShader(AnimationVertexShader, sizeof(AnimationVertexShader), NULL, &pAnimVertexShader);
//	pDevice->CreateVertexShader(TelegraphVertexShader, sizeof(TelegraphVertexShader), NULL, &TeleGVertexShader);
//	pDevice->CreatePixelShader(TelegraphPixelShader, sizeof(TelegraphPixelShader), NULL, &TeleGPixelShader);
//	pDevice->CreateGeometryShader(TelegraphGeometryShader, sizeof(TelegraphGeometryShader), NULL, &TeleGGeomShader);
//
//	//Create input layout
//	D3D11_INPUT_ELEMENT_DESC vsLayout[] =
//	{
//		{ "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
//		{ "NORMAL", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
//		{ "UV", 0, DXGI_FORMAT_R32G32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 }
//	};
//
//	//Create input layout for hud quad
//	D3D11_INPUT_ELEMENT_DESC HUDvsLayout[] =
//	{
//		{ "UV", 0, DXGI_FORMAT_R32G32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
//		{ "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 }
//	};
//
//	//Creat input layout to render a circle
//	D3D11_INPUT_ELEMENT_DESC CircleLayout[] =
//	{
//		{ "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 }
//	};
//	//Create Animation layout to render animations
//	D3D11_INPUT_ELEMENT_DESC animLayout[] =
//	{
//		{ "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
//		{ "NORMAL", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
//		{ "UV", 0, DXGI_FORMAT_R32G32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
//		{ "BLENDINDICIES", 0, DXGI_FORMAT_R32G32B32A32_UINT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
//		{ "BLENDWEIGHT", 0, DXGI_FORMAT_R32G32B32A32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
//	};
//
//	//Creates the input layout
//	pDevice->CreateInputLayout(vsLayout, 3, VertexShader, sizeof(VertexShader), &pInputLayout);
//	pDevice->CreateInputLayout(HUDvsLayout, 2, HUDVertexShader, sizeof(HUDVertexShader), &pHUDInputLayout);
//	pDevice->CreateInputLayout(CircleLayout, 1, CircleVertexShader, sizeof(CircleVertexShader), &pCollisionInputLayout);
//	pDevice->CreateInputLayout(animLayout, 5, AnimationVertexShader, sizeof(AnimationVertexShader), &pAnimInputLayout);
//
//	//Sample Desc
//	ZeroMemory(&Samp_Desc, sizeof(Samp_Desc));
//	Samp_Desc.MinLOD = -D3D11_FLOAT32_MAX;
//	Samp_Desc.MaxLOD = D3D11_FLOAT32_MAX;
//	Samp_Desc.AddressU = D3D11_TEXTURE_ADDRESS_WRAP;
//	Samp_Desc.AddressV = D3D11_TEXTURE_ADDRESS_WRAP;
//	Samp_Desc.AddressW = D3D11_TEXTURE_ADDRESS_WRAP;
//	Samp_Desc.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
//	Samp_Desc.ComparisonFunc = D3D11_COMPARISON_NEVER;
//	Samp_Desc.MaxAnisotropy = 4;
//
//	//Texure Sampler
//	pDevice->CreateSamplerState(&Samp_Desc, &pSamplerState);
//
//
//	// - Text data initialize -
//
//	//Create the vertex buffer to store the info for letter quads
//	D3D11_BUFFER_DESC textBufferDesc;
//	ZeroMemory(&textBufferDesc, sizeof(D3D11_BUFFER_DESC));
//	textBufferDesc.ByteWidth = sizeof(TEXT_VERT) * TextBox::MAX_CHARACTERS * 2;
//	textBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
//	textBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
//	textBufferDesc.BindFlags = D3D11_BIND_VERTEX_BUFFER;
//
//	//Create the buffer of text verts
//	pDevice->CreateBuffer(&textBufferDesc, NULL, &pTextVertBuffer);
//
//
//	//Create the constant buffer for text Colors
//	D3D11_BUFFER_DESC textColorBufferDesc;
//	ZeroMemory(&textColorBufferDesc, sizeof(D3D11_BUFFER_DESC));
//	textColorBufferDesc.ByteWidth = sizeof(TEXT_COLOR);
//	textColorBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
//	textColorBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
//	textColorBufferDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
//
//	//Create text Colors Constant Buffer
//	HRESULT hr = pDevice->CreateBuffer(&textColorBufferDesc, NULL, &pTextColorBuffer);
//
//	pDevice->CreateVertexShader(TextVertexShader, sizeof(TextVertexShader), NULL, &pTextVertexShader);
//	pDevice->CreateGeometryShader(TextGeometryShader, sizeof(TextGeometryShader), NULL, &pTextGeomShader);
//	pDevice->CreatePixelShader(TextPixelShader, sizeof(TextPixelShader), NULL, &pTextPixelShader);
//
//	//Create input layout for hud quad
//	D3D11_INPUT_ELEMENT_DESC TextvsLayout[] =
//	{
//		{ "POSITION", 0, DXGI_FORMAT_R32G32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
//		{ "UV", 0, DXGI_FORMAT_R32G32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 }
//	};
//	pDevice->CreateInputLayout(TextvsLayout, 2, TextVertexShader, sizeof(TextVertexShader), &pTextInputLayout);
//
//	D3D11_BLEND_DESC blendDesc;
//	blendDesc.AlphaToCoverageEnable = false;
//	blendDesc.IndependentBlendEnable = false;
//	blendDesc.RenderTarget[0].BlendEnable = true;
//	blendDesc.RenderTarget[0].BlendOp = D3D11_BLEND_OP_ADD;
//	blendDesc.RenderTarget[0].SrcBlend = D3D11_BLEND_SRC_ALPHA;
//	blendDesc.RenderTarget[0].DestBlend = D3D11_BLEND_INV_SRC_ALPHA;
//	blendDesc.RenderTarget[0].BlendOpAlpha = D3D11_BLEND_OP_ADD;
//	blendDesc.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_SRC_ALPHA;
//	blendDesc.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_INV_SRC_ALPHA;
//	blendDesc.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;
//
//	pDevice->CreateBlendState(&blendDesc, &pBlendState);
//
//	// -- Depth stencil state without z-testing ---
//
//	D3D11_DEPTH_STENCIL_DESC depthstencilDesc = {};
//	depthstencilDesc.DepthEnable = FALSE;
//	depthstencilDesc.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ALL;
//	depthstencilDesc.DepthFunc = D3D11_COMPARISON_ALWAYS;
//	depthstencilDesc.StencilEnable = FALSE;
//
//	depthstencilDesc.BackFace.StencilDepthFailOp = D3D11_STENCIL_OP_KEEP;
//	depthstencilDesc.BackFace.StencilFailOp = D3D11_STENCIL_OP_KEEP;
//	depthstencilDesc.BackFace.StencilFunc = D3D11_COMPARISON_ALWAYS;
//	depthstencilDesc.BackFace.StencilPassOp = D3D11_STENCIL_OP_KEEP;
//
//	depthstencilDesc.FrontFace.StencilDepthFailOp = D3D11_STENCIL_OP_KEEP;
//	depthstencilDesc.FrontFace.StencilFailOp = D3D11_STENCIL_OP_KEEP;
//	depthstencilDesc.FrontFace.StencilFunc = D3D11_COMPARISON_ALWAYS;
//	depthstencilDesc.FrontFace.StencilPassOp = D3D11_STENCIL_OP_KEEP;
//
//	pDevice->CreateDepthStencilState(&depthstencilDesc, &pDepthStateNoZ);
//
//	// --- Particle render data creation ---
//	{
//		//Create the vertex buffer to store particle vertex points
//		D3D11_BUFFER_DESC particleBufferDesc;
//		ZeroMemory(&particleBufferDesc, sizeof(D3D11_BUFFER_DESC));
//		particleBufferDesc.ByteWidth = sizeof(Particle) * Emitter::MAX_PARTICLES;
//		particleBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
//		particleBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
//		particleBufferDesc.BindFlags = D3D11_BIND_VERTEX_BUFFER;
//
//		pDevice->CreateBuffer(&particleBufferDesc, NULL, &m_pParticleVertBuffer);
//
//
//		//Create the constant buffer for emitter data
//		D3D11_BUFFER_DESC emitterBufferDesc;
//		ZeroMemory(&emitterBufferDesc, sizeof(D3D11_BUFFER_DESC));
//		//emitterBufferDesc.ByteWidth = sizeof(EMITTER_DATA);
//		emitterBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
//		emitterBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
//		emitterBufferDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
//
//		hr = pDevice->CreateBuffer(&emitterBufferDesc, NULL, &m_pParticleEmitterBuffer);
//
//		// -- Depth stencil state without depth writing ---
//		D3D11_DEPTH_STENCIL_DESC depthstencilDesc = { };
//		ZeroMemory(&depthstencilDesc, sizeof(D3D11_DEPTH_STENCIL_DESC));
//		depthstencilDesc.DepthEnable = TRUE;
//		depthstencilDesc.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ZERO;
//		depthstencilDesc.DepthFunc = D3D11_COMPARISON_LESS;
//		depthstencilDesc.StencilEnable = FALSE;
//
//		pDevice->CreateDepthStencilState(&depthstencilDesc, &m_pParticleDepthStencilState);
//
//
//		// Create shaders
//		pDevice->CreateVertexShader(ParticleVertexShader, sizeof(ParticleVertexShader), NULL, &m_pParticleVertexShader);
//		pDevice->CreateGeometryShader(ParticleGeometryShader, sizeof(ParticleGeometryShader), NULL, &m_pParticleGeomShader);
//		pDevice->CreatePixelShader(ParticlePixelShader, sizeof(ParticlePixelShader), NULL, &m_pParticlePixelShader);
//
//		//Create input layout for hud quad
//		D3D11_INPUT_ELEMENT_DESC ParticleLayout[] =
//		{
//			{ "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
//			{ "VELOCITY", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
//			{ "ANGLE", 0, DXGI_FORMAT_R32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
//			{ "ANGULAR_SPEED", 0, DXGI_FORMAT_R32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
//			{ "TIME", 0, DXGI_FORMAT_R32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 }
//		};
//		pDevice->CreateInputLayout(ParticleLayout, 5, ParticleVertexShader, sizeof(ParticleVertexShader), &m_pParticleInputLayout);
//
//
//		////-------3D Particle Emitter --------
//		////Creating a Sturctured Buffer to draw the boulders instanced
//		//D3D11_BUFFER_DESC emitterStructuredBufferDesc;
//		//ZeroMemory(&emitterStructuredBufferDesc, sizeof(D3D11_BUFFER_DESC));
//		//emitterStructuredBufferDesc.ByteWidth = sizeof(Particle) * Emitter::MAX_PARTICLES;
//		////emitterStructuredBufferDesc.StructureByteStride = sizeof(Particle);
//		//emitterStructuredBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
//		//emitterStructuredBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
//		//emitterStructuredBufferDesc.BindFlags = D3D11_BIND_SHADER_RESOURCE;
//
//		//hr = pDevice->CreateBuffer(&emitterStructuredBufferDesc, nullptr, &m_p3DParticleEmitterBuffer);
//
//		//CD3D11_SHADER_RESOURCE_VIEW_DESC srv_DESC(m_p3DParticleEmitterBuffer, DXGI_FORMAT_UNKNOWN, 0, Emitter::MAX_PARTICLES);
//		////srv_DESC.Buffer.ElementOffset = sizeof(Particle);
//
//		//hr = pDevice->CreateShaderResourceView(m_p3DParticleEmitterBuffer, &srv_DESC, &m_pParticleEmitterSRV);
//
//		//hr = pDevice->CreateVertexShader(Particle3DVertexShader, sizeof(Particle3DVertexShader), NULL, &m_pParticle3DVertexShader);
//
//	}
//
//	this->ToggleFullScreen(hWnd);
//
//	return true;
//}
//void Renderer::Shutdown()
//{
//#pragma region ReleaseCom
//	//Clean up com objects
//
//	ReleaseCOM(pDevice);
//	ReleaseCOM(pContext);
//	ReleaseCOM(pSwapChain);
//	ReleaseCOM(pRenderTargetView);
//	ReleaseCOM(pBackBuffer);
//	ReleaseCOM(pDepthStencilBuffer);
//	ReleaseCOM(pDepthStencilView);
//	ReleaseCOM(pInputLayout);
//	ReleaseCOM(pSamplerState);
//	ReleaseCOM(ObjectTransformBuffer);
//	ReleaseCOM(ViewProjectionBuffer);
//	ReleaseCOM(BasicPixelShader);
//	ReleaseCOM(BasicVertexShader);
//	ReleaseCOM(HUD_GeomShader);
//	ReleaseCOM(HUD_PixelShader);
//	ReleaseCOM(HUD_VertexShader);
//	ReleaseCOM(HUDQuadDataBuffer);
//	ReleaseCOM(pHUDInputLayout);
//	ReleaseCOM(EffectPixelShader);
//	ReleaseCOM(EffectVertexShader);
//	ReleaseCOM(EffectGeomShader);
//	ReleaseCOM(EffectDataBuffer);
//	ReleaseCOM(pCollisionInputLayout);
//	ReleaseCOM(pCollisionPixelShader);
//	ReleaseCOM(pCollisionVertexShader);
//	ReleaseCOM(pCollisionVertBuffer);
//	ReleaseCOM(pCollisionColorBuffer);
//	ReleaseCOM(pTextVertexShader);
//	ReleaseCOM(pTextGeomShader);
//	ReleaseCOM(pTextPixelShader);
//	ReleaseCOM(pTextVertBuffer);
//	ReleaseCOM(pTextInputLayout);
//	ReleaseCOM(pTextColorBuffer);
//	ReleaseCOM(pBlendState);
//	ReleaseCOM(pAnimBuffer);
//	ReleaseCOM(pAnimInputLayout);
//	ReleaseCOM(pAnimVertexShader);
//	ReleaseCOM(pReactionEffectBuffer);
//	ReleaseCOM(pDepthStateNoZ);
//	ReleaseCOM(pTelegraphBuffer);
//	ReleaseCOM(TeleGGeomShader);
//	ReleaseCOM(TeleGPixelShader);
//	ReleaseCOM(TeleGVertexShader);
//	ReleaseCOM(DirectionalLightBuffer);
//
//	ReleaseCOM(m_pParticleInputLayout);
//	ReleaseCOM(m_pParticleVertexShader);
//	ReleaseCOM(m_pParticleGeomShader);
//	ReleaseCOM(m_pParticlePixelShader);
//	ReleaseCOM(m_pParticleVertBuffer);
//	ReleaseCOM(m_pParticleEmitterBuffer);
//	ReleaseCOM(m_pParticleDepthStencilState);
//	//ReleaseCOM(m_p3DParticleEmitterBuffer);
//	//ReleaseCOM(m_pParticleEmitterSRV);
//	//ReleaseCOM(m_pParticle3DVertexShader);
//
//#pragma endregion
//
//	if (MainCamera != nullptr)
//		delete MainCamera;
//
//}
//void Renderer::Update(CoreFacade* pCoreFacade)
//{
//	ObjectManager& OM = *pCoreFacade->GetObjectManager();
//	PhysicsSystem* PS = pCoreFacade->GetPhysicsSystem();
//
//	//Update Camera
//	if (MainCamera != nullptr)
//	{
//		//ShowCursor(FALSE);
//
//		if (OM.GetPlayer() != nullptr)
//			MainCamera->Update(OM.GetPlayer()->GetObjectTranslation());
//
//		//SCENE svp_local;
//		//svp_local.view = MainCamera->GetRendererViewMat();
//		//svp_local.proj = ProjectionMatrix;
//		//XMMATRIX UpdatedCamera = XMLoadFloat4x4(&svp_local.view);
//		//UpdatedCamera = XMMatrixInverse(0, UpdatedCamera);
//		//XMStoreFloat4x4(&svp_local.InvView, UpdatedCamera);
//		//UpdateConstantBuffer(ViewProjectionBuffer, svp_local);
//
//		//Set the render target view and zBuffer
//		pContext->OMSetRenderTargets(1, &pRenderTargetView, pDepthStencilView);
//
//		//Create and set the view port.
//		D3D11_VIEWPORT VP;
//		VP.Height = (float)CurrentScreenHeight;
//		VP.Width = (float)CurrentScreenWidth;
//		VP.TopLeftX = 0;
//		VP.TopLeftY = 0;
//		VP.MinDepth = 0;
//		VP.MaxDepth = 1;
//
//		float ClearColor[] = { 0.0f, 0.0f, 0.0f, 1.0f };
//
//		pContext->RSSetViewports(1, &VP);
//		pContext->ClearRenderTargetView(pRenderTargetView, ClearColor);
//		pContext->ClearDepthStencilView(pDepthStencilView, D3D11_CLEAR_DEPTH, 1, 0);
//
//#pragma region Render Objects
//		//Loop through each object and render each object
//		for (unsigned int i = 0; i < OM.GetRenderSet().size(); i++)
//		{
//			if (OM.GetRenderSet()[i]->GetActive() == false)
//				continue;
//
//			//Temp check to only render geom
//			if (OM.GetRenderSet()[i]->GetType() == eHUD ||
//				OM.GetRenderSet()[i]->GetType() == eEFFECT ||
//				OM.GetRenderSet()[i]->GetType() == eTELEGRAPH ||
//				OM.GetRenderSet()[i]->GetType() == eEMITTER)
//				continue;
//			//D3D11_TEXTURE_ADDRESS_MODE(1);
//			//if (OM.GetRenderSet()[i]->GetType() == eLEVEL)
//			//	
//			//else
//			//	D3D11_TEXTURE_ADDRESS_MODE(1);
//
//			CMesh * CurRM = OM.GetRenderSet()[i]->GetRendererComponent()->m_RenderMesh;
//
//			//Object size and offset
//			UINT offsetSB = 0;
//			UINT strideSB;
//			if (OM.GetRenderSet()[i]->IsAnimated())
//				strideSB = sizeof(CMesh::tAnimated_Verts);
//			else
//				strideSB = sizeof(CMesh::tStatic_Verts);
//
//			//Update object const buffers
//			//Rotating models to face down towards +Z 
//			XMMATRIX worldPos = XMLoadFloat4x4(&OM.GetRenderSet()[i]->GetWorldTransform());
//			if (OM.GetRenderSet()[i]->GetType() != eWALL)
//				worldPos = XMMatrixMultiply(XMMatrixRotationY(XM_PI), worldPos);
//			XMFLOAT4X4 correctedPos;
//			XMStoreFloat4x4(&correctedPos, worldPos);
//			UpdateConstantBuffer(ObjectTransformBuffer, correctedPos);
//			UpdateConstantBuffer(pReactionEffectBuffer, OM.GetRenderSet()[i]->GetObjectColor());
//
//			//Pipeline
//			pContext->IASetVertexBuffers(0, 1, CurRM->GetVertexBuffer(), &strideSB, &offsetSB);
//			pContext->IASetIndexBuffer(CurRM->GetIndexArray(), DXGI_FORMAT_R16_UINT, offsetSB);
//
//			//Choose which vertex shader to use if model is static or animated
//			if (OM.GetRenderSet()[i]->IsAnimated())
//				pContext->VSSetShader(pAnimVertexShader, NULL, 0);
//			else
//				pContext->VSSetShader(BasicVertexShader, NULL, 0);
//			pContext->PSSetShader(BasicPixelShader, NULL, 0);
//
//			pContext->PSSetShaderResources(0, 1, &OM.GetRenderSet()[i]->GetRendererComponent()->DiffuseTexture);
//			pContext->PSSetSamplers(0, 1, &pSamplerState);
//
//			pContext->VSSetConstantBuffers(0, 1, &ObjectTransformBuffer);
//			pContext->VSSetConstantBuffers(1, 1, &ViewProjectionBuffer);
//			pContext->PSSetConstantBuffers(2, 1, &DirectionalLightBuffer);
//			pContext->PSSetConstantBuffers(3, 1, &pReactionEffectBuffer);
//		
//			if (OM.GetRenderSet()[i]->IsAnimated())
//			{
//				//Add Animation Constant buffer
//				pContext->VSSetConstantBuffers(2, 1, &pAnimBuffer);
//
//				//Update the Constant buffer
//				tKeyFrame  current = OM.GetRenderSet()[i]->GetAnimComponent()->GetInterpolatedFrame();
//				ANIM_DATA temp;
//				for (size_t i = 0; i < current.m_Frame.size(); i++)
//					temp.joints[i] = current.m_Frame[i]->GetWorldMat();
//
//				UpdateConstantBuffer(this->pAnimBuffer, temp);
//
//				//Set Inputlayout to the animation layout
//				pContext->IASetInputLayout(pAnimInputLayout);
//			}
//			else
//				pContext->IASetInputLayout(pInputLayout);
//
//			pContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
//			pContext->DrawIndexed(CurRM->GetIndexSize(), 0, 0);
//		}
//#pragma endregion
//#pragma region Render Collision Shapes
////Render all collision shapes
//
//		if (PS != nullptr /*&& PS->RenderCollisionCircles == true*/)
//		{
//			UINT offset = 0;
//			UINT stride = sizeof(XMFLOAT3);
//
//			pContext->VSSetShader(pCollisionVertexShader, NULL, 0);
//			pContext->PSSetShader(pCollisionPixelShader, NULL, 0);
//			pContext->IASetVertexBuffers(0, 1, &pCollisionVertBuffer, &stride, &offset);
//			pContext->VSSetConstantBuffers(0, 1, &ViewProjectionBuffer);
//			pContext->PSSetConstantBuffers(0, 1, &pCollisionColorBuffer);
//			pContext->IASetInputLayout(pCollisionInputLayout);
//			pContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_LINESTRIP);
//			pContext->OMSetDepthStencilState(pDepthStateNoZ, 1);
//
//#ifdef RENDER_CIRCLE_COL_SHAPES
//			for (size_t i = 0; i < PS->GetCircleCollisionShapes().size(); i++)
//			{
//
//				Physics::Circle& circle = PS->GetCircleCollisionShapes()[i];
//				if (circle.IsActive() && circle.GetGameObjectHolder() != nullptr)
//				{
//
//#ifdef SHOW_BOUNDING_ONLY
//					if (circle.GetShapeUsage() != SU_BOUNDING_SHAPE)
//						continue;
//#endif
//					XMFLOAT3 Circle[360];
//					if (circle.GetGameObjectHolder()->GetPhysicsComponent() != nullptr)
//					{
//						XMFLOAT3 CirclePos = XMFLOAT3(XMVectorGetX(PS->GetCircleCollisionShapes()[i].GetPosition()),
//													  0.0f, //Y position
//													  XMVectorGetY(PS->GetCircleCollisionShapes()[i].GetPosition()));
//
//						for (unsigned int j = 0; j < 360; j++)
//						{
//							Circle[j] = CirclePos;
//							Circle[j].x = Circle[j].x + PS->GetCircleCollisionShapes()[i].GetRadius() * (float) cos(XMConvertToRadians((float) j));
//							Circle[j].z = Circle[j].z + PS->GetCircleCollisionShapes()[i].GetRadius() *(float) sin(XMConvertToRadians((float) j));
//						}
//					}
//
//					//Update Buffers
//					D3D11_MAPPED_SUBRESOURCE MappedResource;
//					pContext->Map(pCollisionVertBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &MappedResource);
//					memcpy_s(MappedResource.pData, sizeof(XMFLOAT3) * 360, &Circle, sizeof(XMFLOAT3) * 360);
//					pContext->Unmap(pCollisionVertBuffer, 0);
//
//					XMFLOAT4 Color(1.0f, 1.0f, 0.0f, 1.0f);
//					if (circle.GetDetectedShapes().empty() == false)
//						Color.z += min(1.0f, circle.GetDetectedShapes().size() / 5.0f);
//
//					pContext->Map(pCollisionColorBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &MappedResource);
//					memcpy_s(MappedResource.pData, sizeof(XMFLOAT4), &Color, sizeof(XMFLOAT4));
//					pContext->Unmap(pCollisionColorBuffer, 0);
//
//					//Renderer the circle
//
//					pContext->Draw(359, 0);
//
//					// Draw resolutions
//					auto contacts = circle.GetContacts();
//					for (auto it = contacts.begin(); it != contacts.end(); ++it)
//					{
//						XMFLOAT3 SegmentStart = Physics::XMCVector3GetXZ(circle.GetPosition(), 0.1f);
//						XMFLOAT3 SegmentEnd = Physics::XMCVector3GetXZ((*it)->GetPosition());
//
//
//						XMFLOAT3 Segment[10];
//						for (unsigned int j = 0; j < 10; j++)
//						{
//							Segment[j].y = SegmentStart.y;
//							Segment[j].x = SegmentStart.x + ( ( 10.0f - j ) / 10.0f )*( SegmentEnd.x - SegmentStart.x );
//							Segment[j].z = SegmentStart.z + ( ( 10.0f - j ) / 10.0f )*( SegmentEnd.z - SegmentStart.z );
//						}
//
//						//Update Buffer
//						D3D11_MAPPED_SUBRESOURCE MappedResource;
//						pContext->Map(pCollisionVertBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &MappedResource);
//						memcpy_s(MappedResource.pData, sizeof(XMFLOAT3) * 10, &Segment, sizeof(XMFLOAT3) * 10);
//						pContext->Unmap(pCollisionVertBuffer, 0);
//
//						XMFLOAT4 Color = { 0.0f, 0.0f, 1.0f, 1.0f };
//
//						pContext->Map(pCollisionColorBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &MappedResource);
//						memcpy_s(MappedResource.pData, sizeof(XMFLOAT4), &Color, sizeof(XMFLOAT4));
//						pContext->Unmap(pCollisionColorBuffer, 0);
//
//						pContext->Draw(10, 0);
//					}
//				}
//			}
//#endif
//#ifdef RENDER_BOX_COL_SHAPES
//			for (size_t i = 0; i < PS->GetOrientedBoxCollisionShapes().size(); i++)
//			{
//				Physics::OrientedBox& obb = PS->GetOrientedBoxCollisionShapes()[i];
//				if (!obb.IsActive() || obb.GetGameObjectHolder() == nullptr)
//					continue;
//
//				XMVECTOR BoxCenter = obb.GetPosition();
//				XMFLOAT2 BoxHSize = Physics::XMCStoreFloat2( obb.GetHalfSize() );
//				XMVECTOR BoxUp = obb.GetDirection();
//				XMVECTOR BoxLeft = XMVector2Orthogonal(BoxUp);
//				
//
//				XMVECTOR Corners[4];
//				Corners[0] = BoxCenter + BoxUp*BoxHSize.x + BoxLeft*BoxHSize.y ;
//				Corners[1] = BoxCenter + BoxUp*BoxHSize.x - BoxLeft*BoxHSize.y ;
//				Corners[2] = BoxCenter - BoxUp*BoxHSize.x - BoxLeft*BoxHSize.y ;
//				Corners[3] = BoxCenter - BoxUp*BoxHSize.x + BoxLeft*BoxHSize.y ;
//
//				XMFLOAT3 Box[40];
//				for (unsigned int j = 0; j < 40; j++)
//					Box[j].y = 0.0f;
//
//				for (size_t iCorner = 0; iCorner < 4; iCorner++)
//				{
//					for (unsigned int j = 0; j < 10; j++)
//					{
//						XMVECTOR pos = XMVectorLerp(Corners[iCorner], Corners[( iCorner + 1 ) % 4], j / 9.0f);
//						Box[iCorner * 10 + j].x = XMVectorGetX(pos);
//						Box[iCorner * 10 + j].z = XMVectorGetY(pos);
//					}
//				}
//
//				//Update Buffer
//				D3D11_MAPPED_SUBRESOURCE MappedResource;
//				pContext->Map(pCollisionVertBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &MappedResource);
//				memcpy_s(MappedResource.pData, sizeof(XMFLOAT3) * 40, &Box, sizeof(XMFLOAT3) * 40);
//				pContext->Unmap(pCollisionVertBuffer, 0);
//
//				XMFLOAT4 Color(1.0f, 1.0f, 1.0f, 1.0f);
//				if( obb.GetDetectedShapes().empty() == false )
//					Color = { 1.0f, 1.0f, 0.0f, 1.0f };
//
//				pContext->Map(pCollisionColorBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &MappedResource);
//				memcpy_s(MappedResource.pData, sizeof(XMFLOAT4), &Color, sizeof(XMFLOAT4));
//				pContext->Unmap(pCollisionColorBuffer, 0);
//
//				pContext->Draw(40, 0);
//			}
//#endif
//#ifdef RENDER_SEGMENT_COL_SHAPES
//			for (size_t i = 0; i < PS->GetSegmentCollisionShapes().size(); i++)
//			{
//				Physics::Segment& segment = PS->GetSegmentCollisionShapes()[i];
//				if (!segment.IsActive() || segment.GetGameObjectHolder() == nullptr)
//					continue;
//
//				XMFLOAT3 SegmentStart = Physics::XMCVector3GetXZ(segment.GetPosition(), 0.1f);
//				XMFLOAT3 SegmentEnd = Physics::XMCVector3GetXZ(segment.GetPosition() + segment.GetRotatedExtent(), 0.1f);
//
//
//				XMFLOAT3 Segment[10];
//				for (unsigned int j = 0; j < 10; j++)
//				{
//					Segment[j].y = SegmentStart.y;
//					Segment[j].x = SegmentStart.x + ( ( 10.0f - j ) / 10.0f )*( SegmentEnd.x - SegmentStart.x );
//					Segment[j].z = SegmentStart.z + ( ( 10.0f - j ) / 10.0f )*( SegmentEnd.z - SegmentStart.z );
//				}
//
//				//Update Buffer
//				D3D11_MAPPED_SUBRESOURCE MappedResource;
//				pContext->Map(pCollisionVertBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &MappedResource);
//				memcpy_s(MappedResource.pData, sizeof(XMFLOAT3) * 10, &Segment, sizeof(XMFLOAT3) * 10);
//				pContext->Unmap(pCollisionVertBuffer, 0);
//
//				XMFLOAT4 Color(1.0f, 1.0f, 1.0f, 1.0f);
//				if( segment.GetDetectedShapes().empty() == false )
//					Color = { 1.0f, 1.0f, 0.0f, 1.0f };
//
//				pContext->Map(pCollisionColorBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &MappedResource);
//				memcpy_s(MappedResource.pData, sizeof(XMFLOAT4), &Color, sizeof(XMFLOAT4));
//				pContext->Unmap(pCollisionColorBuffer, 0);
//
//				pContext->Draw(10, 0);
//			}
//#endif
//		pContext->OMSetDepthStencilState(NULL, 1);
//
//		}
//
//#pragma endregion
//#pragma region Render Telegraphs
//		//Render all of the Telegraphs
//		pContext->OMSetBlendState(pBlendState, NULL, 0xffffffff);
//		pContext->OMSetDepthStencilState(m_pParticleDepthStencilState,1);
//		for (unsigned int i = 0; i < OM.GetTelegraphs().size(); i++)
//		{
//			if (OM.GetTelegraphs()[i]->GetActive() == true && OM.GetTelegraphs()[i]->GetTelegraphComponent()->GetEnabled() == true)
//			{
//				//Update the buffer
//				XMFLOAT2 Position = XMFLOAT2(OM.GetTelegraphs()[i]->GetTelegraphComponent()->PosX, OM.GetTelegraphs()[i]->GetTelegraphComponent()->PosZ);
//				XMFLOAT2 Scale = XMFLOAT2(OM.GetTelegraphs()[i]->GetTelegraphComponent()->StartScale, OM.GetTelegraphs()[i]->GetTelegraphComponent()->EndScale);
//				TELEGRAPH CurrentTele;
//				CurrentTele.IsFear = OM.GetTelegraphs()[i]->GetTelegraphComponent()->IsFear;
//				CurrentTele.Position = Position;
//				CurrentTele.Scale = Scale;
//				CurrentTele.Color1 = OM.GetTelegraphs()[i]->GetTelegraphComponent()->Color1;
//				CurrentTele.Color2 = OM.GetTelegraphs()[i]->GetTelegraphComponent()->Color2;
//				CurrentTele.Color3 = OM.GetTelegraphs()[i]->GetTelegraphComponent()->Color3;
//				CurrentTele.PercentComplete = OM.GetTelegraphs()[i]->GetTelegraphComponent()->PercentComplete;
//		
//				if (OM.GetTelegraphs()[i]->GetTelegraphComponent()->IsFear == true)
//				{
//					CurrentTele.IsFear = 1.0f;
//				}
//				else
//					CurrentTele.IsFear = 0.0f;
//		
//				UpdateConstantBuffer(pTelegraphBuffer, CurrentTele);
//		
//				//Setup the pipe line
//				pContext->VSSetShader(TeleGVertexShader, NULL, 0);
//				pContext->GSSetShader(TeleGGeomShader, NULL, 0);
//				pContext->PSSetShader(TeleGPixelShader, NULL, 0);
//		
//				pContext->PSSetShaderResources(0, 1, &OM.GetTelegraphs()[i]->GetRendererComponent()->DiffuseTexture);
//				pContext->PSSetSamplers(0, 1, &pSamplerState);
//		
//				pContext->GSSetConstantBuffers(0, 1, &pTelegraphBuffer);
//				pContext->GSSetConstantBuffers(1, 1, &ViewProjectionBuffer);
//		
//				pContext->IASetInputLayout(pHUDInputLayout);
//				pContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_POINTLIST);
//				pContext->Draw(1, 0);
//			}
//		}
//		pContext->OMSetBlendState(NULL, NULL, 0xffffffff);
//		pContext->OMSetDepthStencilState(NULL,1);
//#pragma endregion
//#pragma region Render Effects
//		pContext->OMSetBlendState(pBlendState, NULL, 0xffffffff);
//
//		//Render all of the effects
//		for (unsigned int i = 0; i < OM.GetEffects().size(); i++)
//		{		
//			if (/*OM.GetEffects()[i]->GetActive() == true &&*/ OM.GetEffects()[i]->GetEffectComponent()->isEnabled == true )
//			{
//				//Update the buffer
//				if (OM.GetEffects()[i]->GetTag() == "PlayerWaypointPointer")
//					int PlaceToCheck = 0;
//				EFFECT_DATA CurrentEffect;
//				CurrentEffect.Position = OM.GetEffects()[i]->GetEffectComponent()->Position;
//				CurrentEffect.Size = OM.GetEffects()[i]->GetEffectComponent()->Size;
//		
//				UpdateConstantBuffer(EffectDataBuffer, CurrentEffect);
//				UpdateConstantBuffer(pReactionEffectBuffer, OM.GetEffects()[i]->GetObjectColor());
//
//				//Setup the pipe line
//				pContext->VSSetShader(EffectVertexShader, NULL, 0);
//				pContext->GSSetShader(EffectGeomShader, NULL, 0);
//				pContext->PSSetShader(EffectPixelShader, NULL, 0);
//		
//				pContext->PSSetShaderResources(0, 1, &OM.GetEffects()[i]->GetRendererComponent()->DiffuseTexture);
//				pContext->PSSetSamplers(0, 1, &pSamplerState);
//		
//				pContext->GSSetConstantBuffers(0, 1, &EffectDataBuffer);
//				pContext->GSSetConstantBuffers(1, 1, &ViewProjectionBuffer);
//				pContext->PSSetConstantBuffers(0, 1, &pReactionEffectBuffer);
//
//				pContext->IASetInputLayout(pHUDInputLayout);
//				pContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_POINTLIST);
//				pContext->Draw(1, 0);
//			}
//		}
//		pContext->OMSetBlendState(NULL, NULL, 0xffffffff);
//
//
//#pragma endregion
//#pragma region Render Particles
//		
//		ParticleSystem* pParticleSystem = pCoreFacade->GetParticleSystem();
//		if (pParticleSystem)
//		{
//			pContext->OMSetBlendState(pBlendState, NULL, 0xffffffff);
//
//			//ID3D11DeviceContext* pContext = pCoreFacade->GetRenderDeviceContext();
//
//			//Setup the pipe line
//			pContext->VSSetShader(m_pParticleVertexShader, NULL, 0);
//			pContext->GSSetShader(m_pParticleGeomShader, NULL, 0);
//			pContext->PSSetShader(m_pParticlePixelShader, NULL, 0);
//
//			pContext->IASetInputLayout(m_pParticleInputLayout);
//			pContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_POINTLIST);
//			pContext->OMSetDepthStencilState(m_pParticleDepthStencilState, 1);
//			UINT offset = 0;
//			UINT stride = sizeof(Particle);
//
//			pContext->VSSetConstantBuffers(0, 1, &ViewProjectionBuffer);	
//			pContext->GSSetConstantBuffers(0, 1, &ViewProjectionBuffer);	
//
//			
//			//Render all of the particles
//			vector<Emitter> emitters = pParticleSystem->GetEmitters();
//			for (size_t i = 0; i < emitters.size(); i++)
//			{
//				Emitter& emitter = emitters[i];
//				if (!emitter.IsActive() || emitter.Is3D()) continue;
//
//				pContext->PSSetShaderResources(0, 1, &emitter.m_pParticleTexture );
//				
//				//Update cbuffers
//				D3D11_MAPPED_SUBRESOURCE MappedResource;
//
//				const vector<Particle> particles = emitter.GetParticles();
//				pContext->Map(m_pParticleVertBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &MappedResource);
//				memcpy_s(MappedResource.pData, sizeof(Particle) * particles.size(), &particles[0], sizeof(Particle) * particles.size());
//				pContext->Unmap(m_pParticleVertBuffer, 0);
//				pContext->IASetVertexBuffers(0, 1, &m_pParticleVertBuffer, &stride, &offset);
//				   
//
//				pContext->Map(m_pParticleEmitterBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &MappedResource);
//				//memcpy_s(MappedResource.pData, sizeof(EMITTER_DATA), &emitter.GetEmitterData(), sizeof(EMITTER_DATA));
//				pContext->Unmap(m_pParticleEmitterBuffer, 0);
//				pContext->VSSetConstantBuffers(2, 1, &m_pParticleEmitterBuffer);
//				pContext->GSSetConstantBuffers(2, 1, &m_pParticleEmitterBuffer);
//				pContext->PSSetConstantBuffers(2, 1, &m_pParticleEmitterBuffer);
//
//				pContext->Draw( particles.size(),0);
//
//			}
//			pContext->OMSetDepthStencilState(NULL, 1);
//		}
//
//		pContext->OMSetBlendState(NULL, NULL, 0xffffffff);
//
//#pragma region  Three Dimensional Emitter
//		//GameObject* emitter_3D = OM.GetEmitter3D();
//		//if (emitter_3D)
//		//{
//		//	pContext->VSSetShader(m_pParticle3DVertexShader, NULL, 0);
//		//	pContext->PSSetShader(BasicPixelShader, NULL, 0);
//
//		//	//Pipeline
//		//	UINT offsetSB = 0;
//		//	UINT strideSB;
//		//	strideSB = sizeof(CMesh::tStatic_Verts);
//
//		//	CMesh * RMobj = emitter_3D->GetRendererComponent()->m_RenderMesh;
//		//	pContext->IASetVertexBuffers(0, 1, RMobj->GetVertexBuffer(), &strideSB, &offsetSB);
//		//	pContext->IASetIndexBuffer(RMobj->GetIndexArray(), DXGI_FORMAT_R16_UINT, offsetSB);
//		//	pContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
//		//	pContext->IASetInputLayout(this->pInputLayout);
//
//		//	pContext->PSSetShaderResources(0, 1, &emitter_3D->GetRendererComponent()->DiffuseTexture);
//		//	pContext->VSSetShaderResources(0, 1, &m_pParticleEmitterSRV);
//
//		//	pContext->VSSetConstantBuffers(0, 1, &ViewProjectionBuffer); //should already be updated
//		//	pContext->VSSetConstantBuffers(1, 1, &m_pParticleEmitterBuffer);
//
//		//	pContext->PSSetConstantBuffers(2, 1, &DirectionalLightBuffer); //should already be updated
//		//	pContext->PSSetConstantBuffers(3, 1, &pReactionEffectBuffer);
//
//		//	//Mapping Data to the structured buffer
//		//	D3D11_MAPPED_SUBRESOURCE MappedResource;
//		//	UINT stride = sizeof(Particle);
//		//	const vector<Particle> particles = emitter_3D->GetEmitterComponent()->GetParticles();
//		//	pContext->Map(m_p3DParticleEmitterBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &MappedResource);
//		//	memcpy_s(MappedResource.pData, sizeof(Particle) * Emitter::MAX_PARTICLES, &particles[0], sizeof(Particle) * Emitter::MAX_PARTICLES);
//		//	pContext->Unmap(m_p3DParticleEmitterBuffer, 0);
//
//		//	//Updating the Constant buffer
//		//	UpdateConstantBuffer(m_pParticleEmitterBuffer, emitter_3D->GetEmitterComponent()->GetEmitterData());
//		//	UpdateConstantBuffer(pReactionEffectBuffer, emitter_3D->GetObjectColor());
//
//		//	pContext->DrawIndexedInstanced(RMobj->GetIndexSize(), Emitter::MAX_PARTICLES, 0, 0, 0);
//		//}
//#pragma endregion
//
//
//#pragma endregion 
//#pragma region Render HUD Elements
//		//Render All Hud Elements
//		pContext->OMSetBlendState(pBlendState, NULL, 0xffffffff);
//
//		pContext->OMSetDepthStencilState(pDepthStateNoZ, 1);
//
//		if (OM.GetHUDElements().size() > 1)
//			int debugbreak = 0;
//		for (unsigned int i = 0; i < OM.GetHUDElements().size(); i++)
//		{
//			if (OM.GetHUDElements()[i]->GetActive() == true && OM.GetHUDElements()[i]->GetHUDComponent()->isEnabled == true)
//			{
//				//Update the buffer
//				HUD_DATA CurrentHudElement;
//				CurrentHudElement.height = OM.GetHUDElements()[i]->GetHUDComponent()->m_Height;
//				CurrentHudElement.width = OM.GetHUDElements()[i]->GetHUDComponent()->m_Width;
//				CurrentHudElement.PosX = OM.GetHUDElements()[i]->GetHUDComponent()->m_XSceenPos;
//				CurrentHudElement.PosY = OM.GetHUDElements()[i]->GetHUDComponent()->m_YScreenPos;
//				UpdateConstantBuffer(HUDQuadDataBuffer, CurrentHudElement);
//				UpdateConstantBuffer(pReactionEffectBuffer, OM.GetRenderSet()[i]->GetObjectColor());
//
//				//Setup the pipe line
//				pContext->GSSetShader(HUD_GeomShader, NULL, 0);
//				pContext->VSSetShader(HUD_VertexShader, NULL, 0);
//				pContext->PSSetShader(HUD_PixelShader, NULL, 0);
//		
//				pContext->PSSetShaderResources(0, 1, &OM.GetHUDElements()[i]->GetRendererComponent()->DiffuseTexture);
//				pContext->PSSetSamplers(0, 1, &pSamplerState);
//		
//				pContext->GSSetConstantBuffers(2, 1, &HUDQuadDataBuffer);
//				pContext->PSSetConstantBuffers(0, 1, &pReactionEffectBuffer);
//				pContext->IASetInputLayout(pHUDInputLayout);
//				pContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_POINTLIST);
//				pContext->Draw(1, 0);
//			}
//		}
//		pContext->OMSetBlendState(NULL, NULL, 0xffffffff);
//
//		pContext->OMSetDepthStencilState(NULL, 1);
//		
//
//#pragma endregion 
//#pragma region Render Text
//		//Render all text
//		pContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_LINELIST);
//		pContext->VSSetShader(pTextVertexShader, NULL, 0);
//		pContext->GSSetShader(pTextGeomShader, NULL, 0);
//		pContext->PSSetShader(pTextPixelShader, NULL, 0);
//		pContext->PSSetSamplers(0, 1, &pSamplerState);
//		pContext->IASetInputLayout(pTextInputLayout);
//		pContext->OMSetBlendState(pBlendState, NULL, 0xffffffff);
//		pContext->OMSetDepthStencilState(pDepthStateNoZ, 1);
//		for (unsigned int i = 0; i < OM.GetTextBoxes().size(); i++)
//		{
//			TextBox& textBox = *OM.GetTextBoxes()[i]->GetTextComponent();
//			if (textBox.IsActive())
//			{
//
//				const TEXT_VERT* textVerts = textBox.GetTextVerts();
//				size_t textLen = textBox.GetText().size();
//				if (textLen == 0)
//					continue;
//
//				//Update Vertex Buffer
//				D3D11_MAPPED_SUBRESOURCE MappedResource;
//				pContext->Map(pTextVertBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &MappedResource);
//				memcpy_s(MappedResource.pData, sizeof(TEXT_VERT) * textLen * 2, textVerts, sizeof(TEXT_VERT) * textLen * 2);
//				pContext->Unmap(pTextVertBuffer, 0);
//
//				TEXT_COLOR textColor = *textBox.GetTextColor();
//				UpdateConstantBuffer(pTextColorBuffer, textColor);
//				pContext->PSSetConstantBuffers(0, 1, &pTextColorBuffer);
//
//				UINT offset = 0;
//				UINT stride = sizeof(TEXT_VERT);
//				pContext->IASetVertexBuffers(0, 1, &pTextVertBuffer, &stride, &offset);
//				ID3D11ShaderResourceView* pGlyphTexture = textBox.GetFont()->GetGlyphTexture();
//				ID3D11ShaderResourceView* pOutlineTexture = textBox.GetFont()->GetOutlineTexture();
//				pContext->PSSetShaderResources(0, 1, &pGlyphTexture);
//				pContext->PSSetShaderResources(1, 1, &pOutlineTexture);
//
//				pContext->Draw(textLen * 2, 0);
//			}
//
//		}
//		pContext->OMSetBlendState(NULL, NULL, 0xffffffff);
//		pContext->OMSetDepthStencilState(NULL, 1);
//
//		//---
//#pragma endregion
//
//#pragma region Present
//		//Present to the screen
//		pSwapChain->Present(0, 0);
//		pContext->ClearState();
//#pragma endregion
//	}
//}
//
//template<class TYPE>
//void Renderer::CreateConstantBuffer(ID3D11Buffer ** ConstantBuffer, TYPE * data)
//{
//	//Get the size in multiple of 16
//	int DataSize = sizeof(*data);
//	int FourByteCount = DataSize / 16;
//	int ByteWidth = FourByteCount * 16;
//	if (ByteWidth < DataSize)
//		ByteWidth += 16;
//
//	D3D11_BUFFER_DESC Const_Buffer_Desc;
//	ZeroMemory(&Const_Buffer_Desc, sizeof(Const_Buffer_Desc));
//	Const_Buffer_Desc.ByteWidth = ByteWidth;
//	Const_Buffer_Desc.Usage = D3D11_USAGE_DYNAMIC;
//	Const_Buffer_Desc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
//	Const_Buffer_Desc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
//
//	//Sub resource for hud data
//	D3D11_SUBRESOURCE_DATA Const_Buffer_Data;
//	Const_Buffer_Data.pSysMem = data;
//	Const_Buffer_Data.SysMemPitch = 0;
//	Const_Buffer_Data.SysMemSlicePitch = 0;
//
//	//Create World Matrix Constant Buffer
//	pDevice->CreateBuffer(&Const_Buffer_Desc, &Const_Buffer_Data, ConstantBuffer);
//}
//template<class TYPE>
//void Renderer::UpdateConstantBuffer(ID3D11Buffer * ConstantBuffer, TYPE data)
//{
//	D3D11_MAPPED_SUBRESOURCE MappedResource;
//	pContext->Map(ConstantBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &MappedResource);
//	memcpy_s(MappedResource.pData, sizeof(data), &data, sizeof(data));
//	pContext->Unmap(ConstantBuffer, 0);
//}
//XMFLOAT4X4 & Renderer::GetViewMatrix() const
//{
//	return MainCamera->GetViewMatrix();
//}
//XMFLOAT4X4 Renderer::GetProjectionMatrix()
//{
//	return ProjectionMatrix;
//}
//
//ID3D11Device* Renderer::GetRenderDevice()
//{
//	return pDevice;
//}
//
//ID3D11DeviceContext* Renderer::GetRenderDeviceContext()
//{
//	return pContext;
//}
//
//void SetDisplayMode(int iWidth, int iHeight)
//{
//	if (iWidth == 0 && iHeight == 0)
//	{
//		// Restore display settings to those stored in the registry.
//		ChangeDisplaySettings(NULL, 0);
//		return;
//	}
//
//	DEVMODE dm;
//	dm.dmSize = sizeof(DEVMODE);
//
//	int i = 0;
//
//	EnumDisplaySettings(NULL, ENUM_CURRENT_SETTINGS, &dm);
//	int iBpp = dm.dmBitsPerPel;
//	int iRefreshRate = dm.dmDisplayFrequency;
//
//	while (EnumDisplaySettings(NULL, i++, &dm))
//	{
//		// Iterate through the display settings until a match is found.
//		if (dm.dmPelsWidth == iWidth && dm.dmPelsHeight == iHeight &&
//			dm.dmBitsPerPel == iBpp && dm.dmDisplayFrequency == iRefreshRate)
//		{
//			dm.dmFields = DM_PELSWIDTH | DM_PELSHEIGHT | DM_BITSPERPEL | DM_DISPLAYFREQUENCY;
//
//			// Put the new settings into effect.
//			if (ChangeDisplaySettings(&dm, CDS_FULLSCREEN) == DISP_CHANGE_SUCCESSFUL)
//			{
//				return;
//			}
//		}
//	}
//}