#include "../Application/stdafx.h"
#include "Shaders.h"
#include "../Util/Util.h"
#include "D_Renderer.h"

#pragma region Shader Includes
#include "../../Shaders/VertexShader.csh"
//#include "../../Shaders/PixelShader.csh"
#include "../../Shaders/HUDGeometryShader.csh"
#include "../../Shaders/HUDVertexShader.csh"
#include "../../Shaders/HUDPixelShader.csh"
#include "../../Shaders/EffectBillboardGeomShader.csh"
#include "../../Shaders/EffectBillboardPixelShader.csh"
#include "../../Shaders/EffectBillboardVertexShader.csh"
#include "../../Shaders/CirclePixelShader.csh"
#include "../../Shaders/CircleVertexShader.csh"
#include "../../Shaders/TextVertexShader.csh"
#include "../../Shaders/TextGeometryShader.csh"
#include "../../Shaders/TextPixelShader.csh"
#include "../../Shaders/AnimationVertexShader.csh"
#include "../../Shaders/TelegraphVertexShader.csh"
#include "../../Shaders/TelegraphPixelShader.csh"
#include "../../Shaders/TelegraphGeometryShader.csh"
#include "../../Shaders/ParticleVertexShader.csh"
#include "../../Shaders/ParticlePixelShader.csh"
#include "../../Shaders/ParticleGeometryShader.csh"
#include "../../Shaders/GBuffer.csh"
#include "../../Shaders/PointLightPixel.csh"
#include "../../Shaders/PointLightVertex.csh"
#include "../../Shaders/FullScreenQuadGeom.csh"
#include "../../Shaders/Lum_FinalPass.csh"
#include "../../Shaders/Lum_DownScale_2x2.csh"
#include "../../Shaders/DownScale3x3.csh"
#include "../../Shaders/AmbLightPS.csh"
#include "../../Shaders/FullScreenQuadVS.csh"
#include "../../Shaders/GhostPixelShader.csh"
#include "../../Shaders/GlowHorizontalPass.csh"
#include "../../Shaders/GlowVerticalPass.csh"
#include "../../Shaders/ApplyGlowPS.csh"
#include "../../Shaders/Quad_Blur_GS.csh"

#pragma endregion

namespace Paragon_Renderer
{
	//Init Static members
	//Shaders * Shaders::pInstance = nullptr;
	CComPtr<ID3D11InputLayout> Shaders::p_Pos_UV_Norm_InputLayout = nullptr;
	CComPtr<ID3D11InputLayout> Shaders::p_Pos_UV_InputLayout = nullptr;
	CComPtr<ID3D11InputLayout> Shaders::p_Pos_InputLayout = nullptr;
	CComPtr<ID3D11InputLayout> Shaders::p_Animation_InputLayout = nullptr;
	CComPtr<ID3D11InputLayout> Shaders::p_Text_InputLayout = nullptr;
	CComPtr<ID3D11InputLayout> Shaders::p_ParticleInputLayout = nullptr;
	CComPtr<ID3D11InputLayout> Shaders::p_ScreenInputLayout = nullptr;
	CComPtr<ID3D11InputLayout> Shaders::p_FullScreenQuadInputLayout = nullptr;


	//Shaders
	CComPtr<ID3D11PixelShader> Shaders::BasicPixelShader = nullptr;
	CComPtr<ID3D11VertexShader> Shaders::BasicVertexShader = nullptr;
	CComPtr<ID3D11PixelShader> Shaders::GBufferPixelShader = nullptr;
	CComPtr<ID3D11PixelShader> Shaders::pGhostPixelShader = nullptr;

	CComPtr<ID3D11VertexShader> Shaders::pAnimVertexShader = nullptr;

	CComPtr<ID3D11PixelShader> Shaders::HUD_PixelShader = nullptr;
	CComPtr<ID3D11VertexShader> Shaders::HUD_VertexShader = nullptr;
	CComPtr<ID3D11GeometryShader> Shaders::HUD_GeomShader = nullptr;

	CComPtr<ID3D11PixelShader> Shaders::EffectPixelShader = nullptr;
	CComPtr<ID3D11VertexShader> Shaders::EffectVertexShader = nullptr;
	CComPtr<ID3D11GeometryShader> Shaders::EffectGeomShader = nullptr;

	CComPtr<ID3D11PixelShader> Shaders::pCollisionPixelShader = nullptr;
	CComPtr<ID3D11VertexShader> Shaders::pCollisionVertexShader = nullptr;

	CComPtr<ID3D11VertexShader> Shaders::pTextVertexShader = nullptr;
	CComPtr<ID3D11GeometryShader> Shaders::pTextGeomShader = nullptr;
	CComPtr<ID3D11PixelShader> Shaders::pTextPixelShader = nullptr;

	CComPtr<ID3D11PixelShader>    Shaders::TeleGPixelShader = nullptr;
	CComPtr<ID3D11VertexShader>   Shaders::TeleGVertexShader = nullptr;
	CComPtr<ID3D11GeometryShader> Shaders::TeleGGeomShader = nullptr;

	CComPtr<ID3D11VertexShader> Shaders::m_pParticleVertexShader = nullptr;
	CComPtr<ID3D11GeometryShader>	Shaders::m_pParticleGeomShader = nullptr;
	CComPtr<ID3D11PixelShader>	Shaders::m_pParticlePixelShader = nullptr;

	CComPtr<ID3D11PixelShader>	Shaders::m_PointLightPixel = nullptr;
	CComPtr<ID3D11VertexShader> Shaders::m_PointLightVertex = nullptr;
	CComPtr<ID3D11GeometryShader>	Shaders::m_FullScreenQuadGeomShader = nullptr;

	CComPtr<ID3D11PixelShader>	Shaders::m_LumFirstPassPS = nullptr;
	CComPtr<ID3D11PixelShader>	Shaders::m_LumThreeByThreePS = nullptr;
	CComPtr<ID3D11PixelShader>	Shaders::m_LumFinalPassPS = nullptr;

	CComPtr<ID3D11PixelShader> Shaders::m_AmbLightPS = nullptr;
	CComPtr<ID3D11PixelShader> Shaders::m_GlowVerticalBlend = nullptr;
	CComPtr<ID3D11PixelShader> Shaders::m_GlowHorizontalBlend = nullptr;
	CComPtr<ID3D11PixelShader> Shaders::m_ApplyGlowPS = nullptr;

	CComPtr<ID3D11VertexShader> Shaders::m_FullScreenVertexShader = nullptr;
	CComPtr<ID3D11GeometryShader> Shaders::m_FullScreenBlurShaderGS = nullptr;

	Shaders::Shaders()
	{
		//Static COM objects are initialized previously
	}
	Shaders::~Shaders(){}

	void Shaders::Initialize()
	{
		//Create Shaders
		D_Renderer::pDevice->CreateVertexShader(VertexShader, sizeof(VertexShader), NULL, &BasicVertexShader);
		//D_Renderer::pDevice->CreatePixelShader(PixelShader, sizeof(PixelShader), NULL, &BasicPixelShader);
		D_Renderer::pDevice->CreatePixelShader(GBuffer, sizeof(GBuffer), NULL, &GBufferPixelShader);
		D_Renderer::pDevice->CreatePixelShader(GhostPixelShader, sizeof(GhostPixelShader), NULL, &pGhostPixelShader);
		D_Renderer::pDevice->CreateVertexShader(HUDVertexShader, sizeof(HUDVertexShader), NULL, &HUD_VertexShader);
		D_Renderer::pDevice->CreatePixelShader(HUDPixelShader, sizeof(HUDPixelShader), NULL, &HUD_PixelShader);
		D_Renderer::pDevice->CreateGeometryShader(HUDGeometryShader, sizeof(HUDGeometryShader), NULL, &HUD_GeomShader);
		D_Renderer::pDevice->CreateVertexShader(EffectBillboardVertexShader, sizeof(EffectBillboardVertexShader), NULL, &EffectVertexShader);
		D_Renderer::pDevice->CreatePixelShader(EffectBillboardPixelShader, sizeof(EffectBillboardPixelShader), NULL, &EffectPixelShader);
		D_Renderer::pDevice->CreateGeometryShader(EffectBillboardGeomShader, sizeof(EffectBillboardGeomShader), NULL, &EffectGeomShader);
		D_Renderer::pDevice->CreateVertexShader(CircleVertexShader, sizeof(CircleVertexShader), NULL, &pCollisionVertexShader);
		D_Renderer::pDevice->CreatePixelShader(CirclePixelShader, sizeof(CirclePixelShader), NULL, &pCollisionPixelShader);
		D_Renderer::pDevice->CreateVertexShader(AnimationVertexShader, sizeof(AnimationVertexShader), NULL, &pAnimVertexShader);
		D_Renderer::pDevice->CreateVertexShader(TelegraphVertexShader, sizeof(TelegraphVertexShader), NULL, &TeleGVertexShader);
		D_Renderer::pDevice->CreatePixelShader(TelegraphPixelShader, sizeof(TelegraphPixelShader), NULL, &TeleGPixelShader);
		D_Renderer::pDevice->CreateGeometryShader(TelegraphGeometryShader, sizeof(TelegraphGeometryShader), NULL, &TeleGGeomShader);
		D_Renderer::pDevice->CreateVertexShader(TextVertexShader, sizeof(TextVertexShader), NULL, &pTextVertexShader);
		D_Renderer::pDevice->CreateGeometryShader(TextGeometryShader, sizeof(TextGeometryShader), NULL, &pTextGeomShader);
		D_Renderer::pDevice->CreatePixelShader(TextPixelShader, sizeof(TextPixelShader), NULL, &pTextPixelShader);
		D_Renderer::pDevice->CreateVertexShader(ParticleVertexShader, sizeof(ParticleVertexShader), NULL, &m_pParticleVertexShader);
		D_Renderer::pDevice->CreateGeometryShader(ParticleGeometryShader, sizeof(ParticleGeometryShader), NULL, &m_pParticleGeomShader);
		D_Renderer::pDevice->CreatePixelShader(ParticlePixelShader, sizeof(ParticlePixelShader), NULL, &m_pParticlePixelShader);
		D_Renderer::pDevice->CreatePixelShader(PointLightPixel, sizeof(PointLightPixel), NULL, &m_PointLightPixel);
		D_Renderer::pDevice->CreateVertexShader(PointLightVertex, sizeof(PointLightVertex), NULL, &m_PointLightVertex);
		D_Renderer::pDevice->CreateGeometryShader(FullScreenQuadGeom, sizeof(FullScreenQuadGeom), NULL, &m_FullScreenQuadGeomShader);
		D_Renderer::pDevice->CreatePixelShader(Lum_DownScale_2x2, sizeof(Lum_DownScale_2x2), NULL, &m_LumFirstPassPS);
		D_Renderer::pDevice->CreatePixelShader(DownScale3x3, sizeof(DownScale3x3), NULL, &m_LumThreeByThreePS);
		D_Renderer::pDevice->CreatePixelShader(Lum_FinalPass, sizeof(Lum_FinalPass), NULL, &m_LumFinalPassPS);
		D_Renderer::pDevice->CreatePixelShader(AmbLightPS, sizeof(AmbLightPS), NULL, &m_AmbLightPS);
		D_Renderer::pDevice->CreateVertexShader(FullScreenQuadVS, sizeof(FullScreenQuadVS), NULL, &m_FullScreenVertexShader);
		D_Renderer::pDevice->CreatePixelShader(GlowHorizontalPass, sizeof(GlowHorizontalPass), NULL, &m_GlowHorizontalBlend);
		D_Renderer::pDevice->CreatePixelShader(GlowVerticalPass, sizeof(GlowVerticalPass), NULL, &m_GlowVerticalBlend);
		D_Renderer::pDevice->CreatePixelShader(ApplyGlowPS, sizeof(ApplyGlowPS), NULL, &m_ApplyGlowPS);
		D_Renderer::pDevice->CreateGeometryShader(Quad_Blur_GS, sizeof(Quad_Blur_GS), NULL, &m_FullScreenBlurShaderGS);

		//Create Standard Geometry Input Layout
		D3D11_INPUT_ELEMENT_DESC POS_UV_NORM[] =
		{
			{ "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
			{ "NORMAL", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
			{ "UV", 0, DXGI_FORMAT_R32G32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
			{ "TANGENT", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 }
		};

		//Create Input layout for Position and UV 
		D3D11_INPUT_ELEMENT_DESC POS_UV[] =
		{
			{ "UV", 0, DXGI_FORMAT_R32G32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
			{ "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 }
		};

		//Creat Input layout for Position
		D3D11_INPUT_ELEMENT_DESC POS[] =
		{
			{ "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 }
		};

		//Create Input layout for Animation
		D3D11_INPUT_ELEMENT_DESC ANIMATION[] =
		{
			{ "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
			{ "NORMAL", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
			{ "UV", 0, DXGI_FORMAT_R32G32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
			{ "TANGENT", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
			{ "BLENDINDICIES", 0, DXGI_FORMAT_R32G32B32A32_UINT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
			{ "BLENDWEIGHT", 0, DXGI_FORMAT_R32G32B32A32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 }
		};

		//Create Input layout for text - TODO:: This is the same as the POS_UV layout. Correct and remove this later
		D3D11_INPUT_ELEMENT_DESC TEXT[] =
		{
			{ "POSITION", 0, DXGI_FORMAT_R32G32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
			{ "UV", 0, DXGI_FORMAT_R32G32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 }
		};

		//Create input layout for fullscreen quad.
		//D3D11_INPUT_ELEMENT_DESC FULLSCREEN[] =
		//{
		//	{ "POSITION", 0, DXGI_FORMAT_R32G32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
		//	{ "TEXTCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 }
		//};

		D3D11_INPUT_ELEMENT_DESC FULLSCREEN[] =
		{
			{ "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
			{ "NORMAL", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
			{ "UV", 0, DXGI_FORMAT_R32G32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 }
		};

		//Create input layout for hud quad
		D3D11_INPUT_ELEMENT_DESC ParticleLayout[] =
		{
			{ "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
			{ "VELOCITY", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
			{ "ANGLE", 0, DXGI_FORMAT_R32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
			{ "ANGULAR_SPEED", 0, DXGI_FORMAT_R32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
			{ "TIME", 0, DXGI_FORMAT_R32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
			{ "IMPACT", 0, DXGI_FORMAT_R32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 }
		};

		//Creates the input layout
		D_Renderer::pDevice->CreateInputLayout(POS_UV_NORM, 4, VertexShader, sizeof(VertexShader), &p_Pos_UV_Norm_InputLayout);
		D_Renderer::pDevice->CreateInputLayout(POS_UV, 2, HUDVertexShader, sizeof(HUDVertexShader), &p_Pos_UV_InputLayout);
		D_Renderer::pDevice->CreateInputLayout(POS, 1, CircleVertexShader, sizeof(CircleVertexShader), &p_Pos_InputLayout);
		D_Renderer::pDevice->CreateInputLayout(ANIMATION, 6, AnimationVertexShader, sizeof(AnimationVertexShader), &p_Animation_InputLayout);
		D_Renderer::pDevice->CreateInputLayout(TEXT, 2, TextVertexShader, sizeof(TextVertexShader), &p_Text_InputLayout);
		D_Renderer::pDevice->CreateInputLayout(ParticleLayout, 6, ParticleVertexShader, sizeof(ParticleVertexShader), &p_ParticleInputLayout);
		D_Renderer::pDevice->CreateInputLayout(FULLSCREEN, 3, PointLightVertex, sizeof(PointLightVertex), &p_ScreenInputLayout);
		D_Renderer::pDevice->CreateInputLayout(POS_UV, 2, FullScreenQuadVS, sizeof(FullScreenQuadVS), &p_FullScreenQuadInputLayout);
	}

	void Shaders::Shutdown()
	{
		//Release all shaders
		BasicPixelShader.Release();
		BasicVertexShader.Release();
		pAnimVertexShader.Release();
		HUD_PixelShader.Release();
		HUD_VertexShader.Release();
		HUD_GeomShader.Release();
		EffectPixelShader.Release();
		EffectVertexShader.Release();
		EffectGeomShader.Release();
		pCollisionPixelShader.Release();
		pCollisionVertexShader.Release();
		pTextVertexShader.Release();
		pTextGeomShader.Release();
		pTextPixelShader.Release();
		TeleGPixelShader.Release();
		TeleGVertexShader.Release();
		TeleGGeomShader.Release();
		m_pParticleGeomShader.Release();
		m_pParticlePixelShader.Release();
		m_pParticleVertexShader.Release();
		GBufferPixelShader.Release();
		pGhostPixelShader.Release();
		m_PointLightPixel.Release();
		m_PointLightVertex.Release();
		m_FullScreenQuadGeomShader.Release();
		m_LumThreeByThreePS.Release();
		m_LumFirstPassPS.Release();
		m_LumFinalPassPS.Release();
		m_AmbLightPS.Release();
		m_FullScreenVertexShader.Release();
		m_GlowHorizontalBlend.Release();
		m_GlowVerticalBlend.Release();
		m_ApplyGlowPS.Release();
		m_FullScreenBlurShaderGS.Release();


		//Release all Input Layouts
		p_Pos_UV_Norm_InputLayout.Release();
		p_Pos_UV_InputLayout.Release();
		p_Pos_InputLayout.Release();
		p_Animation_InputLayout.Release();
		p_Text_InputLayout.Release();
		p_ParticleInputLayout.Release();
		p_ScreenInputLayout.Release();
		p_FullScreenQuadInputLayout.Release();


	}

	ID3D11InputLayout * Shaders::GetInputLayout(InputLayoutType Type)
	{
		switch (Type)
		{
		case Paragon_Renderer::IL_POS_UV_NORM:
			return p_Pos_UV_Norm_InputLayout;
		case Paragon_Renderer::IL_POS_UV:
			return p_Pos_UV_InputLayout;
		case Paragon_Renderer::IL_POS:
			return p_Pos_InputLayout;
		case Paragon_Renderer::IL_ANIMATION:
			return p_Animation_InputLayout;
		case Paragon_Renderer::IL_TEXT:
			return p_Text_InputLayout;
		case Paragon_Renderer::IL_PARTICLES:
			return p_ParticleInputLayout;
		default:
			return nullptr;
		}
	}

	void Shaders::Bind_Ghost_Anim_Pass()
	{
		D_Renderer::pContext->VSSetShader(pAnimVertexShader, NULL, 0);
		D_Renderer::pContext->PSSetShader(pGhostPixelShader, NULL, 0);
		D_Renderer::pContext->IASetInputLayout(p_Animation_InputLayout);
	}
	void Shaders::Bind_Ghost_Static_Pass()
	{
		D_Renderer::pContext->VSSetShader(BasicVertexShader, NULL, 0);
		D_Renderer::pContext->PSSetShader(pGhostPixelShader, NULL, 0);
		D_Renderer::pContext->IASetInputLayout(p_ScreenInputLayout);
	}
	void Shaders::Bind_HUD_Shaders()
	{
		D_Renderer::pContext->PSSetShader(HUD_PixelShader, NULL, 0);
		D_Renderer::pContext->VSSetShader(HUD_VertexShader, NULL, 0);
		D_Renderer::pContext->GSSetShader(HUD_GeomShader, NULL, 0);
		D_Renderer::pContext->IASetInputLayout(p_Pos_UV_InputLayout);
	}
	void Shaders::Bind_Billboard_Shaders()
	{
		D_Renderer::pContext->PSSetShader(EffectPixelShader, NULL, 0);
		D_Renderer::pContext->VSSetShader(EffectVertexShader, NULL, 0);
		D_Renderer::pContext->GSSetShader(EffectGeomShader, NULL, 0);
		D_Renderer::pContext->IASetInputLayout(p_Pos_UV_InputLayout);
	}
	void Shaders::Bind_Text_Shaders()
	{
		D_Renderer::pContext->PSSetShader(pTextPixelShader, NULL, 0);
		D_Renderer::pContext->VSSetShader(pTextVertexShader, NULL, 0);
		D_Renderer::pContext->GSSetShader(pTextGeomShader, NULL, 0);
		D_Renderer::pContext->IASetInputLayout(p_Text_InputLayout);
	}
	void Shaders::Bind_Telegraph_Shaders()
	{
		D_Renderer::pContext->PSSetShader(TeleGPixelShader, NULL, 0);
		D_Renderer::pContext->VSSetShader(TeleGVertexShader, NULL, 0);
		D_Renderer::pContext->GSSetShader(TeleGGeomShader, NULL, 0);
		D_Renderer::pContext->IASetInputLayout(p_Pos_UV_InputLayout);
	}
	void Shaders::Bind_Animation_VertexShader()
	{
		D_Renderer::pContext->VSSetShader(pAnimVertexShader, NULL, 0);
		//D_Renderer::pContext->PSSetShader(BasicPixelShader, NULL, 0);
		D_Renderer::pContext->PSSetShader(GBufferPixelShader, NULL, 0);
		D_Renderer::pContext->IASetInputLayout(p_Animation_InputLayout);
	}
	void Shaders::Bind_StaticGeom_Shader()
	{
		D_Renderer::pContext->VSSetShader(BasicVertexShader, NULL, 0);
		//D_Renderer::pContext->PSSetShader(BasicPixelShader, NULL, 0);
		D_Renderer::pContext->PSSetShader(GBufferPixelShader, NULL, 0);
		D_Renderer::pContext->IASetInputLayout(p_Pos_UV_Norm_InputLayout);
	}
	void Shaders::Bind_Particle_Shaders()
	{
		D_Renderer::pContext->VSSetShader(m_pParticleVertexShader, NULL, 0);
		D_Renderer::pContext->PSSetShader(m_pParticlePixelShader, NULL, 0);
		D_Renderer::pContext->GSSetShader(m_pParticleGeomShader, NULL, 0);
		D_Renderer::pContext->IASetInputLayout(p_ParticleInputLayout);
	}

	void Shaders::Bind_PointLight_Shaders()
	{
		D_Renderer::pContext->VSSetShader(m_PointLightVertex, NULL, 0);
		D_Renderer::pContext->PSSetShader(m_PointLightPixel, NULL, 0);
		D_Renderer::pContext->GSSetShader(NULL, NULL, 0);
		D_Renderer::pContext->IASetInputLayout(p_ScreenInputLayout);
	}

	//Lum Passes
	void Shaders::Bind_Lum_First_Pass()
	{
		D_Renderer::pContext->VSSetShader(m_FullScreenVertexShader, NULL, 0);
		D_Renderer::pContext->GSSetShader(m_FullScreenQuadGeomShader, NULL, 0);
		D_Renderer::pContext->PSSetShader(m_LumFirstPassPS, NULL, 0);
		D_Renderer::pContext->IASetInputLayout(p_FullScreenQuadInputLayout);
	}
	void Shaders::Bind_Lum_Second_Pass()
	{
		D_Renderer::pContext->VSSetShader(m_FullScreenVertexShader, NULL, 0);
		D_Renderer::pContext->GSSetShader(m_FullScreenQuadGeomShader, NULL, 0);
		D_Renderer::pContext->PSSetShader(m_LumThreeByThreePS, NULL, 0);
		D_Renderer::pContext->IASetInputLayout(p_FullScreenQuadInputLayout);
	}
	void Shaders::Bind_Lum_Final_Pass()
	{
		D_Renderer::pContext->VSSetShader(m_FullScreenVertexShader, NULL, 0);
		D_Renderer::pContext->GSSetShader(m_FullScreenQuadGeomShader, NULL, 0);
		D_Renderer::pContext->PSSetShader(m_LumFinalPassPS, NULL, 0);
		D_Renderer::pContext->IASetInputLayout(p_FullScreenQuadInputLayout);
	}

	void Shaders::Bind_Amb_Light_Pass()
	{
		D_Renderer::pContext->VSSetShader(m_FullScreenVertexShader, NULL, 0);
		D_Renderer::pContext->GSSetShader(m_FullScreenQuadGeomShader, NULL, 0);
		D_Renderer::pContext->PSSetShader(m_AmbLightPS, NULL, 0);
		D_Renderer::pContext->IASetInputLayout(p_FullScreenQuadInputLayout);
	}

	void Shaders::Bind_Horizontal_Glow_Shaders()
	{
		//D_Renderer::pContext->VSSetShader(m_FullScreenVertexShader, NULL, 0);
		//D_Renderer::pContext->GSSetShader(m_FullScreenBlurShaderGS, NULL, 0);
		D_Renderer::pContext->PSSetShader(m_GlowHorizontalBlend, NULL, 0);
		//D_Renderer::pContext->IASetInputLayout(p_FullScreenQuadInputLayout);
	}

	void Shaders::Bind_Vertical_Glow_Shaders()
	{
		D_Renderer::pContext->VSSetShader(m_FullScreenVertexShader, NULL, 0);
		D_Renderer::pContext->GSSetShader(m_FullScreenBlurShaderGS, NULL, 0);
		D_Renderer::pContext->PSSetShader(m_GlowVerticalBlend, NULL, 0);
		D_Renderer::pContext->IASetInputLayout(p_FullScreenQuadInputLayout);
	}
	void Shaders::Bind_Apply_Glow_Shaders()
	{
		//D_Renderer::pContext->VSSetShader(m_FullScreenVertexShader, NULL, 0);
		D_Renderer::pContext->GSSetShader(m_FullScreenQuadGeomShader, NULL, 0);
		D_Renderer::pContext->PSSetShader(m_ApplyGlowPS, NULL, 0);
		//D_Renderer::pContext->IASetInputLayout(p_FullScreenQuadInputLayout);
	}
}