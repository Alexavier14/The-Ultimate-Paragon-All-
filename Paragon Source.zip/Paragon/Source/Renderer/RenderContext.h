#pragma once

#include "RenderSet.h"

namespace Paragon_Renderer
{

	enum Context_Type { CT_STATIC_GEOM, CT_ANIM_GEOM, CT_EMISS_GEOM, CT_HUD, CT_BILLBOARD, CT_PARTICLE, CT_TELE, CT_POINT, CT_TEXT, CT_GHOST_ANIM, CT_GHOST_STATIC};

	class RenderContext
	{
	private:
		//Render set associated with this Context
		RenderSet * CurrentRenderSet;

		//Render Functions used to bind data to the DX pipeline for the current render set.
		void Bind_StaticGeometry();
		void Bind_AnimatedGeometry();
		void Bind_EmissiveGeometry();
		void Bind_HUD_Elements();
		void Bind_Text_Elements();
		void Bind_Effect_Billboard_Elements();
		void Bind_Particle_Elements();
		void Bind_Telegraph_Elements();
		void Bind_PointLight_Elements();
		void Bind_Ghost_Static();
		void Bind_Ghost_Animation();

		//The type associated with this context
		Context_Type ContextType;

	public:
		RenderContext(Context_Type Type);
		~RenderContext();

		void AddRenderNode(RenderNode * RN);

		void ClearRenderSet();
		void BindContext();

		//Accessors		
		RenderSet * GetRenderset();
		inline Context_Type GetTypeOfContext() { return ContextType; }

	};

}
