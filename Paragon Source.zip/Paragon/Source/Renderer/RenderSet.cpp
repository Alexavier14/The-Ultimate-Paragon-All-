#include "../Application/stdafx.h"

#include "RenderSet.h"
#include "D_Renderer.h"
#include "RenderNode.h"

namespace Paragon_Renderer
{
	RenderSet::RenderSet()
	{
		HeadNode = nullptr;
		TailNode = nullptr;
	}
	RenderSet::~RenderSet(){}

	RenderNode * RenderSet::GetHeadPointer()
	{
		return HeadNode;
	}
	void RenderSet::AddRenderNode(RenderNode * NodeToAdd)
	{
		if (HeadNode == nullptr)
		{
			HeadNode = TailNode = NodeToAdd;
			return;
		}

		TailNode->SetNext(NodeToAdd);
		TailNode = NodeToAdd;
		NodeToAdd->SetNext(nullptr);

	}
	void RenderSet::ClearRenderSet()
	{
		//Breaking the linked list chain
		HeadNode = TailNode = nullptr;
	}

}