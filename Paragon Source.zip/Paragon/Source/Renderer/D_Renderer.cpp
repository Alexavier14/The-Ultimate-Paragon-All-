#include "../Application/stdafx.h"
#include"D_Renderer.h"
#include "RenderNode.h"
#include "GraphicsDebugEvent.h"

namespace Paragon_Renderer
{
	//Base Directx Pointers
	CComPtr<ID3D11Device 				> D_Renderer::pDevice = NULL;
	CComPtr<ID3D11DeviceContext 		> D_Renderer::pContext = NULL;
	CComPtr<IDXGISwapChain 				> D_Renderer::pSwapChain = NULL;
	CComPtr<ID3D11RenderTargetView 		> D_Renderer::pRenderTargetView = NULL;
	CComPtr<ID3D11Texture2D 			> D_Renderer::pBackBuffer = NULL;
	CComPtr<ID3D11Texture2D 			> D_Renderer::pDepthStencilBuffer = NULL;
	CComPtr<ID3D11DepthStencilView  	> D_Renderer::pDepthStencilView = NULL;
	D3D11_VIEWPORT							D_Renderer::ScreenViewport;


	unsigned int D_Renderer::ScreenHeight = 0;
	unsigned int D_Renderer::ScreenWidth = 0;
	unsigned int D_Renderer::SampleQuality = 0;
	Camera * D_Renderer::MainCamera = 0;
	XMFLOAT4X4 D_Renderer::ProjectionMatrix = XMFLOAT4X4();

	D_Renderer::D_Renderer(){}
	D_Renderer::~D_Renderer(){}
	void D_Renderer::Initialize(HWND hWnd, HINSTANCE hInstance, bool bIsWindowed)
	{
		//Calculate the current screen size
		RECT CurrWindRect;
		GetClientRect(hWnd, &CurrWindRect);
		ScreenWidth = CurrWindRect.right - CurrWindRect.left;
		ScreenHeight = CurrWindRect.bottom - CurrWindRect.top;

		//Create the Camera
		MainCamera = new Camera;
		MainCamera->Initialize();

		//Proj matrix
		XMMATRIX matProjection = XMMatrixPerspectiveFovLH(XMConvertToRadians(45), (float)(ScreenWidth / ScreenHeight), 0.1f, 250.0f);
		XMStoreFloat4x4(&ProjectionMatrix, matProjection);

		// Data to create Dev and SwapChain
		const D3D_FEATURE_LEVEL FlagEleven = D3D_FEATURE_LEVEL_11_0;
		const D3D_FEATURE_LEVEL FL = D3D_FEATURE_LEVEL_10_1;
		D3D11_CREATE_DEVICE_FLAG flag;

#if _DEBUG
		flag = D3D11_CREATE_DEVICE_DEBUG;
#else 
		flag = D3D11_CREATE_DEVICE_SINGLETHREADED;
#endif

		DXGI_SWAP_CHAIN_DESC SC;
		ZeroMemory(&SC, sizeof(SC));
		SC.BufferCount = 1;
		SC.BufferDesc.Width = (UINT)ScreenWidth;
		SC.BufferDesc.Height = (UINT)ScreenHeight;
		SC.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
		SC.BufferDesc.RefreshRate.Numerator = 60;
		SC.BufferDesc.RefreshRate.Denominator = 1;
		SC.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
		SC.OutputWindow = hWnd;
		SC.SampleDesc.Count = 1;
		SC.SampleDesc.Quality = 0;
		SC.Windowed = true;

		D3D_FEATURE_LEVEL pFeatureLevel;

		// Data to create Dev and SwapChain
		D3D11CreateDeviceAndSwapChain(NULL, D3D_DRIVER_TYPE_HARDWARE, 0, flag, &FlagEleven, 1, D3D11_SDK_VERSION, &SC, &pSwapChain, &pDevice, &pFeatureLevel, &pContext);

		// Check to see the device support
		UINT Samp_Count = CURRENT_SAMPLE_COUNT;
		pDevice->CheckMultisampleQualityLevels(DXGI_FORMAT_R8G8B8A8_UNORM, Samp_Count, &SampleQuality);

		//Update the quality levels
		if (SampleQuality > 0)
			--SampleQuality;
		SC.SampleDesc.Count = Samp_Count;
		SC.SampleDesc.Quality = SampleQuality;

		//Release device and swapchain to create another
		pDevice.Release();
		pContext.Release();
		pSwapChain.Release();

		//Recreate Device and swapchain with the new quality levels
		D3D11CreateDeviceAndSwapChain(NULL, D3D_DRIVER_TYPE_HARDWARE, 0, flag, &FL, 1, D3D11_SDK_VERSION, &SC, &pSwapChain, &pDevice, &pFeatureLevel, &pContext);

		//Scale all buffers to fix the current window
		ResizeBuffers(ScreenWidth, ScreenHeight);

		//Reset to not be FS
		pSwapChain->SetFullscreenState(!bIsWindowed, NULL);
	}

	void D_Renderer::ShutDown()
	{
		//Clear Base COM
		pDevice.Release();
		pContext.Release();
		pSwapChain.Release();
		pRenderTargetView.Release();
		pBackBuffer.Release();
		pDepthStencilBuffer.Release();
		pDepthStencilView.Release();

		//Clear Camera
		SAFE_DELETE(MainCamera);
	}

	void D_Renderer::ResizeBuffers(unsigned int width, unsigned int height)
	{
		//Update the screen quad verts
		ConstantBuffers::GetInstance()->cbUpdate_Screen_Quad_Buffer(width, height);

		//return ResizeBuffersSolution(_width, _height);
		pRenderTargetView.Release();
		pDepthStencilBuffer.Release();
		pDepthStencilView.Release();
		pBackBuffer.Release();

		ScreenHeight = height;
		ScreenWidth = width;

		//Get the Back Buffer
		pSwapChain->GetBuffer(0, __uuidof(pBackBuffer), reinterpret_cast<void**>(&pBackBuffer));

		//Create the render target
		pDevice->CreateRenderTargetView(pBackBuffer, NULL, &pRenderTargetView);
		SetD3DName(pBackBuffer, "BackBuffer");


		// Create the Z-Buffer Texture and the Depth Stencil View
		D3D11_TEXTURE2D_DESC tDesc;
		ZeroMemory(&tDesc, sizeof(tDesc));
		tDesc.Width = (UINT)width;
		tDesc.Height = (UINT)height;
		tDesc.MipLevels = 1;
		tDesc.ArraySize = 1;
		tDesc.Format = DXGI_FORMAT_D32_FLOAT_S8X24_UINT;
		tDesc.SampleDesc.Count = CURRENT_SAMPLE_COUNT;
		tDesc.SampleDesc.Quality = SampleQuality;
		DXGI_SWAP_CHAIN_DESC TempSwapDesc;
		pSwapChain->GetDesc(&TempSwapDesc);
		tDesc.SampleDesc = TempSwapDesc.SampleDesc;
		tDesc.Usage = D3D11_USAGE_DEFAULT;
		tDesc.BindFlags = D3D11_BIND_DEPTH_STENCIL;
		tDesc.CPUAccessFlags = 0;
		tDesc.MiscFlags = 0;

		// Create the ZBuffer - 
		pDevice->CreateTexture2D(&tDesc, NULL, &pDepthStencilBuffer);

		D3D11_DEPTH_STENCIL_VIEW_DESC descDSV;
		ZeroMemory(&descDSV, sizeof(descDSV));
		descDSV.Format = DXGI_FORMAT_D32_FLOAT_S8X24_UINT;
#if USING_MSAA == 1
		descDSV.ViewDimension = D3D11_DSV_DIMENSION_TEXTURE2DMS;
#else 
		descDSV.ViewDimension = D3D11_DSV_DIMENSION_TEXTURE2D;
#endif
		descDSV.Texture2D.MipSlice = 0;

		pDevice->CreateDepthStencilView(pDepthStencilBuffer.p, &descDSV, &pDepthStencilView);

		//Set the render target view and zBuffer
		pContext->OMSetRenderTargets(1, &pRenderTargetView.p, pDepthStencilView.p);

		//Set up the view port.
		ScreenViewport.Height = (float)height;
		ScreenViewport.Width = (float)width;
		ScreenViewport.TopLeftX = 0;
		ScreenViewport.TopLeftY = 0;
		ScreenViewport.MinDepth = 0;
		ScreenViewport.MaxDepth = 1.0f;

		pContext->RSSetViewports(1, &ScreenViewport);
	}

	void D_Renderer::SetResolution(unsigned int width, unsigned int height, bool IsWindowed)
	{
		//Release com objects that will need to be reset
		pRenderTargetView.Release();
		pDepthStencilBuffer.Release();
		pDepthStencilView.Release();
		pBackBuffer.Release();

		//Resize the Buffers
		pSwapChain->ResizeBuffers(0, width, height, DXGI_FORMAT_UNKNOWN, DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH);
		ResizeBuffers(width, height);
		pSwapChain->SetFullscreenState(IsWindowed, NULL);
	}

	void D_Renderer::Render(RenderContext * CurRC)
	{
#if _DEBUG
		wstring eventName = L"default";
		switch (CurRC->GetTypeOfContext())
		{
		case CT_STATIC_GEOM:	eventName = L"Static Geometry";		break;
		case CT_ANIM_GEOM:		eventName = L"Animated Geometry";	break;
		case CT_EMISS_GEOM:		eventName = L"Emissive Geometry";	break;
		case CT_HUD:			eventName = L"HUD Elements";		break;
		case CT_BILLBOARD:		eventName = L"Billboards";			break;
		case CT_PARTICLE:		eventName = L"Particles";			break;
		case CT_TELE:			eventName = L"Telegraphs";			break;
		case CT_POINT:			eventName = L"Point Lights";		break;
		case CT_TEXT:			eventName = L"Text Elements";		break;
		case CT_GHOST_ANIM:      eventName = L"Ghost Anim";			break;
		}
		MarkEvent(eventName);
#endif

		RenderNode * ListItter = CurRC->GetRenderset()->GetHeadPointer();
		if ( ListItter != nullptr )
			CurRC->BindContext();

		while (ListItter != nullptr)
		{
			ListItter->RenderProcess(CurRC->GetTypeOfContext());
			ListItter = ListItter->GetNext();
		}
	}

	unsigned int D_Renderer::GetSampleQuality()
	{
		return SampleQuality;
	}
	unsigned int D_Renderer::GetSamepleCount()
	{
		return CURRENT_SAMPLE_COUNT;
	}
	unsigned int D_Renderer::GetScreenHeight()
	{
		return ScreenHeight;
	}
	unsigned int D_Renderer::GetScreenWidth()
	{
		return ScreenWidth;
	}

	Camera * D_Renderer::GetMainCamera()
	{
 		return MainCamera;
	}
	XMFLOAT4X4&  D_Renderer::GetProjectionMatrix()
	{
		return ProjectionMatrix;
	}
}