#include "../Application/stdafx.h"
#include "BlendStateManager.h"
#include "../Util/Util.h"
#include "D_Renderer.h"


namespace Paragon_Renderer
{
	CComPtr<ID3D11BlendState> BlendStateManager::pStates[BS_AMOUNT];
	B_State BlendStateManager::CurrentStateType = B_State::BS_DEFUALT;


	BlendStateManager::BlendStateManager(){}
	BlendStateManager::~BlendStateManager(){}

	void BlendStateManager::Initialize()
	{
		//Create the defualt blend state Blendstates 
		CurrentStateType = B_State::BS_DEFUALT;
		ApplyState(B_State::BS_DEFUALT);

		for (size_t i = 0; i < BS_AMOUNT; i++)
		{
			B_State state = B_State(i);

			//Defualt Blend State
			D3D11_BLEND_DESC blendDesc;
			blendDesc.AlphaToCoverageEnable = false;
			blendDesc.IndependentBlendEnable = false;
			blendDesc.RenderTarget[0].BlendEnable = FALSE;
			blendDesc.RenderTarget[0].SrcBlend = D3D11_BLEND_ONE;
			blendDesc.RenderTarget[0].DestBlend = D3D11_BLEND_ZERO;
			blendDesc.RenderTarget[0].BlendOp = D3D11_BLEND_OP_ADD;
			blendDesc.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ONE;
			blendDesc.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_ZERO;
			blendDesc.RenderTarget[0].BlendOpAlpha = D3D11_BLEND_OP_ADD;
			blendDesc.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;

			//Setup the new state
			switch (state)
			{
				case Paragon_Renderer::BS_DEFUALT:
				{
					pStates[state].Release();
					continue;
				}
				case Paragon_Renderer::BS_ADD:
				{
					blendDesc.RenderTarget[0].BlendEnable = TRUE;
					blendDesc.RenderTarget[0].SrcBlend = D3D11_BLEND_SRC_ALPHA;
					blendDesc.RenderTarget[0].DestBlend = D3D11_BLEND_INV_SRC_ALPHA;
					blendDesc.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ONE;
					blendDesc.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_ONE;
					break;
				}
				case Paragon_Renderer::BS_ALPA:
				{
					blendDesc.RenderTarget[0].BlendEnable = TRUE;
					blendDesc.RenderTarget[0].SrcBlend = D3D11_BLEND_SRC_ALPHA;
					blendDesc.RenderTarget[0].DestBlend = D3D11_BLEND_INV_SRC_ALPHA;
					blendDesc.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_SRC_ALPHA;
					blendDesc.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_INV_SRC_ALPHA;
					break;
				}
				case Paragon_Renderer::BS_LIGHT:
				{
					blendDesc.RenderTarget[0].BlendEnable = TRUE;
					blendDesc.RenderTarget[0].SrcBlend = D3D11_BLEND_SRC_ALPHA;
					blendDesc.RenderTarget[0].DestBlend = D3D11_BLEND_ONE;
					blendDesc.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ONE;
					blendDesc.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_ZERO;

					//blendDesc.RenderTarget[0].SrcBlend = D3D11_BLEND_ONE;
					//blendDesc.RenderTarget[0].DestBlend = D3D11_BLEND_ONE;
					//blendDesc.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ONE;
					//blendDesc.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_ZERO;
					break;
				}
				default:
					break;
			}

			pStates[state].Release();
			D_Renderer::pDevice->CreateBlendState(&blendDesc, &pStates[state]);

		}


	}
	void BlendStateManager::Shutdown()
	{
		//Cleanup Blendstates
		for (size_t i = 0; i < BS_AMOUNT; i++)
			pStates[i].Release();
			
	}

	void BlendStateManager::ApplyState(B_State state)
	{
		CurrentStateType = state;
		D_Renderer::pContext->OMSetBlendState(pStates[state], NULL, 0xffffffff);
		//BindCurrentState();
	}

	B_State BlendStateManager::GetCurrentStateType()
	{
		return CurrentStateType;
	}

	void BlendStateManager::BindCurrentState()
	{
		//D_Renderer::pContext->OMSetBlendState(pCurrentState, NULL, 0xffffffff);
	}
}

