#include "../Application/stdafx.h"

#include "Camera.h"
#include "../Util/Util.h"
#include "../Util/TimeManager.h"
#include <string>
#include "../Physics/Physics.h"
using namespace Physics;

#define CAMERA_SPEED 50.0f


Camera::Camera(){}
Camera::~Camera(){}
void Camera::Initialize()
{
	XMMATRIX WorldMat = XMMatrixIdentity();
	XMStoreFloat4x4(&CameraWorld, WorldMat);

	//View Matrix Init
	XMMATRIX ViewMat = XMMatrixInverse(0, WorldMat);
	XMStoreFloat4x4(&ViewMatrix, ViewMat);

}
void Camera::Update(XMFLOAT3 PlayerPos)
{
#if 1 //_DEBUG
	static bool DebugCamera = false;
			if( GetAsyncKeyState(VK_NUMPAD0) & 1 )
				DebugCamera = !DebugCamera;
			
			if( DebugCamera )
				UpdateDebugCameraPosition();
			else
				this->UpdateCameraPosition(PlayerPos);
#else
			this->UpdateCameraPosition(PlayerPos);
#endif

	XMMATRIX CameraWorldMat = XMLoadFloat4x4( &CameraWorld );
	XMMATRIX ViewMat = XMMatrixInverse(0, CameraWorldMat );
	XMStoreFloat4x4( &ViewMatrix, ViewMat);
}

XMFLOAT4X4 Camera::GetRendererViewMat()
{
	return ViewMatrix;
}
XMFLOAT4X4 Camera::GetViewMatrix()
{
	return ViewMatrix;
}

XMFLOAT4 Camera::GetCameraPos()
{
	XMMATRIX WorldMat = XMLoadFloat4x4(&CameraWorld);
	return XMCStoreFloat4(WorldMat.r[3]);
}

void Camera::SetCameraPos(XMFLOAT3 location)
{
	memcpy_s(CameraWorld.m[3], sizeof(XMFLOAT3), &location, sizeof(XMFLOAT3));
}

void Camera::UpdateCinematicCamera(XMFLOAT3 WaypointLoc, XMFLOAT3 DoorLocation)
{
	XMMATRIX WorldMat = XMLoadFloat4x4(&CameraWorld);
	

	//Position
	XMVECTOR CurrentLoc = WorldMat.r[3];
	XMFLOAT4 UpdatedWaypoint = XMFLOAT4(WaypointLoc.x, WaypointLoc.y, WaypointLoc.z, 1.0f);
	XMVECTOR LookAt = XMLoadFloat4(&UpdatedWaypoint);


	XMVECTOR NeedsToFace = LookAt - CurrentLoc;
	XMVECTOR HoldingPosition = XMVector3Normalize(NeedsToFace) * 50.0f * TimeManager::GetTimeDelta() + CurrentLoc;



	XMVECTOR distanceVec = XMVector4Length(LookAt - HoldingPosition);
	XMFLOAT4 distance;
	XMStoreFloat4(&distance, distanceVec);


	if (distance.x < 50.0f)
		HoldingPosition = CurrentLoc;




	//Up Vec
	XMFLOAT4 Up(0.0f, 1.0f, 0.0f, 0.0f);
	XMVECTOR UpVec = XMLoadFloat4(&Up);

	//Look At

	XMStoreFloat4x4(&ViewMatrix, XMMatrixLookAtLH(HoldingPosition, XMLoadFloat3(&DoorLocation), UpVec));
	XMStoreFloat4x4(&CameraWorld, XMMatrixInverse(0, XMLoadFloat4x4(&ViewMatrix)));
	return;

	//XMVECTOR ZAxis = XMVector3Normalize(XMLoadFloat3(&DoorLocation));
	//XMVECTOR XAxis = XMVector3Cross(UpVec, ZAxis);
	//XAxis = XMVector3Normalize(XAxis);
	//XMVECTOR YAxis = XMVector3Cross(ZAxis, XAxis);
	//YAxis = XMVector3Normalize(YAxis);

	//WorldMat.r[0] = (XAxis);
	//WorldMat.r[1] = (YAxis);
	//WorldMat.r[2] = (ZAxis);
	//WorldMat.r[3] = HoldingPosition;
	//XMStoreFloat4x4(&CameraWorld, WorldMat);

	//XMMATRIX ViewMat = XMMatrixInverse(0, XMLoadFloat4x4(&CameraWorld));
	//XMStoreFloat4x4(&ViewMatrix, ViewMat);
}

void Camera::UpdateCameraPosition(XMFLOAT3 PlayerPos)
{
	XMMATRIX WorldMat = XMLoadFloat4x4(&CameraWorld);

	const float cameraHeight = 70;

	//XMFLOAT4 CameraPos;
	XMVECTOR CameraPosition = WorldMat.r[3];
	CameraPosition = XMVectorSetY(CameraPosition, cameraHeight);
	CameraPosition = XMVectorSetW(CameraPosition, 1.0f);
	XMVECTOR TargetPos = XMLoadFloat3(&PlayerPos);

	//Position
	XMVECTOR velocityVel = XMVectorZero();

	XMVECTOR CameraDestination = TargetPos + XMCLoadFloat3(30, cameraHeight, 18);
	XMVECTOR deltaPos = CameraDestination - CameraPosition;
	deltaPos = XMVectorSetY(deltaPos, 0.0f);
	deltaPos = XMVectorSetW(deltaPos, 0.0f);
	float distance = XMCVector3Length(deltaPos);
	if (XMCVector3LengthSq(deltaPos) > EPSILON_DIST)
		velocityVel = XMVector3Normalize(deltaPos)*CAMERA_SPEED*(distance*0.2f);
	velocityVel = XMVector2ClampLength(velocityVel, 0.0f, CAMERA_SPEED);
	CameraPosition += velocityVel*TimeManager::GetTimeDelta();
	//CameraPosition = CameraDestination;

	XMVECTOR Up = XMCLoadFloat3(0,1,0);

	//Look At
	//XMVECTOR ZAxis = XMVector3Normalize(TargetPos - CameraPosition); // This makes the camera rotate towards the player
	XMVECTOR ZAxis = XMVector3Normalize(TargetPos - CameraDestination);
	XMVECTOR XAxis = XMVector3Cross(Up, ZAxis);
	XAxis = XMVector3Normalize(XAxis);
	XMVECTOR YAxis = XMVector3Cross(ZAxis, XAxis);
	YAxis = XMVector3Normalize(YAxis);
	CameraPosition = XMVectorSetW(CameraPosition, 1.0f);

	WorldMat.r[0] = (XAxis);
	WorldMat.r[1] = (YAxis);
	WorldMat.r[2] = (ZAxis);
	WorldMat.r[3] = CameraPosition;
	XMStoreFloat4x4(&CameraWorld, WorldMat);
}



void Camera::UpdateDebugCameraPosition()
{
	XMMATRIX WorldMat = XMLoadFloat4x4(&CameraWorld);

	float delta = TimeManager::GetTimeDelta();

	XMVECTOR TranslateVec = XMVectorZero();

	//Update Translation
	if ( GetAsyncKeyState(VK_NUMPAD6) ) //Right
		TranslateVec += XMLoadFloat3(&XMFLOAT3(CAMERA_SPEED, 0, 0));
	if ( GetAsyncKeyState(VK_NUMPAD4) ) //Left
		TranslateVec += XMLoadFloat3(&XMFLOAT3(-CAMERA_SPEED, 0, 0));
	if ( GetAsyncKeyState(VK_NUMPAD8) ) //Up
		TranslateVec += XMLoadFloat3(&XMFLOAT3(0, CAMERA_SPEED, 0));
	if ( GetAsyncKeyState(VK_NUMPAD2) )//Down
		TranslateVec += XMLoadFloat3(&XMFLOAT3(0, -CAMERA_SPEED, 0));
	if ( GetAsyncKeyState(VK_ADD) )//Forward
		TranslateVec += XMLoadFloat3(&XMFLOAT3(0, 0, CAMERA_SPEED));
	if ( GetAsyncKeyState(VK_SUBTRACT) )//Back
		TranslateVec += XMLoadFloat3(&XMFLOAT3(0, 0, -CAMERA_SPEED));
	
	XMMATRIX TranslationMatrix = XMMatrixTranslationFromVector(TranslateVec*delta);

	float rotationAngleY = 0;
	if ( GetAsyncKeyState(VK_NUMPAD1) )//Rotate Left
		rotationAngleY += 1.0f;
	if ( GetAsyncKeyState(VK_NUMPAD3) )//Rotate Left
		rotationAngleY += -1.0f;

	XMMATRIX YRotationMatrix = XMMatrixRotationY(rotationAngleY*delta);


	float rotationAngleX = 0;
	if ( GetAsyncKeyState(VK_NUMPAD7) )//Rotate Down
		rotationAngleX += 1.0f;
	if ( GetAsyncKeyState(VK_NUMPAD9) )//Rotate Up
		rotationAngleX += -1.0f;

	XMMATRIX XRotationMatrix = XMMatrixRotationX(rotationAngleX*delta);

	WorldMat = TranslationMatrix*YRotationMatrix*XRotationMatrix*WorldMat;

	//Reload the XMMatrix back to the float 4x4
	XMStoreFloat4x4(&CameraWorld, WorldMat);
}