#pragma once 
//#include "../Application/stdafx.h"
#include "../Renderer/RenderContext.h"


class RenderNode
{
private:
	RenderNode * Next;
	GameObject * ObjectData;

	void Static_Geom_Render();
	void Anim_Geom_Render();
	void Emiss_Geom_Render();
	void HUD_Ulit_Render();
	void Text_Ulit_Render();
	void Telegraph_Unlit_Render();
	void Billboard_Effect_Unlit_Render();
	void PointLight_Render();
	void Particle_Render();

public:
	RenderNode(GameObject* RenderableObject) { ObjectData = RenderableObject; }
	~RenderNode(){}

	//Function to determine which render process to call
	void RenderProcess(Paragon_Renderer::Context_Type PerObjectType);

	inline void SetNext(RenderNode * next) { Next = next; };
	inline RenderNode* GetNext(){ return Next; }
};