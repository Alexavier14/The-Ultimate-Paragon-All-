#pragma once
#include <atlcomcli.h>

namespace Paragon_Renderer
{
	enum B_State {BS_DEFUALT, BS_ADD, BS_ALPA, BS_LIGHT, BS_AMOUNT};
	class BlendStateManager
	{
	private:
		static CComPtr<ID3D11BlendState> pStates[BS_AMOUNT];
		static B_State CurrentStateType;
		static void BindCurrentState();

	public:
		BlendStateManager();
		~BlendStateManager();

		static void ApplyState(B_State BlendState);
		static void Initialize();
		static void Shutdown();

		B_State GetCurrentStateType();
	};

}