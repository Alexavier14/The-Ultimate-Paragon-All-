#include "../Application/stdafx.h"
#include "TrapComponent.h"
#include "../Util/TimeManager.h"


TrapComponent::TrapComponent(GameObject* parent, XMFLOAT3 offset, float total_time) : 
m_bEnabled(false), m_fTimer(0.0f), m_fTimeUntilActivated(0.0f), m_fTotalTime(total_time), m_bToMove(false), m_bTimerEnabled(true)
{

	m_fOffset = offset;

	if (parent != nullptr)
	{
		m_Parent = parent;
		m_fPosition = XMFLOAT4(parent->GetObjectTranslation().x + m_fOffset.x,
			parent->GetObjectTranslation().y + m_fOffset.y + 0.0f,
			parent->GetObjectTranslation().z + m_fOffset.z,
			1.0f);
	}
	else
	{
		m_fPosition = XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f);
	}
}

TrapComponent::~TrapComponent()
{
}

void TrapComponent::Update()
{
	//Update the effect visibility if toggled
	if (m_bEnabled && m_bTimerEnabled)
	{
		m_fTimer += TimeManager::GetTimeDelta();
		if (m_fTimer >= m_fTotalTime)
		{
			m_fTimer = 0.0f;
			m_bEnabled = false;
			
		}

	}

	//Update the trap position ------- TESTING ONLY!!!!!
	if (m_Parent != nullptr && m_bEnabled)
	{
		m_fPosition = XMFLOAT4(m_Parent->GetObjectTranslation().x + m_fOffset.x,
			m_Parent->GetObjectTranslation().y + m_fOffset.y,
			m_Parent->GetObjectTranslation().z + m_fOffset.z,
			1.0f);
	}

}