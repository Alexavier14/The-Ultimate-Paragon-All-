#include "..\Application\stdafx.h"
#ifndef EVENTCOMPONENT_H_
#define EVENTCOMPONENT_H_

#include "../Util/Clock.h"
#include <queue>

enum EventType 
{
	eDOOR_EVENT, 
	eWIN_EVENT,
	eWEB_EVENT,
};

class EventComponent
{

public:
	EventType m_EventType;

	std::queue<XMFLOAT3> CameraToDoorWaypoints;
	bool Triggered, finished, targeted;
	int TargetsRemaining;
	int InitialTargets;

	XMFLOAT3 m_Location;
	Clock m_Clock;

	EventComponent();
	~EventComponent();

	EventType GetEventType() const;
	void SetEventType(EventType eventType);

	XMVECTOR GetLocation() const;
	void SetLocation(XMVECTOR location);

};
#endif