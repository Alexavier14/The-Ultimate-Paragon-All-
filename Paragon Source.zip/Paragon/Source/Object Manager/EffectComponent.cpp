#include "../Application/stdafx.h"

#include "EffectComponent.h"
#include "../Physics/Physics.h"
using namespace Physics;

EffectComponent::EffectComponent(GameObject * pHolder, GameObject * pParent, XMFLOAT2 TextureSize, XMFLOAT3 PosOffset, XMFLOAT2 Pos)
{
	isEnabled = false;
	bIsTimed = true;

	Position.x = Pos.x;
	Position.y = Pos.y;

	Size = TextureSize;
	PositionOffset = PosOffset;

	Holder = pHolder;
	
	if (pParent != nullptr)
	{
		Parent = pParent;
		Position = XMCStoreFloat3(Parent->GetObjectTranslationVec() + XMLoadFloat3(&PositionOffset) );
	}
	else
	{
		Position = XMFLOAT3(0,0,0);
	}

	fEffectTimer = 0.0f;
	fTotalTime = 0.0f;
}


EffectComponent::~EffectComponent(){}

void EffectComponent::SetPosition(XMFLOAT4 pos)
{
	this->Position.x = pos.x;
	this->Position.y = pos.y;
	this->Position.z = pos.z;
}
void EffectComponent::Update(float time)
{
	//Update the effect visibility if toggled
	if (isEnabled && bIsTimed)
	{
		fEffectTimer += time;
		if (fEffectTimer > fTotalTime)
		{
			this->isEnabled = false;
			fEffectTimer = 0.0f;
		}

	}

	//Update the billboards pos
	if (Parent != nullptr && isEnabled)
	{
		Position = XMCStoreFloat3(Parent->GetObjectTranslationVec() + XMLoadFloat3(&PositionOffset) + XMCLoadFloat3(0,5,0) );
	}

}

void EffectComponent::ToggleEffect(bool TurnOn, float TotalTimeToDisplay)
{
	this->fTotalTime = TotalTimeToDisplay;

	if (TurnOn == true)
	{
		this->isEnabled = true;
	}
	else
	{
		this->isEnabled = false;
		this->fEffectTimer = fTotalTime;
	}
}

void EffectComponent::ToggleEffect(bool TurnOn)
{
	if (TurnOn == true)
	{
		this->isEnabled = true;
	}
	else
	{
		this->isEnabled = false;
		this->fEffectTimer = fTotalTime;
	}
}