#include "../Application/stdafx.h"
#include "../Util/Util.h"
#include "RendererComponent.h"

RendererComponent::RendererComponent()
{
	RendNode_MainRender = NULL;
	RendNode_SecondaryRender = NULL;
	DiffuseTexture = NULL;
	NormalMap = NULL;
	SpecularMap = NULL;
	EmisiveMap = NULL;
	TelegraphTexture = NULL;

	TextureFlags.UseEmisTex = false;
	TextureFlags.UseNormalTex = false;
	TextureFlags.UseSpecTex = false;
	TextureFlags.ApplyNormals = false;
}
RendererComponent::~RendererComponent(){}

void RendererComponent::ShutDown()
{
	SAFE_DELETE(RendNode_MainRender);
	SAFE_DELETE(RendNode_SecondaryRender);

	DiffuseTexture = NULL;
	NormalMap = NULL;
	SpecularMap = NULL;
	EmisiveMap = NULL;
	TelegraphTexture = NULL;
}

void RendererComponent::CreateAndSetRenderNode(GameObject * GO)
{
	//Update the texture flags to allow or not to apply normal maps
	if (m_RenderMesh && m_RenderMesh->GetApplyNormalMap() == true)
		TextureFlags.ApplyNormals = true;

	//Main Rendernode
	if (RendNode_MainRender != nullptr)
	{
		PrintConsole("An object is trying to create a render node that already had a valid render node. This can cause problems.");
	}
	else
	{
		RenderNode * NewNode = new RenderNode(GO);
		RendNode_MainRender = NewNode;
	}
	
	//Effect Pass Render Node
	if (RendNode_SecondaryRender != nullptr)
	{
		PrintConsole("An object is trying to create a render node that already had a valid render node. This can cause problems.");
	}
	else
	{
		RenderNode * NewNode = new RenderNode(GO);
		RendNode_SecondaryRender = NewNode;
	}
}