#pragma once
#include "../Application/stdafx.h"
#include "GameObject.h"
class TrapComponent
{
	float m_fTimer;
	float m_fTotalTime;
	float m_fTimeUntilActivated;
	bool m_bEnabled, m_bToMove;
	bool m_bTimerEnabled;
	GameObject* m_Parent;
	XMFLOAT3 m_fOffset;
	XMFLOAT4 m_fPosition;

public:
	TrapComponent(GameObject* parent, XMFLOAT3 offset, float total_time);
	~TrapComponent();

	void Update();

	GameObject* GetParent(void)			const { return m_Parent; }
	XMFLOAT3    GetOffset(void)			const { return m_fOffset; }
	XMFLOAT4	GetPosition(void)		const { return m_fPosition; }
	const bool	GetEnabled(void)		const { return m_bEnabled; }
	const bool	GetToMove(void)			const { return m_bToMove; }
	const bool	GetTimerEnabled(void)	const { return m_bTimerEnabled; }
	const float	GetTimeTillAct(void)	const { return m_fTimeUntilActivated; }
	const float	GetTimer(void)			const { return m_fTimer; }

	void	SetParent(GameObject* _parent)	{ m_Parent = _parent; }
	void	SetPosition(XMFLOAT4 _position)	{ m_fPosition = _position; }
	void	SetOffset(XMFLOAT3 _offset)		{ m_fOffset = _offset; }
	void	SetEnabled(bool _enabled)		{ m_bEnabled = _enabled; }
	void	SetTimerEnabled(bool _enabled)	{ m_bTimerEnabled = _enabled; }
	void	SetTimer(float _timer)			{ m_fTotalTime = _timer; }
	void	SetTimeTillAct(float _timer)	{ m_fTimeUntilActivated = _timer; }
	void	SetToMove(bool _move)			{ m_bToMove = _move; }
};

