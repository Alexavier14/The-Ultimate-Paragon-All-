#include "../Application/stdafx.h"
#include "EventComponent.h"
#include "../Physics/Physics.h"
using namespace Physics;

EventComponent::EventComponent() : Triggered(false), finished(false), 
TargetsRemaining(0), targeted(false)
{
}


EventComponent::~EventComponent()
{
}


EventType EventComponent::GetEventType() const
{
	return m_EventType;
}
void EventComponent::SetEventType(EventType eventType)
{
	m_EventType = eventType;
}

XMVECTOR EventComponent::GetLocation() const
{
	return XMLoadFloat3(&m_Location);
}
void EventComponent::SetLocation(XMVECTOR location)
{
	m_Location = XMCStoreFloat3(location);
}
