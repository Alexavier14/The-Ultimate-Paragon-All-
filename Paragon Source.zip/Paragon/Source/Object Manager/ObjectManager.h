#include "../Application/stdafx.h"

#pragma once

#include "GameObject.h"
#include "HUDElement.h"
#include "Telegraph.h"

#include "../Text Manager/TextBox.h"

using namespace std;

class CoreFacade;

class ObjectManager
{
private:
	//Main List of all of the game objects used in the level. Used for clean up
	vector<GameObject*> m_GameObjects;
	
	//A vector of game objects that are loaded and are waiting to be added to the main list
	vector<GameObject*> m_LoadingObjects;

	//Storage for all of the game objects that we can return to other systems for access without looping through the general list
	vector<GameObject*> Geodes;
	vector<GameObject*> Anvils;
	vector<GameObject*> Spiders;
	vector<GameObject*> Golems;
	vector<GameObject*> Worms;
	vector<GameObject*> Nodes;
	vector<GameObject*> StaticLevelObjects;
	vector<GameObject*> Walls;
	vector<GameObject*> AllEnemies;
	vector<GameObject*> GeodeTargets;
	vector<GameObject*> Gems;
	vector<GameObject*> Doors;
	vector<GameObject*> HUD;
	vector<GameObject*> Telegraphs;
	vector<GameObject*> Effects;
	vector<GameObject*> Emitters;
	vector<GameObject*> TextBoxes; 
	vector<GameObject*>	PointLights;
	vector<GameObject*>	Torches;
	vector<GameObject*> SpiderTraps;
	vector<GameObject*> FallRocks;
	vector<GameObject*> WormTraps;
	vector<GameObject*> Elevators;
	vector<GameObject*> Spawners;
	vector<GameObject*> ParagonHolders;

	GameObject* Player;
	GameObject* PressurePlate;
	//GameObject* Elevator; 
	GameObject* Reticle;
	GameObject* HitMark;
	GameObject* ArrowMarker;
	GameObject* PlayerWayPoint;
	//GameObject* Emitter3D;
	GameObject* WormAttack;

	GameObject* Loading_Player;
	GameObject* Loading_WormAttack;
	GameObject* Loading_TransitionScreen;
	GameObject* Loading_PressurePlate;
	GameObject* Loading_Reticle;
	GameObject* Loading_HitMark;
	GameObject* Loading_ArrowMarker;
	GameObject* Loading_PlayerWayPoint;
	GameObject* Paragon;
	GameObject* Hammer;

	bool IsLoadingState;
	GameObject * TransitionScreen;

public:
	ObjectManager();
	~ObjectManager();

	GameObject * GetGameObject( int index );
	
	void ClearAllLoadedObjects();
	bool AddGameObject(GameObject* ObjectToAdd);
	void Update(CoreFacade* coreFacade);
	void LoadingComplete();
	void SetLoadingState(bool isLoading);

	//Get the current render set
	vector<GameObject*>& GetRenderSet();

	//Access to all of the Game Objects
	GameObject* GetPlayer();
	GameObject* GetReticle();
	GameObject* GetHitMark();
	GameObject* GetPressurePlate();
	GameObject* GetArrowMarker();
	GameObject* GetTransitionScreen();
	GameObject* GetParagon();
	GameObject* GetHammer();
	vector<GameObject*>& GetGeodeTargets();
	vector<GameObject*>& GetAnvils();
	const vector<GameObject*>& GetGeodes();
	vector<GameObject*>& GetSpiders();
	vector<GameObject*>& GetGolems();
	vector<GameObject*>& GetWorms();
	vector<GameObject*>& GetMiningNodes();
	vector<GameObject*>& GetLevelObjects();
	vector<GameObject*>& GetAllEnemies();
	vector<GameObject*>& GetWalls();
	vector<GameObject*>& GetGems();
	vector<GameObject*>& GetDoors();
	vector<GameObject*>& GetHUDElements();
	vector<GameObject*>& GetTelegraphs();
	vector<GameObject*>& GetEffects();
	vector<GameObject*>& GetEmitters();
	vector<GameObject*>& GetTextBoxes();
	vector<GameObject*>& GetPointLights();
	vector<GameObject*>& GetTorches();
	vector<GameObject*>& GetSpiderTraps();
	vector<GameObject*>& GetFallRocks();
	vector<GameObject*>& GetWormTraps();
	vector<GameObject*>& GetElevators();
	vector<GameObject*>& GetSpawners();
	vector<GameObject*>& GetParagonHolders();

	GameObject * LoadingScreen;
	GameObject * GetGoalObject();
	GameObject * GetPlayerWaypointPointer();
	GameObject * GetWormAttack();

};

