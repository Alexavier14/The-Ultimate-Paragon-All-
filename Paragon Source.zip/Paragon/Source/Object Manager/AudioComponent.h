#pragma once

class GameObject;
class Entity3D;
class AudioSystemWwise;
class SoundManager;

class CAudioComponent
{
private:
	Entity3D* m_pEntity;
	GameObject* m_pHolder;
	AudioSystemWwise* m_pAudioSystem;
public:

	CAudioComponent(GameObject* GO, SoundManager* SoundManager);
	~CAudioComponent();

	void Update();
	void PlayAudioFollow(unsigned int audioID);
	void PlayAudioAtSpot(unsigned int audioID);
	void PlayAudio2D(unsigned int audioID);

};