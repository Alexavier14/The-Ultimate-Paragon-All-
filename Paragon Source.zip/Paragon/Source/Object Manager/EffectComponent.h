#include "../Application/stdafx.h"

#pragma once

#include "../Asset Manager/AssetManager.h"

class GameObject;

using namespace DirectX;
class EffectComponent
{
	GameObject * Parent;
	GameObject * Holder;
	float fEffectTimer;
	float fTotalTime;
	bool bIsTimed;

public:
	XMFLOAT3 Position;
	XMFLOAT3 PositionOffset;
	XMFLOAT2 Size;
	bool isEnabled;

	EffectComponent(GameObject * pHolder, GameObject * pParent, XMFLOAT2 TextureSize, XMFLOAT3 PositionOffset, XMFLOAT2 Position);
	~EffectComponent();

	void Update(float time);
	void ToggleEffect(bool TurnOn, float TotalTimeToDisplay);
	void ToggleEffect(bool TurnOn);
	GameObject * GetParent() const { return Parent; };
	GameObject * GetHolder() const { return Holder; };
	const float GetTotalTime() const { return fTotalTime; };

	void SetPosition(XMFLOAT4 pos);
	void SetHolder(GameObject * holder)		{ Holder = holder; };
	void SetParent(GameObject * parent)		{ Parent = parent; };
	void SetEffectTimer(float Time)			{ fEffectTimer = Time; };
	void SetTotalTime(float Time)			{ fTotalTime = Time; };
	void SetIsTimed(bool isTimed)			{ bIsTimed = isTimed; };
};

