#include "../Application/stdafx.h"
#include "PointLightComponent.h"
#include "../Util/Util.h"
#include "../Util/TimeManager.h"
#include "GameObject.h"
#include "../Physics/Physics.h"
using namespace Physics;

#define SEND_COLOR_FADE_TIME 3.0f

XMFLOAT3 PointLightComponent::SapphireSendColor = XMFLOAT3(0.1f, 0.4f, 1.0f);
XMFLOAT3 PointLightComponent::RubySendColor = XMFLOAT3(1.0f, 0.1f, 0.2f);
XMFLOAT3 PointLightComponent::DiamondSendColor = XMFLOAT3(1.0f, 1.0f, 1.0f);
XMFLOAT3 PointLightComponent::LastGeodeSentColor = XMFLOAT3(1.0f, 1.0f, 1.0f);

XMFLOAT3 PointLightComponent::TorchColor1 = XMFLOAT3(1.0f, 1.0f, 1.0f);
XMFLOAT3 PointLightComponent::TorchColor2 = XMFLOAT3(1.0f, 1.0f, 1.0f);

float PointLightComponent::SentGeodeTimer = SEND_COLOR_FADE_TIME;

PointLightComponent::PointLightComponent(Paragon_Renderer::cbPOINT_LIGHT PLD)
{
	FullFadeAtten = XMFLOAT3(1.0f, 1.0f, 1.0f);
	NoFadeAtten = PLD.attenuation;
	LightFadeRatio = 0;
	

	FlickerTimer = 0.0f;
	FollowParentY = false;
	ToggleUp = false;
	Parent = nullptr;
	AddFlicker = false;
	FollowParent = false;

	UpperSwitchLimit = 0.003f;
	LowerSwitchLimit = 0.001f;
	
	PointLightData = PLD;
	StartingDiffuseColor = PLD.diffuseColor;
	StartingAmbColor = PLD.ambientColor;

	LastGeodeSentColor = PLD.diffuseColor;
	AttenValue = 0.0f;

	OffsetFromForward = XMFLOAT3(0.0f, 0.0f, 0.0f);
}
PointLightComponent::~PointLightComponent(){}

void PointLightComponent::SetFadeOut(float FadeSpeed)
{
	if (FadeSpeed > 0.0f)
		FadeOutActive = true;
	LightFadeSpeed = FadeSpeed;
}

void PointLightComponent::SetFadeIn(float FadeSpeed)
{
	if (FadeSpeed > 0.0f)
		FadeInActive = true;
	LightFadeSpeed = FadeSpeed;
}
void PointLightComponent::SetRange(float Range)
{
	PointLightData.range = Range;
	XMFLOAT3 PointLightPos = Parent->GetObjectTranslation();
	XMMATRIX PointLightTransform = XMLoadFloat4x4(&Parent->GetWorldTransform());
	PointLightTransform = XMMatrixMultiply(PointLightTransform, XMMatrixScaling(Range, Range, Range));
	PointLightTransform = XMMatrixMultiply(PointLightTransform, XMMatrixTranslation(PointLightPos.x, PointLightPos.y, PointLightPos.z));
	Parent->SetObjectTransform(PointLightTransform);
}

void PointLightComponent::Update()
{
	//Update Fader
	if (FadeOutActive || FadeInActive)
	{
		if (FadeOutActive)
			LightFadeRatio -= LightFadeSpeed * TimeManager::GetTimeDelta();

		if (FadeInActive)
			LightFadeRatio += LightFadeSpeed * TimeManager::GetTimeDelta();

		//Fade Complete
		if (LightFadeRatio > 1.0f || LightFadeRatio < 0.0f)
		{
			FadeOutActive = false;
			FadeInActive = false;
			LightFadeSpeed = 0.0f;
		}
		else
		{
			//Update Atten
			XMVECTOR BaseAtten = XMLoadFloat3(&NoFadeAtten);
			XMVECTOR OutAtten = XMLoadFloat3(&FullFadeAtten);
			XMVECTOR NewAtten = XMVectorLerp(OutAtten, BaseAtten, LightFadeRatio);
			XMStoreFloat3(&PointLightData.attenuation, NewAtten);
		}
	}

	//Flicker
	if (AddFlicker == true)
	{
		FlickerTimer += TimeManager::GetTimeDelta();
		if (ToggleUp == false)
		{
			AttenValue -= 0.001f * TimeManager::GetTimeDelta();
		}
		else
		{
			AttenValue += 0.001f * TimeManager::GetTimeDelta();
		}

		if (AttenValue >= UpperSwitchLimit || AttenValue <= LowerSwitchLimit)
			ToggleUp = !ToggleUp;
	}

	if (FollowObject != nullptr)
	{
		if (OffsetFromForward.x != 0.0f || OffsetFromForward.y != 0.0f || OffsetFromForward.z != 0.0f)
		{
			XMVECTOR ForwardVev = XMVector4Normalize(FollowObject->GetForwardVec());
			XMFLOAT3 Forward;
			XMStoreFloat3(&Forward, ForwardVev);
			Forward.x *= OffsetFromForward.x;
			Forward.y *= OffsetFromForward.y;
			Forward.z *= OffsetFromForward.z;

			this->PointLightData.position.x = FollowObject->GetObjectTranslation().x + Forward.x;
			this->PointLightData.position.z = FollowObject->GetObjectTranslation().z + Forward.z;

			if (FollowParentY == true)
				this->PointLightData.position.y = FollowObject->GetObjectTranslation().y + 1.0f + Forward.y;
		}
		else
		{
			this->PointLightData.position.x = FollowObject->GetObjectTranslation().x;
			this->PointLightData.position.z = FollowObject->GetObjectTranslation().z;

			if (FollowParentY == true)
				this->PointLightData.position.y = FollowObject->GetObjectTranslation().y + 1.0f;
		}

		if (FollowObject->GetType() == ePLAYER || FollowObject->GetType() == eRETICLE)
		{
			if (SentGeodeTimer <= SEND_COLOR_FADE_TIME)
			{
				//Lerp
				XMVECTOR SendColor = XMLoadFloat3(&LastGeodeSentColor);
				XMVECTOR BaseDiffColor = XMLoadFloat3(&StartingDiffuseColor);
				XMVECTOR BaseAmbColor = XMLoadFloat3(&StartingAmbColor);


				float TimeRatio = SentGeodeTimer / SEND_COLOR_FADE_TIME;

				XMVECTOR LerpDiffColor = XMVectorLerp(SendColor, BaseDiffColor, TimeRatio);
				XMVECTOR LerpAmbColor = XMVectorLerp(SendColor, BaseAmbColor, TimeRatio);

				XMFLOAT3 FinalDiffColor;
				XMFLOAT3 FinalAmbColor;

				XMStoreFloat3(&FinalDiffColor, LerpDiffColor);
				XMStoreFloat3(&FinalAmbColor, LerpAmbColor);

				//Set Light Colors
				PointLightData.ambientColor = FinalAmbColor;
				PointLightData.diffuseColor = FinalDiffColor;

				//Update the timer
				SentGeodeTimer += TimeManager::GetTimeDelta();
			}
			else
			{
				PointLightData.ambientColor = StartingAmbColor;
				PointLightData.diffuseColor = StartingDiffuseColor;
			}
		}
	}
	
	
	//The Parent of evey light should be the physical sphere object
	if (Parent != nullptr)
	{ 
		XMMATRIX PointLightTransform = XMMatrixIdentity();
		PointLightTransform = XMMatrixMultiply(PointLightTransform, XMMatrixScaling(PointLightData.range, PointLightData.range, PointLightData.range));
		PointLightTransform = XMMatrixMultiply(PointLightTransform, XMMatrixTranslation(PointLightData.position.x, PointLightData.position.y, PointLightData.position.z));
		Parent->SetObjectTransform(PointLightTransform);
	}
}

void PointLightComponent::RubySent()
{
	LastGeodeSentColor = RubySendColor;
	SentGeodeTimer = 0.0f;
}
void PointLightComponent::SapphireSent()
{
	LastGeodeSentColor = SapphireSendColor;
	SentGeodeTimer = 0.0f;
}
void PointLightComponent::DiamondSent()
{
	LastGeodeSentColor = DiamondSendColor;
	SentGeodeTimer = 0.0f;
}
