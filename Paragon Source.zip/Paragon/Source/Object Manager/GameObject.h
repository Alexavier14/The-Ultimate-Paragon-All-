#include "../Application/stdafx.h"

// Author      : Daniel Stover
// Last Edited : 8/11/2014

#pragma once
using namespace DirectX;
//All of the components

class AIData;
class CAnimComponent;
class RendererComponent;
class PhysicsComponent;
class PlayerComponent;
class ReticleComponent;
class EffectComponent;
class EventComponent;
class SpawnerComponent;
class PointLightComponent;
class Telegraph;
class Emitter;
class HUDElement;
class TextBox;
class TrapComponent;
class NavAgent;
class CAudioComponent;
class SoundManager;

namespace Physics{ class Segment; };

class CoreFacade;
class CMesh;
struct ID3D11ShaderResourceView;

//Object types help distinguish what types they are.
enum ObjectType { 

	//Add To List When Exporting

	//Core Game Components
	ePLAYER, eRETICLE, eGOAL, eANVIL,
	//Geode types
	eRUBYGEODE, eSAPPHIREGEODE, eDIAMONDGEODE,
	//Enemy types
	eSPIDER, eGOLEM, eWORM,
	//Mining node types
	eRUBYNODE, eSAPPHIRENODE, eDIAMONDNODE,
	//Gem pickup types
	eRUBYGEM, eSAPPHIREGEM, eDIAMONDGEM, 
	//Misc
	eLEVEL, eWALL, eDOOR, eWAYPOINT, ePRESSUREPLATE, eELEVATOR, ePLAYERWAYPOINTMARKER, eARROWMARKER,
	eEFFECT, eHUD, eTELEGRAPH, eEMITTER, ePOINTLIGHT, eTEXTBOX, eTORCH, eEMITTER3D, eSPIDER_WEB, eDECORATION, eSPAWNER, 
	ePARAGON, eRUBYHOLDER, eSAPPHIREHOLDER, eDIAMONDHOLDER,


	//NOT USED IN EXPORTING
	eTRANSITION, eLOADSCREEN,
	eWORMATTACK/*Temporary enum*/, eROCK_TRAP, eWORM_TRAP,
	eHITMARK/* Display where the geodes*/, eHAMMER, 
};


//Used if there is only one effect for the object.
#define DEFAULT_EFFECT 0

//Base Times for effects
#define HIT_TIME		0.25f

//Struct for Color and Ratio Lerping
//Used By the Renderer
//Updated by the Game Object
//m_Color = the color to lerp towards
//m_Ratio = ratio of the color to lerp towards 
//m_Padding = is used only to make the structure 16 byte aligned
struct tObjectColor
{
	XMFLOAT4 	m_Color;
	float		m_Ratio;
	XMFLOAT3	m_Padding;

	tObjectColor() : m_Color(1.0f, 1.0f, 1.0f, 1.0f), m_Ratio(0.0f), m_Padding(-1.0f, -1.0f, -1.0f) {};
};

class GameObject
{
	// ---------------
	// --- Members ---
	// ---------------

	bool IsActive;
	bool isAnimated;
	bool isFocus;
	float m_fReactionTime;
	float m_fReactionTotalTime;

	//Core Components of the game object. 

	AIData *			 m_pAIData;
	CAnimComponent*		 m_pAnimComponent;
	RendererComponent*	 m_pRendererComponent;
	PhysicsComponent*	 m_pPhysicsComponent;
	PlayerComponent*	 m_pPlayerComponent;
	ReticleComponent*	 m_pReticleComponent;
	EffectComponent*     m_pEffectComponent;
	PointLightComponent* m_pPointLightComponent;
	Telegraph*           m_pTelegraphComponent;
	Emitter*             m_pEmitterComponent;
	HUDElement*          m_pHUDComponent;
	EventComponent*		 m_pEventComponent;
	TextBox*			 m_pTextComponent;
	TrapComponent*		 m_pTrapComponent;
	SpawnerComponent*	 m_pSpawnerComponent;
	NavAgent*			 m_pNavAgent;
	CAudioComponent*	 m_pAudioComponent;

	//Child Game Objects
	std::vector<GameObject*> GameObjects_Effects;
	std::vector<GameObject*> GameObject_Telegraphs;
	std::vector<GameObject*> GameObject_Emitters;
	std::vector<GameObject*> GameObject_HUD_Elements;
	std::vector<GameObject*> GameObject_PointLight_Children;

	GameObject*				GemDrop;

	XMFLOAT4X4 m_WorldMat;

	//GameObject Tag
	string m_Tag;
	ObjectType m_eTypeID;

	//GameObject Color for lerping
	tObjectColor m_tColor;

public:
	GameObject();
	~GameObject();
	
	// -----------------
	// --- Accessors ---
	// -----------------

	RendererComponent*		GetRendererComponent();
	AIData*					GetAIData() const;				//should have const before AIData *
	NavAgent*				GetNavAgent() const;
	CAnimComponent*			GetAnimComponent() const;
	PhysicsComponent*		GetPhysicsComponent();
	PlayerComponent*		GetPlayerComponent();
	ReticleComponent*		GetReticleComponent();
	TextBox*				GetTextComponent();
	EffectComponent*		GetEffectComponent();
	EffectComponent*		GetChildEffectComponent(int index);
	GameObject*				GetChildEffectObject(int index);
	GameObject*				GetChildGemObject();
	EventComponent*			GetEventComponent();
	SpawnerComponent*		GetSpawnerComponent();
	Telegraph*				GetChildTelegraphComponent(int index);
	Telegraph*				GetTelegraphComponent();
	Emitter*				GetChildEmitterComponent(int index);
	Emitter*				GetEmitterComponent();
	HUDElement*				GetHUDComponent();
	PointLightComponent*    GetPointLightComponent();
	GameObject*				GetChildPointLight(int index);
	CAudioComponent*		GetAudioComponent() const;

	ObjectType				GetType() const;
	const std::string&		GetTag( ) const;
	XMFLOAT4X4				GetWorldTransform() const;		
	XMMATRIX				GetWorldTransformMat() const;		
	XMFLOAT3				GetObjectTranslation() const;
	XMVECTOR				GetObjectTranslationVec() const;
	XMVECTOR				GetForwardVec() const;
	bool					GetActive()	const { return IsActive; };
	bool					IsAnimated() const { return isAnimated; }
	bool					IsFocused() const { return isFocus; };
	float					GetReactionTime() const { return m_fReactionTime; }
	tObjectColor			GetObjectColor() const;

	TrapComponent*			GetTrapComponent() const;

	//Where is it stored in Object manager
	int ObjectIndex; 

	//Color the object will highlight in ghost mode
	XMFLOAT4 GhostColor;

	// ----------------
	// --- Mutators ---
	// ----------------

	void	SetFocused(bool _isFocus) { isFocus = _isFocus; };
	void	SetActive(bool _Active) { IsActive = _Active; };
	void	SetIsAnimated(bool animated) { isAnimated = animated; }
	void	SetTypeID(ObjectType type);
	void	SetAIData(AIData * data);
	void	SetNavAgent(NavAgent* navAgent);
	void	SetRendererComponent(ID3D11ShaderResourceView* diffuse, ID3D11ShaderResourceView* normal, ID3D11ShaderResourceView* spec, ID3D11ShaderResourceView* glow, CMesh* meshData);
	void	SetPhysicsComponent( PhysicsComponent* physicsComponent );
	void	SetPlayerComponent( PlayerComponent* playerComponent );
	void	SetPointLightComponent(PointLightComponent * PL);
	void	SetTextBoxComponent(TextBox * TextBoxComp);
	void	SetReticleComponent( ReticleComponent* reticleComponent );
	void	SetEventComponent(EventComponent* eventComponent);
	void	SetAnimComponent(CAnimComponent* animComponent);
	void	SetTelegraphComponenet(Telegraph* TelegraphComponent);
	void	SetEffectComponent(EffectComponent* EffectComponent);
	void	SetSpawnerComponent(SpawnerComponent* SpawnerComponent);
	void	SetHUDComponent(HUDElement * HUDComponent);
	void	SetEmitterComponent(Emitter * EmitterComponent);

	void	AddEffectChildObject(GameObject * Effect_GameObject);
	void	AddTelegraphChildObject(GameObject* Teleraph_GameOjbect);
	void	AddEmitterChildObject(GameObject* Emitter_GameObject);
	void	AddGemChildObject(GameObject* pGem);
	void	AddPointLightChild(GameObject* pPointLight);

	void	SetObjectTransform(const XMMATRIX& transform );
	void	SetObjectTransform(const XMFLOAT4X4& transform );
	void	SetObjectTranslation( const XMFLOAT3& translation );
	void	SetObjectTranslation( const XMVECTOR& translation );
	void	SetTransformToIdentiy();
	void	SetTag(const std::string& tag);
	void	SetScale( float scale );
	void	SetReactionTime(float reaction_time);
	void	SetObjectColor(tObjectColor color);
	void	SetObjectColor(XMFLOAT4 color, float ratio = 0.0f);
	void	SetObjectColor(XMVECTOR color, float ratio = 0.0f);
	void	SetObjectColorRatio(float ratio);
	void	SetObjectColorAlpha(float alpha);
	void	SetTrapComponent(TrapComponent* tcomp);
	void	SetWorldTransform(XMMATRIX& transform);
	void	SetWorldTransform(XMFLOAT4X4& transform);

	// ---------------
	// --- Methods ---
	// ---------------

	void SteerTo(XMMATRIX * FINALPOS, float TurnSpeed, Physics::Segment *Left, Physics::Segment *Right, Physics::Segment *VelocityDist);
	void TurnTo(XMMATRIX * FinalPos, float TurnSpeed);
	void TurnTo(const XMVECTOR& FinalPos, float TurnSpeed, bool IgnoreY = true);
	void TurnRight(float TurnSpeed);
	void CreateAIData();
	void CreateAudioComponent(SoundManager* SM);
	void LookAt( XMVECTOR direction );
	void SetObjectTranslation(float x, float y, float z);
	void TakeDamage(short dmg = 1);

	//Shutdown Components
	void Shutdown();

	/*
		Calls Update on all of the object's components.
	*/
	void Update(CoreFacade* coreFacade);

};

