#include "../Application/stdafx.h"

#include "ReticleComponent.h"

#include "GameObject.h"
#include "PlayerComponent.h"
#include "PhysicsComponent.h"
#include "AnimComponent.h"
#include "../Particle System/Emitter.h"
#include "../Particle System/Particle.h"

#include "../Physics/Physics.h"
#include "../Physics/Segment.h"

#include "../Object Manager/PointLightComponent.h"

#include "../Application/CoreFacade.h"

#include <DirectXColors.h>

using namespace DirectX;
using namespace Physics;

#define RETICLE_SCAN_SIZE 6.0f

// Has to match with define on GeodeBehavior.cpp
#define GEODE_SEND_DIST 25.0f 

ReticleComponent::ReticleComponent(GameObject& holder) :
m_Holder(holder), m_bPlayerStop(false)
{
}


ReticleComponent::~ReticleComponent()
{
}



void ReticleComponent::Update(CoreFacade* pCoreFacade)
{
	if(pCoreFacade->FocusOnPlayer == false)
		return;

	UpdateRecall(pCoreFacade);
	UpdateMove(pCoreFacade);

	static bool rayPrediction = false;
	if( pCoreFacade->IsToggledKey( VK_F11 ) )
	   rayPrediction = !rayPrediction;

	//if(rayPrediction)
		UpdateRayPrediction( pCoreFacade );



}

void ReticleComponent::UpdateRayPrediction(CoreFacade* pCoreFacade)
{
	GameObject* pPlayer = pCoreFacade->m_ObjectManager->GetPlayer( );

	XMVECTOR reticlePos = XMCVector3SwizzleXZ(m_Holder.GetObjectTranslationVec());

	Segment* pSegment = dynamic_cast<Segment*>( pPlayer->GetPhysicsComponent()->GetCollisionShape(SU_EVENT) );
	XMVECTOR SegPos = pSegment->GetPosition();


	float closestDistSq = FLT_MAX;
	XMVECTOR closestIntersection = SegPos + XMLoadFloat2( &pSegment->GetExtent());
	ObjectType closestObjType = eRETICLE;

	auto& DetectedShapes = pSegment->GetDetectedShapes();
	for each ( CollisionShape* pShape in DetectedShapes )
	{
		GameObject* detectedHolder = pShape->GetGameObjectHolder();

		if(!detectedHolder->GetActive() && detectedHolder->GetType() != eWALL) // Walls are set as inactive
			continue; // Ignore inactive objects
		if( pShape->GetShapeUsage() != SU_BOUNDING_SHAPE )
			continue; // Only detect bounding shapes
		ObjectType detectedType = detectedHolder->GetType();

		switch (detectedType) 
		{
			case eRETICLE:
			case eANVIL:
			case ePLAYER:
			case eSAPPHIREGEODE:
			case eRUBYGEODE:
			case eDIAMONDGEODE:
				continue; // Ignore these types
		}
		XMVECTOR intersection = pSegment->Intersection(pShape );
		float distanceSq = XMCVector2LengthSq(intersection - SegPos);
		if (distanceSq < closestDistSq)
		{
			closestObjType = detectedType;
			closestDistSq = distanceSq;
			closestIntersection = intersection;
		}
	}
	
	GameObject* pHitMark = pCoreFacade->GetObjectManager()->GetHitMark();

	XMFLOAT4 markColor = XMCStoreFloat4( Colors::Honeydew );

	float distanceToMark = 0;
	float markScale = 0.7f;

	bool objectsDetected = closestDistSq < FLT_MAX;
	if(objectsDetected)
		distanceToMark = sqrtf(closestDistSq);

	bool showMark = objectsDetected;

	switch (closestObjType)
	{
		case eANVIL:
		case eWALL:
		case eDOOR:
			showMark = false; // Don't mark these types
	}

	if ( showMark )
	{
		pHitMark->SetActive(true);
		pHitMark->GetChildPointLight(0)->GetPointLightComponent()->SetRange(5.0f);
	}
	else
	{
		pHitMark->SetActive(false);
		pHitMark->GetChildPointLight(0)->GetPointLightComponent()->SetRange(0.0f);
	}

	pHitMark->SetObjectColor(markColor, 1.0f);
	pHitMark->SetTransformToIdentiy();
	pHitMark->SetScale(markScale);
	pHitMark->SetObjectTranslation( XMCVector2SwizzleXZ(closestIntersection) );

	
	XMVECTOR playerPos = XMCVector3SwizzleXZ(pPlayer->GetObjectTranslationVec());
	XMVECTOR direction = XMVector2Normalize( reticlePos - playerPos );

	XMFLOAT2 tipScale( 2.5f, 2.5f );
	XMFLOAT2 extensionScale( 2.5f, (distanceToMark - 2.0f*tipScale.y)*0.5f);

	if (!showMark)
	{
		tipScale.y = 0;
		extensionScale.y = 0;
	}

	Telegraph* pSendArrowTip = pPlayer->GetChildTelegraphComponent(0); // TODO: make enums for access
	pSendArrowTip->SetEnabled(true);
	pSendArrowTip->SetTime(100000);
	pSendArrowTip->SetDirection(XMCStoreFloat2( direction ) );
	pSendArrowTip->SetScale( tipScale );
	pSendArrowTip->SetOffset(XMCStoreFloat2( direction*(distanceToMark - tipScale.y) ) );

	Telegraph* pSendArrowExtension = pPlayer->GetChildTelegraphComponent(1);
	pSendArrowExtension->SetEnabled(true);
	pSendArrowExtension->SetTime(100000);
	pSendArrowExtension->SetDirection(XMCStoreFloat2( direction ) );
	pSendArrowExtension->SetScale( extensionScale );
	pSendArrowExtension->SetOffset(XMCStoreFloat2( direction*extensionScale.y ) );

	// Update Player to Reticle segment
	pSegment->SetPosition( playerPos );
	//XMVECTOR extent = direction*GEODE_SEND_DIST;
	XMVECTOR extent = reticlePos - playerPos;
	pSegment->SetExtent( XMCStoreFloat2( extent ) );
}


void ReticleComponent::UpdateRecall(CoreFacade* pCoreFacade)
{
	PhysicsComponent* pPhysics = m_Holder.GetPhysicsComponent();

	GameObject* pPlayer = pCoreFacade->m_ObjectManager->GetPlayer( );
	PlayerComponent* pPlayerComp = pPlayer->GetPlayerComponent();
	XMFLOAT4X4 reticleTransform;
	bool reticleGrowActive = true;

	// Position = (Cos(Theta), Theta, Sin(Theta)) * Radius;
	// XMRotateY(DeltaTime)
	// RotateY * World
	// Telegraph.cpp ZOffset
	// Rotate based on time
	// Use position offsets instead of radius
	if ( reticleGrowActive && pCoreFacade->IsPressing(BT_RECALL) )
	{
		m_Holder.GetChildEmitterComponent(0)->SetPositionOffset(XMFLOAT3(5.5f, 1.0f, 0.0f));
		m_Holder.GetChildEmitterComponent(1)->SetPositionOffset(XMFLOAT3(-5.5f, 1.0f, 0.0f));
		m_Holder.GetChildEmitterComponent(2)->SetPositionOffset(XMFLOAT3(0.0f, 1.0f, 5.5f));
		m_Holder.GetChildEmitterComponent(3)->SetPositionOffset(XMFLOAT3(0.0f, 1.0f, -5.5f));
		m_Holder.GetChildEmitterComponent(4)->SetPositionOffset(XMFLOAT3(4.0f, 1.0f, 4.0f));
		m_Holder.GetChildEmitterComponent(5)->SetPositionOffset(XMFLOAT3(-4.0f, 1.0f, -4.0f));
		m_Holder.GetChildEmitterComponent(6)->SetPositionOffset(XMFLOAT3(-4.0f, 1.0f, 4.0f));
		m_Holder.GetChildEmitterComponent(7)->SetPositionOffset(XMFLOAT3(4.0f, 1.0f, -4.0f));
		for (unsigned int index = 0; index < 8; index++)
		{
			m_Holder.GetChildEmitterComponent(index)->SetSpawning(true);
			m_Holder.GetChildEmitterComponent(index)->SetSpawnTimer(0.25f);
			//m_Holder.GetChildEmitterComponent(index)->SetPositionOffset(XMFLOAT3(5.5f, 1.0f, 0.0f));
			m_Holder.GetChildEmitterComponent(index)->SetSpawnRate(20.0f);
			m_Holder.GetChildEmitterComponent(index)->SetVelocityAverage(XMFLOAT3(2.0f, 0.0f, 0.0f));
			m_Holder.GetChildEmitterComponent(index)->SetPositionVariance(0.0f);
			m_Holder.GetChildEmitterComponent(index)->SetSpeedVariance(0.0f);
			m_Holder.GetChildEmitterComponent(index)->SetLifeTime(0.15f);
			m_Holder.GetChildEmitterComponent(index)->SetScale(0, XMFLOAT2(2.0f, 3.0f));
			m_Holder.GetChildEmitterComponent(index)->SetScale(1, XMFLOAT2(2.0f, 3.0f));
			//m_Holder.GetChildEmitterComponent(index)->Ro
		}

		if (!m_bPlayerStop)
		{
			m_bPlayerStop = true;
			XMVECTOR PlayerPos = pPlayer->GetObjectTranslationVec();
			pPlayerComp->SetDestination(XMCVector2GetXZ(PlayerPos));
		}
		XMStoreFloat4x4(&reticleTransform, XMMatrixScaling(6, 1, 6));
		m_Holder.SetObjectTransform(reticleTransform);
	}
	else
	{
		//m_bPlayerStop = false;
		m_Holder.GetChildEmitterComponent(0)->SetSpawning(false);
		m_Holder.GetChildEmitterComponent(1)->SetSpawning(false);
		m_Holder.GetChildEmitterComponent(2)->SetSpawning(false);
		m_Holder.GetChildEmitterComponent(3)->SetSpawning(false);
		m_Holder.GetChildEmitterComponent(4)->SetSpawning(false);
		m_Holder.GetChildEmitterComponent(5)->SetSpawning(false);
		m_Holder.GetChildEmitterComponent(6)->SetSpawning(false);
		m_Holder.GetChildEmitterComponent(7)->SetSpawning(false);
		//m_Holder.GetChildEmitterComponent(2)->SetSpawning(false);
		//m_Holder.GetChildEmitterComponent(0)->SetActive(false);
		//m_Holder.GetChildEmitterComponent(1)->SetSpawning(false);
		//m_Holder.GetChildEmitterComponent(1)->SetActive(false);
		
		XMStoreFloat4x4(&reticleTransform, XMMatrixScaling(1, 1, 1));
		m_Holder.SetObjectTransform(reticleTransform);
	}

	XMFLOAT4 color = XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f);
	if (!pCoreFacade->IsPressing(BT_RECALL))
	{
		list<Physics::CollisionShape*> collisions = pPhysics->GetCollisionShape(SU_BOUNDING_SHAPE)->GetDetectedShapes();
		for (auto iterator = collisions.begin(); iterator != collisions.end(); iterator++)
		{
			if ((*iterator)->GetCollisionShapeType() == SU_SCANNER)
				continue;

			GameObject* object = (*iterator)->GetPhysicsComponentHolder()->GetHolder();
			switch (object->GetType())
			{
			case ObjectType::eANVIL:
			case ObjectType::eDIAMONDNODE:
			case ObjectType::eRUBYNODE:
			case ObjectType::eSAPPHIRENODE:
			case ObjectType::eDIAMONDGEM:
			case ObjectType::eRUBYGEM:
			case ObjectType::eSAPPHIREGEM:
			case ObjectType::eSPIDER:
			case ObjectType::eGOLEM:
			case ObjectType::eWORM:
				color = XMFLOAT4(1.0f, 0.42f, 0.075f, 1.0f);
				break;
			case ObjectType::eWALL:
			case ObjectType::eDOOR:
				color = XMFLOAT4(1.0f, 0.0f, 0.0f, 1.0f);
				break;
			default:
				break;
			}
		}
	}
	else
		color = XMFLOAT4(0.0f, 0.0f, 1.0f, 1.0f);

	m_Holder.SetObjectColor(color, 1.0f);

}

void ReticleComponent::UpdateMove(CoreFacade* pCoreFacade)
{
	
	PhysicsComponent* pPhysics = m_Holder.GetPhysicsComponent();
	GameObject* pPlayer = pCoreFacade->m_ObjectManager->GetPlayer( );

	XMVECTOR mousePos = XMLoadFloat2(&pCoreFacade->GetMousePos());

	XMMATRIX view = XMLoadFloat4x4(&pCoreFacade->GetViewMatrix());
	XMMATRIX projection = XMLoadFloat4x4(&pCoreFacade->GetProjectionMatrix());
	XMVECTOR worldPos = XMVector3Unproject(mousePos, 0, 0, 1024, 768, 0.0f, 1.0f, projection, view, XMMatrixIdentity());
	
	// Picking algorithm

	XMVECTOR camPos = pCoreFacade->GetCameraPosition();
	XMVECTOR rayDir = XMVectorSubtract(worldPos, camPos);
	worldPos = XMVectorSetByIndex(worldPos, 0.0f, 1);

	XMVECTOR up = XMLoadFloat3(&XMFLOAT3(0, 1, 0));

	XMVECTOR intersection = Physics::IntersectRayPlane(up, 0, rayDir, camPos);

	// --- 

	m_Holder.SetObjectTranslation(intersection);

	if ( pCoreFacade->IsPressing( BT_MOVE ) )
	{
		auto& Walls = pCoreFacade->m_ObjectManager->GetWalls();
		CollisionShape* reticleBounds = pPhysics->GetCollisionShape(SU_BOUNDING_SHAPE);

		for (size_t i = 0; i < Walls.size(); i++)
		{
			GameObject* pWall = Walls[i];
			CollisionShape* wallBounds = pWall->GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE);
			if (reticleBounds->	Collides(wallBounds) )
				return;
		}

		GameObject* PointerEffect = pCoreFacade->m_ObjectManager->GetPlayerWaypointPointer();
		XMFLOAT2 IntersectionPoint = Physics::XMCVector2GetXZ(intersection);
		
		PointerEffect->GetEffectComponent()->ToggleEffect(true);
		PointerEffect->GetEffectComponent()->Position = XMFLOAT3(IntersectionPoint.x, 0.25f, IntersectionPoint.y);
		
		pPlayer->GetPlayerComponent( )->SetDestination( IntersectionPoint );

	}


}


