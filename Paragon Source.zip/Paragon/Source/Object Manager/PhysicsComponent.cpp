#include "../Application/stdafx.h"

#include "../Physics/Physics.h"
#include "AIData.h"

#include "PhysicsComponent.h"

#include "GameObject.h"
using namespace Physics;

//#define PHYSICS_DEBUG
#ifdef PHYSICS_DEBUG
#define PrintConsoleM PrintConsole
#else
#define PrintConsoleM __noop
#endif

#define DEFAULT_MASS 1.0f
#define MAX_SPEED 50.0f
PhysicsComponent::PhysicsComponent() :
m_bActive(false),
m_bAvailable(true),
m_Mass(DEFAULT_MASS)
{
	for (size_t iShp = 0; iShp < NUM_SHAPE_USES; iShp++)
		m_CollisionShapes[iShp] = NULL;

	Reset();
}
PhysicsComponent::~PhysicsComponent()
{
}

// --------------------------
// --- Accessors/Mutators ---
// --------------------------

bool PhysicsComponent::IsActive() const
{
	return m_bActive;
}
bool PhysicsComponent::IsAvailable() const
{
	return m_bAvailable;
}
GameObject*	PhysicsComponent::GetHolder()
{
	return m_pHolder;
}
CollisionShape* PhysicsComponent::GetCollisionShape(ShapeUsage shapeType)
{
	return m_CollisionShapes[shapeType];
}
DirectX::XMFLOAT2 PhysicsComponent::GetPosition() const
{
	return m_vPosition;
}
DirectX::XMFLOAT2 & PhysicsComponent::GetVelocity()
{
	return m_vVelocity;
}
float PhysicsComponent::GetMass() const
{
	return m_Mass;
}
float PhysicsComponent::GetFrameTime() const
{
	return m_FrameTime;
}

void PhysicsComponent::SetActive(bool bActive)
{
	m_bActive = bActive;
}
void PhysicsComponent::SetAvailable(bool bAvailable)
{
	m_bAvailable = bAvailable;
}
void PhysicsComponent::SetPosition(DirectX::XMFLOAT2 position)
{
	m_vPosition = position;
}
void PhysicsComponent::SetVelocity(DirectX::XMFLOAT2 velocity)
{
	XMVECTOR vel = XMLoadFloat2(&velocity);
	float speed = XMCVector2Length(vel);
	if (speed > MAX_SPEED)
	{
		//PrintConsoleM( "SLOW DOWN MAN" );
		vel *= MAX_SPEED / speed;
	}
	//if( m_vVelocity.x != m_vVelocity.x || m_vVelocity.y != m_vVelocity.y )
	//	PrintConsoleM( "WUT? NANANANANA" );
	XMStoreFloat2(&m_vVelocity, vel);
}
void PhysicsComponent::SetFrameTime(float frameTime)
{
	m_FrameTime = frameTime;
}
void PhysicsComponent::SetMass(float mass)
{
	m_Mass = mass;
}
void PhysicsComponent::SetForwardVelocity(float speed)
{
	XMVECTOR velocity = m_pHolder->GetForwardVec()*speed;
	m_vVelocity = XMCVector2GetXZ(velocity);
}
void PhysicsComponent::SetHolder(GameObject* pHolder)
{
	m_pHolder = pHolder;

	XMFLOAT3 translation = m_pHolder->GetObjectTranslation();
	m_vPosition.x = translation.x;
	m_vPosition.y = translation.z;

}
void PhysicsComponent::SetCollisionShape(CollisionShape* collisionShape, ShapeUsage shapeType)
{
	collisionShape->SetPhysicsComponentHolder(this);
	collisionShape->SetShapeUsage(shapeType);
	m_CollisionShapes[shapeType] = collisionShape;
}


// ---------------
// --- Methods ---
// ---------------

void PhysicsComponent::Update()
{
	m_FrameTime = 0;

	XMFLOAT3 translation = m_pHolder->GetObjectTranslation();
	translation.x = m_vPosition.x;
	translation.z = m_vPosition.y;
	m_pHolder->SetObjectTranslation(translation);
}

void PhysicsComponent::ActivateCollision()
{
	for (size_t iShp = 0; iShp < NUM_SHAPE_USES; iShp++)
		if (m_CollisionShapes[iShp])
			m_CollisionShapes[iShp]->SetActive(true);
}

void PhysicsComponent::DeactivateCollision()
{
	for (size_t iShp = 0; iShp < NUM_SHAPE_USES; iShp++)
		if (m_CollisionShapes[iShp])
			m_CollisionShapes[iShp]->SetActive(false);
}

void PhysicsComponent::Reset()
{
	DeactivateCollision();

	m_bActive = false;

	m_eResponseType = NO_RESPOSNSE;
	m_vPosition = XMFLOAT2(0, 0);
	m_vVelocity = XMFLOAT2(0, 0);

	DeactivateCollision();

	m_pHolder = NULL;

}

void PhysicsComponent::AdvanceSimulationTo(float deltaTime)
{
	XMVECTOR pos = XMLoadFloat2(&m_vPosition);
	XMVECTOR vel = XMLoadFloat2(&m_vVelocity);

	float dt = deltaTime - m_FrameTime;
	if (m_FrameTime != 0 || deltaTime != TimeManager::GetTimeDelta())
	{
		//PrintConsoleM( "Advance simulation from " + FloatToString( m_FrameTime) + " to " + FloatToString(deltaTime) );
		//PrintConsoleM( "dt = " + FloatToString( dt, 10 ));
	}

	if (dt < 0)
	{
		//dt = 0;
		//PrintConsoleM( "Backwards time advance attempted!");
	}
	//XMVECTOR move = vel*dt;
	//if ( XMCVector2Length( move ) > 1.0f )
	//{
	//	PrintConsoleM( "Big Movement!");
	//}
	//if ( XMCVector2Length( vel ) > 20.0f )
	//{
	//	PrintConsoleM( "Big Speed!");
	//}
	pos += vel*dt;

	XMStoreFloat2(&m_vPosition, pos);

	m_FrameTime = deltaTime;
}
