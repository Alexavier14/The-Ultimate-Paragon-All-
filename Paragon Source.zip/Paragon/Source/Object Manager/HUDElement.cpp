#include "../Application/stdafx.h"

#include "HUDElement.h"

HUDElement::HUDElement( ) : m_Width(0), m_Height(0),  m_XSceenPos(0),  m_YScreenPos(0) {isEnabled = true;}
HUDElement::~HUDElement(){}

HUDElement::HUDElement(float width, float height, float ScreenX, float ScreenY)
{
	m_Height = height;
	m_Width = width;
	m_XSceenPos = ScreenX;
	m_YScreenPos = ScreenY;
	m_Color = { 1.0f, 1.0f, 1.0f, 1.0f };
	m_ColorRatio = 0.0f;
	isEnabled = true;
}



