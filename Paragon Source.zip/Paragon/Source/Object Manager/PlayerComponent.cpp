#include "../Application/stdafx.h"

#include "PlayerComponent.h"
#include "PhysicsComponent.h"
#include "EffectComponent.h"
#include "AnimComponent.h"
#include "AudioComponent.h"
#include "../Physics/Physics.h"
#include "../Application/CoreFacade.h"
#include "../Physics/Circle.h"
#include "../Object Manager/AIData.h"
#include "../Util/Util.h"
#include "../Sound/SoundManager.h"
#include "../Sound/Entity3D.h"
#include "../Sound/AudioSystemWwise.h"
#include "../Sound/Wwise_IDs.h"
#include "../Particle System/Emitter.h"

#include "../Object Manager/EventComponent.h"
#include "../Object Manager/GameObject.h"

#include "../AI System/PathPlanner.h"
#include "../AI System/NavMesh.h"
#include "../AI System/NavAgent.h"

using namespace DirectX;
using namespace Physics;

#define GEODECAP 10

#define PLAYER_TRAIL_EMITTER 0
#define PLAYER_BOULDER_EMITTER 1
#define PLAYER_STORM1_EMITTER 2
#define ANVIL_CREATION_EMITTER 0
#define ANVIL_RUBY_CREATION_EMITTER 1
#define ANVIL_SAPP_CREATION_EMITTER 2
#define ANVIL_DIAM_CREATION_EMITTER 3

#define DEFAULT_PLAYER_SPEED 24.0f
#define DEBUG_PLAYER_SPEED 100.0f

#define DEFAULT_PLAYER_TURN_SPEED 10.0f

PlayerComponent::PlayerComponent(GameObject& holder) :
m_Holder(holder),
m_vDestination(0, 0),
m_bTravelToWaypoint(false),
m_bWalking(false),
m_StopUpdating(false),
m_bWinEventStarted(false),
m_bMovingOnElevator(false),
ElevatorMusicOn(false),
m_bCollidedWithDoor(false),
m_bStuck(false),
m_bKnockback(false),
m_TargetTrap(nullptr),
m_bInCombat(false),
Sholder(true),
Rholder(true),
Dholder(true), 
Captured(false)
{
	m_nHealth = 5;

	//Needs default for CORE
	m_nRGeodes = 0;
	m_nSGeodes = 0;
	m_nDGeodes = 0;

	m_nRGems = 0;
	m_nSGems = 0;
	m_nDGems = 0;
	m_bFirstGeode = true;
	m_vDestination = XMCVector2GetXZ(XMLoadFloat3(&holder.GetObjectTranslation()));

	m_PlayerSpeed = DEFAULT_PLAYER_SPEED;
	m_usEnemiesKilled = 0;

	m_nGemsGathered = 0;
	m_nGeodesCreated = 0;
	m_nGeodesLost = 0;

	LightningTimer = 1.0f;
}


PlayerComponent::~PlayerComponent()
{
}

void PlayerComponent::Initialize(CoreFacade* pCoreFacade)
{
	m_Holder.GetNavAgent()->SetMoveSpeed(DEFAULT_PLAYER_SPEED);
	m_Holder.GetNavAgent()->SetTurnSpeed(DEFAULT_PLAYER_TURN_SPEED);
}


void PlayerComponent::StopPlayer(bool StartOrStop, float Timer)
{
	m_StopUpdating = StartOrStop;
	if (StartOrStop)
		cStopMovingTimer.Start();
	WaitTimer = Timer;
}

void PlayerComponent::Update(CoreFacade* pCoreFacade)
{
	//Update the Y - Position at level start
	XMFLOAT3 PlayersPos = this->m_Holder.GetObjectTranslation();
	if (PlayersPos.y > 0.0f)
	{
		if (!ElevatorMusicOn)
			pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_SFX_ELEVATOR);
		PlayersPos.y -= 4.5f * TimeManager::GetTimeDelta();
		m_bMovingOnElevator = true;
		ElevatorMusicOn = true;
	}
	else
	{
		ElevatorMusicOn = false;
		m_bMovingOnElevator = false;
		PlayersPos.y = 0.0f;
	}

	for (size_t i = 0; i < pCoreFacade->m_ObjectManager->GetGeodeTargets().size(); i++)
	{
		if (pCoreFacade->m_ObjectManager->GetGeodeTargets()[i]->GetType() == eSAPPHIREHOLDER
			&& pCoreFacade->m_ObjectManager->GetGeodeTargets()[i]->GetAIData()->health <= 0)
		{
			Sholder = false;
		}
		else if (pCoreFacade->m_ObjectManager->GetGeodeTargets()[i]->GetType() == eRUBYHOLDER
			&& pCoreFacade->m_ObjectManager->GetGeodeTargets()[i]->GetAIData()->health <= 0)
		{
			Rholder = false;
		}
		else if (pCoreFacade->m_ObjectManager->GetGeodeTargets()[i]->GetType() == eDIAMONDHOLDER
			&& pCoreFacade->m_ObjectManager->GetGeodeTargets()[i]->GetAIData()->health <= 0)
		{
			Dholder = false;
		}
	}

	if (Sholder == false && Rholder == false && Dholder == false && Captured == true)
	{
		LightningTimer -= TimeManager::GetTimeDelta() * 1.0f;

		for (size_t i = 0; i < pCoreFacade->m_ObjectManager->GetAllEnemies().size(); i++)
		{
			if (pCoreFacade->m_ObjectManager->GetAllEnemies()[i]->GetActive() && pCoreFacade->m_ObjectManager->GetAllEnemies()[i]->GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE)->Collides(
				this->m_Holder.GetPhysicsComponent()->GetCollisionShape(SU_ATTACK))
				&& LightningTimer <= 0.0f)
			{
				pCoreFacade->m_ObjectManager->GetAllEnemies()[i]->TakeDamage(10);
				LightningTimer = 1.0f;
			}
		}
	}

	for (size_t i = 0; i < pCoreFacade->m_ObjectManager->GetGems().size(); i++)
	{
		if (pCoreFacade->m_ObjectManager->GetGems()[i]->GetActive()
			&&

			pCoreFacade->m_ObjectManager->GetGems()[i]->GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE)->Collides(
			this->m_Holder.GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE))
			
			&& 
			
			((pCoreFacade->m_ObjectManager->GetGems()[i]->GetType() == ePARAGON && pCoreFacade->m_ObjectManager->GetGems()[i]->GetAIData()->fActionCooldownB <= 0.4f) ||
			pCoreFacade->m_ObjectManager->GetGems()[i]->GetType() != ePARAGON))
		{
			//pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_SFX_GEM_PICKUP_01);
			m_Holder.GetAudioComponent()->PlayAudioFollow(PLAY_SFX_GEM_PICKUP_01);
			switch (pCoreFacade->m_ObjectManager->GetGems()[i]->GetType())
			{
			case ePARAGON:
			{
				this->m_Holder.GetChildEmitterComponent(4)->SetSpawning(true);
				this->m_Holder.GetChildEmitterComponent(4)->SetSpawnRate(30.0f);
				this->m_Holder.GetChildEmitterComponent(5)->SetSpawning(true);
				this->m_Holder.GetChildEmitterComponent(5)->SetSpawnRate(30.0f);
				this->m_Holder.GetChildEmitterComponent(6)->SetSpawning(true);
				this->m_Holder.GetChildEmitterComponent(6)->SetSpawnRate(50.0f);
				pCoreFacade->m_ObjectManager->GetGems()[i]->SetActive(false);
				pCoreFacade->m_ObjectManager->GetGems()[i]->GetPhysicsComponent()->DeactivateCollision();
				pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::STOP_BGM_GAUNTLET);
				pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_BGM_PARAGON_LOOP_07);
				pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_SFX_ELECTRICSTORM);
				Captured = true;
				break;
			}
			case eRUBYGEM:
			{
				AddGemCount(eRUBYGEM, 1);
				pCoreFacade->m_ObjectManager->GetGems()[i]->GetChildPointLight(0)->SetActive(false);
				if (!pCoreFacade->GetRubyUnlock())
				{
					pCoreFacade->SetRubyUnlock(true);
					vector<GameObject*>& Doors = pCoreFacade->m_ObjectManager->GetDoors();
					for each (GameObject* pDoor in Doors)
					{
						EventComponent* doorEvent = pDoor->GetEventComponent();
						doorEvent->TargetsRemaining--;
						if (doorEvent->TargetsRemaining == 0)
							doorEvent->Triggered = true;
					}
				}
				break;
			}
			case eSAPPHIREGEM:
			{
				AddGemCount(eSAPPHIREGEM, 1);
				pCoreFacade->m_ObjectManager->GetGems()[i]->GetChildPointLight(0)->SetActive(false);
				break;
			}
			case eDIAMONDGEM:
			{
				AddGemCount(eDIAMONDGEM, 1);
				pCoreFacade->m_ObjectManager->GetGems()[i]->GetChildPointLight(0)->SetActive(false);
				if (!pCoreFacade->GetDiamondUnlock())
				{
					pCoreFacade->SetDiamondUnlock(true);
					vector<GameObject*>& Doors = pCoreFacade->m_ObjectManager->GetDoors();
					for each (GameObject* pDoor in Doors)
					{
						EventComponent* doorEvent = pDoor->GetEventComponent();
						doorEvent->TargetsRemaining--;
						if (doorEvent->TargetsRemaining == 0)
							doorEvent->Triggered = true;
					}
				}
				break;
			}
			}
			pCoreFacade->m_ObjectManager->GetGems()[i]->SetActive(false);
			pCoreFacade->m_ObjectManager->GetGems()[i]->GetChildEmitterComponent(0)->SetSpawnRate(0);
			pCoreFacade->m_ObjectManager->GetGems()[i]->GetPhysicsComponent()->DeactivateCollision();
		}
	}
	//m_Holder.SetObjectTranslation(PlayersPos);

	// Movement 
	float delta = TimeManager::GetTimeDelta();

	PhysicsComponent& physics = *m_Holder.GetPhysicsComponent();
	XMVECTOR playerVel = XMLoadFloat2(&physics.GetVelocity());
	float playerSpeedSq = XMCVector2LengthSq(playerVel);


	if (m_bFirstGeode)
	{
		
		m_nSGems = 1;
		CreateGeode(pCoreFacade, eSAPPHIREGEODE);

		if (pCoreFacade->CurrentLevel == 2)
		{
			m_nDGems = 1;
			m_nRGems = 1;
			PrintConsole("creating other geodes");
			CreateGeode(pCoreFacade, eRUBYGEODE);
			CreateGeode(pCoreFacade, eDIAMONDGEODE);
		}
		
		m_bFirstGeode = false;
	}

	if (m_StopUpdating && cStopMovingTimer.Watch() > WaitTimer)
	{
		m_StopUpdating = false;
	}
	else if (m_StopUpdating)
	{
		physics.SetVelocity(XMFLOAT2(0, 0));
		return;
	}


	if (m_nHealth == 0)
		return;

	std::vector<GameObject*> trapList = pCoreFacade->GetObjectManager()->GetSpiderTraps();
	for (unsigned int index = 0; index < trapList.size(); index++)
	{
		if (trapList[index]->GetTrapComponent()->GetToMove())
			continue;
		if (trapList[index]->GetActive() == false)
		{
			if (m_TargetTrap)
			{
				if (trapList[index] == m_TargetTrap)
				{
					m_bStuck = false;
					m_TargetTrap = nullptr;
					break;
				}
			}

			continue;
		}
		else if (!m_bStuck)
		{
			if (physics.GetCollisionShape(SU_BOUNDING_SHAPE)->Collides(trapList[index]->GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE)))
			{
				m_TargetTrap = trapList[index];
				m_bStuck = true;
				break;
			}
		}
	}

	if (m_bMovingOnElevator == false && !m_bStuck)
		MoveToWaypoint(pCoreFacade);
	else if (m_bStuck)
		physics.SetVelocity(XMFLOAT2(0.f, 0.f));


	//else
	if (m_bKnockback)
	{
		static float dist_time = 0.0f;
		dist_time += TimeManager::GetTimeDelta();

		//Knock the player back.
		//Make the player take damage.
		if (m_fKnockbackDir.x == 0 && m_fKnockbackDir.y == 0)
			m_fKnockbackDir.y = 1.0f;
		m_Holder.GetPhysicsComponent()->SetVelocity({ m_fKnockbackDir.x * 21.0f, m_fKnockbackDir.y * 21.0f });
		if (dist_time > 1.5f)
		{
			HitPlayer(pCoreFacade, 1);
			m_bKnockback = false;
			dist_time = 0.0f;
		}
	}

	UpdateAudio(pCoreFacade);

	UpdateDebugControls(pCoreFacade);

	UpdateAnvils(pCoreFacade);

	Emitter* pBoulderDrop = m_Holder.GetChildEmitterComponent(PLAYER_BOULDER_EMITTER);
	pBoulderDrop->SetPosition(m_Holder.GetObjectTranslation());

}

bool PlayerComponent::GetPlayerInRangeAnvils(CoreFacade * CF)
{
	bool playerInRange = false;
	vector<GameObject*> Anvils = CF->m_ObjectManager->GetAnvils();
	for (unsigned int AnvilItter = 0; AnvilItter < Anvils.size(); AnvilItter++)
	{
		GameObject* pAnvil = Anvils[AnvilItter];
		auto PhyShapeList = pAnvil->GetPhysicsComponent()->GetCollisionShape(SU_SCANNER)->GetDetectedShapes();
		for each(CollisionShape* pShape in PhyShapeList)
		{
			if (pShape->GetShapeUsage() != SU_BOUNDING_SHAPE)
				continue;

			GameObject * possibleCollide = pShape->GetGameObjectHolder();
			if (possibleCollide->GetActive() == false)
				continue;

			if (possibleCollide->GetType() == ePLAYER)
			{
				playerInRange = true;
				break;
			}

		}
	}
	return playerInRange;
}
void PlayerComponent::UpdateAnvils(CoreFacade* pCoreFacade)
{
	vector<GameObject*> Anvils = pCoreFacade->m_ObjectManager->GetAnvils();
	for (unsigned int AnvilItter = 0; AnvilItter < Anvils.size(); AnvilItter++)
	{
		GameObject* pAnvil = Anvils[AnvilItter];
		Emitter* pCreationEmitter = pAnvil->GetChildEmitterComponent(ANVIL_CREATION_EMITTER);
		Emitter* pRubyCreationEmitter = pAnvil->GetChildEmitterComponent(ANVIL_RUBY_CREATION_EMITTER);
		Emitter* pSappCreationEmitter = pAnvil->GetChildEmitterComponent(ANVIL_SAPP_CREATION_EMITTER);
		Emitter* pDiamCreationEmitter = pAnvil->GetChildEmitterComponent(ANVIL_DIAM_CREATION_EMITTER);

		auto PhyShapeList = pAnvil->GetPhysicsComponent()->GetCollisionShape(SU_SCANNER)->GetDetectedShapes();
		bool playerInRange = false;
		for each(CollisionShape* pShape in PhyShapeList)
		{
			if (pShape->GetShapeUsage() != SU_BOUNDING_SHAPE)
				continue;

			GameObject * possibleCollide = pShape->GetGameObjectHolder();
			if (possibleCollide->GetActive() == false)
				continue;

			//EffectComponent * newEffect = m_Holder.GetChildEffectComponent(0);

			if (possibleCollide->GetType() == ePLAYER)
			{
				//pAnvil->GetChildEffectComponent(0)->isEnabled = true;
				playerInRange = true;
				break;
			}

		}

		if (playerInRange)
		{
			if (pCoreFacade->IsToggled(ButtonID::BT_RUBY))
				CreateGeode(pCoreFacade, eRUBYGEODE);

			if (pCoreFacade->IsToggled(ButtonID::BT_SAPP))
				CreateGeode(pCoreFacade, eSAPPHIREGEODE);

			if (pCoreFacade->IsToggled(ButtonID::BT_DIAM))
				CreateGeode(pCoreFacade, eDIAMONDGEODE);

			pCreationEmitter->SetSpawning(true);

			bool RubyAvailable = GetGemCount(eRUBYGEM) > 0 && GetGeodeCount(eRUBYGEODE) < GEODECAP && pCoreFacade->GetRubyUnlock();
			bool SappAvailable = GetGemCount(eSAPPHIREGEM) > 0 && GetGeodeCount(eSAPPHIREGEODE) < GEODECAP;
			bool Diamvailable = GetGemCount(eDIAMONDGEM) > 0 && GetGeodeCount(eDIAMONDGEODE) < GEODECAP && pCoreFacade->GetDiamondUnlock();

			pRubyCreationEmitter->SetSpawning(RubyAvailable);
			pSappCreationEmitter->SetSpawning(SappAvailable);
			pDiamCreationEmitter->SetSpawning(Diamvailable);
		}
		else
		{
			pAnvil->GetChildEffectComponent(0)->isEnabled = false;
			pCreationEmitter->SetSpawning(false);
			pRubyCreationEmitter->SetSpawning(false);
			pSappCreationEmitter->SetSpawning(false);
			pDiamCreationEmitter->SetSpawning(false);
		}
	}

	//This is where i'm adding the code for updating the anvil info
	tObjectColor geode_info;
	//Ruby Geodes
	if (GetGemCount(eRUBYGEM) > 0)
		geode_info.m_Padding.x = 0.0f;
	if (GetGemCount(eRUBYGEM) <= 0 && GetGeodeCount(eRUBYGEODE) > 0 || pCoreFacade->GetRubyUnlock() == false)
		geode_info.m_Padding.x = 1.0f;
	if (GetGemCount(eRUBYGEM) <= 0 && GetGeodeCount(eRUBYGEODE) <= 0 && pCoreFacade->GetRubyUnlock() == true)
		geode_info.m_Padding.x = 2.0f;
	if (GetGeodeCount(eRUBYGEODE) == GEODECAP)
		geode_info.m_Padding.x = 3.0f;

	//Sapphire Geodes
	if (GetGemCount(eSAPPHIREGEM) > 0)
		geode_info.m_Padding.y = 0.0f;
	if ((GetGemCount(eSAPPHIREGEM) <= 0 && GetGeodeCount(eSAPPHIREGEODE) > 0))
		geode_info.m_Padding.y = 1.0f;
	if (GetGemCount(eSAPPHIREGEM) <= 0 && GetGeodeCount(eSAPPHIREGEODE) <= 0)
		geode_info.m_Padding.y = 2.0f;
	if (GetGeodeCount(eSAPPHIREGEODE) == GEODECAP)
		geode_info.m_Padding.y = 3.0f;

	//Diamond Geodes
	if (GetGemCount(eDIAMONDGEM) > 0)
		geode_info.m_Padding.z = 0.0f;
	if ((GetGemCount(eDIAMONDGEM) <= 0 && GetGeodeCount(eDIAMONDGEODE) > 0) || pCoreFacade->GetDiamondUnlock() == false)
		geode_info.m_Padding.z = 1.0f;
	if (GetGemCount(eDIAMONDGEM) <= 0 && GetGeodeCount(eDIAMONDGEODE) <= 0 && pCoreFacade->GetDiamondUnlock() == true)
		geode_info.m_Padding.z = 2.0f;
	if (GetGeodeCount(eDIAMONDGEODE) == GEODECAP)
		geode_info.m_Padding.z = 3.0f;

	for (size_t i = 0; i < Anvils.size(); i++)
	{
		Anvils[i]->GetChildEffectObject(DEFAULT_EFFECT)->SetObjectColor(geode_info);
	}
}


void PlayerComponent::SetForward(XMFLOAT2 direction)
{
	float angleY = atan2(direction.x, direction.y);

	XMMATRIX worldTransform = XMLoadFloat4x4(&m_Holder.GetWorldTransform());
	XMMATRIX rotation = XMMatrixRotationY(angleY);
	XMMATRIX translation = XMMatrixTranslationFromVector(worldTransform.r[3]);
	worldTransform = XMMatrixMultiply(rotation, translation);
	m_Holder.SetObjectTransform(worldTransform);
}

void PlayerComponent::SetDestination(DirectX::XMFLOAT2 destination)
{
	//PrintConsole("SettingDestination");
	m_bTravelToWaypoint = true;
	m_vDestination = destination;

	XMFLOAT2 PlayerPos = XMCVector2GetXZ(m_Holder.GetObjectTranslationVec());
	m_Holder.GetNavAgent()->Begin(PlayerPos, destination);
}


void PlayerComponent::HitPlayer(CoreFacade* pCoreFacade, unsigned short nDamage)
{
	if (nDamage >= m_nHealth)
	{
		// Player Death
		m_nHealth = 0;

		m_Holder.GetAnimComponent()->SetAnimName(PLAYER_DEATH, false);
		m_Holder.GetAnimComponent()->SetIsDeathAnim(true);
		m_Holder.GetPhysicsComponent()->SetVelocity(XMFLOAT2(0.0f, 0.0f));
		m_Holder.GetPhysicsComponent()->DeactivateCollision();
		m_Holder.GetAudioComponent()->PlayAudioFollow(PLAY_ADR_BALIN_DEATH);
		//pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_ADR_BALIN_DEATH);
	}
	else
	{
		m_nHealth -= nDamage;
		m_Holder.GetAudioComponent()->PlayAudioFollow(PLAY_ADR_BALIN_HURT);
		//pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_ADR_BALIN_HURT);
	}

	m_Holder.SetReactionTime(HIT_TIME);
	m_Holder.SetObjectColor(XMFLOAT4(1.0f, 0.0f, 0.0f, 1.0f));
}

unsigned short PlayerComponent::GetHealth() const
{
	return m_nHealth;
}

unsigned short PlayerComponent::GetGeodeCount(ObjectType const GeodeType) const
{
	switch (GeodeType)
	{
	case eRUBYGEODE:
		return m_nRGeodes;
	case eSAPPHIREGEODE:
		return m_nSGeodes;
	case eDIAMONDGEODE:
		return m_nDGeodes;
	}

	return 0;
}

unsigned short PlayerComponent::GetGemCount(ObjectType const GemType) const
{
	switch (GemType)
	{
	case eRUBYGEM:
		return m_nRGems;
	case eSAPPHIREGEM:
		return m_nSGems;
	case eDIAMONDGEM:
		return m_nDGems;
	}

	return 0;
}

//AddGeodeCount
//GeodeType to access the correct counter
// - eRUBYGEODE == Ruby Geodes
// - eSAPPHIREGEODE == Sapphire Geode
// - eDIAMONDGEODE == Diamond Geode
//num is the number total to add.
//use negative numbers to reduce the count.
void PlayerComponent::AddGeodeCount(ObjectType GeodeType, short num)
{
	switch (GeodeType)
	{
	case eRUBYGEODE:
		m_nRGeodes += num;
		break;
	case eSAPPHIREGEODE:
		m_nSGeodes += num;
		break;
	case eDIAMONDGEODE:
		m_nDGeodes += num;
		break;
	}

	if (m_nRGeodes < 0)
		m_nRGeodes = 0;
	if (m_nSGeodes < 0)
		m_nSGeodes = 0;
	if (m_nDGeodes < 0)
		m_nDGeodes = 0;

	if (num > 0)
		m_nGeodesCreated += num;
	else
		m_nGeodesLost -= num;
}

//AddGeodeCount
//GemType to access the correct counter
// - eRUBYGEM == Ruby Gem
// - eSAPPHIREGEM == Sapphire Gem
// - eDIAMONDGEM == Diamond Gem
//num is the number total to add.
//use negative numbers to reduce the count.
void PlayerComponent::AddGemCount(ObjectType GemType, short num)
{
	switch (GemType)
	{
	case eRUBYGEM:
		m_nRGems += num;
		break;
	case eSAPPHIREGEM:
		m_nSGems += num;
		break;
	case eDIAMONDGEM:
		m_nDGems += num;
		break;
	}

	if (m_nRGems < 0)
		m_nRGems = 0;
	if (m_nSGems < 0)
		m_nSGems = 0;
	if (m_nDGems < 0)
		m_nDGems = 0;

	if (num > 0)
		m_nGemsGathered += num;
}

ObjectType GeodeToGem(ObjectType geodeType)
{
	switch (geodeType)
	{
	case eRUBYGEODE: return eRUBYGEM;
	case eSAPPHIREGEODE: return eSAPPHIREGEM;
	case eDIAMONDGEODE: return eDIAMONDGEM;
	}
	return ObjectType(-1);
}

void PlayerComponent::CreateGeode(CoreFacade* pCoreFacade, ObjectType geodeType)
{
	ObjectType gemType = GeodeToGem(geodeType);

	int geodeCount = GetGeodeCount(geodeType);
	int gemCount = GetGemCount(GeodeToGem(geodeType));

	bool bFreeGeode = false;
	if (gemCount == 0 && geodeCount == 0)
	{
		if ((geodeType == eRUBYGEODE && pCoreFacade->GetRubyUnlock() == false) ||
			(geodeType == eDIAMONDGEODE && pCoreFacade->GetDiamondUnlock() == false))
			return;
		else
		{
			PrintConsole("Created Free");
			bFreeGeode = true;
		}
	}
	else
	{
		if (geodeCount >= GEODECAP) return;
		if (gemCount < 1) return;
	}


	if (bFreeGeode)
	{
		m_Holder.GetAudioComponent()->PlayAudioFollow(PLAY_SFX_GEM_PICKUP_02);
		//pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_SFX_GEM_PICKUP_02);
	}
	else
	{
		m_Holder.GetAudioComponent()->PlayAudioFollow(PLAY_SFX_GEM_PICKUP_02);
		//pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_SFX_GEM_PICKUP_02);
		AddGemCount(gemType, -1);
	}

	//m_Holder.GetChildEffectComponent(0)->Position = XMFLOAT4(m_Holder.GetObjectTranslation().x, m_Holder.GetObjectTranslation().y, m_Holder.GetObjectTranslation().z, 1.0f);
	m_Holder.GetChildEffectComponent(0)->ToggleEffect(true);

	const vector<GameObject*>& Geodes = pCoreFacade->m_ObjectManager->GetGeodes();

	for (unsigned int index = 0; index < Geodes.size(); index++)
	{
		GameObject * pGeode = Geodes[index];
		if (pGeode->GetActive() == false && pGeode->GetType() == geodeType)
		{
			pGeode->SetActive(true);

			if (m_bFirstGeode)
				pGeode->GetAIData()->geodeState = AIData::GeIdle;
			else
				pGeode->GetAIData()->geodeState = AIData::GeFollowing;
			pGeode->SetTransformToIdentiy();

			XMFLOAT3 PlayerPos = pCoreFacade->m_ObjectManager->GetPlayer()->GetObjectTranslation();
			PhysicsComponent* physicsGeode = pGeode->GetPhysicsComponent();
			physicsGeode->SetPosition(XMFLOAT2(PlayerPos.x - rand() % 5, PlayerPos.z - rand() % 5));

			physicsGeode->ActivateCollision();

			AddGeodeCount(geodeType, 1);

			break;
		}
	}

}


void PlayerComponent::MoveToWaypoint(CoreFacade* pCoreFacade)
{
	NavAgent* pNavAgent = m_Holder.GetNavAgent();
	pNavAgent->Update();

	if (!pNavAgent->IsMoving())
	{
		pCoreFacade->m_ObjectManager->GetPlayerWaypointPointer()->GetEffectComponent()->ToggleEffect(false);
	}

	PhysicsComponent& physics = *m_Holder.GetPhysicsComponent();
	Emitter* pTrailEmitter = m_Holder.GetChildEmitterComponent(PLAYER_TRAIL_EMITTER);
	float speed = XMCVector2Length(XMLoadFloat2(&physics.GetVelocity()));

	if (speed > 0.5f)
	{
		m_Holder.GetAnimComponent()->SetAnimName(PLAYER_WALK, true);
		pTrailEmitter->SetSpawning(true);
	}
	else
	{
		m_Holder.GetAnimComponent()->SetAnimName(PLAYER_IDLE, true);
		pTrailEmitter->SetSpawning(false);
	}

}

void PlayerComponent::UpdateDebugControls(CoreFacade* pCoreFacade)
{
	if (pCoreFacade->IsPressingKey(VK_DECIMAL))
	{
		if (pCoreFacade->IsToggledKey(VK_NUMPAD8))
		{
			for (size_t i = 0; i < pCoreFacade->m_ObjectManager->GetDoors().size(); i++)
			{
				pCoreFacade->m_ObjectManager->GetDoors()[i]->GetEventComponent()->TargetsRemaining--;
				if (pCoreFacade->m_ObjectManager->GetDoors()[i]->GetEventComponent()->TargetsRemaining == 0)
					pCoreFacade->m_ObjectManager->GetDoors()[i]->GetEventComponent()->Triggered = true;
			}

			for (size_t i = 0; i < pCoreFacade->m_ObjectManager->GetTorches().size(); i++)
			{
				if (pCoreFacade->m_ObjectManager->GetTorches()[i]->GetChildPointLight(0)->GetTag() == "DoorTorch")
					pCoreFacade->m_ObjectManager->GetTorches()[i]->GetEventComponent()->TargetsRemaining--;
			}
		}
		static bool speedToggle = false;
		if (pCoreFacade->IsToggledKey(VK_NUMPAD4))
			speedToggle = !speedToggle;

		float moveSpeed = speedToggle ? DEBUG_PLAYER_SPEED : DEFAULT_PLAYER_SPEED;
		m_Holder.GetNavAgent()->SetMoveSpeed(moveSpeed);


		if (pCoreFacade->IsToggledKey(VK_NUMPAD1))
		{
			AddGemCount(eRUBYGEM, 1);
			CreateGeode(pCoreFacade, eRUBYGEODE);
		}

		if (pCoreFacade->IsToggledKey(VK_NUMPAD2))
		{
			AddGemCount(eSAPPHIREGEM, 1);
			CreateGeode(pCoreFacade, eSAPPHIREGEODE);
		}

		if (pCoreFacade->IsToggledKey(VK_NUMPAD3))
		{
			AddGemCount(eDIAMONDGEM, 1);
			CreateGeode(pCoreFacade, eDIAMONDGEODE);
		}

		if (pCoreFacade->IsToggledKey(VK_NUMPAD7))
		{
			CollisionShape* pBoundingShape = m_Holder.GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE);
			if (pBoundingShape->GetResolutionType() == RT_NONE)
				pBoundingShape->SetResolutionType(RT_DYNAMIC);
			else
				pBoundingShape->SetResolutionType(RT_NONE);

		}
	}
}

void PlayerComponent::SetKnockbackDir2(XMVECTOR dir)
{
	m_fKnockbackDir = XMCStoreFloat2(XMVector2Normalize(dir));
}
void PlayerComponent::SetKnockbackDir2(XMVECTOR dest, XMVECTOR source)
{
	m_fKnockbackDir = XMCStoreFloat2(XMVector2Normalize(dest - source));
}
void PlayerComponent::SetKnockbackDir3(XMVECTOR dir)
{
	m_fKnockbackDir = XMCStoreFloat2(XMVector2Normalize(XMCVector3SwizzleXZ(dir)));
}
void PlayerComponent::SetKnockbackDir3(XMVECTOR dest, XMVECTOR source)
{
	m_fKnockbackDir = XMCStoreFloat2(XMVector2Normalize(XMCVector3SwizzleXZ(dest - source)));
}

void PlayerComponent::UpdateAudio(CoreFacade* pCoreFacade)
{
	XMVECTOR playerPOS = m_Holder.GetObjectTranslationVec();
	XMVECTOR cameraPOS = pCoreFacade->GetCameraPosition();

	XMVECTOR ZAxis = XMVector3Normalize(playerPOS - cameraPOS);
	XMVECTOR XAxis = XMVector3Cross(XMCLoadFloat3(0,1.0f,0), ZAxis);
	XAxis = XMVector3Normalize(XAxis);
	XMVECTOR YAxis = XMVector3Cross(ZAxis, XAxis);
	YAxis = XMVector3Normalize(YAxis); 

	XMMATRIX _temp;
	_temp.r[0] = XAxis;
	_temp.r[1] = YAxis;
	_temp.r[2] = ZAxis;
	_temp.r[3] = playerPOS;

	pCoreFacade->GetSoundManager()->UpdateEntityMat(XMCStoreFloat4x4(_temp), m_Holder.GetWorldTransform());
}