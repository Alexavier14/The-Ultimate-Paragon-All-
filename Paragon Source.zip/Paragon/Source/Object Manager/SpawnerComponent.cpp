#include "../Application/stdafx.h"
#include "GameObject.h"
#include "../Application/CoreFacade.h"
#include "SpawnerComponent.h"
#include "PhysicsComponent.h"
#include "../Particle System/Emitter.h"
#include "../Util/TimeManager.h"

SpawnerComponent::SpawnerComponent(CoreFacade * cf)
{
	cfacade = cf;
	UntilNextSpawn = FLT_MAX;//RESET_SPAWN_TIME;
	WaveNumber = 0;
	TotalLeft = 3;
	GrandTotal = 0;
}

SpawnerComponent::~SpawnerComponent()
{
	EnemyCache.clear();
}

void SpawnerComponent::Update()
{
	if (UntilNextSpawn == FLT_MAX)
	{
		for (size_t i = 0; i < cfacade->m_ObjectManager->GetGeodeTargets().size(); i++)
		{
			if ((cfacade->m_ObjectManager->GetGeodeTargets()[i]->GetType() == eSAPPHIREHOLDER
				|| cfacade->m_ObjectManager->GetGeodeTargets()[i]->GetType() == eRUBYHOLDER
				|| cfacade->m_ObjectManager->GetGeodeTargets()[i]->GetType() == eDIAMONDHOLDER)
				&& cfacade->m_ObjectManager->GetGeodeTargets()[i]->GetAIData()->health != 200)
				TotalLeft = 0;//UntilNextSpawn = 5.0f;
		}
	}
	else
		UntilNextSpawn -= TimeManager::GetTimeDelta();

	//PrintConsole("TotalLeft: ", TotalLeft);

	int checkTotalDead = 0;
	for (size_t i = 0; i < cfacade->m_ObjectManager->GetGeodeTargets().size(); i++)
	{
		if ((cfacade->m_ObjectManager->GetGeodeTargets()[i]->GetType() == eSAPPHIREHOLDER
			|| cfacade->m_ObjectManager->GetGeodeTargets()[i]->GetType() == eRUBYHOLDER
			|| cfacade->m_ObjectManager->GetGeodeTargets()[i]->GetType() == eDIAMONDHOLDER)
			&& cfacade->m_ObjectManager->GetGeodeTargets()[i]->GetAIData()->health <= 0)
			checkTotalDead++;
	}


	if (TotalLeft <= 0/*
		|| UntilNextSpawn <= 0.0f*/)
	{
		if (EnemyCache.size() == 0 || WaveNumber >= 6)
			return;

		if ((GrandTotal == 2 && checkTotalDead < 1)
			|| (GrandTotal == 4 && checkTotalDead < 2)
			|| (GrandTotal == 7 && checkTotalDead < 2)
			|| (GrandTotal == 10 && checkTotalDead < 3)
			|| (GrandTotal == 14 && checkTotalDead < 3))
			return;

		/*if (GrandTotal == 2 && (checkTotalDead == 0 || checkTotalDead == 1))
			TotalLeft = 2;*/
		if ((GrandTotal == 4 || GrandTotal == 7) && checkTotalDead == 2)
			TotalLeft = 3;
		else if ((GrandTotal == 10 || GrandTotal == 14) && checkTotalDead >= 3)
			TotalLeft = 4;
		else
			TotalLeft = 2;

		for (size_t i = 0; i < EnemyCache.size(); i++)
		{
			if (EnemyCache[i]->GetActive())
				continue;

			if (WaveSpawnType[WaveNumber].x != 0.0f && EnemyCache[i]->GetType() == eSPIDER)
			{
				EnemyCache[i]->SetActive(true);
				EnemyCache[i]->GetPhysicsComponent()->ActivateCollision();
				WaveSpawnType[WaveNumber].x = 0.0f;
				//TotalLeft++;
			}
			if (WaveSpawnType[WaveNumber].y != 0.0f && EnemyCache[i]->GetType() == eGOLEM)
			{
				EnemyCache[i]->SetActive(true);
				EnemyCache[i]->GetPhysicsComponent()->ActivateCollision();
				EnemyCache[i]->GetChildEmitterComponent(0)->SetSpawning(true);
				EnemyCache[i]->GetChildEmitterComponent(1)->SetSpawning(true);
				EnemyCache[i]->GetChildEmitterComponent(1)->SetSpawning(true);
				WaveSpawnType[WaveNumber].y = 0.0f;
				//TotalLeft++;
			}
			if (WaveSpawnType[WaveNumber].z != 0.0f && EnemyCache[i]->GetType() == eWORM)
			{
				EnemyCache[i]->SetActive(true);
				EnemyCache[i]->GetPhysicsComponent()->ActivateCollision();
				EnemyCache[i]->GetChildEmitterComponent(0)->SetSpawning(true);
				EnemyCache[i]->GetChildEmitterComponent(1)->SetSpawning(true);
				WaveSpawnType[WaveNumber].z = 0.0f;
				//TotalLeft++;
			}
			
		}
		WaveNumber++;
		
		UntilNextSpawn = RESET_SPAWN_TIME;
	}
}