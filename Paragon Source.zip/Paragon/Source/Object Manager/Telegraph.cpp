#include "../Application/stdafx.h"
#include "Telegraph.h"
#include "../Util/Util.h"
#include "../Util/TimeManager.h"

#include "../Physics/Circle.h"
#include "../Physics/OrientedBox.h"
#include "../Physics/Segment.h"
#include "../Physics/Physics.h"
#include "../Physics/CollisionShape.h"
#include "../Object Manager/PhysicsComponent.h"
#include "../Object Manager/GameObject.h"

using namespace Physics;

Telegraph::Telegraph() :
isEnabled(false),
m_bFreeze(false),
m_fOffset(NULL, NULL),
m_fPosition(NULL, NULL),
m_fScale(NULL, NULL),
m_fRadius(NULL),
telegraphColor(1.0f, 0.5f, 0.5f),
TotalTime(NULL),
ActiveTime(NULL),
PercentComplete(NULL)
{
	Parent = nullptr;
	m_ElementTexture = nullptr;
	ZeroMemory(&m_tBufferTele, sizeof(Paragon_Renderer::cbTELEGRAPH));
}

Telegraph::~Telegraph()
{
	Parent = nullptr;
	m_ElementTexture = nullptr;
}

void Telegraph::Update()
{
	if (Parent == nullptr || Parent->GetActive() == false)
	{
		//Shut of tele
		isEnabled = false;
		this->ActiveTime = 0.0f;
		PercentComplete = 0.0f;
	}
	else if (isEnabled)
	{
		switch (m_eTeleType)
		{
		case eCONE:
			UpdateConeTelegraph();
			break;
		case eCIRCLE:
			UpdateCircleTelegraph();
			break;
		case eOBB:
			UpdateOBBTelegraph();
			break;
		case eNONE:
			UpdateDefaultTelegraph();
			break;
		default:
			printf("%s = INVALID TELEGRAPH SHAPE", Parent->GetTag());
			break;
		}
	}
}


//Accessors
const bool Telegraph::GetEnabled() const 
{
	return isEnabled;
}

const float Telegraph::GetPercentage() const
{
	return PercentComplete;
}

const Paragon_Renderer::cbTELEGRAPH Telegraph::GetTelegraphBuffer() const
{
	return m_tBufferTele;
}
XMFLOAT2 Telegraph::GetScale() const
{
	return m_fScale;
}




//Mutators
void Telegraph::SetEnabled(bool Enabled)
{
	if (isEnabled == false)
	{
		this->ActiveTime = 0.0f;
		PercentComplete = 0.0f;
	}
	isEnabled = Enabled;
}

void Telegraph::SetTelegraphColor(XMVECTOR color)
{
	m_tBufferTele.Color = XMCStoreFloat3(color);
}

void Telegraph::SetPosition(XMFLOAT2 pos)
{
	m_tBufferTele.Position = pos;
}

void Telegraph::SetPosition(float _x, float _y)
{
	m_tBufferTele.Position = { _x, _y };
}

void Telegraph::SetOffset(XMFLOAT2 offset)
{
	m_fOffset = offset;
}

void Telegraph::SetOffset(float _x, float _y)
{
	m_fOffset = { _x, _y };
}

void Telegraph::SetTime(float _time)
{
	TotalTime = _time;
}

void Telegraph::SetDirection(const XMFLOAT2& direction)
{
	m_Direction = direction;
}

void Telegraph::SetScale(const XMFLOAT2& scale)
{
	m_fScale = scale;
}


//Factory Methods
bool Telegraph::MakeDefaultTelegraph(GameObject* _parent, XMFLOAT2 Offset, XMFLOAT2 scale, float TimeToComplete)
{
	//Set Telegraph Type
	m_eTeleType = eNONE;

	if (_parent == nullptr)
	{
		printConsole("No parent for Default Telegraph");
		return false;
	}
	Parent = _parent;
	m_fOffset = Offset;
	m_fScale = { scale.x * 0.5f, scale.y * 0.5f };

	TotalTime = TimeToComplete;

	return true;
}

bool Telegraph::MakeOBBTelegraph(GameObject* _parent, XMFLOAT2 Offset, XMFLOAT2 scale, float TimeToComplete)
{
	//Set Telegraph Type
	m_eTeleType = eOBB;

	if (_parent == nullptr)
	{
		printConsole("No parent for OBB Telegraph");
		return false;
	}
	Parent = _parent;
	m_fOffset = Offset;
	m_fScale = { scale.x * 0.5f, scale.y * 0.5f };

	TotalTime = TimeToComplete;

	return true;
}
bool Telegraph::MakeCircleTelegraph(GameObject* _parent, XMFLOAT2 Offset, float radius, float TimeToComplete)
{
	//Set Telegraph Type
	m_eTeleType = eCIRCLE;

	if (_parent == nullptr)
	{
		printConsole("No parent for Circle Telegraph");
		return false;
	}
	Parent = _parent;
	m_fOffset = Offset;
	m_fRadius = radius;

	TotalTime = TimeToComplete;

	return true;
}
bool Telegraph::MakeConeTelegraph(GameObject* _parent, XMFLOAT2 Offset, float radius, float angle, float TimeToComplete)
{
	//Set Telegraph Type
	m_eTeleType = eCONE;

	if (_parent == nullptr)
	{
		printConsole("No parent for Cone Telegraph");
		return false;
	}
	Parent = _parent;
	m_fOffset = Offset;
	m_fRadius = radius;
	m_fAngle = XMConvertToRadians(angle);

	TotalTime = TimeToComplete;

	return true;
}

//Private Update Functions

void Telegraph::UpdateDefaultTelegraph()
{
	XMVECTOR ParentPos = XMCVector3SwizzleXZ(Parent->GetObjectTranslationVec());
	XMVECTOR Offset = XMLoadFloat2( &m_fOffset );
	m_fPosition = XMCStoreFloat2(ParentPos + Offset);

	m_tBufferTele.Position = m_fPosition;
	m_tBufferTele.ForwardVec = m_Direction;
	m_tBufferTele.Scale = m_fScale;
	m_tBufferTele.Type = m_eTeleType;
	m_tBufferTele.PercentComplete = 1.0f;
}


void Telegraph::UpdateOBBTelegraph()
{
	XMFLOAT2 Forward = { 0, 0 };

	//Update the timer until complete
	if (this->ActiveTime <= TotalTime)
	{
		XMVECTOR swizzle = XMCVector3SwizzleXZ(XMLoadFloat3(&Parent->GetObjectTranslation()));
		swizzle += ZOffset();
		m_fPosition = XMCStoreFloat2(swizzle);

		//Update the timer
		if (!m_bFreeze)
			this->ActiveTime += TimeManager::GetTimeDelta();

		XMVECTOR forwardZ = XMCVector3SwizzleXZ(Parent->GetWorldTransformMat().r[2]);
		Forward = XMCStoreFloat2(XMVector2Normalize(forwardZ));

		//Update the perfectage complete
		PercentComplete = ActiveTime / TotalTime;

		XMCClamp(PercentComplete, 0.0f, 1.0f);
	}
	else if (this->ActiveTime > TotalTime && !m_bFreeze)
	{
		//Timer expired! Telegraph done
		isEnabled = false;

		//Reset for when it is reactivated. 
		this->ActiveTime = 0.0f;
		PercentComplete = 0.0f;
	}

	m_tBufferTele.Position = m_fPosition;
	m_tBufferTele.ForwardVec = Forward;
	m_tBufferTele.Scale = m_fScale;
	m_tBufferTele.Type = m_eTeleType;
	m_tBufferTele.PercentComplete = PercentComplete;
}
void Telegraph::UpdateCircleTelegraph()
{
	XMFLOAT2 Forward = { 0, 0 };

	//Update the timer until complete
	if (this->ActiveTime <= TotalTime)
	{
		XMVECTOR swizzle = XMCVector3SwizzleXZ(XMLoadFloat3(&Parent->GetObjectTranslation()));
		swizzle += ZOffset();
		m_fPosition = XMCStoreFloat2(swizzle);

		//Update the timer
		if (!m_bFreeze)
			this->ActiveTime += TimeManager::GetTimeDelta();

		XMVECTOR forwardZ = XMCVector3SwizzleXZ(Parent->GetWorldTransformMat().r[2]);
		Forward = XMCStoreFloat2(XMVector2Normalize(forwardZ));

		//Update the perfectage complete
		PercentComplete = ActiveTime / TotalTime;

		XMCClamp(PercentComplete, 0.0f, 1.0f);
	}
	else if (this->ActiveTime > TotalTime && !m_bFreeze)
	{
		//Timer expired! Telegraph done
		isEnabled = false;

		//Reset for when it is reactivated. 
		this->ActiveTime = 0.0f;
		PercentComplete = 0.0f;
	}

	m_tBufferTele.Position = m_fPosition;
	m_tBufferTele.ForwardVec = Forward;
	m_tBufferTele.Radius = m_fRadius;
	m_tBufferTele.Type = m_eTeleType;
	m_tBufferTele.PercentComplete = PercentComplete;
}
void Telegraph::UpdateConeTelegraph()
{
	XMFLOAT2 Forward = { 0, 0 };
	//Update the timer until complete
	if (this->ActiveTime <= TotalTime)
	{
		XMVECTOR swizzle = XMCVector3SwizzleXZ(XMLoadFloat3(&Parent->GetObjectTranslation()));
		swizzle += ZOffset();
		m_fPosition = XMCStoreFloat2(swizzle);

		XMVECTOR forwardZ = XMCVector3SwizzleXZ(Parent->GetWorldTransformMat().r[2]);
		Forward = XMCStoreFloat2(XMVector2Normalize(forwardZ));

		//Update the timer
		if (!m_bFreeze)
			this->ActiveTime += TimeManager::GetTimeDelta();

		//Update the perfectage complete
		PercentComplete = ActiveTime / TotalTime;
	}
	else if (this->ActiveTime > TotalTime && !m_bFreeze)
	{
		//Timer expired! Telegraph done
		isEnabled = false;

		//Reset for when it is reactivated. 
		this->ActiveTime = 0.0f;
		PercentComplete = 0.0f;
	}

	m_tBufferTele.Angle = m_fAngle;
	m_tBufferTele.ForwardVec = Forward;
	m_tBufferTele.Position = m_fPosition;
	m_tBufferTele.Radius = m_fRadius;
	m_tBufferTele.Type = m_eTeleType;
	m_tBufferTele.PercentComplete = PercentComplete;
}

//Helper Functions
XMVECTOR Telegraph::ZOffset()
{
	XMVECTOR ZVector = Parent->GetWorldTransformMat().r[2];
	ZVector *= m_fOffset.y;

	XMVECTOR XVector = Parent->GetWorldTransformMat().r[0];
	XVector *= m_fOffset.x;
	return XMCVector3SwizzleXZ(ZVector + XVector);
}

void Telegraph::SetFreeze(bool bFreeze, float Percentage)
{
	if (bFreeze)
	{
		this->m_bFreeze = bFreeze;
		this->ActiveTime = Percentage * this->TotalTime;
		this->PercentComplete = Percentage;
		isEnabled = true;
	}
	else
	{
		isEnabled = bFreeze;
		this->ActiveTime = 0.0f;
		PercentComplete = 0.0f;
		m_bFreeze = bFreeze;
	}
}
