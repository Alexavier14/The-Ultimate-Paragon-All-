#include "../Application/stdafx.h"

#include <Windows.h>
// Author      : Daniel Stover
// Last Edited : 8/11/2014
#include "GameObject.h"

#include "AIData.h"
#include "AnimComponent.h"
#include "RendererComponent.h"
#include "PhysicsComponent.h"
#include "PlayerComponent.h"
#include "ReticleComponent.h"
#include "EffectComponent.h"
#include "EventComponent.h"
#include "TrapComponent.h"
#include "PointLightComponent.h"
#include "AudioComponent.h"

#include "../Physics/Physics.h"
#include "../Physics/Circle.h"
#include "../Application/CoreFacade.h"
#include "../Object Manager/SpawnerComponent.h"
#include "../Util/TimeManager.h"
#include "../Util/Util.h"
#include "../Particle System/Emitter.h"
#include "../Text Manager/TextBox.h"
#include "../AI System/NavAgent.h"
#include "../Sound/SoundManager.h"

using namespace std;
using namespace Physics;

//#define MATRIX_CHECK
#ifdef MATRIX_CHECK
void CheckMatrix(XMFLOAT4X4& in)
{
	for (size_t i = 0; i < 4; i++)
	{
		for (size_t j = 0; j < 4; j++)
		{
			if (in.m[i][j] != in.m[i][j])
				OutputDebugStringA("Bad Check");
		}
	}
}
#else
#define CheckMatrix(m)__noop
#endif

GameObject::GameObject() :
m_pAIData(NULL),
m_pAnimComponent(NULL),
m_pRendererComponent(NULL),
m_pPhysicsComponent(NULL),
m_pPlayerComponent(NULL),
m_pReticleComponent(NULL),
m_pHUDComponent(NULL),
m_pEffectComponent(NULL),
m_pTelegraphComponent(NULL),
m_pEmitterComponent(NULL),
m_pEventComponent(NULL),
m_pTextComponent(NULL),
m_pPointLightComponent(NULL),
m_pTrapComponent(NULL),
m_pSpawnerComponent(NULL),
m_pAudioComponent(NULL),
m_tColor(),
ObjectIndex(0)
{
	this->IsActive = false;
	this->m_pRendererComponent = new RendererComponent;
	this->m_pAIData = nullptr;
	this->m_pAnimComponent = nullptr;
	IsActive = true;
	isAnimated = false;
	isFocus = false;
	GhostColor = XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f);

}
GameObject::~GameObject()
{
}

// -----------------
// --- Accessors ---
// -----------------

ObjectType GameObject::GetType() const
{
	return m_eTypeID;
}

const string& GameObject::GetTag() const
{
	return m_Tag;
}

XMFLOAT4X4 GameObject::GetWorldTransform() const
{
	return m_WorldMat;
}

XMMATRIX GameObject::GetWorldTransformMat() const
{
	return XMLoadFloat4x4(&m_WorldMat);
}

RendererComponent* GameObject::GetRendererComponent()
{
	return m_pRendererComponent;
}

PlayerComponent* GameObject::GetPlayerComponent()
{
	return m_pPlayerComponent;
}

AIData* GameObject::GetAIData() const
{
	return m_pAIData;
}

NavAgent* GameObject::GetNavAgent() const
{
	return m_pNavAgent;
}

TextBox* GameObject::GetTextComponent()
{
	return m_pTextComponent;
}

PointLightComponent* GameObject::GetPointLightComponent()
{
	return m_pPointLightComponent;
}

PhysicsComponent* GameObject::GetPhysicsComponent()
{
	return m_pPhysicsComponent;
}

ReticleComponent* GameObject::GetReticleComponent()
{
	return m_pReticleComponent;
}

EventComponent*	GameObject::GetEventComponent()
{
	return m_pEventComponent;
}

SpawnerComponent* GameObject::GetSpawnerComponent()
{
	return m_pSpawnerComponent;
}
CAnimComponent*	GameObject::GetAnimComponent() const
{
	return this->m_pAnimComponent;
}

EffectComponent* GameObject::GetEffectComponent()
{
	return this->m_pEffectComponent;
}
EffectComponent* GameObject::GetChildEffectComponent(int index)
{
	if (GameObjects_Effects.size() > NULL && (unsigned int)index < GameObjects_Effects.size())
		return GameObjects_Effects[index]->m_pEffectComponent;

	printConsole("Tried to grab an Effect Component out of range.");
	return nullptr;
}

GameObject* GameObject::GetChildEffectObject(int index)
{
	if (GameObjects_Effects.size() > NULL && (unsigned int)index < GameObjects_Effects.size())
		return GameObjects_Effects[index];

	printConsole("Tried to grab an Effect Object out of range.");
	return nullptr;
}

GameObject* GameObject::GetChildPointLight(int index)
{
	if (GameObject_PointLight_Children.size() > NULL && (unsigned int)index < GameObject_PointLight_Children.size())
		return GameObject_PointLight_Children[index];

	printConsole("Tried to grab a Point Light out of range.");
	return nullptr;
}

GameObject* GameObject::GetChildGemObject()
{
	return GemDrop;
}

Telegraph* GameObject::GetChildTelegraphComponent(int index)
{
	if (GameObject_Telegraphs.size() > NULL && (unsigned int)index < GameObject_Telegraphs.size())
		return GameObject_Telegraphs[index]->m_pTelegraphComponent;

	printConsole("Tried to grab a Telegraph out of range.");
	return nullptr;
}

Emitter* GameObject::GetChildEmitterComponent(int index)
{
	if (GameObject_Emitters.size() > NULL && (unsigned int)index < GameObject_Emitters.size())
		return GameObject_Emitters[index]->m_pEmitterComponent;

	printConsole("Tried to grab an Emitter out of range.");
	return nullptr;
}

Emitter* GameObject::GetEmitterComponent()
{
	return m_pEmitterComponent;
}

HUDElement*	GameObject::GetHUDComponent()
{
	return this->m_pHUDComponent;
}
Telegraph*	GameObject::GetTelegraphComponent()
{
	return this->m_pTelegraphComponent;
}

TrapComponent* GameObject::GetTrapComponent() const
{
	return this->m_pTrapComponent;
}

CAudioComponent* GameObject::GetAudioComponent() const
{
	return this->m_pAudioComponent;
}


// ----------------
// --- Mutators ---
// ----------------

void GameObject::SetTypeID(ObjectType type)
{
	m_eTypeID = type;
}

void GameObject::SetAIData(AIData * data)
{
	if (m_pAIData == nullptr)
		m_pAIData = data;
}
void GameObject::SetNavAgent(NavAgent* navAgent)
{
	m_pNavAgent = navAgent;
}
void GameObject::SetEventComponent(EventComponent* eventComponent)
{
	m_pEventComponent = eventComponent;
}

void GameObject::SetRendererComponent(ID3D11ShaderResourceView* diffuse, ID3D11ShaderResourceView* normal, ID3D11ShaderResourceView* spec, ID3D11ShaderResourceView* glow, CMesh* meshData)
{
	m_pRendererComponent->m_RenderMesh = meshData;
	m_pRendererComponent->DiffuseTexture = diffuse;
	m_pRendererComponent->NormalMap = normal;
	m_pRendererComponent->SpecularMap = spec;
	m_pRendererComponent->EmisiveMap = glow;

	if (spec != nullptr)
		m_pRendererComponent->TextureFlags.UseSpecTex = true;

	if (normal != nullptr)
		m_pRendererComponent->TextureFlags.UseNormalTex = true;

	if (glow != nullptr)
		m_pRendererComponent->TextureFlags.UseEmisTex = true;
}

void GameObject::SetPhysicsComponent(PhysicsComponent* physicsComponent)
{
	m_pPhysicsComponent = physicsComponent;
}

void GameObject::SetPlayerComponent(PlayerComponent* playerComponent)
{
	m_pPlayerComponent = playerComponent;
}

void GameObject::SetReticleComponent(ReticleComponent* reticleComponent)
{
	m_pReticleComponent = reticleComponent;
}

void GameObject::SetSpawnerComponent(SpawnerComponent* spawnerComponent)
{
	m_pSpawnerComponent = spawnerComponent;
}

void GameObject::SetPointLightComponent(PointLightComponent * PL)
{
	m_pPointLightComponent = PL;
}
void GameObject::AddEffectChildObject(GameObject * Effect_GameObject)
{
	GameObjects_Effects.push_back(Effect_GameObject);
}

void GameObject::AddTelegraphChildObject(GameObject * Telegraph_GameObject)
{
	GameObject_Telegraphs.push_back(Telegraph_GameObject);
}

void GameObject::AddEmitterChildObject(GameObject* pEmitter)
{
	GameObject_Emitters.push_back(pEmitter);
}

void GameObject::AddGemChildObject(GameObject* pGem)
{
	GemDrop = pGem;
}

void GameObject::AddPointLightChild(GameObject* pPointLight)
{
	GameObject_PointLight_Children.push_back(pPointLight);
}

void GameObject::SetTelegraphComponenet(Telegraph* TelegraphComp)
{
	this->m_pTelegraphComponent = TelegraphComp;
}
void GameObject::SetEffectComponent(EffectComponent* EffectComponent)
{
	this->m_pEffectComponent = EffectComponent;
}
void GameObject::SetHUDComponent(HUDElement * HUDComponent)
{
	m_pHUDComponent = HUDComponent;
}
void GameObject::SetEmitterComponent(Emitter * EmitterComponent)
{
	m_pEmitterComponent = EmitterComponent;
}
void GameObject::SetTextBoxComponent(TextBox * TextBoxComp)
{
	m_pTextComponent = TextBoxComp;
}
void GameObject::SetAnimComponent(CAnimComponent* animComponent)
{
	this->m_pAnimComponent = animComponent;
}


void GameObject::SetObjectTranslation(const XMFLOAT3& translation)
{
	m_WorldMat.m[3][0] = translation.x;
	m_WorldMat.m[3][1] = translation.y;
	m_WorldMat.m[3][2] = translation.z;
	if (m_pPhysicsComponent)
		m_pPhysicsComponent->SetPosition(XMFLOAT2(translation.x, translation.z));
}

void GameObject::SetObjectTranslation(const XMVECTOR& translation)
{
	XMStoreFloat3((XMFLOAT3*)&m_WorldMat.m[3], translation);
	if (m_pPhysicsComponent)
		m_pPhysicsComponent->SetPosition(XMCVector2GetXZ(translation));
}

void GameObject::SetObjectTranslation(float x, float y, float z)
{
	XMFLOAT4 NewTranslation = XMFLOAT4(x, y, z, 1.0f);
	XMVECTOR translation = XMLoadFloat4(&NewTranslation);
	XMMATRIX transform = XMLoadFloat4x4(&m_WorldMat);
	transform.r[3] = translation;
	XMStoreFloat4x4(&m_WorldMat, transform);
	if (m_pPhysicsComponent)
		m_pPhysicsComponent->SetPosition(XMFLOAT2(XMVectorGetX(translation), XMVectorGetZ(translation)));
}

XMFLOAT3 GameObject::GetObjectTranslation() const
{
	XMFLOAT3 translation;
	XMMATRIX transform = XMLoadFloat4x4(&m_WorldMat);
	XMStoreFloat3(&translation, transform.r[3]);
	return translation;
}

XMVECTOR GameObject::GetObjectTranslationVec() const
{
	return XMLoadFloat3(&GetObjectTranslation());
}

XMVECTOR GameObject::GetForwardVec() const
{
	return XMVector3Normalize(XMLoadFloat3((XMFLOAT3*)&m_WorldMat.m[2]));
}


void GameObject::SetTag(const string& tag)
{
	this->m_Tag = tag;
}

void GameObject::SetObjectTransform(const XMMATRIX& transform)
{
	XMStoreFloat4x4(&m_WorldMat, transform);
}

void GameObject::SetObjectTransform(const XMFLOAT4X4& transform)
{
	this->m_WorldMat = transform;
}

void GameObject::SetTransformToIdentiy()
{
	XMStoreFloat4x4(&m_WorldMat, XMMatrixIdentity());
}

void GameObject::SetScale(float scale)
{
	XMMATRIX transform = XMLoadFloat4x4(&m_WorldMat);
	for (size_t i = 0; i < 3; i++)
		transform.r[i] = XMVector3Normalize(transform.r[i])*scale;

	//XMMATRIX scaling_mat = XMMatrixScaling(scale, scale, scale);

	XMStoreFloat4x4(&m_WorldMat, transform);
}

tObjectColor GameObject::GetObjectColor() const
{
	return this->m_tColor;
}
void GameObject::SetObjectColor(tObjectColor color)
{
	this->m_tColor = color;
}
void GameObject::SetObjectColor(XMFLOAT4 color, float ratio)
{
	//if (this->m_Tag == "CutsceneBar")
	//	PrintConsole("Updating Ratio to", ratio);
	this->m_tColor.m_Color = color;
	this->m_tColor.m_Ratio = ratio;
}
void GameObject::SetObjectColor(XMVECTOR color, float ratio)
{
	XMStoreFloat4(&this->m_tColor.m_Color, color);
	this->m_tColor.m_Ratio = ratio;
}
void GameObject::SetObjectColorRatio(float ratio)
{
	m_tColor.m_Ratio = ratio;
}
void GameObject::SetObjectColorAlpha(float alpha)
{
	m_tColor.m_Color.w = alpha;
}

void GameObject::SetReactionTime(float reaction_time)
{
	this->m_fReactionTime = m_fReactionTotalTime = reaction_time;
}

void GameObject::SetTrapComponent(TrapComponent* tcomp)
{
	this->m_pTrapComponent = tcomp;
}

void GameObject::SetWorldTransform(XMMATRIX& transform)
{
	XMStoreFloat4x4(&m_WorldMat, transform);
}

void GameObject::SetWorldTransform(XMFLOAT4X4& transform)
{
	m_WorldMat = transform;
}


// ---------------
// --- Methods ---
// ---------------

void GameObject::CreateAIData()
{
	this->m_pAIData = new AIData;
}

void GameObject::SteerTo(XMMATRIX * FINALPOS, float TurnSpeed, Segment *Left, Segment *Right, Segment *VelocityDist)
{
	//Two steering OBB's and a velocity vector
	TurnTo(FINALPOS, TurnSpeed);

	XMMATRIX OBJLocPos = XMLoadFloat4x4(&this->GetWorldTransform());

	XMVECTOR toFinal = XMVector3Normalize(FINALPOS->r[3] - OBJLocPos.r[3]);
	XMVECTOR toRight = XMVector3Normalize(OBJLocPos.r[0]);
	float dot_test = XMCVector3Dot(toFinal, toRight);
	//float angle = acos(dot_test);
	float dW = TurnSpeed * (float)TimeManager::GetTimeDelta();


	auto AllCollidesLeft = Left->GetDetectedShapes();
	auto AllCollidesRight = Right->GetDetectedShapes();
	float SegmentLengthLeft = FLT_MAX;
	float SegmentLengthRight = FLT_MAX;
	for (auto Iter = AllCollidesLeft.begin(); Iter != AllCollidesLeft.end(); ++Iter)
	{
		GameObject * possibleCollide = (*Iter)->GetGameObjectHolder();

		if (!possibleCollide->GetActive())
			continue;

		if ((*Iter)->GetShapeUsage() == SU_BOUNDING_SHAPE
			&& (possibleCollide->GetType() != ePLAYER && possibleCollide->GetType() != eRUBYGEODE && possibleCollide->GetType() != eSAPPHIREGEODE && possibleCollide->GetType() != eDIAMONDGEODE))
		{
			/*OrientedBox * BoxToCheck = (OrientedBox*)&(*Iter);
			XMFLOAT2 boxHSize; XMStoreFloat2(&boxHSize, BoxToCheck->GetHalfSize());
			XMVECTOR boxDir = BoxToCheck->GetDirection();
			XMVECTOR obbExtents[3];
			obbExtents[0] = boxDir*boxHSize.x;
			obbExtents[1] = XMVector2Orthogonal(boxDir)*boxHSize.y;
			obbExtents[2] = XMVectorSet(0, 0, 1, 0)*1.0f;
			XMVECTOR closestOnObb = ClosestPointOnOBB(posA, posB, obbExtents);
			*/
			if (possibleCollide->GetType() == eWALL)
			{
				SegmentLengthLeft = 0.0f;
				break;
			}
			else
			{
				XMVECTOR intersectionVector =
					IntersectRaySphere((*Iter)->GetPosition(), ((Circle*)(*Iter))->GetRadius(), XMCVector3SwizzleXZ(Left->GetRotatedExtent()), Left->GetPosition());
				XMVECTOR SegmentIntersectionLength = intersectionVector - Left->GetPosition();
				SegmentLengthLeft = XMCVector2Length(SegmentIntersectionLength);
				break;
			}
		}
	}


	for (auto Iter = AllCollidesRight.begin(); Iter != AllCollidesRight.end(); ++Iter)
	{
		GameObject * possibleCollide = (*Iter)->GetGameObjectHolder();

		if (!possibleCollide->GetActive())
			continue;

		if ((*Iter)->GetShapeUsage() == SU_BOUNDING_SHAPE
			&& (possibleCollide->GetType() != ePLAYER && possibleCollide->GetType() != eRUBYGEODE && possibleCollide->GetType() != eSAPPHIREGEODE && possibleCollide->GetType() != eDIAMONDGEODE))
		{
			if (possibleCollide->GetType() == eWALL)
			{
				SegmentLengthRight = 0.0f;
				break;
			}
			else
			{
				XMVECTOR intersectionVector =
					IntersectRaySphere((*Iter)->GetPosition(), ((Circle*)(*Iter))->GetRadius(), XMCVector3SwizzleXZ(Right->GetRotatedExtent()), Right->GetPosition());
				XMVECTOR SegmentIntersectionLength = intersectionVector - Right->GetPosition();
				SegmentLengthRight = XMCVector2Length(SegmentIntersectionLength);
				break;
			}
		}
	}

	if (SegmentLengthLeft == SegmentLengthRight && SegmentLengthLeft == FLT_MAX)
		return;
	if (SegmentLengthLeft <= SegmentLengthRight)
	{
		OBJLocPos = XMMatrixRotationY(-dW)*OBJLocPos;
		this->SetObjectTransform(OBJLocPos);
	}
	else
	{
		OBJLocPos = XMMatrixRotationY(dW)*OBJLocPos;
		this->SetObjectTransform(OBJLocPos);
	}

}

void GameObject::TurnTo(XMMATRIX * FinalPos, float TurnSpeed)
{
	TurnTo(FinalPos->r[3], TurnSpeed);
}

void GameObject::TurnTo(const XMVECTOR& FinalPos, float TurnSpeed, bool IgnoreY)
{
	XMVECTOR rightVec = XMVector3Normalize(GetWorldTransformMat().r[0]);
	XMVECTOR forwardVec = XMVector3Normalize(GetWorldTransformMat().r[2]);
	XMMATRIX rotation = XMMatrixIdentity();

	XMVECTOR toVector;
	float dot_turn, dot_front;

	toVector = XMVector3Normalize(FinalPos - GetObjectTranslationVec());

	dot_turn = XMCVector3Dot(rightVec, toVector);
	dot_front = XMCVector3Dot(forwardVec, toVector);

	if (dot_turn == 0.0f)
		dot_turn = EPSILON;

	if (!(dot_turn >= -0.1f && dot_turn <= 0.1f) || !(dot_front > 0.9f))
		rotation = XMMatrixRotationY(TimeManager::GetTimeDelta() * TurnSpeed * dot_turn);

	SetWorldTransform(rotation * GetWorldTransformMat());
}

void GameObject::TurnRight(float TurnSpeed)
{
	XMMATRIX WorldMat = XMLoadFloat4x4(&GetWorldTransform());
	float dW = TurnSpeed * TimeManager::GetTimeDelta();
	WorldMat = XMMatrixRotationY(dW)*WorldMat;
	SetObjectTransform(WorldMat);
}


void GameObject::LookAt(XMVECTOR direction)
{
	float angleY = atan2(XMVectorGetX(direction), XMVectorGetZ(direction));
	if (angleY != angleY)
	{
		OutputDebugStringA("BadFloat LookAt");
		return;
	}
	XMMATRIX worldTransform = GetWorldTransformMat();
	XMMATRIX rotation = XMMatrixRotationY(angleY);
	XMMATRIX translation = XMMatrixTranslationFromVector(worldTransform.r[3]);
	worldTransform = rotation*translation;
	SetObjectTransform(worldTransform);
}

void GameObject::TakeDamage(short dmg)
{
	if (this->GetAIData())
	{
		this->GetAIData()->health -= dmg;
	}
	else return;

	//This is where we try to make it flash....
	this->m_fReactionTime = m_fReactionTotalTime = HIT_TIME;
	this->m_tColor.m_Color = XMFLOAT4(1.0f, 0.0f, 0.0f, 1.0f);
}

void GameObject::CreateAudioComponent(SoundManager* SM)
{
	m_pAudioComponent = new CAudioComponent(this, SM);
}

void GameObject::Update(CoreFacade* coreFacade)
{

	if (m_pPointLightComponent)
		m_pPointLightComponent->Update();

	CheckMatrix(m_WorldMat);

	if (m_pPlayerComponent)
		m_pPlayerComponent->Update(coreFacade);

	CheckMatrix(m_WorldMat);


	if (m_pReticleComponent)
		m_pReticleComponent->Update(coreFacade);

	CheckMatrix(m_WorldMat);

	if (m_pHUDComponent)
		SetObjectColor(m_pHUDComponent->m_Color, m_pHUDComponent->m_ColorRatio);

	CheckMatrix(m_WorldMat);


	if (m_pTrapComponent)
	{
		if (m_pTrapComponent->GetEnabled() != true)
			this->SetActive(false);
	
		m_pTrapComponent->Update();
	}

	if (m_pAudioComponent)
		m_pAudioComponent->Update();

	if (m_pSpawnerComponent)
	{
		m_pSpawnerComponent->Update();
	}

	CheckMatrix(m_WorldMat);


	for (size_t i = 0; i < GameObjects_Effects.size(); i++)
	{
		if (GameObjects_Effects[i]->GetEffectComponent()->isEnabled == true)
			GameObjects_Effects[i]->m_pEffectComponent->Update((float)TimeManager::GetTimeDelta());
	}

	CheckMatrix(m_WorldMat);

	//Update Billboard Effect Positions for particles
	if (m_eTypeID == ePLAYER)
		int poop = 0;
	for (unsigned int i = 0; i < GameObject_Emitters.size(); i++)
		GameObject_Emitters[i]->m_pEmitterComponent->SetPosition(GetObjectTranslation());

	CheckMatrix(m_WorldMat);

	//Update the telegraphs
	for (unsigned int i = 0; i < GameObject_Telegraphs.size(); i++)
		GameObject_Telegraphs[i]->m_pTelegraphComponent->Update();

	CheckMatrix(m_WorldMat);

	//Update the time to show that something has ben hit.
	if (this->m_fReactionTime > 0.0f)
	{
		this->m_fReactionTime -= TimeManager::GetTimeDelta();
		this->m_tColor.m_Ratio = this->m_fReactionTime / this->m_fReactionTotalTime;
	}

#pragma region Arrow Markers towards anvils

#define MIN_ANVIL_DISTANCE 8.0f
#define VISIBLE_TIME 0.75f
	if (this->GetType() == eARROWMARKER)
	{
		bool reticle_collision = false;
		short closest_anvil = 0;
		float closest_dist = FLT_MAX;
		XMVECTOR player_pos = XMLoadFloat3(&coreFacade->GetObjectManager()->GetPlayer()->GetObjectTranslation());

		for (size_t i = 0; i < coreFacade->GetObjectManager()->GetAnvils().size(); i++)
		{
			GameObject * anvil = coreFacade->GetObjectManager()->GetAnvils()[i];

			XMVECTOR anvil_pos = XMLoadFloat3(&anvil->GetObjectTranslation());

			float dist = XMCVector3Length(anvil_pos - player_pos);
			if (dist < closest_dist)
			{
				closest_anvil = i;
				closest_dist = dist;
			}

			//See if the reticle is colliding with an anvil
			if (coreFacade->GetObjectManager()->GetReticle()->GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE)->
				Collides(coreFacade->GetObjectManager()->GetAnvils()[i]->GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE))
				&& dist > MIN_ANVIL_DISTANCE)
				reticle_collision = true;
		}

		GameObject * target_anvil = coreFacade->GetObjectManager()->GetAnvils()[closest_anvil];
		if (target_anvil != nullptr)
		{
			XMStoreFloat4x4(&m_WorldMat, XMMatrixTranslationFromVector(player_pos));
			XMVECTOR anvil_pos = XMLoadFloat3(&target_anvil->GetObjectTranslation());
			XMVECTOR curr_pos = XMLoadFloat3(&this->GetObjectTranslation());
			XMVECTOR direction = curr_pos - anvil_pos;
			this->LookAt(direction);

			XMMATRIX curr_mat = this->GetWorldTransformMat();
			XMVECTOR forwardZ = curr_mat.r[2];
			//forwardZ = XMVector3Normalize(forwardZ);
			forwardZ *= -5.0f;
			forwardZ.m128_f32[1] = 0.5f;
			XMMATRIX tran_mat = XMMatrixTranslationFromVector(forwardZ);

			XMStoreFloat4x4(&this->m_WorldMat, curr_mat * tran_mat);

		}

		if ((coreFacade->IsPressing(BT_TAB) || reticle_collision) && closest_dist > MIN_ANVIL_DISTANCE)
		{
			if (reticle_collision)
				m_pAIData->fActionCooldown += TimeManager::GetTimeDelta() * 5.0f;
			else
				m_pAIData->fActionCooldown += TimeManager::GetTimeDelta();

			if (m_pAIData->fActionCooldown > VISIBLE_TIME)
				m_pAIData->fActionCooldown = VISIBLE_TIME;

			//Turn On The Anvil Marker over the anvil.
			target_anvil->GetChildEffectComponent(1)->isEnabled = true;
		}
		else if (m_pAIData->fActionCooldown > 0.0f)
		{
			target_anvil->GetChildEffectComponent(1)->isEnabled = false;
			m_pAIData->fActionCooldown -= TimeManager::GetTimeDelta();
		}
		//PrintConsole("Closest Anvil Distance = ", closest_dist);


		if (m_pAIData->fActionCooldown > 0.0f)
		{
			this->IsActive = true;
			SetObjectColor(XMFLOAT4(0.0, 0.0, 0.0, 0.0f), (VISIBLE_TIME - m_pAIData->fActionCooldown) / VISIBLE_TIME);
		}
		else
		{
			this->IsActive = false;
		}


	}
#pragma endregion


	//if (GetType() == eLEVEL)
	//{
	//	XMFLOAT2 position = XMCVector2GetXZ( GetObjectTranslationVec() );
	//	XMSHORT2 tile = PathPlanner::GetInstance().GetTile(position);
	//	XMFLOAT4 color(0,0,0,0);
	//	float ratio = 0;
	//	if (tile.x % 2 == 0)
	//	{
	//		color.x = 1;
	//		ratio = 1;
	//	}
	//	if (tile.y % 2 == 0)
	//	{
	//		color.y = 1;
	//		ratio = 1;
	//	}

	//	SetObjectColor(color, ratio);

	//}
	//if (GetType() == ePLAYER)
	//{
	//	XMFLOAT2 position = XMCVector2GetXZ( GetObjectTranslationVec() );
	//	XMSHORT2 tile = PathPlanner::GetInstance().GetTile(position);
	//	if (tile.x%2 == 0 )
	//		SetObjectColor(XMFLOAT4(1, 0, 1, 1), 1);
	//	else
	//		SetObjectColor(XMFLOAT4(1, 0, 1, 1), 0);

	//}

	CheckMatrix(m_WorldMat);
}

void GameObject::Shutdown()
{
	//Clean up all of the components that we are responsible for
	//-- DO NOT CLEAN UP CHILDREN OBJECTS, They will handle themseleves! -- 

	if (m_pRendererComponent != nullptr)
		m_pRendererComponent->ShutDown();
	SAFE_DELETE(m_pRendererComponent);
	SAFE_DELETE(m_pReticleComponent);
	SAFE_DELETE(m_pAnimComponent);
	SAFE_DELETE(m_pPlayerComponent);
	SAFE_DELETE(m_pAIData);
	SAFE_DELETE(m_pEventComponent);
	SAFE_DELETE(m_pEffectComponent);
	SAFE_DELETE(m_pTelegraphComponent);
	SAFE_DELETE(m_pHUDComponent);
	SAFE_DELETE(m_pTextComponent);
	SAFE_DELETE(m_pPointLightComponent);
	SAFE_DELETE(m_pNavAgent);
	SAFE_DELETE(m_pTrapComponent);
	SAFE_DELETE(m_pSpawnerComponent);
	SAFE_DELETE(m_pAudioComponent);

	GameObjects_Effects.clear();
	GameObject_Telegraphs.clear();
	GameObject_Emitters.clear();
	GameObject_HUD_Elements.clear();
	GameObject_PointLight_Children.clear();
}

