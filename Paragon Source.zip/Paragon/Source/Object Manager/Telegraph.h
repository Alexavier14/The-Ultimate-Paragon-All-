#pragma once

#include "../Renderer/ConstantBuffers.h"

#include <DirectXMath.h>
using namespace DirectX;

enum TelegraphType { eNONE, eCONE, eCIRCLE, eOBB };

class GameObject;

class Telegraph
{
	//Member Variables
	TelegraphType m_eTeleType;
	GameObject * Parent;

	bool		isEnabled;
	bool		m_bFreeze;

	XMFLOAT2	m_fOffset;
	XMFLOAT2	m_fPosition;
	XMFLOAT2	m_fScale; //The OBBs' scale.
	float		m_fRadius; //The Cones' and Circles' scale
	float		m_fAngle;

	XMFLOAT3	telegraphColor;
	float		TotalTime;
	float		ActiveTime;
	float		PercentComplete;
	
	XMFLOAT2	m_Direction; // used only by default type

	Paragon_Renderer::cbTELEGRAPH m_tBufferTele;

public:
	ID3D11ShaderResourceView * m_ElementTexture;

	Telegraph();
	~Telegraph();

	void Update();

	//Accessors
	const bool GetEnabled() const;
	const float GetPercentage() const;
	const Paragon_Renderer::cbTELEGRAPH GetTelegraphBuffer() const;
	XMFLOAT2 GetScale() const;
	//Mutators
	void SetEnabled(bool Enabled);
	void SetTelegraphColor(XMVECTOR color);
	void SetPosition(XMFLOAT2 pos);
	void SetPosition(float _x, float _y);
	void SetOffset(XMFLOAT2 offset);
	void SetOffset(float _x, float _y);
	void SetTime(float _time);
	void SetDirection( const XMFLOAT2& direction );
	void SetScale( const XMFLOAT2& scale );
	//Factory Methods
	bool MakeDefaultTelegraph(GameObject* _parent, XMFLOAT2 Offset, XMFLOAT2 scale, float TimeToComplete);
	bool MakeOBBTelegraph(GameObject* _parent, XMFLOAT2 Offset, XMFLOAT2 scale, float TimeToComplete);
	bool MakeCircleTelegraph(GameObject* _parent, XMFLOAT2 Offset, float radius, float TimeToComplete);
	bool MakeConeTelegraph(GameObject* _parent, XMFLOAT2 Offset, float radius, float angle, float TimeToComplete);

	
	//Tell the Telegraph to freeze at certain amount
	//bFreeze:
	// true  = keep the telegraph showing at the percentage given.
	// false = Turn off the freeze and let the telegraph continue as intended.
	//Percentage:
	// Use a value between 1.0 and 0.0 
	// 1.0 = Telegraph completely filled.
	// 0.0 = Not filled at all.
	// default = 1.0 so you can just call SetFreeze(true/false);
	void SetFreeze(bool bFreeze, float Percentage = 1.0f);


private:
	void UpdateDefaultTelegraph();
	void UpdateOBBTelegraph();
	void UpdateCircleTelegraph();
	void UpdateConeTelegraph();

	//Helper Functions
	XMVECTOR ZOffset();
};

