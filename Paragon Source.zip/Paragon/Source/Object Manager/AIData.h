#include "../Application/stdafx.h"
#include "../Util/Clock.h"

#ifndef AIDATA_H_
#define AIDATA_H_

//Offset Amount for attack areas
#define SPIDER_Z_OFFSET		6.0f
#define SPIDER_X_OFFSET		0.0f
#define GOLEM_Z_OFFSET		7.0f
#define GOLEM_X_OFFSET		3.0f
#define WORM_Z_OFFSET		12.0f
#define WORM_X_OFFSET		0.0f

class GameObject;

struct GeodeData
{

};

struct EnemyData
{

};

struct NodeData
{

};

using namespace DirectX;
class AIData
{
	
public:
	//TODO: AI variables are used for various random, independent purposes, find way to clarify usage and prevent usage conflicts (unions?)
	//AI Targeting
	GameObject * ObjTarget;
	std::vector<GameObject*> AOETargets;
	XMFLOAT3 fTargetPos;
	std::vector<XMFLOAT3> WayPoints;
	std::vector<GameObject*> m_TrapList;
	XMFLOAT3 fJumpingPoint;
	int m_nAtkNum, m_nTrapNum;
	float m_fAirTime;
	// Temporary Variable to store the Y velocity for jumping spiders
	float m_fTempVelY;
	XMFLOAT3 fTempVel;
	bool bAtkWithLeader, bLeaderEngage;
	bool bInRange;
	bool bStartLeap;
	bool bIsMined;
	bool bWebJump;
	bool bActionDone;
	bool bWebsActive;
	int  nCoinFlip;
	int	 nEnemyGroup;
	bool bLeader;
	bool bToSwitchStates;
	bool bSubmerged;
	bool bSubmerging;

	//Enemy Special Booleans
	bool bEnemySpecialA;
	bool bEnemySpecialB;
	bool bEnemySpecialC;
	bool bEnemySpecialD;

	//Attack information
	float fActionCooldown;		
	float fActionCooldownB;
	float fActionCooldownC;
	float fActionCooldownD;

	//Attack Cooldown timers
	float AttackCooldownSwitcher;
	float TrapCooldownSwitcher;
	float DebuffCooldownSwitcher;

	float fSendDistance;

	//Performance Based Counters
	int nUnitsKilled;

	// fCrowdControlCooldown;
	Clock cAIClockTimer;
	//float fGeodeInCCTimer;
	short health;
	bool bAttacked, bCCed, bAttackSound, bCCSound, bWaypointIsWaiting, bAggro, bFirstSight;

	//Waypoints
	unsigned short usLastWaypoint;

	enum GeodeState {
		GeAttack, GeMine, GePickup, GeSend,
		GeRecall, GeFollowing,
		GeFear, GeStun, GeKnockback,
		GeScan,
		GeDeath, GeStuck, GeVictory,
		GeTrap, GeIdle
	};
	GeodeState geodeState;

	enum EnemyState {
		EnRoot, EnAttack, EnDebuff, EnPatrol, EnTrap, EnScan, EnReposition,EnDeath, EnPreJump, EnJump,
	};
	EnemyState enemyState;

	AIData();
	~AIData();
};

#endif