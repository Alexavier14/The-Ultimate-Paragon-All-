#pragma once

class GameObject;
class CoreFacade;

class ReticleComponent
{
	GameObject& m_Holder;
	bool m_bPlayerStop;
	public:
	ReticleComponent( GameObject& holder );
	~ReticleComponent( );

	void Update(CoreFacade* coreFacade);
	
	private:

	void UpdateRayPrediction(CoreFacade* pCoreFacade);
	void UpdateRecall(CoreFacade* pCoreFacade);
	void UpdateMove(CoreFacade* pCoreFacade);
};
