#include "../Application/stdafx.h"

#include "ObjectManager.h"
#include "../Asset Manager/AssetManager.h"
#include "../Util/Util.h"

#include "PhysicsComponent.h"
#include "PlayerComponent.h"

ObjectManager::ObjectManager()
{
	//Init all pointer values
	Player = nullptr;
	PressurePlate = nullptr;
	Reticle = nullptr;
	HitMark = nullptr;
	PlayerWayPoint = nullptr;
	ArrowMarker = nullptr;
	WormAttack = nullptr;
	TransitionScreen = nullptr;


	//Objects To Store During Loading
	Loading_Player = nullptr;
	Loading_WormAttack = nullptr;
	Loading_TransitionScreen = nullptr;
	Loading_PressurePlate = nullptr;
	Loading_Reticle = nullptr;
	Loading_HitMark = nullptr;
	Loading_ArrowMarker = nullptr;
	Loading_PlayerWayPoint = nullptr; 

	IsLoadingState = false;
}
ObjectManager::~ObjectManager(){}

bool ObjectManager::AddGameObject(GameObject * ObjectToAdd)
{
	if (m_GameObjects.size() > 521)
		int BREAKHERE = 1;
	bool ObjectValid = false;

	//Check if the object type is valid
	switch (ObjectToAdd->GetType())
	{
#pragma region Player
	case ObjectType::ePLAYER:
	{
		if (Player != nullptr)
			PrintConsole("OverWriting Player in Object Manager!");
			this->Player = ObjectToAdd;

		ObjectValid = true;
		break;
	}
#pragma endregion
#pragma region RubyGeode
	case ObjectType::eRUBYGEODE:
	{
		if (IsLoadingState == false)
		this->Geodes.push_back(ObjectToAdd);
		ObjectValid = true;
		break;
	}
#pragma endregion
#pragma region SapphireGeode
	case ObjectType::eSAPPHIREGEODE:
	{
		if (IsLoadingState == false)
		this->Geodes.push_back(ObjectToAdd);
		ObjectValid = true;
		break;
	}
#pragma endregion
#pragma region DiamondGeode
	case ObjectType::eDIAMONDGEODE:
	{
		if (IsLoadingState == false)
		this->Geodes.push_back(ObjectToAdd);
		ObjectValid = true;
		break;
	}
#pragma endregion
#pragma region Spider
	case ObjectType::eSPIDER:
	{
		if (IsLoadingState == false)
		{
			GeodeTargets.push_back(ObjectToAdd);
			AllEnemies.push_back(ObjectToAdd);
			Spiders.push_back(ObjectToAdd);
		}
		ObjectValid = true;
		break;
	}
#pragma endregion
#pragma region Golem
	case ObjectType::eGOLEM:
	{
		if (IsLoadingState == false)
		{
			GeodeTargets.push_back(ObjectToAdd);
			Golems.push_back(ObjectToAdd);
			AllEnemies.push_back(ObjectToAdd);
		}
		ObjectValid = true;
		break;
	}
#pragma endregion
#pragma region Worm
	case ObjectType::eWORM:
	{
		if (IsLoadingState == false)
		{
			Worms.push_back(ObjectToAdd);
			GeodeTargets.push_back(ObjectToAdd);
			AllEnemies.push_back(ObjectToAdd);
		}
		ObjectValid = true;
		break;
	}
#pragma endregion
#pragma region Spawners
	case ObjectType::eSPAWNER:
	{
		if (IsLoadingState == false)
			Spawners.push_back(ObjectToAdd);
		ObjectValid = true;
		break;
	}
#pragma endregion
#pragma region Anvil
	case ObjectType::eANVIL:
	{
		if (IsLoadingState == false)
			Anvils.push_back(ObjectToAdd);
		else //Temporary Plz remove
			Hammer = ObjectToAdd;
		ObjectValid = true;
		break;
	}
#pragma endregion
#pragma region LevelObject
	case ObjectType::eLEVEL:
	{
		if (IsLoadingState == false)
		StaticLevelObjects.push_back(ObjectToAdd);
		ObjectValid = true;
		break;
	}
#pragma endregion
#pragma region Wall
	case ObjectType::eWALL:
	{
		if (IsLoadingState == false)
		Walls.push_back(ObjectToAdd);
		ObjectValid = true;
		break;
	}
#pragma endregion
#pragma region DiamondGem
	case ObjectType::eDIAMONDGEM:
	{
		if (IsLoadingState == false)
		{
			GeodeTargets.push_back(ObjectToAdd);
			Gems.push_back(ObjectToAdd);
		}
		ObjectValid = true;
		break;
	}
#pragma endregion
#pragma region RubyGem
	case ObjectType::eRUBYGEM:
	{
		if (IsLoadingState == false)
		{
			GeodeTargets.push_back(ObjectToAdd);
			Gems.push_back(ObjectToAdd);
		}
		ObjectValid = true;
		break;
	}
#pragma endregion
#pragma region SaphhireGem
	case ObjectType::eSAPPHIREGEM:
	{
		if (IsLoadingState == false)
		{
			GeodeTargets.push_back(ObjectToAdd);
			Gems.push_back(ObjectToAdd);
		}
		ObjectValid = true;
		break;
	}
#pragma endregion
#pragma region DiamondNode
	case ObjectType::eDIAMONDNODE:
	{
		if (IsLoadingState == false)
		{
			GeodeTargets.push_back(ObjectToAdd);
			Nodes.push_back(ObjectToAdd);
		}
		ObjectValid = true;
		break;
	}
#pragma endregion
#pragma region RubyNode
	case ObjectType::eRUBYNODE:
	{
		if (IsLoadingState == false)
		{
			GeodeTargets.push_back(ObjectToAdd);
			Nodes.push_back(ObjectToAdd);
		}
		ObjectValid = true;
		break;
	}
#pragma endregion
#pragma region SapphireNode
	case ObjectType::eSAPPHIRENODE:
	{
		if (IsLoadingState == false)
		{
			GeodeTargets.push_back(ObjectToAdd);
			Nodes.push_back(ObjectToAdd);
		}
		ObjectValid = true;
		break;
	}
#pragma endregion
#pragma region PressurePlate
	case ObjectType::eGOAL:
	{
		if (PressurePlate != nullptr)
			PrintConsole("OverWriting Pressure Plate in Object Manager!");

		if (IsLoadingState == false)
			PressurePlate = ObjectToAdd;
		else
			Loading_PressurePlate = ObjectToAdd;
		ObjectValid = true;
		break;
	}
#pragma endregion
#pragma region Elevator
	case ObjectType::eELEVATOR:
	{
		Elevators.push_back(ObjectToAdd);
		ObjectValid = true;
		break;
	}
#pragma endregion
#pragma region Reticle
	case ObjectType::eRETICLE:
	{
		if (Reticle != nullptr)
			PrintConsole("OverWriting Reticle in Object Manager!");

		if (IsLoadingState == false)
			Reticle = ObjectToAdd;
		else
			Loading_Reticle = ObjectToAdd;
		ObjectValid = true;
		break;
	}
#pragma endregion
#pragma region HitMark
	case ObjectType::eHITMARK:
	{
		if (HitMark != nullptr)
			PrintConsole("OverWriting HitMark in Object Manager!");

		if (IsLoadingState == false)
			HitMark = ObjectToAdd;
		else
			Loading_HitMark = ObjectToAdd;

		ObjectValid = true;
		break;
	}
#pragma endregion
#pragma region Door
	case ObjectType::eDOOR:
	{
		if (IsLoadingState == false)
			Doors.push_back(ObjectToAdd);
		ObjectValid = true;
		break;
	}
#pragma endregion
#pragma region ArrowMarker
	case ObjectType::eARROWMARKER:
	{
		if (ArrowMarker != nullptr)
			PrintConsole("OverWriting ArrowMarker in Object Manager!");

		if (IsLoadingState == false)
			ArrowMarker = ObjectToAdd;
		else
			Loading_ArrowMarker = ObjectToAdd;

		ObjectValid = true;
		break;
	}
#pragma endregion
#pragma region Hud 
	case ObjectType::eHUD:
	{
		if (IsLoadingState == false)
			HUD.push_back(ObjectToAdd);	

		ObjectValid = true;
		break;
	}
#pragma endregion
#pragma region Transition 
	case ObjectType::eTRANSITION:
	{
		//ObjectToAdd->SetActive(false);
		ObjectValid = true;
		if (IsLoadingState == false)
			TransitionScreen = ObjectToAdd;
		else
			Loading_TransitionScreen = ObjectToAdd;
		break;
	}
#pragma endregion
#pragma region LoadingScreen 
	case ObjectType::eLOADSCREEN:
	{
		if (IsLoadingState == false)
		{
			ObjectToAdd->SetTypeID(eHUD);
			HUD.push_back(ObjectToAdd);
		}

		//LoadingScreen = ObjectToAdd;
		ObjectValid = true;
		break;
	}
#pragma endregion
#pragma region Telegraph
	case ObjectType::eTELEGRAPH:
	{
		if (IsLoadingState == false)
			Telegraphs.push_back(ObjectToAdd);
		ObjectValid = true;
		break;
	}
#pragma endregion
#pragma region Effect
	case ObjectType::eEFFECT:
	{
		if (ObjectToAdd->GetTag() == "PlayerWaypointPointerEffect")
		{
			if (IsLoadingState == false)
				PlayerWayPoint = ObjectToAdd;
			else
				Loading_PlayerWayPoint = ObjectToAdd;
		}

		if (IsLoadingState == false)
			Effects.push_back(ObjectToAdd);
		ObjectValid = true;
		break;
	}
#pragma endregion
#pragma region Particle Emitter
	case ObjectType::eEMITTER:
	{
		if (IsLoadingState == false)
			Emitters.push_back(ObjectToAdd);
		ObjectValid = true;
		break;
	}
#pragma endregion
#pragma region TextBox
	case ObjectType::eTEXTBOX:
	{
		if (IsLoadingState == false)
			TextBoxes.push_back(ObjectToAdd);
		ObjectValid = true;
		break;
	}
#pragma endregion
#pragma region Lights
	case ObjectType::ePOINTLIGHT:
	{
		if (IsLoadingState == false)
			PointLights.push_back(ObjectToAdd);
		ObjectValid = true;
		break;
	}
#pragma endregion
#pragma region Particle Emitter
	case ObjectType::eEMITTER3D:
	{
		//Emitter3D = ObjectToAdd;
		if (IsLoadingState == false)
			Emitters.push_back(ObjectToAdd);
		ObjectValid = true;
		break;
	}
#pragma endregion
#pragma region Torches
	case ObjectType::eTORCH:
	{
		if (IsLoadingState == false)
			Torches.push_back(ObjectToAdd);
		ObjectValid = true;
		break;
	}
#pragma endregion
#pragma region Decorations
	case ObjectType::eDECORATION:
	{
		if (IsLoadingState == false)
			StaticLevelObjects.push_back(ObjectToAdd);
		ObjectValid = true;
		break;
	}
#pragma endregion
#pragma region SpiderWebs
	case ObjectType::eSPIDER_WEB:
	{
		if (IsLoadingState == false)
			SpiderTraps.push_back(ObjectToAdd);
		ObjectValid = true;
		break;
	}
#pragma endregion
#pragma region FallingRock
	case ObjectType::eROCK_TRAP:
	{
		if (IsLoadingState == false)
			FallRocks.push_back(ObjectToAdd);
		ObjectValid = true;
		break;
	}
#pragma endregion
#pragma region FallingRock
	case ObjectType::eWORM_TRAP:
	{
		if (IsLoadingState == false)
			WormTraps.push_back(ObjectToAdd);
		ObjectValid = true;
		break;
	}
#pragma endregion
#pragma region WormAttack
	case ObjectType::eWORMATTACK:
	{
		if (IsLoadingState == false)
			WormAttack = ObjectToAdd;
		else
			Loading_WormAttack = ObjectToAdd;
		ObjectValid = true;
		break;
	}
#pragma endregion
#pragma region Paragon
	case ObjectType::ePARAGON:
	{
		if (IsLoadingState == false)
		{
			Paragon = ObjectToAdd;
			Gems.push_back(ObjectToAdd);
		}
		ObjectValid = true;
		break;
	}
#pragma endregion
#pragma region Paragon Holders
	case ObjectType::eDIAMONDHOLDER:
	case ObjectType::eRUBYHOLDER:
	case ObjectType::eSAPPHIREHOLDER:
	{
		if (IsLoadingState == false)
		{
			ParagonHolders.push_back(ObjectToAdd);
			GeodeTargets.push_back(ObjectToAdd);
		}
		ObjectValid = true;
		break;
	}
#pragma endregion
#pragma region Paragon
	case ObjectType::eHAMMER:
	{
		if (IsLoadingState == false)
			Hammer = ObjectToAdd;
		ObjectValid = true;
		break;
	}
#pragma endregion

#pragma region Default
	default:
	{
		PrintConsole("Tried to add an invalid object to the OM. Memory leak caused");
 		return false;
		break;
	}
#pragma endregion
	}

	if (ObjectValid == true)
	{
		if (IsLoadingState == false)
		{
 			ObjectToAdd->ObjectIndex = m_GameObjects.size();
			this->m_GameObjects.push_back(ObjectToAdd);
		}
		else
		{
			m_LoadingObjects.push_back(ObjectToAdd);
		}
	}

	return ObjectValid;
}
void ObjectManager::Update(CoreFacade* coreFacade)
{
	//Update each gameobject
	for each (GameObject* object in m_GameObjects)
	{
		//if (object->GetType() == eTRANSITION)
		//	int BreakRightHereTest = 0;
 		object->Update(coreFacade);
	}

}
GameObject * ObjectManager::GetGameObject(int index)
{
	return m_GameObjects[index];
}

void ObjectManager::ClearAllLoadedObjects()
{

	for (unsigned int i = 0; i < m_GameObjects.size(); i++)
	{
		if (m_GameObjects[i] != nullptr)
		{
			m_GameObjects[i]->Shutdown();
			SAFE_DELETE(m_GameObjects[i]);
		}
	}
 	m_GameObjects.clear();
	
	Geodes.clear();
	Anvils.clear();
	Spiders.clear();
	Golems.clear();
	Worms.clear();
	Nodes.clear();
	StaticLevelObjects.clear();
	Walls.clear();
	AllEnemies.clear();
	GeodeTargets.clear();
	Gems.clear();
	Doors.clear();
	HUD.clear();
	Telegraphs.clear();	
	Effects.clear();
	Emitters.clear();
	TextBoxes.clear();
	PointLights.clear();
	Torches.clear();
	SpiderTraps.clear();
	Elevators.clear();
	FallRocks.clear();
	WormTraps.clear();
	Spawners.clear();
	ParagonHolders.clear();

	Hammer = nullptr;
	Paragon = nullptr;
	WormAttack = nullptr;
	Player = nullptr;
	PressurePlate = nullptr;
	Reticle = nullptr;
	HitMark = nullptr;
	PlayerWayPoint = nullptr;
	TransitionScreen = nullptr;
	ArrowMarker = nullptr;
}

GameObject* ObjectManager::GetTransitionScreen()
{
	if (TransitionScreen)
		return TransitionScreen;
	else
	{
		PrintConsole("Transition Screen is Null");
		return NULL;
	}
}
void ObjectManager::SetLoadingState(bool isLoading)
{
	IsLoadingState = isLoading;

	if (isLoading == true)
	{
		m_LoadingObjects.clear();

		Loading_Player = nullptr;
		Loading_WormAttack = nullptr;
		Loading_TransitionScreen = nullptr;
		Loading_PressurePlate = nullptr;
		Loading_Reticle = nullptr;
		Loading_HitMark = nullptr;
		Loading_ArrowMarker = nullptr;
		Loading_PlayerWayPoint = nullptr;
	}
}

void ObjectManager::LoadingComplete()
{ 
	//Geodes.clear();
	//Anvils.clear();
	//Spiders.clear();
	//Golems.clear();
	//Worms.clear();
	//Nodes.clear();
	//StaticLevelObjects.clear();
	//Walls.clear();
	//AllEnemies.clear();
	//GeodeTargets.clear();
	//Gems.clear();
	//Doors.clear();
	//HUD.clear();
	//Telegraphs.clear();
	//Effects.clear();
	//Emitters.clear();
	//TextBoxes.clear();
	//PointLights.clear();
	//Torches.clear();
	//SpiderTraps.clear();
	//Elevators.clear();
	//FallRocks.clear();
	//WormTraps.clear();

	//Store all of the objects that were loaded
	if (Loading_Player != nullptr)
		Player = Loading_Player;

	if (Loading_PressurePlate != nullptr)
		PressurePlate = Loading_PressurePlate;

	if (Loading_Reticle != nullptr)
		Reticle = Loading_Reticle;

	if (Loading_HitMark != nullptr)
		HitMark = Loading_HitMark;

	if (Loading_PlayerWayPoint != nullptr)
		PlayerWayPoint = Loading_PlayerWayPoint;

	if (Loading_ArrowMarker != nullptr)
		ArrowMarker = Loading_ArrowMarker;

	if (Loading_WormAttack != nullptr)
		WormAttack = Loading_WormAttack;

	if (Loading_TransitionScreen != nullptr)
	{
		if (TransitionScreen != nullptr)
			TransitionScreen->SetActive(false);
		TransitionScreen = Loading_TransitionScreen;
	}

	IsLoadingState = false;
	for (size_t i = 0; i < m_LoadingObjects.size(); i++)
	{
		AddGameObject(m_LoadingObjects[i]);
	}
	//m_LoadingObjects.clear();
}

vector<GameObject*>& ObjectManager::GetElevators()
{
	return Elevators;
}

GameObject* ObjectManager::GetPlayerWaypointPointer()
{
	return PlayerWayPoint;
}

vector<GameObject*>& ObjectManager::GetGeodeTargets()
{
	return GeodeTargets;
}
vector<GameObject*>& ObjectManager::GetRenderSet()
{
	return m_GameObjects;
}
GameObject* ObjectManager::GetPlayer()
{
	return Player;
}
GameObject* ObjectManager::GetReticle()
{
	return Reticle;
}
GameObject* ObjectManager::GetHitMark()
{
	return HitMark;
}
GameObject* ObjectManager::GetPressurePlate()
{
	return PressurePlate;
}
GameObject* ObjectManager::GetArrowMarker()
{
	return ArrowMarker;
}
GameObject * ObjectManager::GetWormAttack()
{
	return WormAttack;
}
GameObject * ObjectManager::GetParagon()
{
	return Paragon;
}
GameObject * ObjectManager::GetHammer()
{
	return Hammer;
}
vector<GameObject*>& ObjectManager::GetAnvils()
{
	return Anvils;
}
const vector<GameObject*>& ObjectManager::GetGeodes()
{
	return Geodes;
}
vector<GameObject*>& ObjectManager::GetSpiders()
{
	return Spiders;
}
vector<GameObject*>& ObjectManager::GetGolems()
{
	return Golems;
}
vector<GameObject*>& ObjectManager::GetWorms()
{
	return Worms;
}
vector<GameObject*>& ObjectManager::GetMiningNodes()
{
	return Nodes;
}
vector<GameObject*>& ObjectManager::GetLevelObjects()
{
	return StaticLevelObjects;
}
vector<GameObject*>& ObjectManager::GetAllEnemies()
{
	return AllEnemies;
}
vector<GameObject*>& ObjectManager::GetWalls()
{
	return Walls;
}

vector<GameObject*>& ObjectManager::GetGems()
{
	return Gems;
}

vector<GameObject*>& ObjectManager::GetDoors()
{
	return Doors;
}

vector<GameObject*>& ObjectManager::GetHUDElements()
{
	return HUD;
}
vector<GameObject*>& ObjectManager::GetTelegraphs()
{
	return Telegraphs;
}
vector<GameObject*>& ObjectManager::GetEffects()
{
	return Effects;
}
vector<GameObject*>& ObjectManager::GetEmitters()
{
	return Emitters;
}
vector<GameObject*>& ObjectManager::GetTextBoxes()
{
	return TextBoxes;
}
vector<GameObject*>& ObjectManager::GetPointLights()
{
	return PointLights;
}
vector<GameObject*>& ObjectManager::GetTorches()
{
	return Torches;
}

vector<GameObject*>& ObjectManager::GetFallRocks()
{
	return FallRocks;
}

vector<GameObject*>& ObjectManager::GetSpawners()
{
	return Spawners;
}

vector<GameObject*>& ObjectManager::GetSpiderTraps()
{
	return SpiderTraps;
}

vector<GameObject*>& ObjectManager::GetWormTraps()
{
	return WormTraps;
}

vector<GameObject*>& ObjectManager::GetParagonHolders()
{
	return ParagonHolders;
}