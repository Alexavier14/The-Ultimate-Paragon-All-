#include "../Application/stdafx.h"

#pragma once

class GameObject;
namespace Physics { class CollisionShape; }

#include "../Physics/CollisionShape.h"

#define INFINITE_MASS -1.0f

class PhysicsComponent
{
	enum ResponseType {
		NO_RESPOSNSE,		// Collision resolution does not affect this object
		DYNAMIC_RESPONSE,	// Collision resolution will change this object's velocity
	};


	// ---------------
	// --- Members ---
	// ---------------

	bool m_bAvailable;
	bool m_bActive;

	ResponseType m_eResponseType;
	DirectX::XMFLOAT2 m_vPosition;
	DirectX::XMFLOAT2 m_vVelocity;
	float m_Mass;

	float m_FrameTime; // The time this Game object has advanced in the simulation during this frame. [0,dt]

	Physics::CollisionShape* m_CollisionShapes[NUM_SHAPE_USES];

	GameObject* m_pHolder;

	public:
	PhysicsComponent();
	~PhysicsComponent();


	// --------------------------
	// --- Accessors/Mutators ---
	// --------------------------

	bool IsActive() const;
	void SetActive( bool bActive );

	bool IsAvailable() const;
	void SetAvailable( bool bAvailable );

	GameObject*	GetHolder();
	void SetHolder(GameObject* pHolder);

	DirectX::XMFLOAT2 GetPosition() const;
	DirectX::XMFLOAT2 & GetVelocity();
	float GetFrameTime() const;
	float GetMass() const;

	void SetPosition(DirectX::XMFLOAT2 position);
	void SetVelocity(DirectX::XMFLOAT2 velocity);
	void SetMass(float mass);
	void SetFrameTime( float frameTime );

	//Assigns a velocity with the specified speed in the forward direction from the Object's world matrix 
	void SetForwardVelocity(float speed);

	void SetCollisionShape(Physics::CollisionShape* collisionShape, ShapeUsage shapeType);
	Physics::CollisionShape* GetCollisionShape(ShapeUsage shapeType);



	// ---------------
	// --- Methods ---
	// ---------------

	/*
		Gets Called by the Object Manager to update the position according to the velocity and refresh the world matrix
		*/
	void Update();

	void AdvanceSimulationTo( float deltaTime );

	void ActivateCollision();
	void DeactivateCollision();

	void Reset();

};

