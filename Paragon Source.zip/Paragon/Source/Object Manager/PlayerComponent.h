#include "../Application/stdafx.h"
#include "../Util/Clock.h"

#pragma once
#include "GameObject.h"

class CoreFacade;

#define PLAYER_MAX_HEALTH 5

enum PlayerEffectTypes { 
	ePLAYER_SMITHING_EFFECT, 
	ePLAYER_SEND_EFFECT, 
	ePLAYER_EFFECT_AMOUNT };

enum PlayerTelegraphTypes { 
	ePLAYER_SEND_ARROW_TIP_TELEGRAPH, 
	ePLAYER_SEND_ARROW_EXTENSION_TELEGRAPH, 
	ePLAYER_TELEGRAPH_AMOUNT };

class PlayerComponent
{
	GameObject& m_Holder;
	GameObject* m_TargetTrap;

	//DirectX::XMFLOAT2 m_vForward;
	bool m_bTravelToWaypoint;
	bool m_bFirstGeode;
	bool m_bMovingOnElevator;
	bool ElevatorMusicOn;
	unsigned int m_nCurrentRoom;

	XMFLOAT2 m_vDestination;

	// The player's health is an integer number ranging from 0 to PLAYER_MAX_HEALTH.
	unsigned short m_nHealth;

	// Unsigned short for the number of enemies the player has killed
	unsigned short m_usEnemiesKilled;

	//Bools to enable LIGHTNING!
	bool Sholder, Rholder, Dholder, Captured;
	float LightningTimer;

	//Number of each type of Geodes
	short m_nRGeodes;
	short m_nSGeodes;
	short m_nDGeodes;

	//Number of each type of Gems
	short m_nRGems;
	short m_nSGems;
	short m_nDGems;

	bool m_bWalking, m_StopUpdating, m_bStuck, m_bKnockback, m_bInCombat;

	XMFLOAT2 m_fKnockbackDir;

	Clock cStopMovingTimer;
	float WaitTimer;
	float m_PlayerSpeed;

	short m_nGemsGathered;
	short m_nGeodesCreated;
	short m_nGeodesLost;
	bool  m_bFirstEncounter;

public:

	bool m_bWinEventStarted; // TODO: Use an event
	bool m_bCollidedWithDoor;

	PlayerComponent(GameObject& holder);
	~PlayerComponent();

	void Initialize(CoreFacade* pCoreFacade);

	void Update(CoreFacade* pCoreFacade);

	//Set Forward vector and reorientate world matrix
	//Param forward: a 2D Vector
	void SetForward(DirectX::XMFLOAT2 direction);
	void SetDestination(DirectX::XMFLOAT2 destination);

	void HitPlayer(CoreFacade* pCoreFacade, unsigned short nDamage);

	unsigned short GetHealth() const;

	unsigned short GetEnemiesKilled(){ return m_usEnemiesKilled; }
	void SetEnemiesKilled(unsigned short _ek){ m_usEnemiesKilled = _ek; }
	void SetStuck(bool _stuck){ m_bStuck = _stuck; }
	void SetKnockBack(bool knockback){ m_bKnockback = knockback; }

	//Stores a Knockback direction using a float2 vector
	void SetKnockbackDir2(XMVECTOR dir);
	//Stores a Knockback direction using float2 vectors
	void SetKnockbackDir2(XMVECTOR dest, XMVECTOR source);
	//Stores a Knockback direction using a float3 vector
	void SetKnockbackDir3(XMVECTOR dir);
	//Stores a Knockback direction using float3 vectors
	void SetKnockbackDir3(XMVECTOR dest, XMVECTOR source);

	void SetRoomNumber(unsigned int _roomNum){ m_nCurrentRoom = _roomNum; }

	unsigned short GetGeodeCount(ObjectType const GeodeType) const;
	unsigned short GetGemCount(ObjectType const GemType) const;

	short GetNumGeodesCreated() const { return m_nGeodesCreated; }
	short GetNumGeodesLost() const { return m_nGeodesLost; }
	short GetNumGemsGathered() const { return m_nGemsGathered; }
	bool  GetStuck() const { return m_bStuck; }
	bool  GetKnockback() const { return m_bKnockback; }
	GameObject* GetStuckTrap() const { return m_TargetTrap; }
	unsigned int GetCurrentRoom() const { return m_nCurrentRoom; }
	bool  GetElevatorMove() const { return m_bMovingOnElevator; }

	//AddGeodeCount
	//GeodeType to access the correct counter
	// - eRUBYGEODE == Ruby Geodes
	// - eSAPPHIREGEODE == Sapphire Geode
	// - eDIAMONDGEODE == Diamond Geode
	//num is the number total to add.
	//use negative numbers to reduce the count.
	void AddGeodeCount(ObjectType GeodeType, short num);

	//AddGeodeCount
	//GemType to access the correct counter
	// - eRUBYGEM == Ruby Gem
	// - eSAPPHIREGEM == Sapphire Gem
	// - eDIAMONDGEM == Diamond Gem
	//num is the number total to add.
	//use negative numbers to reduce the count.
	void AddGemCount(ObjectType GemType, short num);


	//Stops the Player from Updating, locking out controls
	//StartOrStop sets the flag to stop updating
	// if true, cStopMovingTimer starts
	// Timer is how long the timer will last.
	void StopPlayer(bool StartOrStop, float Timer);

	//Returns if the player is in range of an anvil
	bool GetPlayerInRangeAnvils(CoreFacade * CF);
private:

	// ---------------
	// --- Helpers ---
	// ---------------

	void CreateGeode(CoreFacade* pCoreFacade, ObjectType geodeType);

	void MoveToWaypoint(CoreFacade* pCoreFacade);

	void UpdateAudio(CoreFacade* pCoreFacade);
	void UpdateAnvils(CoreFacade* pCoreFacade);
	void UpdateDebugControls(CoreFacade* pCoreFacade);
	bool GetPlayerInRangeAnvils();
};

