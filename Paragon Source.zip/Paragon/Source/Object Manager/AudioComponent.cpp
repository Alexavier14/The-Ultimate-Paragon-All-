#include "../Application/stdafx.h"

#include "AudioComponent.h"
#include "GameObject.h"
#include "../Sound/AudioSystemWwise.h"
#include "../Sound/Entity3D.h"
#include "../Sound/SoundManager.h"
#include "../Physics/Physics.h"
#include "../Util/Util.h"

using namespace Physics;

CAudioComponent::CAudioComponent(GameObject* GO, SoundManager* SoundManager)
{
	m_pHolder = GO;
	m_pEntity = new Entity3D();
	m_pAudioSystem = SoundManager->GetAudioSystem();
	if (!m_pAudioSystem->RegisterEntity(m_pEntity, GO->GetTag().c_str()))
	{
		printConsole("Audio Entity could not register: " + GO->GetTag());
	}
	//else
	//	printConsole("Audio Entity created: " + GO->GetTag());

}
CAudioComponent::~CAudioComponent()
{
	if (!m_pAudioSystem->UnRegisterEntity(m_pEntity))
	{
		printConsole("Audio Entity could not unregister: " + m_pHolder->GetTag());
	}
	//else
	//	printConsole("Audio Entity destroyed: " + m_pHolder->GetTag());

	SAFE_DELETE(m_pEntity);	
	m_pHolder = nullptr;
	m_pAudioSystem = nullptr;
}
void CAudioComponent::Update()
{
	XMMATRIX world = m_pHolder->GetWorldTransformMat();
	m_pEntity->SetPosition(XMCStoreFloat3(world.r[3]));
	m_pEntity->SetXAxis(XMCStoreFloat3(world.r[0]));
	m_pEntity->SetYAxis(XMCStoreFloat3(world.r[1]));
	m_pEntity->SetZAxis(XMCStoreFloat3(world.r[2]));
}
void CAudioComponent::PlayAudioFollow(unsigned int audioID)
{
	m_pAudioSystem->PostEvent(audioID, m_pEntity);
}
void CAudioComponent::PlayAudioAtSpot(unsigned int audioID)
{
	m_pAudioSystem->PostEvent(audioID, m_pEntity->GetPosition());
}
void CAudioComponent::PlayAudio2D(unsigned int audioID)
{
	m_pAudioSystem->PostEvent(audioID);
}
