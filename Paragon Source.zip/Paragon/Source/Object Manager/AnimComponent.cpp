#include "../Application/stdafx.h"

#include "AnimComponent.h"
#include "../Animation System/Animation.h"


CAnimComponent::CAnimComponent()
{
	m_fCurrKeyTime = 0.0f;
	m_fNextKeyTime = 0.0f;
	m_fTransitionTime = 0.0f;
	m_fTransitionTotalTime = 1.0f;
	m_fAnimSpeed = 1.0f;
	m_pCurrAnim = nullptr;
	m_bCurrLooping = true;
	m_bNextLooping = true;
	m_bDeathAnim = false;
}

CAnimComponent::CAnimComponent(string animName, bool isLooping)
{
	m_sAnimName = animName;
	m_fCurrKeyTime = 0.0f;
	m_fNextKeyTime = 0.0f;
	m_fAnimSpeed = 1.0f;
	m_bCurrLooping = isLooping;
	m_bNextLooping = true;
	m_pCurrAnim = m_pNextAnim = nullptr;
	m_bDeathAnim = false;
}

CAnimComponent::CAnimComponent(CAnimComponent const &cpy)
{
	*this = cpy;
}

CAnimComponent & CAnimComponent::operator=(CAnimComponent const &assign)
{
	this->m_sAnimName = assign.m_sAnimName;

	//Do not delete or you will remove the data from the Asset Manager
	this->m_pCurrAnim = nullptr;
	this->m_pCurrAnim = assign.m_pCurrAnim;

	this->m_Interpolated_Frame.fKeyTime = assign.m_Interpolated_Frame.fKeyTime;
	this->m_Interpolated_Frame.m_Bones = assign.m_Interpolated_Frame.m_Bones;

	return *this;
}

CAnimComponent::~CAnimComponent()
{
	for (size_t j = 0; j < m_Interpolated_Frame.m_Bones.size(); j++)
	{
		delete m_Interpolated_Frame.m_Bones[j];
		m_Interpolated_Frame.m_Bones[j] = nullptr;
	}
}

//Accessors
string CAnimComponent::GetAnimName() const
{
	return this->m_sAnimName;
}

float CAnimComponent::GetCurrKeyTime() const
{
	return this->m_fCurrKeyTime;
}

float CAnimComponent::GetNextKeyTime() const
{
	return this->m_fNextKeyTime;
}

float CAnimComponent::GetTransitionTime() const
{
	return this->m_fTransitionTime;
}

float CAnimComponent::GetTransitionTotalTime() const
{
	return this->m_fTransitionTotalTime;
}

float CAnimComponent::GetAnimSpeed() const
{
	return m_fAnimSpeed;
}

const CAnimation* CAnimComponent::GetCurrAnimation() const
{
	return this->m_pCurrAnim;
}

const CAnimation* CAnimComponent::GetNextAnimation() const
{
	return this->m_pNextAnim;
}

tKeyFrame CAnimComponent::GetInterpolatedFrame() const
{
	return this->m_Interpolated_Frame;
}

bool CAnimComponent::IsDeathAnim() const
{
	return this->m_bDeathAnim;
}

bool CAnimComponent::IsTransitioning() const
{	
	if (!m_bNewAnim || (!m_bCurrLooping && ((m_fCurrKeyTime < m_pCurrAnim->GetAnimTime() - 0.3f && m_fAnimSpeed > 0.0f)
		|| (m_fCurrKeyTime > 0.3f && m_fAnimSpeed < 0.0f))))
		return false;
		
	return true;
}


//Mutators
void CAnimComponent::SetAnimName(string name, bool isLooping)
{
	if (m_bDeathAnim || (m_pNextAnim == nullptr && !IsTransitioning()))
	{
		this->m_sAnimName = name;
		m_bNextLooping = isLooping;
		m_fAnimSpeed = 1.0f;
	}
}

void CAnimComponent::SetKeyTime(float time)
{
	this->m_fCurrKeyTime = time;
}

///This Function set the animation speed.
//The suggested range is -2.0f -> +2.0f
//if speed == -value the animation will run backwards
//if speed == 0 the animation will freeze it's current animation.
//if speed == +value the animation will run backwards
// values > 0 and < 1 slow the animation
// values > 1 speed the animation
void CAnimComponent::SetAnimSpeed(float speed)
{
	m_fAnimSpeed = speed;
}

void CAnimComponent::StopTransition()
{
	if (m_pNextAnim)
	{
		m_sAnimName = m_pNextAnim->GetAnimTag();
		m_bNewAnim = false;
		m_pCurrAnim = m_pNextAnim;
		m_bCurrLooping = m_bNextLooping;
		m_fCurrKeyTime = m_fNextKeyTime;
		m_pNextAnim = nullptr;
	}
}


void CAnimComponent::SetAnimation(CAnimation * anim, float transition)
{
	if (m_pCurrAnim)
	{
		m_pNextAnim = anim;
		m_bNewAnim = true; 
		m_fTransitionTime = 0.0f;
		m_fTransitionTotalTime = transition;

		if (m_fAnimSpeed > 0)
			m_fNextKeyTime = 0.0f;
		else
			m_fNextKeyTime = m_pNextAnim->GetAnimTime();

	}
	else
	{
		m_pCurrAnim = anim;
		m_fCurrKeyTime = 0.0f;
		m_bCurrLooping = m_bNextLooping;

		if (m_fAnimSpeed > 0)
			m_fCurrKeyTime = 0.0f;
		else
			m_fCurrKeyTime = m_pCurrAnim->GetAnimTime();
	}

}

void CAnimComponent::SetInterpolatedFrame(tKeyFrame interpolation)
{
	this->m_Interpolated_Frame.fKeyTime = interpolation.fKeyTime;

	//if first time through
	if (m_Interpolated_Frame.m_Bones.size() == 0)
	{
		for (size_t i = 0; i < interpolation.m_Bones.size(); i++)
		{
			CNode * init = new CNode();
			init->GetWorldMat() = interpolation.m_Bones[i]->GetWorldMat();
			init->m_ChildrenIndex = interpolation.m_Bones[i]->m_ChildrenIndex;
			init->m_nParentIndex = interpolation.m_Bones[i]->m_nParentIndex;
			m_Interpolated_Frame.m_Bones.push_back(init);
		}

		for (size_t j = 0; j < m_Interpolated_Frame.m_Bones.size(); j++)
		{
			if (m_Interpolated_Frame.m_Bones[j]->m_nParentIndex == j)
				m_Interpolated_Frame.m_Bones[j]->m_pParent = nullptr;
			else
				m_Interpolated_Frame.m_Bones[j]->m_pParent = m_Interpolated_Frame.m_Bones[m_Interpolated_Frame.m_Bones[j]->m_nParentIndex];

			for (size_t x = 0; x < m_Interpolated_Frame.m_Bones[j]->m_ChildrenIndex.size(); x++)
				m_Interpolated_Frame.m_Bones[j]->AddChild(m_Interpolated_Frame.m_Bones[m_Interpolated_Frame.m_Bones[j]->m_ChildrenIndex[x]]);
		}
	}

	else
		for (size_t i = 0; i < m_Interpolated_Frame.m_Bones.size(); i++)
		{
		this->m_Interpolated_Frame.m_Bones[i]->GetWorldMat() = interpolation.m_Bones[i]->GetWorldMat();
		}
}

//void SetIsDeathAnim(bool isDeath = true)
//Sets a flag(m_bDeathAnim) to notify AddTime that this animation is death animation
void CAnimComponent::SetIsDeathAnim(bool isDeath)
{
	this->m_bDeathAnim = isDeath;
}

void CAnimComponent::SetTransitionTime(float time)
{
	this->m_fTransitionTime = time;
}

//Helpers
void CAnimComponent::AddTime(float delta)
{
	this->m_fCurrKeyTime += (delta * m_fAnimSpeed);
	if (m_bCurrLooping)
	{
		if (this->m_fCurrKeyTime < 0)
			this->m_fCurrKeyTime += this->m_pCurrAnim->GetAnimTime();
		else if (this->m_fCurrKeyTime >= this->m_pCurrAnim->GetAnimTime())
			this->m_fCurrKeyTime -= this->m_pCurrAnim->GetAnimTime();
	}

	if (m_bNewAnim)
	{
		this->m_fNextKeyTime += (delta * m_fAnimSpeed);
		this->m_fTransitionTime += delta; //This is not affected by the animation speed.

		if (m_bNextLooping)
		{
			if (this->m_fNextKeyTime < 0)
				this->m_fNextKeyTime += this->m_pNextAnim->GetAnimTime();
			else if (this->m_fNextKeyTime >= this->m_pNextAnim->GetAnimTime())
				this->m_fNextKeyTime -= this->m_pNextAnim->GetAnimTime();
		}

		if (m_fTransitionTime > m_fTransitionTotalTime)
		{
			m_sAnimName = m_pNextAnim->GetAnimTag();
			m_bNewAnim = false;
			m_pCurrAnim = m_pNextAnim;
			m_bCurrLooping = m_bNextLooping;
			m_fCurrKeyTime = m_fNextKeyTime;
			m_pNextAnim = nullptr;
		}

	}



#if _DEBUG //Used only with debug to get keytime back to normal when using break points
	if (m_fCurrKeyTime >(this->m_pCurrAnim->GetAnimTime() + 10.0f))
		m_fCurrKeyTime = 0.0f;
#endif // _DEBUG - Used only with debug to get keytime back to normal when using break points

}

void CAnimComponent::SetAnimationTime(float time)
{
	float AnimationTime = this->m_pCurrAnim->GetAnimTime();
	float Ratio = time / AnimationTime;
	this->m_fAnimSpeed = Ratio;
}