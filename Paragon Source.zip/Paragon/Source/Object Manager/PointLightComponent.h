#pragma once
#include "../Renderer/ConstantBuffers.h"
#include "../Util/Util.h"

class GameObject;
class PointLightComponent
{
private:
	static XMFLOAT3 SapphireSendColor;
	static XMFLOAT3 RubySendColor;
	static XMFLOAT3 DiamondSendColor;
	static XMFLOAT3 LastGeodeSentColor;

	static XMFLOAT3 TorchColor1;
	static XMFLOAT3 TorchColor2;;

	XMFLOAT3 StartingDiffuseColor;
	XMFLOAT3 StartingAmbColor;
	
	static float SentGeodeTimer;
	float AttenValue;

	bool FadeOutActive;
	bool FadeInActive;
	float LightFadeRatio;
	float LightFadeSpeed;
	XMFLOAT3 FullFadeAtten;
	XMFLOAT3 NoFadeAtten;

public:
	GameObject * Parent;
	GameObject * FollowObject;

	Paragon_Renderer::cbPOINT_LIGHT PointLightData;

	float UpperSwitchLimit;
	float LowerSwitchLimit;
	float FlickerTimer;
	XMFLOAT3 OffsetFromForward;

	void Update();
	void SetFadeOut(float FadeSpeed);
	void SetFadeIn(float FadeSpeed);
	void SetRange(float Range);
	bool ToggleUp;
	bool AddFlicker;
	bool FollowParentY;
	bool FollowParent;
	PointLightComponent(Paragon_Renderer::cbPOINT_LIGHT PointLightData);
	~PointLightComponent();

	static void RubySent();
	static void SapphireSent();
	static void DiamondSent();

};

