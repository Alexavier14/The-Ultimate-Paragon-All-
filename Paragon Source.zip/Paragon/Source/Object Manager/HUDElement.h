#include "../Application/stdafx.h"

#pragma once
using namespace std;

class HUDElement
{
private:
public:
	float m_Height;
	float m_Width;
	float m_XSceenPos;
	float m_YScreenPos;

	//Used by GameObject use its reaction data.
	float m_ColorRatio;
	XMFLOAT4 m_Color;
	bool isEnabled;

	HUDElement();
	HUDElement(float width, float height, float ScreenX, float ScreenY);
	~HUDElement();
};

