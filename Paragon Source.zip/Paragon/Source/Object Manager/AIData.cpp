#include "../Application/stdafx.h"

#include "AIData.h"
#include "GameObject.h"

AIData::AIData() :
//fParticleTimer(0.0f),
fActionCooldown(0.0f),
fActionCooldownB(0.0f),
fActionCooldownC(0.0f),
fActionCooldownD(0.0f),
bIsMined(false),
bActionDone(false),
bWaypointIsWaiting(false),
bAttackSound(false),
bCCSound(false),
bAtkWithLeader(false),
bLeaderEngage(false),
bSubmerged(false),
bSubmerging(false),
ObjTarget(NULL),
m_nAtkNum(0),
m_fAirTime(0.0f),
bStartLeap(false),
m_fTempVelY(0.0f),
m_nTrapNum(0),
nUnitsKilled(0),
bWebJump(false),
fSendDistance(0),
bWebsActive(false),
nCoinFlip(1),
bAggro(false),
bFirstSight(false),
nEnemyGroup(0),
bLeader(false),
bInRange(false),
bToSwitchStates(false)
{
}

AIData::~AIData()
{
}