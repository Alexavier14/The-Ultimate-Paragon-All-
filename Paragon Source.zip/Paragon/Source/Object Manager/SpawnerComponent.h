#pragma once
#include "../Application/stdafx.h"

#define RESET_SPAWN_TIME  100.0f

class CoreFacade;

class SpawnerComponent
{
	CoreFacade * cfacade;
public:
	float UntilNextSpawn;
	int WaveNumber, TotalLeft, GrandTotal;
	vector<GameObject*> EnemyCache;
	vector<XMFLOAT3> WaveSpawnType;


	SpawnerComponent(CoreFacade * cf);
	~SpawnerComponent();
	void Update();
};