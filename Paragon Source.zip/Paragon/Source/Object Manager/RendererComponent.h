#pragma once
#include "../Application/stdafx.h"
#include "../Asset Manager/Mesh.h"
#include "../Util/Util.h"
#include "../Renderer/RenderNode.h"
#include "../Renderer/ConstantBuffers.h"

//An Enum to represent how this object will be rendered
class RendererComponent
{
private:
	//Used by the renderer to render this object
	RenderNode * RendNode_MainRender;
	RenderNode * RendNode_SecondaryRender;


public:
	//Object Geometry
	CMesh * m_RenderMesh;

	//Base Geometry Textures
	ID3D11ShaderResourceView * DiffuseTexture;
	ID3D11ShaderResourceView * NormalMap;
	ID3D11ShaderResourceView * SpecularMap;
	ID3D11ShaderResourceView * EmisiveMap;

	//Textures for other components
	ID3D11ShaderResourceView * TelegraphTexture;

	Paragon_Renderer::cbTEXTUREFLAGS TextureFlags;


	void ShutDown();
	void CreateAndSetRenderNode(GameObject * GO);
	inline  RenderNode * GetRenderNode(int index) { if (index == 0) return RendNode_MainRender; else return  RendNode_SecondaryRender; }
	
	RendererComponent();
	~RendererComponent();
};


