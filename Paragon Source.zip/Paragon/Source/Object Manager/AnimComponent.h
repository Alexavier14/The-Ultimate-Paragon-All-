#include "../Application/stdafx.h"

#pragma once

#include "../Animation System/Animation.h"

//Tags for animations
#define PLAYER_IDLE			"PlayerIdle"
#define PLAYER_WALK			"PlayerWalk"
#define PLAYER_SEND			"PlayerSend"
#define PLAYER_RECALL		"PlayerRecall"
//#define PLAYER_SEND_ALL		"PlayerSendAll"
//#define PLAYER_RECALL_ALL	"PlayerRecallAll"
#define PLAYER_HIT			"PlayerHit"
#define PLAYER_DEATH		"PlayerDeath"

#define SPIDER_IDLE			"SpiderIdle"
#define SPIDER_ATTACK		"SpiderAttack"
#define SPIDER_DEATH_ANIM	"SpiderDeath"
#define SPIDER_MOVE			"SpiderWalk"
#define SPIDER_WEB_LAUNCH	"SpiderTrapAnim"
#define SPIDER_CC			"SpiderCC"

#define GOLEM_IDLE			"GolemIdle"
#define GOLEM_ATTACK		"GolemAttack"
#define GOLEM_DEATH_ANIM	"GolemDeath"
#define GOLEM_MOVE			"GolemWalk"
#define GOLEM_TRAP			"GolemTrapAnim"
#define GOLEM_CC			"GolemCC"

#define WORM_IDLE			"WormIdle"
#define WORM_ATTACK			"WormAttack"
#define WORM_DEATH_ANIM		"WormDeath"
#define WORM_EMERGE_ANIM	"WormEmerge"
#define WORM_SUBMERGE_ANIM	"WormSubmerge"
#define WORM_CC				"WormCC"

#define SAPPHIRE_IDLE		"SapphireIdle"
#define SAPPHIRE_ATTACK		"SapphireAttack"
#define SAPPHIRE_DEATH		"SapphireDeath"
#define SAPPHIRE_MOVE		"SapphireMove"
#define SAPPHIRE_HATTACK	"SapphireHeavyAttack"
#define SAPPHIRE_SCAN		"SapphireScan"
#define SAPPHIRE_DANCE		"SapphireDance"

#define RUBY_IDLE			"RubyIdle"
#define RUBY_ATTACK			"RubyAttack"
#define RUBY_DEATH			"RubyDeath"
#define RUBY_MOVE			"RubyMove"
#define RUBY_HATTACK		"RubyHeavyAttack"
#define RUBY_SCAN			"RubyScan"
#define RUBY_DANCE			"RubyDance"

#define DIAMOND_IDLE		"DiamondIdle"
#define DIAMOND_ATTACK		"DiamondAttack"
#define DIAMOND_DEATH		"DiamondDeath"
#define DIAMOND_MOVE		"DiamondMove"
#define DIAMOND_HATTACK		"DiamondHeavyAttack"
#define DIAMOND_SCAN		"DiamondScan"
#define DIAMOND_DANCE		"DiamondDance"


#define HAMMER_HIT			"HammerHit"

class CAnimComponent
{
	string	m_sAnimName;
	float	m_fCurrKeyTime;
	float	m_fNextKeyTime;
	float	m_fAnimSpeed;
	float	m_fTransitionTime;
	float	m_fTransitionTotalTime;
	bool	m_bNewAnim;
	bool	m_bCurrLooping;
	bool	m_bNextLooping;
	bool	m_bDeathAnim;

	//CurrAnim = the current animation we are working with.
	//NextAnim = the next animation we are going to work towards. whether it be a new animation or the previous.
	CAnimation * m_pCurrAnim, * m_pNextAnim;
	tKeyFrame m_Interpolated_Frame;

public:
	CAnimComponent();
	CAnimComponent(string animName, bool isLooping = true);

	CAnimComponent(CAnimComponent const &cpy);
	CAnimComponent & operator=(CAnimComponent const &assign);

	~CAnimComponent();

	//Accessors
	string GetAnimName() const;
	float GetCurrKeyTime() const;
	float GetNextKeyTime() const;
	float GetTransitionTime() const;
	float GetTransitionTotalTime() const;
	float GetAnimSpeed() const;
	const CAnimation* GetCurrAnimation() const;
	const CAnimation* GetNextAnimation() const;
	tKeyFrame GetInterpolatedFrame() const;
	bool IsDeathAnim() const;
	bool IsTransitioning() const;

	//Mutators
	void SetAnimName(string name, bool isLooping);
	void SetKeyTime(float time);
	void SetAnimation(CAnimation * anim, float transition);
	void SetInterpolatedFrame(tKeyFrame interpolation);
	void SetIsDeathAnim(bool isDeath);
	void SetAnimationTime(float time);

	//Setting the Transition Time will set the total time 
	//it takes to change from one animation to another.
	void SetTransitionTime(float time);

	//This Function set the animation speed.
	//The suggested range is -2.0f -> +2.0f
	//if speed == -value the animation will run backwards
	//if speed == 0 the animation will freeze it's current animation.
	//if speed == +value the animation will run backwards
	// values > 0 and < 1 slow the animation
	// values > 1 speed the animation
	void SetAnimSpeed(float speed);

	//Stops the animation transition.
	void StopTransition();

	//Helpers
	void AddTime(float delta);

};