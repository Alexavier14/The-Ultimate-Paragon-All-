#pragma once
#include "../Asset Manager/AssetManager.h"
#include "../Application/CoreFacade.h"
#include "../Application/GameFacade.h"
#include "../Physics/Circle.h"
#include "../Physics/OrientedBox.h"
#include "../Physics/Segment.h"
#include "../Physics/Physics.h"
#include "../Physics/PhysicsSystem.h"
#include "../Renderer/RenderController.h"

#include <mutex>

class TextBox;
class EffectComponent;
class EventComponent;
class HUDElement;

class LevelManager
{
	//friend CoreFacade;
public:

	LevelManager();
	~LevelManager();

	//Loading Functions from corefacade
	void LoadGameObjects(vector<ObjectToLoad> & ObjDataVec, CoreFacade * CF, GameFacade * GF);
	void LoadGem(GameObject* Parent, ObjectType gemType, CoreFacade * CF, GameFacade * GF);
	void LoadStandardGameObjects(CoreFacade * CF, GameFacade * GF);
	void LoadGeodes(CoreFacade * CF, GameFacade * GF);
	void LoadStandardEffects(CoreFacade * CF);
	void AddPointLight(GameObject * GO, float Range, float PosY, XMFLOAT3 DiffColor, XMFLOAT3 AmbColor, XMFLOAT3 SpecColor, XMFLOAT3 Atten, string LightName, bool UseFollowY, CoreFacade * CF, bool Active = true, bool Lock = false);
	TextBox* LoadTextBox(float posX, float posY, float scale, const XMFLOAT4& glyphColor, const XMFLOAT4& outlineColor, string font, CoreFacade * CF, GameFacade * GF);
	EffectComponent* LoadEffect(GameObject* pGO, const string& tag, const string& texture, const XMFLOAT2& size, const XMFLOAT3& Offset, CoreFacade * CF );
	EventComponent* LoadEvent(ObjectToLoad obj, GameObject* pGO, EventType eventType, int targetsRemaining, CoreFacade * CF, GameFacade * GF, XMVECTOR location );
	HUDElement*	LoadHudElement(string tag, string filePath, float posX, float posY, float width, float height, CoreFacade * CF, GameFacade * GF);
	Telegraph* LoadTelegraph(CoreFacade* CF, GameObject* pGO, string tag, string texture, XMVECTOR color);
};

