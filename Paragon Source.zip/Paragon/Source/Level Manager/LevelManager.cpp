#include "../Application/stdafx.h"
#include "LevelManager.h"
#include "../Util/Util.h"
#include "../Util/TimeManager.h"
#include "../Animation System/AnimationSystem.h"
#include "../Sound/SoundManager.h"
#include "../Input Manager/InputManager.h"
#include "../Text Manager/TextManager.h"
#include "../Sound/Wwise_IDs.h"
#include "../Particle System/ParticleSystem.h"
#include "../Object Manager/EventComponent.h"
#include "../Object Manager/SpawnerComponent.h"
#include "../Object Manager/PointLightComponent.h"
#include "../Object Manager/RendererComponent.h"
#include "../State Manager/LoadingScreenState.h"
#include "../Object Manager/AIData.h"
#include "../AI System/NavAgent.h"
#include <DirectXColors.h>

#define MAX_GEODE_COUNT 30 
#define TELEGRAPH_COLOR_ATTACK	Colors::Yellow
#define TELEGRAPH_COLOR_DEBUFF	Colors::Purple
#define TELEGRAPH_COLOR_TRAP	Colors::OrangeRed
//Used for the Cone Telegraphs
#define ANGLE_FUNC(x) { 180.0f - float(x) }

using namespace Physics;
using namespace DirectX;

int CurrentMemeoryAddress = 0;

LevelManager::LevelManager(){}
LevelManager::~LevelManager(){}

void LevelManager::LoadGameObjects(vector<ObjectToLoad> & ObjDataVec, CoreFacade * CF, GameFacade * GF)
{
	CF->SetDoneLoading(false);

	static int MemoryAddress = (unsigned int)this;

	//Load each object
	for (unsigned int i = 0; i < ObjDataVec.size(); i++)
	{
		if ((unsigned int)this != MemoryAddress)
		{
			int breakheretest = 0;
			WriteObjectToThreadFile(ObjDataVec[i].FBX_filename.c_str(), i);
		}
		WriteObjectToThreadFile(ObjDataVec[i].FBX_filename.c_str(), i);


		//Add the object component based on the object type
		switch (ObjDataVec[i].pGO->GetType())
		{
#pragma region Player
		case ObjectType::ePLAYER:
		{
			GameObject*& pPlayer = ObjDataVec[i].pGO;

			//GHOST COLOR
			pPlayer->GhostColor = XMFLOAT4(0.9f, 0.9f, 0.9f, 1.0f);

			PhysicsComponent* playerPhysics = GF->MakePhysicsCompoment(ObjDataVec[i].pGO);
			playerPhysics->SetMass(1e6);
			ObjDataVec[i].pGO->SetPhysicsComponent(playerPhysics);

			Circle* circlePlayer = GF->MakeCircleShape(RT_DYNAMIC);
			circlePlayer->SetRadius(2.25f);
			playerPhysics->SetCollisionShape(circlePlayer, SU_BOUNDING_SHAPE);

			//Lighting Effect after the player gets the paragon.
			Circle* Player_Lighting_Storm = GF->MakeCircleShape(RT_NONE);
			Player_Lighting_Storm->SetRadius(5.0f);
			playerPhysics->SetCollisionShape(Player_Lighting_Storm, SU_ATTACK);

			Segment* playerToReticleSegment = GF->MakeSegmentShape(RT_NONE);
			playerToReticleSegment->SetRotating(false);
			playerPhysics->SetCollisionShape(playerToReticleSegment, SU_EVENT);

			NavAgent* pPlayerNavAgent = new NavAgent(pPlayer);
			pPlayerNavAgent->Initialize(CF);
			pPlayerNavAgent->SetSkipToGoal(true);
			pPlayer->SetNavAgent(pPlayerNavAgent);

			PlayerComponent* playerComp = new PlayerComponent(*ObjDataVec[i].pGO);
			playerComp->Initialize(CF);
			ObjDataVec[i].pGO->SetPlayerComponent(playerComp);
			ObjDataVec[i].pGO->SetFocused(true);


			ObjDataVec[i].pGO->CreateAIData();
			AIData * playerData = ObjDataVec[i].pGO->GetAIData();
			playerData->health = 5;
			ObjDataVec[i].pGO->SetAIData(playerData);

			LoadEvent(ObjDataVec[i], pPlayer, eWIN_EVENT, 0, CF, GF, XMVectorZero());

			pPlayer->CreateAudioComponent(CF->GetSoundManager());

			// -- Effects --

			LoadEffect(pPlayer, "PlayerSmithing", "Attack1.dds", XMFLOAT2(4.5f, 4.5f), XMFLOAT3(0.0f, 0.0f, 0.0f), CF);
			// Rock Trap Objects
			for (unsigned int NumOfRocks = 0; NumOfRocks < 18; NumOfRocks++)
			{
				ObjectToLoad RockTrap;
				TrapComponent * newRockTrap1 = new TrapComponent(ObjDataVec[i].pGO, XMFLOAT3(0.0f, 0.0f, 0.0f), 4.0f);
				RockTrap.FBX_filename = "../Assets/Mesh/FallRock.fbx";
				RockTrap.Texture_filename = "../Assets/Textures/3D_Falling_RockD_Diffuse.dds";
				RockTrap.NormTexture_filename = "../Assets/Textures/3D_Falling_RockD_Normal.dds";
				RockTrap.SpecTexture_filename = "../Assets/Textures/3D_Falling_RockD_Spec.dds";

				//newRockTrap1->SetEnabled(true);
				GameObject* RockTrapGO = new GameObject;
				RockTrapGO->SetTag("RockTrap");

				XMMATRIX transform = XMLoadFloat4x4(&ObjDataVec[i].pGO->GetWorldTransform());
				int randomIndex = rand() % 4;
				float RotationValues[4] = { 0, 115, 165, 270 };
				transform *= XMMatrixRotationY(XMConvertToRadians(RotationValues[randomIndex]));
				transform *= XMMatrixRotationX(XMConvertToRadians(RotationValues[randomIndex]));

				RockTrapGO->SetObjectTransform(transform);
				//RockTrapGO->SetScale(4.0f);
				RockTrapGO->SetTrapComponent(newRockTrap1);
				RockTrapGO->SetTypeID(eROCK_TRAP);
				RockTrapGO->SetActive(false);
				RockTrapGO->CreateAIData();

				/*PhysicsComponent* physicsRockTrap = GF->MakePhysicsCompoment(RockTrapGO);

				Circle* circleRockTrap = GF->MakeCircleShape(RT_NONE);
				circleRockTrap->SetRadius(3.0f);
				physicsRockTrap->SetCollisionShape(circleRockTrap, SU_BOUNDING_SHAPE);

				RockTrapGO->SetPhysicsComponent(physicsRockTrap);

				TelegraphToLoad RockFall;
				Telegraph * RockFallTele = LoadTelegraph(CF, RockTrapGO, "RockFall", "GolemAttackTele.dds", Colors::Purple);
				RockFallTele->MakeCircleTelegraph(RockTrapGO, XMFLOAT2(0.0f, 0.0f), 4.0f, 3.0f);*/

				RockTrap.pGO = RockTrapGO;
				CF->m_AssetManager->LoadModel(&RockTrap);
				CF->m_ObjectManager->AddGameObject(RockTrap.pGO);

			}

			// -- Telegraphs --

			Telegraph* pSendArrowTip = LoadTelegraph(CF, pPlayer, "Send Arrow Tip", "2D_SendArrowTip.dds", Colors::Cornsilk);
			pSendArrowTip->MakeDefaultTelegraph(pPlayer, XMFLOAT2(0, 0), XMFLOAT2(5, 5), 3.0f);

			Telegraph* pSendArrowExtension = LoadTelegraph(CF, pPlayer, "Send Arrow Extension", "2D_SendArrowExtension.dds", Colors::Cornsilk);
			pSendArrowExtension->MakeDefaultTelegraph(pPlayer, XMFLOAT2(0, 0), XMFLOAT2(5, 5), 3.0f);

			// -- Animations -- 

			ObjDataVec[i].FBX_filename = "../Assets/Mesh/3D_Dwarf_Idle_Anim.fbx";
			ObjDataVec[i].Texture_filename = "../Assets/Textures/3D_Dwarf_Diffuse.dds";
			ObjDataVec[i].NormTexture_filename = "../Assets/Textures/3D_Dwarf_Normals.dds";
			ObjDataVec[i].SpecTexture_filename = "../Assets/Textures/3D_Dwarf_Spec.dds";
			ObjDataVec[i].pGO->SetAnimComponent(new CAnimComponent(PLAYER_IDLE));
			ObjDataVec[i].pGO->SetIsAnimated(true);

			AnimToLoad playerIdle(PLAYER_IDLE, "../Assets/Animations/3D_Dwarf_Idle_Anim.fbx"); //Idle will always be found in the mesh folder
			AnimToLoad playerWalk(PLAYER_WALK, "../Assets/Animations/3D_Dwarf_Walk_Anim.fbx");
			AnimToLoad playerSend(PLAYER_SEND, "../Assets/Animations/3D_Dwarf_Direct_Anim.fbx");
			AnimToLoad playerRecall(PLAYER_RECALL, "../Assets/Animations/3D_Dwarf_Recall_Anim.fbx");
			AnimToLoad playerHit(PLAYER_HIT, "../Assets/Animations/3D_Dwarf_Hit_Anim.fbx");
			AnimToLoad playerDeath(PLAYER_DEATH, "../Assets/Animations/3D_Dwarf_Death_Anim.fbx");

			CF->m_AssetManager->LoadAnimation(&playerIdle);
			CF->m_AssetManager->LoadAnimation(&playerWalk);
			CF->m_AssetManager->LoadAnimation(&playerSend);
			CF->m_AssetManager->LoadAnimation(&playerRecall);
			CF->m_AssetManager->LoadAnimation(&playerHit);
			CF->m_AssetManager->LoadAnimation(&playerDeath);

			GF->LoadEmitter("PlayerTrail", ObjDataVec[i].pGO, CF)->SetSpawning(false);

			//Loading Boulders for Rock Fall and Cave In
			Emitter * RockEmitter;
			RockEmitter = GF->LoadEmitter("GolemRockCave", ObjDataVec[i].pGO, CF);
			RockEmitter->SetEmitterSetting(1);
			RockEmitter->SetSpawnOnPlane(true);
			RockEmitter->SetSpawning(true);

			GF->LoadEmitter("BoulderImpact", ObjDataVec[i].pGO, CF)->SetSpawning(false);

			//The Second larger rock emitter
			RockEmitter = GF->LoadEmitter("Larger_GolemRockCave", ObjDataVec[i].pGO, CF);
			RockEmitter->SetEmitterSetting(1);
			RockEmitter->SetSpawnOnPlane(true);
			RockEmitter->SetSpawning(false);
			RockEmitter->SetSpawnRate(0.0f);

			//Storm Emitter
			Emitter * StormEmitter = GF->LoadEmitter("Lightning", ObjDataVec[i].pGO, CF);
			StormEmitter->SetEmitterSetting(1);
			StormEmitter->SetSpawning(false);
			StormEmitter->SetSpawnOnPlane(true);
			StormEmitter = GF->LoadEmitter("Lightning2", ObjDataVec[i].pGO, CF);
			StormEmitter->SetEmitterSetting(1);
			StormEmitter->SetSpawning(false);
			StormEmitter->SetSpawnOnPlane(true);

			//Spark Emitter
			Emitter * StormSparkEmitter = GF->LoadEmitter("Lightning_Sparks", ObjDataVec[i].pGO, CF);
			//StormSparkEmitter->SetEmitterSetting(1);
			StormSparkEmitter->SetSpawning(false);
			//StormSparkEmitter->SetSpawnOnPlane(true);

			//Dwarf Spark Emitter

			break;
		}
#pragma endregion
#pragma region Spider
		case ObjectType::eSPIDER:
		{
			GameObject*& pSpider = ObjDataVec[i].pGO;
			//if (ObjDataVec[i].pGO->GetTag() == "DumbSpider")
			//	LoadGem(ObjDataVec[i].pGO, eRUBYGEM, CF, GF);
			//else
			//	LoadGem(ObjDataVec[i].pGO, eSAPPHIREGEM, CF, GF);
			pSpider->GhostColor = XMFLOAT4(0.9f, 0.2f, 0.1f, 1.0f);
			PhysicsComponent* physicsSpider = GF->MakePhysicsCompoment(ObjDataVec[i].pGO);
			physicsSpider->SetVelocity({ 0, 0.0f });
			physicsSpider->SetMass(1e12f);
			ObjDataVec[i].pGO->SetPhysicsComponent(physicsSpider);

			ObjDataVec[i].pGO->CreateAIData();
			AIData * dataSpider = ObjDataVec[i].pGO->GetAIData();
			dataSpider->health = 25;
			dataSpider->bAttacked = dataSpider->bCCed = dataSpider->bAttackSound = dataSpider->bCCSound = false;
			dataSpider->enemyState = AIData::EnPatrol;
			dataSpider->WayPoints = ObjDataVec[i].WayPoints;
			//dataSpider->m_fAirTime = 1.5f;

			pSpider->CreateAudioComponent(CF->GetSoundManager());


			//Animations
			ObjDataVec[i].FBX_filename = "../Assets/Mesh/SpiderIdle.fbx";
			ObjDataVec[i].pGO->SetAnimComponent(new CAnimComponent(SPIDER_IDLE));
			ObjDataVec[i].pGO->SetIsAnimated(true);

			AnimToLoad spiderIdle(SPIDER_IDLE, "../Assets/Animations/Spider_Anim_Idle.fbx"); //Idle will always be found in the mesh folder
			AnimToLoad spiderMove(SPIDER_MOVE, "../Assets/Animations/Spider_Anim_Walk.fbx");
			AnimToLoad spiderCC(SPIDER_CC, "../Assets/Animations/SpiderCC.fbx");
			AnimToLoad spiderWebLaunch(SPIDER_WEB_LAUNCH, "../Assets/Animations/Spider_Anim_Spell.fbx");
			AnimToLoad spiderAttack(SPIDER_ATTACK, "../Assets/Animations/Spider_Anim_Attack.fbx");
			AnimToLoad spiderDeath(SPIDER_DEATH_ANIM, "../Assets/Animations/Spider_Anim_Death.fbx");

			CF->m_AssetManager->LoadAnimation(&spiderIdle);
			CF->m_AssetManager->LoadAnimation(&spiderMove);
			CF->m_AssetManager->LoadAnimation(&spiderCC);
			CF->m_AssetManager->LoadAnimation(&spiderWebLaunch);
			CF->m_AssetManager->LoadAnimation(&spiderAttack);
			CF->m_AssetManager->LoadAnimation(&spiderDeath);


			Circle* circleSpider1Bound = GF->MakeCircleShape(RT_DYNAMIC);
			circleSpider1Bound->SetRadius(4.0f);
			physicsSpider->SetCollisionShape(circleSpider1Bound, SU_BOUNDING_SHAPE);

			Circle* circleSpider1Scanner = GF->MakeCircleShape(RT_NONE);
			circleSpider1Scanner->SetRadius(20.0f);
			physicsSpider->SetCollisionShape(circleSpider1Scanner, SU_SCANNER);

			//Circle* circleSpider1AttkScanner = GF->MakeCircleShape(RT_NONE);
			//circleSpider1AttkScanner->SetRadius(4.0f);
			//physicsSpider->SetCollisionShape(circleSpider1AttkScanner, SU_ATTACK);

			if (ObjDataVec[i].pGO->GetTag() == "FirstTrapSpider")
			{
				Circle* eventSpiderCircle = GF->MakeCircleShape(RT_NONE);
				eventSpiderCircle->SetRadius(40.0f);
				physicsSpider->SetCollisionShape(eventSpiderCircle, SU_EVENT);
				dataSpider->bLeader = true;
				dataSpider->nEnemyGroup = 1;
			}

			else if (ObjDataVec[i].pGO->GetTag() == "Spider2")
			{
				dataSpider->nEnemyGroup = 1;
			}
			Cone* coneSpider1AttkScanner = GF->MakeConeShape(RT_NONE, 60.0f, 10.0f); //Use ANGLE_FUNC(x) to get the right angle for the telegraph.
			physicsSpider->SetCollisionShape(coneSpider1AttkScanner, SU_ATTACK);

			Circle* circleSpiderFearScanner = GF->MakeCircleShape(RT_NONE);
			circleSpiderFearScanner->SetRadius(10.0f);
			physicsSpider->SetCollisionShape(circleSpiderFearScanner, SU_CC);

			//---- Telegraphs ---

			Telegraph * SpiderAttackTele = LoadTelegraph(CF, pSpider, "Spider Attack", "SpiderAttackTele.dds", TELEGRAPH_COLOR_ATTACK);
			SpiderAttackTele->MakeConeTelegraph(ObjDataVec[i].pGO, XMFLOAT2(NULL, NULL), 12.075F, ANGLE_FUNC(60.0f), 3.0f);

			Telegraph * SpiderFearTele = LoadTelegraph(CF, pSpider, "Spider Fear", "SpiderFear.dds", TELEGRAPH_COLOR_DEBUFF);
			SpiderFearTele->MakeCircleTelegraph(ObjDataVec[i].pGO, XMFLOAT2(0.0f, 0.0f), 10.0f, 4.0f);

			Telegraph * SpiderJumpTele = LoadTelegraph(CF, pSpider, "Spider Jump", "SpiderAttackTele.dds", TELEGRAPH_COLOR_ATTACK);
			SpiderJumpTele->MakeCircleTelegraph(ObjDataVec[i].pGO, XMFLOAT2(0.0f, 0.0f), 6.0f, 3.0f);

			//---EFFECTS FOR SPIDER---

			XMFLOAT3 effectOffset(0.0f, 0.0f, 0.0f);
			XMFLOAT2 effectSize(4.5f, 4.5f);

			LoadEffect(pSpider, "SpiderHealthBar", "SpiderHealth.dds", effectSize, effectOffset, CF);
			//LoadEffect(pSpider, "SpiderAttack", "Clear.dds", effectSize, effectOffset, CF);


			// Spider Trap Object
			// Web 1:
			ObjectToLoad SpiderTrap;
			TrapComponent * newSpiderTrap = new TrapComponent(ObjDataVec[i].pGO, XMFLOAT3(0.0f, 2.0f, 0.0f), 4.0f);
			SpiderTrap.FBX_filename = "../Assets/Mesh/3D_Spider_Web.fbx";
			SpiderTrap.Texture_filename = "../Assets/Textures/Default_Texture.dds";

			//newSpiderTrap1->SetEnabled(true);
			GameObject* SpiderTrapGO = new GameObject;
			SpiderTrapGO->SetTag("SpiderTrap");
			SpiderTrapGO->SetObjectColor(Colors::White, 1.0f);
			SpiderTrapGO->CreateAudioComponent(CF->GetSoundManager());
			//SpiderTrapGO->SetObjectTransform(ObjDataVec[i].pGO->GetWorldTransform());
			XMMATRIX transform = XMLoadFloat4x4(&ObjDataVec[i].pGO->GetWorldTransform());
			transform.r[0] = XMVector3Normalize(transform.r[0])*4.0f;
			transform.r[2] = XMVector3Normalize(transform.r[2])*4.0f;
			SpiderTrapGO->SetObjectTransform(transform);
			SpiderTrapGO->SetTrapComponent(newSpiderTrap);
			SpiderTrapGO->SetTypeID(eSPIDER_WEB);
			SpiderTrapGO->SetActive(false);
			SpiderTrapGO->CreateAIData();

			// Web 2:
			ObjectToLoad SpiderTrap1;
			TrapComponent * newSpiderTrap1 = new TrapComponent(ObjDataVec[i].pGO, XMFLOAT3(0.0f, 2.0f, 0.0f), 4.0f);
			SpiderTrap1.FBX_filename = "../Assets/Mesh/3D_Spider_Web.fbx";
			SpiderTrap1.Texture_filename = "../Assets/Textures/Default_Texture.dds";

			GameObject* SpiderTrapGO1 = new GameObject;
			SpiderTrapGO1->SetTag("SpiderTrap1");
			SpiderTrapGO1->CreateAudioComponent(CF->GetSoundManager());
			//SpiderTrapGO->SetObjectTransform(ObjDataVec[i].pGO->GetWorldTransform());
			SpiderTrapGO1->SetObjectColor(Colors::White, 1.0f);
			XMMATRIX transform1 = XMLoadFloat4x4(&ObjDataVec[i].pGO->GetWorldTransform());
			transform.r[0] = XMVector3Normalize(transform.r[0])*4.0f;
			transform.r[2] = XMVector3Normalize(transform.r[2])*4.0f;
			SpiderTrapGO1->SetObjectTransform(transform);
			//SpiderTrapGO->SetScale(4.0f);
			SpiderTrapGO1->SetTrapComponent(newSpiderTrap1);
			SpiderTrapGO1->SetTypeID(eSPIDER_WEB);
			SpiderTrapGO1->SetActive(false);
			SpiderTrapGO1->CreateAIData();

			// Web 3:
			ObjectToLoad SpiderTrap2;
			TrapComponent * newSpiderTrap2 = new TrapComponent(ObjDataVec[i].pGO, XMFLOAT3(0.0f, 2.0f, 0.0f), 4.0f);
			SpiderTrap2.FBX_filename = "../Assets/Mesh/3D_Spider_Web.fbx";
			SpiderTrap2.Texture_filename = "../Assets/Textures/Default_Texture.dds";

			GameObject* SpiderTrapGO2 = new GameObject;
			SpiderTrapGO2->SetTag("SpiderTrap2");
			SpiderTrapGO2->SetObjectColor(Colors::White, 1.0f);
			SpiderTrapGO2->CreateAudioComponent(CF->GetSoundManager());
			//SpiderTrapGO->SetObjectTransform(ObjDataVec[i].pGO->GetWorldTransform());
			XMMATRIX transform2 = XMLoadFloat4x4(&ObjDataVec[i].pGO->GetWorldTransform());
			transform.r[0] = XMVector3Normalize(transform.r[0])*4.0f;
			transform.r[2] = XMVector3Normalize(transform.r[2])*4.0f;
			SpiderTrapGO2->SetObjectTransform(transform);
			//SpiderTrapGO->SetScale(4.0f);
			SpiderTrapGO2->SetTrapComponent(newSpiderTrap2);
			SpiderTrapGO2->SetTypeID(eSPIDER_WEB);
			SpiderTrapGO2->SetActive(false);
			SpiderTrapGO2->CreateAIData();

			PhysicsComponent* physicsSpiderTrap = GF->MakePhysicsCompoment(SpiderTrapGO);
			Circle* circleSpiderTrap = GF->MakeCircleShape(RT_NONE);
			circleSpiderTrap->SetRadius(4.0f);
			physicsSpiderTrap->SetCollisionShape(circleSpiderTrap, SU_BOUNDING_SHAPE);
			SpiderTrapGO->SetPhysicsComponent(physicsSpiderTrap);

			PhysicsComponent* physicsSpiderTrap1 = GF->MakePhysicsCompoment(SpiderTrapGO1);
			Circle* circleSpiderTrap1 = GF->MakeCircleShape(RT_NONE);
			circleSpiderTrap1->SetRadius(4.0f);
			physicsSpiderTrap1->SetCollisionShape(circleSpiderTrap1, SU_BOUNDING_SHAPE);
			SpiderTrapGO1->SetPhysicsComponent(physicsSpiderTrap1);

			PhysicsComponent* physicsSpiderTrap2 = GF->MakePhysicsCompoment(SpiderTrapGO2);
			Circle* circleSpiderTrap2 = GF->MakeCircleShape(RT_NONE);
			circleSpiderTrap2->SetRadius(4.0f);
			physicsSpiderTrap2->SetCollisionShape(circleSpiderTrap2, SU_BOUNDING_SHAPE);
			SpiderTrapGO2->SetPhysicsComponent(physicsSpiderTrap2);

			SpiderTrap.pGO = SpiderTrapGO;
			CF->m_AssetManager->LoadModel(&SpiderTrap);
			CF->m_ObjectManager->AddGameObject(SpiderTrap.pGO);
			dataSpider->m_TrapList.push_back(SpiderTrap.pGO);

			SpiderTrap1.pGO = SpiderTrapGO1;
			CF->m_AssetManager->LoadModel(&SpiderTrap1);
			CF->m_ObjectManager->AddGameObject(SpiderTrap1.pGO);
			dataSpider->m_TrapList.push_back(SpiderTrap1.pGO);

			SpiderTrap2.pGO = SpiderTrapGO2;
			CF->m_AssetManager->LoadModel(&SpiderTrap2);
			CF->m_ObjectManager->AddGameObject(SpiderTrap2.pGO);
			dataSpider->m_TrapList.push_back(SpiderTrap2.pGO);

			ObjDataVec[i].pGO->SetAIData(dataSpider);

			Emitter * JumpEmitter;
			JumpEmitter = GF->LoadEmitter("PlayerTrail", ObjDataVec[i].pGO, CF);
			JumpEmitter->SetSpawning(false);
			//JumpEmitter->SetSpawnOnPlane(true);
			//JumpEmitter->SetSpawnRate(0.0f);
			//RockEmitter->SetLifeTime(0.5f);

			// Cutscene for Web Tutorial Spider
			if (ObjDataVec[i].pGO->GetTag() == "FirstTrapSpider")
			{
				//ObjDataVec[i].pGO->SetReactionTime(2.0f);
				EventComponent* TWebEvent = new EventComponent;
				TWebEvent->m_EventType = eWEB_EVENT;
				//TWebEvent->InitialTargets = 1;
				TWebEvent->TargetsRemaining = 1;
				//TWebEvent->CameraToDoorWaypoints.push(ObjDataVec[i].pGO->GetObjectTranslation());
				TWebEvent->SetLocation(ObjDataVec[i].pGO->GetObjectTranslationVec());
				ObjDataVec[i].pGO->SetEventComponent(TWebEvent);

			}


			//ObjDataVec[i].pGO->SetAnimComponent(new CAnimComponent(SPIDER_IDLE));
			//ObjDataVec[i].pGO->SetIsAnimated(true);

			//AnimToLoad SpiderIdle(SPIDER_IDLE, "../Assets/Mesh/3D_Spider_Idle_anim.fbx"); //Idle will always be found in the mesh folder

			//CF->GetAssetManager()->LoadAnimation(&SpiderIdle);

			break;
		}
#pragma endregion
#pragma region EnemySpawner
		case ObjectType::eSPAWNER:
		{
			GameObject *& pSpawner = ObjDataVec[i].pGO;

			SpawnerComponent* SpawnerData = new SpawnerComponent(CF);
			SpawnerData->WaveSpawnType = ObjDataVec[i].WayPoints;
			pSpawner->SetSpawnerComponent(SpawnerData);
			break;
		}
#pragma endregion
#pragma region Golem
		case ObjectType::eGOLEM:
		{
			GameObject*& pGolem = ObjDataVec[i].pGO;
			pGolem->GhostColor = XMFLOAT4(0.9f, 0.2f, 0.1f, 1.0f);

			ObjDataVec[i].FBX_filename = "../Assets/Mesh/3D_Golem_Idle_Anim.fbx";
			ObjDataVec[i].Texture_filename = "../Assets/Textures/3D_GolemEnemy_Diffuse.dds";
			ObjDataVec[i].NormTexture_filename = "../Assets/Textures/3D_GolemEnemy_Normal.dds";
			ObjDataVec[i].SpecTexture_filename = "../Assets/Textures/3D_GolemEnemy_Specular.dds";
			ObjDataVec[i].SpecTexture_filename = "../Assets/Textures/3D_GolemEnemy_Emissive.dds";

			//LoadGem(ObjDataVec[i].pGO, eDIAMONDGEM, CF, GF);
			PhysicsComponent* physicsGolem = GF->MakePhysicsCompoment(ObjDataVec[i].pGO);
			physicsGolem->SetVelocity({ 0, 0.0f });
			physicsGolem->SetMass(1e12f);
			ObjDataVec[i].pGO->SetPhysicsComponent(physicsGolem);

			ObjDataVec[i].pGO->CreateAIData();
			AIData * dataGolem = ObjDataVec[i].pGO->GetAIData();
			dataGolem->health = 30;
			//ObjDataVec[i].pGO->SetScale(1.25f);
			dataGolem->bAttacked = dataGolem->bCCed = dataGolem->bAttackSound = dataGolem->bCCSound = false;
			dataGolem->enemyState = AIData::EnPatrol;
			dataGolem->WayPoints = ObjDataVec[i].WayPoints;
			ObjDataVec[i].pGO->SetAIData(dataGolem);

			pGolem->SetAnimComponent(new CAnimComponent(GOLEM_IDLE));
			pGolem->SetIsAnimated(true);

			pGolem->CreateAudioComponent(CF->GetSoundManager());

			Circle* circleGolem1Bound = GF->MakeCircleShape(RT_DYNAMIC);
			circleGolem1Bound->SetRadius(4.0f);
			physicsGolem->SetCollisionShape(circleGolem1Bound, SU_BOUNDING_SHAPE);

			Circle* circleGolem1Scanner = GF->MakeCircleShape(RT_NONE);
			circleGolem1Scanner->SetRadius(20.0f);
			physicsGolem->SetCollisionShape(circleGolem1Scanner, SU_SCANNER);

			Circle* circleGolem1AttkScanner = GF->MakeCircleShape(RT_NONE);
			circleGolem1AttkScanner->SetRadius(8.0f);
			physicsGolem->SetCollisionShape(circleGolem1AttkScanner, SU_ATTACK);

			Circle* circleGolemStunScanner = GF->MakeCircleShape(RT_NONE);
			circleGolemStunScanner->SetRadius(10.0f);
			physicsGolem->SetCollisionShape(circleGolemStunScanner, SU_CC);


			// Rock Trap Objects
			for (unsigned int NumOfRocks = 0; NumOfRocks < 8; NumOfRocks++)
			{
				ObjectToLoad RockTrap;
				TrapComponent * newRockTrap1 = new TrapComponent(ObjDataVec[i].pGO, XMFLOAT3(0.0f, 6.0f, 0.0f), 4.0f);
				RockTrap.FBX_filename = "../Assets/Mesh/FallRock.fbx";
				RockTrap.Texture_filename = "../Assets/Textures/3D_Falling_RockD_Diffuse.dds";
				RockTrap.NormTexture_filename = "../Assets/Textures/3D_Falling_RockD_Normal.dds";
				RockTrap.SpecTexture_filename = "../Assets/Textures/3D_Falling_RockD_Spec.dds";

				//newRockTrap1->SetEnabled(true);
				GameObject* RockTrapGO = new GameObject;
				RockTrapGO->SetTag("RockTrap");
				//RockTrapGO->SetObjectTransform(ObjDataVec[i].pGO->GetWorldTransform());
				RockTrapGO->CreateAudioComponent(CF->GetSoundManager());
				XMMATRIX transform = XMLoadFloat4x4(&ObjDataVec[i].pGO->GetWorldTransform());
				int randomIndex = rand() % 4;
				float RotationValues[4] = { 0, 115, 165, 270 };
				transform *= XMMatrixRotationY(XMConvertToRadians(RotationValues[randomIndex]));
				transform *= XMMatrixRotationX(XMConvertToRadians(RotationValues[randomIndex]));
				//transform.r[0] = XMVector3Normalize(transform.r[0])*4.0f;
				//transform.r[2] = XMVector3Normalize(transform.r[2])*4.0f;
				RockTrapGO->SetObjectTransform(transform);
				//RockTrapGO->SetScale(4.0f);
				RockTrapGO->SetTrapComponent(newRockTrap1);
				RockTrapGO->SetTypeID(eROCK_TRAP);
				RockTrapGO->SetActive(false);
				RockTrapGO->CreateAIData();

				PhysicsComponent* physicsRockTrap = GF->MakePhysicsCompoment(RockTrapGO);

				Circle* circleRockTrap = GF->MakeCircleShape(RT_NONE);
				circleRockTrap->SetRadius(3.0f);
				physicsRockTrap->SetCollisionShape(circleRockTrap, SU_SCANNER);

				RockTrapGO->SetPhysicsComponent(physicsRockTrap);

				TelegraphToLoad RockFall;
				Telegraph * RockFallTele = LoadTelegraph(CF, RockTrapGO, "RockFall", "GolemAttackTele.dds", TELEGRAPH_COLOR_TRAP);
				RockFallTele->MakeCircleTelegraph(RockTrapGO, XMFLOAT2(0.0f, 0.0f), 4.0f, 3.0f);

				RockTrap.pGO = RockTrapGO;
				CF->m_AssetManager->LoadModel(&RockTrap);
				CF->m_ObjectManager->AddGameObject(RockTrap.pGO);

			}




			//---- Golem Telegraphs -----

			Telegraph * GolemAttackTele = LoadTelegraph(CF, pGolem, "Golem Attack", "GolemAttackTele.dds", TELEGRAPH_COLOR_ATTACK);
			GolemAttackTele->MakeCircleTelegraph(ObjDataVec[i].pGO, XMFLOAT2(0.0f, 0.0f/*GOLEM_Z_OFFSET*/), 9.0f, 3.0f);
			Telegraph * GolemStunTele = LoadTelegraph(CF, pGolem, "Golem Fear", "GolemAttackTele.dds", TELEGRAPH_COLOR_DEBUFF);
			GolemStunTele->MakeCircleTelegraph(ObjDataVec[i].pGO, XMFLOAT2(0.0f, 0.0f), 10.0f, 4.0f);

			//---EFFECTS FOR GOLEM---

			XMFLOAT3 effectOffset(0.0f, 0.0f, 0.0f);
			XMFLOAT2 effectSize(4.5f, 4.5f);

			LoadEffect(pGolem, "GolemHealthbar", "SpiderHealth.dds", effectSize, effectOffset, CF);

			// Emitters

			Emitter* pGolempSmash = GF->LoadEmitter("GolemSmash", ObjDataVec[i].pGO, CF);
			pGolempSmash->SetSpawning(false);
			pGolempSmash->SetSpawnOnPlane(true);

			Emitter* pGolempStomp = GF->LoadEmitter("GolemStomp", ObjDataVec[i].pGO, CF);
			pGolempStomp->SetSpawning(false);
			pGolempStomp->SetSpawnOnPlane(true);

			Emitter* pGolemWalk = GF->LoadEmitter("GolemWalk", ObjDataVec[i].pGO, CF);
			pGolempStomp->SetSpawning(false);
			pGolempStomp->SetSpawnOnPlane(true);

			//Load animations
			AnimToLoad golemIdle(GOLEM_IDLE, "../Assets/Animations/3D_Golem_Idle_Anim.fbx"); //Idle will always be found in the mesh folder
			AnimToLoad golemMove(GOLEM_MOVE, "../Assets/Animations/3D_Golem_Move_Anim.fbx");
			AnimToLoad golemCC(GOLEM_CC, "../Assets/Animations/3D_Golem_CC_Anim.fbx");
			AnimToLoad golemTrap(GOLEM_TRAP, "../Assets/Animations/3D_Golem_TrapAttack_Anim.fbx");
			AnimToLoad golemAttack(GOLEM_ATTACK, "../Assets/Animations/3D_Golem_Shockwave.fbx");
			AnimToLoad golemDeath(GOLEM_DEATH_ANIM, "../Assets/Animations/3D_Golem_Death_Anim.fbx");

			CF->m_AssetManager->LoadAnimation(&golemIdle);
			CF->m_AssetManager->LoadAnimation(&golemMove);
			CF->m_AssetManager->LoadAnimation(&golemCC);
			CF->m_AssetManager->LoadAnimation(&golemTrap);
			CF->m_AssetManager->LoadAnimation(&golemAttack);
			CF->m_AssetManager->LoadAnimation(&golemDeath);

			break;
		}
#pragma endregion
#pragma region Worm
		case ObjectType::eWORM:
		{
			GameObject*& pWorm = ObjDataVec[i].pGO;
			//Remove Texture Hard coding
			//ObjDataVec[i].Texture_filename = "../Assets/Textures/Worm_D.dds";
			//ObjDataVec[i].NormTexture_filename = "../Assets/Textures/Worm_N.dds";
			//ObjDataVec[i].SpecTexture_filename = "../Assets/Textures/Worm_S.dds";
			//LoadGem(ObjDataVec[i].pGO, eDIAMONDGEM, CF, GF);

			//ObjDataVec[i].FBX_filename = "../Assets/Mesh/3D_Worm_Animation_Idle.fbx";
			pWorm->SetIsAnimated(true);
			pWorm->SetAnimComponent(new CAnimComponent(WORM_SUBMERGE_ANIM, false));

			PhysicsComponent* physicsWorm = GF->MakePhysicsCompoment(ObjDataVec[i].pGO);
			physicsWorm->SetVelocity({ 0, 0.0f });
			physicsWorm->SetMass(1e12f);
			ObjDataVec[i].pGO->SetPhysicsComponent(physicsWorm);

			ObjDataVec[i].pGO->CreateAIData();
			AIData * dataWorm = ObjDataVec[i].pGO->GetAIData();
			dataWorm->health = 35;
			dataWorm->bAttacked = dataWorm->bCCed = dataWorm->bAttackSound = dataWorm->bCCSound = false;
			dataWorm->enemyState = AIData::EnPatrol;
			dataWorm->fActionCooldownB = 0.0f;
			dataWorm->WayPoints = ObjDataVec[i].WayPoints;
			ObjDataVec[i].pGO->SetAIData(dataWorm);

			pWorm->CreateAudioComponent(CF->GetSoundManager());

			Circle* circleWorm1Bound = GF->MakeCircleShape(RT_DYNAMIC);
			circleWorm1Bound->SetRadius(4.0f);
			physicsWorm->SetCollisionShape(circleWorm1Bound, SU_BOUNDING_SHAPE);

			Circle* circleWorm1Scanner = GF->MakeCircleShape(RT_NONE);
			circleWorm1Scanner->SetRadius(18.0f);
			physicsWorm->SetCollisionShape(circleWorm1Scanner, SU_SCANNER);

			//OrientedBox* OBBWorm1AttkScanner = GF->MakeOBBShape(RT_NONE);
			//OBBWorm1AttkScanner->SetSize(6.0f, 14.0f);
			//physicsWorm->SetCollisionShape(OBBWorm1AttkScanner, SU_ATTACK);

			Circle* OBBWorm1AttkScanner = GF->MakeCircleShape(RT_NONE);
			OBBWorm1AttkScanner->SetRadius(3.75f);
			physicsWorm->SetCollisionShape(OBBWorm1AttkScanner, SU_ATTACK);

			Cone* coneWorm1FearScanner = GF->MakeConeShape(RT_NONE, 270.0f, 15.0f); //Use ANGLE_FUNC(x) to get the right angle for the telegraph.
			physicsWorm->SetCollisionShape(coneWorm1FearScanner, SU_CC);

			Circle* WormRangeScanner = GF->MakeCircleShape(RT_NONE);
			WormRangeScanner->SetRadius(18.0f);
			physicsWorm->SetCollisionShape(WormRangeScanner, SU_RANGEDATTACK);

			//---- Worm  Telegraphs -----

			Telegraph * WormAttackTele = LoadTelegraph(CF, pWorm, "Worm Attack", "SpiderAttackTele.dds", TELEGRAPH_COLOR_ATTACK);
			WormAttackTele->MakeOBBTelegraph(ObjDataVec[i].pGO, XMFLOAT2(WORM_X_OFFSET, WORM_Z_OFFSET), XMFLOAT2(8.5f, 28.0f), 1.6f);

			Telegraph * WormKnockbackTele = LoadTelegraph(CF, pWorm, "Worm Knockback", "SpiderFear.dds", TELEGRAPH_COLOR_DEBUFF/*CadetBlue*/);
			WormKnockbackTele->MakeConeTelegraph(ObjDataVec[i].pGO, XMFLOAT2(NULL, NULL), 12.075f, ANGLE_FUNC(270.0f), 3.0f);

			Telegraph * WormEmergeTele = LoadTelegraph(CF, pWorm, "Worm Emerge", "SpiderFear.dds", TELEGRAPH_COLOR_ATTACK/*CadetBlue*/);
			WormEmergeTele->MakeCircleTelegraph(ObjDataVec[i].pGO, XMFLOAT2(0.0f, 0.0f), 5.0f, 3.0f);

			//---EFFECTS FOR Worm---

			XMFLOAT3 effectOffset(0.0f, 0.0f, 0.0f);
			XMFLOAT2 effectSize(4.5f, 4.5f);

			LoadEffect(pWorm, "WormHealthbar", "SpiderHealth.dds", effectSize, effectOffset, CF);

			//Loading Underground movement
			Emitter * DustEmitter;
			DustEmitter = GF->LoadEmitter("WormTrail1", ObjDataVec[i].pGO, CF);
			//DustEmitter->SetEmitterSetting(1);
			DustEmitter->SetSpawnOnPlane(true);
			DustEmitter->SetSpawning(true);

			Emitter * DustEmitter2;
			DustEmitter2 = GF->LoadEmitter("WormTrail2", ObjDataVec[i].pGO, CF);
			//DustEmitter2->SetEmitterSetting(1);
			DustEmitter2->SetSpawnOnPlane(true);
			DustEmitter2->SetSpawning(true);


			//--- Worm Trap -----


			for (size_t j = 0; j < 5; j++)
			{
				ObjectToLoad WormTrap;
				WormTrap.FBX_filename = "../Assets/Mesh/3D_Worm_Trap.fbx";
				WormTrap.Texture_filename = "../Assets/Textures/WormHole_D.dds";
				WormTrap.NormTexture_filename = "../Assets/Textures/WormHole_N.dds";
				WormTrap.SpecTexture_filename = "../Assets/Textures/WormHole_S.dds";

				GameObject* WormTrapGO = new GameObject;
				WormTrapGO->SetTag("WormTrap");
				WormTrapGO->SetTransformToIdentiy();
				WormTrapGO->SetActive(false);
				WormTrapGO->CreateAIData();
				WormTrapGO->SetTypeID(eWORM_TRAP);
				WormTrapGO->CreateAudioComponent(CF->GetSoundManager());
				WormTrapGO->SetObjectTranslation(WormTrapGO->GetObjectTranslation().x, 2.0f, WormTrapGO->GetObjectTranslation().z);

				TrapComponent * WormTrapComponent = new TrapComponent(ObjDataVec[i].pGO, { 0, 0.0f, 0 }, 30.0f);
				WormTrapGO->SetTrapComponent(WormTrapComponent);

				PhysicsComponent * WormTrapPhysics = GF->MakePhysicsCompoment(WormTrapGO);
				Circle * WormTrapCircle = GF->MakeCircleShape(RT_NONE);
				WormTrapCircle->SetRadius(3.5f);
				WormTrapPhysics->SetCollisionShape(WormTrapCircle, SU_SCANNER);
				WormTrapGO->SetPhysicsComponent(WormTrapPhysics);

				DustEmitter = GF->LoadEmitter("WormTrapParticle1", WormTrapGO, CF);
				//DustEmitter->SetEmitterSetting(1);
				DustEmitter->SetSpawnOnPlane(true);
				DustEmitter->SetSpawning(false);

				DustEmitter2 = GF->LoadEmitter("WormTrapParticle2", WormTrapGO, CF);
				//DustEmitter2->SetEmitterSetting(1);
				DustEmitter2->SetSpawnOnPlane(false);
				DustEmitter2->SetSpawning(false);

				WormTrap.pGO = WormTrapGO;

				CF->m_AssetManager->LoadModel(&WormTrap);
				CF->m_ObjectManager->AddGameObject(WormTrapGO);
			}

			//Animations
			AnimToLoad worm_idle(WORM_IDLE, "../Assets/Animations/3D_Worm_Animation_Idle.fbx");
			AnimToLoad worm_attk(WORM_ATTACK, "../Assets/Animations/3D_Worm_Animation_Attack.fbx");
			AnimToLoad worm_cc(WORM_CC, "../Assets/Animations/3D_Worm_Animation_CC.fbx");
			AnimToLoad worm_emerge(WORM_EMERGE_ANIM, "../Assets/Animations/3D_Worm_Animation_Emerge.fbx");
			AnimToLoad worm_submerge(WORM_SUBMERGE_ANIM, "../Assets/Animations/3D_Worm_Animation_Submerge.fbx");
			CF->GetAssetManager()->LoadAnimation(&worm_idle);
			CF->GetAssetManager()->LoadAnimation(&worm_attk);
			CF->GetAssetManager()->LoadAnimation(&worm_cc);
			CF->GetAssetManager()->LoadAnimation(&worm_emerge);
			CF->GetAssetManager()->LoadAnimation(&worm_submerge);

			break;
		}
#pragma endregion
#pragma region Anvil1
		case ObjectType::eANVIL:
		{
			GameObject*& pAnvil = ObjDataVec[i].pGO;

			PhysicsComponent* physicsAnvil = GF->MakePhysicsCompoment(ObjDataVec[i].pGO);
			physicsAnvil->SetVelocity({ 0, 0.0f });
			physicsAnvil->SetMass(INFINITE_MASS);
			ObjDataVec[i].pGO->SetPhysicsComponent(physicsAnvil);

			//Bounding Box
			OrientedBox * NewBoundingShape = GF->MakeOBBShape(Physics::ResolutionType::RT_FIXED);
			XMMATRIX AnvilTransform = XMLoadFloat4x4(&ObjDataVec[i].pGO->GetWorldTransform());
			XMVECTOR xAxis = AnvilTransform.r[0];

			XMFLOAT2 halfSize = XMFLOAT2(2.25f, 3.75f);
			NewBoundingShape->SetHalfSize(XMLoadFloat2(&halfSize));
			XMVECTOR direction = XMCVector3SwizzleXZ(xAxis);
			NewBoundingShape->SetDirection(direction);
			physicsAnvil->SetCollisionShape(NewBoundingShape, SU_BOUNDING_SHAPE);

			Circle* circleAnvilScanner = GF->MakeCircleShape(RT_NONE);
			circleAnvilScanner->SetRadius(7.0f);
			physicsAnvil->SetCollisionShape(circleAnvilScanner, SU_SCANNER);

			ObjDataVec[i].pGO->CreateAudioComponent(CF->GetSoundManager());

			//Effects 

			XMFLOAT3 effectOffset(0.0f, 0.0f, 0.0f);
			XMFLOAT2 effectSize(4.5f, 4.5f);

			//Special Case Loading for Anvil Option Effect.
			EffectComponent* pAnvilOptionsEffect = LoadEffect(pAnvil, "AnvilOptions", "2D_Anvil_Options.dds", XMFLOAT2(8.0f, 4.0f), XMFLOAT3(0, 5, 0), CF);
			//LoadingScreenState::LoadLock.lock();
			//ID3D11Device* pDevice = CF->m_Render_Controller->GetDevice();
			//LoadingScreenState::LoadLock.unlock();
			//RendererComponent* pAnvilOptionsRendComp = pAnvilOptionsEffect->GetParent()->GetRendererComponent();

			//WriteToThreadLog("Could Be Asset Problem");
			//CF->m_AssetManager->LoadTexture("../Assets/Textures/2D_Unavailable_Geode_Creation.dds", pDevice, &pAnvilOptionsRendComp->NormalMap);
			//CF->m_AssetManager->LoadTexture("../Assets/Textures/2D_Free_Geode_Creation.dds", pDevice, &pAnvilOptionsRendComp->SpecularMap);
			//CF->m_AssetManager->LoadTexture("../Assets/Textures/2D_Max_Geode_Creation.dds", pDevice, &pAnvilOptionsRendComp->EmisiveMap);

			//WriteToThreadLog("Could Be Effect Problem");
			LoadEffect(pAnvil, "AnvilMarker", "2D_Anvil_Marker.dds", XMFLOAT2(6.0f, 6.0f), XMFLOAT3(-1.0f, 5.0f, 0), CF);

			//WriteToThreadLog("Could Be Emitter Problem");
			GF->LoadEmitter("AnvilSparkles", ObjDataVec[i].pGO, CF);
			GF->LoadEmitter("AnvilSparklesRuby", ObjDataVec[i].pGO, CF)->SetEmitterSetting(2);
			GF->LoadEmitter("AnvilSparklesSapp", ObjDataVec[i].pGO, CF)->SetEmitterSetting(2);
			GF->LoadEmitter("AnvilSparklesDiam", ObjDataVec[i].pGO, CF)->SetEmitterSetting(2);

			break;
		}
#pragma endregion
#pragma region LevelObject
		case ObjectType::eLEVEL:
		{
			//Level is static and should not need extras
			break;
		}
#pragma endregion
#pragma region DiamondNode
		case ObjectType::eDIAMONDNODE:
		{
			GameObject*& pDiamondNode = ObjDataVec[i].pGO;
			//Set up the node data
			ObjDataVec[i].pGO->CreateAIData();
			ObjDataVec[i].pGO->GetAIData()->health = 3;
			//ObjDataVec[i].pGO->GetAIData()->ObjTarget = DiamondeGem.pGO;
			ObjDataVec[i].pGO->GetAIData()->fTargetPos = ObjDataVec[i].pGO->GetObjectTranslation();

			PhysicsComponent* physicsNode = GF->MakePhysicsCompoment(ObjDataVec[i].pGO);
			physicsNode->SetVelocity({ 0, 0.0f });
			physicsNode->SetMass(INFINITE_MASS);
			ObjDataVec[i].pGO->SetPhysicsComponent(physicsNode);

			Circle* circleNodeBound = GF->MakeCircleShape(RT_FIXED);
			circleNodeBound->SetRadius(1.5f);
			physicsNode->SetCollisionShape(circleNodeBound, SU_BOUNDING_SHAPE);


			XMFLOAT3 effectOffset(0.0f, 0.0f, 0.0f);
			XMFLOAT2 effectSize(4.5f, 4.5f);

			LoadEffect(pDiamondNode, "DiamondNodeOptions", "2D_Diamond_Mine.dds", effectSize, effectOffset, CF);

			AddPointLight(pDiamondNode, 15.0f, 1.5f, XMFLOAT3(0.6f, 0.6f, 0.9f), XMFLOAT3(0.4f, 0.4f, 0.4f), XMFLOAT3(1.0f, 1.0f, 1.0f), XMFLOAT3(0.505f, 0.415f, 0.405f), "Diamond Gem Light", false, CF, true);

			//LoadGem(ObjDataVec[i].pGO, eDIAMONDGEM, CF, GF);

			GF->LoadEmitter("Diamond_Node_Mined1", ObjDataVec[i].pGO, CF)->SetSpawning(false);
			GF->LoadEmitter("Diamond_Node_Mined2", ObjDataVec[i].pGO, CF)->SetSpawning(false);
			GF->LoadEmitter("Diamond_Node_Mined3", ObjDataVec[i].pGO, CF)->SetSpawning(false);
			GF->LoadEmitter("Diamond_Node_Mined4", ObjDataVec[i].pGO, CF)->SetSpawning(false);
			GF->LoadEmitter("Diamond_Node_Sparks", ObjDataVec[i].pGO, CF)->SetSpawning(true);
			GF->LoadEmitter("NodeDustCloud", ObjDataVec[i].pGO, CF)->SetSpawning(false);



			break;
		}
#pragma endregion
#pragma region RubyNode
		case ObjectType::eRUBYNODE:
		{
			GameObject*& pRubyNode = ObjDataVec[i].pGO;

			//Set up the node data
			ObjDataVec[i].pGO->CreateAIData();
			ObjDataVec[i].pGO->GetAIData()->health = 3;
			//ObjDataVec[i].pGO->GetAIData()->ObjTarget = RubyGem.pGO;
			ObjDataVec[i].pGO->GetAIData()->fTargetPos = ObjDataVec[i].pGO->GetObjectTranslation();

			PhysicsComponent* physicsNode = GF->MakePhysicsCompoment(ObjDataVec[i].pGO);
			physicsNode->SetVelocity({ 0, 0.0f });
			physicsNode->SetMass(INFINITE_MASS);
			ObjDataVec[i].pGO->SetPhysicsComponent(physicsNode);

			Circle* circleNodeBound = GF->MakeCircleShape(RT_FIXED);
			circleNodeBound->SetRadius(1.5f);
			physicsNode->SetCollisionShape(circleNodeBound, SU_BOUNDING_SHAPE);


			XMFLOAT3 effectOffset(0.0f, 0.0f, 0.0f);
			XMFLOAT2 effectSize(4.5f, 4.5f);

			LoadEffect(pRubyNode, "RubyNodeOptions", "2D_Ruby_Mine.dds", effectSize, effectOffset, CF);

			//LoadGem(ObjDataVec[i].pGO, eRUBYGEM, CF, GF);

			GF->LoadEmitter("Ruby_Node_Mined1", ObjDataVec[i].pGO, CF)->SetSpawning(false);
			GF->LoadEmitter("Ruby_Node_Mined2", ObjDataVec[i].pGO, CF)->SetSpawning(false);
			GF->LoadEmitter("Ruby_Node_Mined3", ObjDataVec[i].pGO, CF)->SetSpawning(false);
			GF->LoadEmitter("Ruby_Node_Mined4", ObjDataVec[i].pGO, CF)->SetSpawning(false);
			GF->LoadEmitter("Ruby_Node_Sparks", ObjDataVec[i].pGO, CF)->SetSpawning(true);
			GF->LoadEmitter("NodeDustCloud", ObjDataVec[i].pGO, CF)->SetSpawning(false);


			AddPointLight(pRubyNode, 15.0f, 1.5f, XMFLOAT3(0.8f, 0.1f, 0.1f), XMFLOAT3(0.8f, 0.1f, 0.1f), XMFLOAT3(1.0f, 0.0f, 0.0f), XMFLOAT3(0.505f, 0.415f, 0.405f), "Ruby Node Light", false, CF, true);

			break;
		}
#pragma endregion
#pragma region SapphireNode
		case ObjectType::eSAPPHIRENODE:
		{
			GameObject*& pSapphireNode = ObjDataVec[i].pGO;


			//Set up the node data
			ObjDataVec[i].pGO->CreateAIData();
			ObjDataVec[i].pGO->GetAIData()->health = 3;
			//ObjDataVec[i].pGO->GetAIData()->ObjTarget = SapphireGem.pGO;
			ObjDataVec[i].pGO->GetAIData()->fTargetPos = ObjDataVec[i].pGO->GetObjectTranslation();


			PhysicsComponent* physicsNode = GF->MakePhysicsCompoment(ObjDataVec[i].pGO);
			physicsNode->SetVelocity({ 0, 0.0f });
			physicsNode->SetMass(INFINITE_MASS);
			ObjDataVec[i].pGO->SetPhysicsComponent(physicsNode);

			Circle* circleNodeBound = GF->MakeCircleShape(RT_FIXED);
			circleNodeBound->SetRadius(1.5f);
			physicsNode->SetCollisionShape(circleNodeBound, SU_BOUNDING_SHAPE);

			XMFLOAT3 effectOffset(0.0f, 0.0f, 0.0f);
			XMFLOAT2 effectSize(4.5f, 4.5f);

			//Point Light
			XMFLOAT4 TPos = XMCStoreFloat4(ObjDataVec[i].pGO->GetObjectTranslationVec());
			float Range = 10.0f;
			Paragon_Renderer::cbPOINT_LIGHT LightData;
			GameObject * PointLightGO = new GameObject;
			LightData.ambientColor = XMFLOAT3(0.55f, 0.7f, 0.9f);
			LightData.diffuseColor = XMFLOAT3(0.0f, 0.55f, 1.0f);
			LightData.specularColor = XMFLOAT3(0.7f, 0.7f, 0.7f);
			LightData.attenuation = XMFLOAT3(0.505f, 0.415f, 0.405f);
			LightData.position = XMFLOAT4(TPos.x, 2.5f, TPos.z, 1.0f);
			LightData.range = Range;
			LightData.specularPower = 0.5f;
			LightData.specularIntensity = 0.5f;

			PointLightComponent * PL = new PointLightComponent(LightData);
			PointLightGO->SetTypeID(ePOINTLIGHT);
			PointLightGO->SetActive(true);
			PointLightGO->SetPointLightComponent(PL);
			PointLightGO->SetTag("SappNodeLight");

			//Create a sphere to render for the point light
			ObjectToLoad PointLightSphere;
			PointLightSphere.pGO = PointLightGO;
			PointLightSphere.FBX_filename = "../Assets/Mesh/PointLightSphere.fbx";
			PointLightSphere.Texture_filename = "None";

			//Set up matrix
			XMMATRIX PointLightTransform = XMMatrixIdentity();

			//Apply Scale
			PointLightTransform = XMMatrixMultiply(PointLightTransform, XMMatrixScaling(Range, Range, Range));

			//Apply Translation
			PointLightTransform = XMMatrixMultiply(PointLightTransform, XMMatrixTranslation(TPos.x, 1.5f, TPos.z));

			PointLightSphere.pGO->SetObjectTransform(PointLightTransform);

			CF->m_AssetManager->LoadModel(&PointLightSphere);
			CF->m_ObjectManager->AddGameObject(PointLightGO);
			ObjDataVec[i].pGO->AddPointLightChild(PointLightGO);

			LoadEffect(pSapphireNode, "SapphireNodeOptions", "2D_Sapphire_Mine.dds", effectSize, effectOffset, CF);

			//LoadGem(ObjDataVec[i].pGO, eSAPPHIREGEM, CF, GF);

			GF->LoadEmitter("Sapp_Node_Mined1", ObjDataVec[i].pGO, CF)->SetSpawning(false);
			GF->LoadEmitter("Sapp_Node_Mined2", ObjDataVec[i].pGO, CF)->SetSpawning(false);
			GF->LoadEmitter("Sapp_Node_Mined3", ObjDataVec[i].pGO, CF)->SetSpawning(false);
			GF->LoadEmitter("Sapp_Node_Mined4", ObjDataVec[i].pGO, CF)->SetSpawning(false);
			GF->LoadEmitter("Sapp_Node_Sparks", ObjDataVec[i].pGO, CF)->SetSpawning(true);
			GF->LoadEmitter("NodeDustCloud", ObjDataVec[i].pGO, CF)->SetSpawning(false);

			pSapphireNode->GetChildEmitterComponent(5)->SetSpawnOnPlane(true);
			//pSapphireNode->GetChildEmitterComponent(5)->SetEmitterSetting(1);

			break;
		}
#pragma endregion
#pragma region PressurePlate
		case ObjectType::ePRESSUREPLATE:
		{
			ObjDataVec[i].pGO->SetPhysicsComponent(GF->MakePhysicsCompoment(ObjDataVec[i].pGO));

			Circle* circleGoal = GF->MakeCircleShape(RT_NONE);
			circleGoal->SetRadius(12.0f);
			circleGoal->SetOffset(XMLoadFloat2(&XMFLOAT2(0.150f, 0.0f))); // <- TODO Freeze transformation for TestCylinder.fbx object correctly
			ObjDataVec[i].pGO->GetPhysicsComponent()->SetCollisionShape(circleGoal, SU_SCANNER);
			ObjDataVec[i].pGO->SetTypeID(eGOAL);
			break;
		}
#pragma endregion
#pragma region Elevator
		case ObjectType::eELEVATOR:
		{
			GameObject * Player = CF->m_ObjectManager->GetPlayer();
			if (Player != nullptr)
			{
				//Player->SetObjectTranslation(ObjDataVec[i].pGO->GetObjectTranslation());
			}
			else
				PrintConsole("Tried to move a player to the elevator but the player was NULL");

			break;
		}
#pragma endregion
#pragma region Wall
		case ObjectType::eWALL:
		{
			ObjectToLoad& wallToLoad = ObjDataVec[i];
			GameObject*& pWall = wallToLoad.pGO;

			wallToLoad.pGO->SetActive(false);

			PhysicsComponent* wallPhysics = GF->MakePhysicsCompoment(pWall);
			pWall->SetPhysicsComponent(wallPhysics);

			pWall->SetActive(false); // To disable rendering			

			OrientedBox* wallOBB = GF->MakeOBBShape(RT_FIXED);

			XMMATRIX wallTransform = XMLoadFloat4x4(&pWall->GetWorldTransform());
			XMVECTOR xAxis = wallTransform.r[0];
			XMVECTOR zAxis = wallTransform.r[2];

			XMFLOAT2 halfSize;
			halfSize.x = XMCVector3Length(xAxis)*0.5f;
			halfSize.y = XMCVector3Length(zAxis)*0.5f;
			wallOBB->SetHalfSize(XMLoadFloat2(&halfSize));
			XMVECTOR direction = XMCVector3SwizzleXZ(xAxis);
			wallOBB->SetDirection(direction);

			wallPhysics->SetCollisionShape(wallOBB, SU_BOUNDING_SHAPE);

			break;
		}
#pragma endregion
#pragma region Torch
		case ObjectType::eTORCH:
		{
			XMFLOAT4 TPos = XMCStoreFloat4(ObjDataVec[i].pGO->GetObjectTranslationVec());

			//Add a point light for each game object
			float Range = 30.0f;
			//LoadingScreenState::LoadLock.lock();
			Paragon_Renderer::cbPOINT_LIGHT LightData;
			GameObject * PointLightGO = new GameObject;
			LightData.ambientColor = XMFLOAT3(0.4f, 0.2f, 0.1f);
			LightData.diffuseColor = XMFLOAT3(1.0f, 0.6f, 0.01f);
			LightData.specularColor = XMFLOAT3(0.4f, 0.2f, 0.1f);
			LightData.attenuation = XMFLOAT3(0.505f, 0.015f, 0.005f);
			LightData.position = XMFLOAT4(TPos.x, TPos.y, TPos.z, 1.0f);
			LightData.range = Range;
			LightData.specularPower = 1.0f;
			LightData.specularIntensity = 1.0f;


			PointLightComponent * PL = new PointLightComponent(LightData);
			//LoadingScreenState::LoadLock.unlock();
			PL->AddFlicker = true;
			PL->Parent = PointLightGO;
			PL->FollowObject = ObjDataVec[i].pGO;
			PL->FollowParentY = true;

			ObjDataVec[i].pGO->CreateAudioComponent(CF->GetSoundManager());

			if (ObjDataVec[i].pGO->GetTag() == "DoorTorch")
			{
				PL->PointLightData.attenuation = XMFLOAT3(0.01f, 0.01f, 0.01f);
				PointLightGO->SetTag("DoorTorch");
				LightData.range = 15.0f;
				LightData.position.y = ObjDataVec[i].pGO->GetObjectTranslation().y;
				PL->FollowObject = ObjDataVec[i].pGO;
			}
			else
			{
				PointLightGO->SetTag("Wall Torch");
				PL->OffsetFromForward = XMFLOAT3(0.0f, 0.0f, 2.0f);
			}
			PointLightGO->SetTypeID(ePOINTLIGHT);
			PointLightGO->SetActive(true);
			PointLightGO->SetPointLightComponent(PL);

			ObjDataVec[i].pGO->AddPointLightChild(PointLightGO);


			//Create a sphere to render for the point light
			ObjectToLoad PointLightSphere;
			PointLightSphere.pGO = PointLightGO;
			PointLightSphere.FBX_filename = "../Assets/Mesh/PointLightSphere.fbx";
			PointLightSphere.Texture_filename = "";
			if (PointLightGO->GetTag() == "Wall Torch")
				PointLightSphere.Texture_filename = "../Assets/Textures/Torch_Noise.dds";


			//Set up matrix
			XMMATRIX PointLightTransform = XMMatrixIdentity();

			//Apply Scale
			PointLightTransform = XMMatrixMultiply(PointLightTransform, XMMatrixScaling(Range, Range, Range));

			//Apply Translation
			PointLightTransform = XMMatrixMultiply(PointLightTransform, XMMatrixTranslation(TPos.x, TPos.y, TPos.z));

			PointLightSphere.pGO->SetObjectTransform(PointLightTransform);

			CF->m_AssetManager->LoadModel(&PointLightSphere);
			CF->m_ObjectManager->AddGameObject(PointLightGO);

			Emitter * SmokeE = GF->LoadEmitter("TorchSmoke", ObjDataVec[i].pGO, CF);
			//Emitter * FireE = GF->LoadEmitter("TorchFire", ObjDataVec[i].pGO, CF);
			//SmokeE->SetEmitterSetting(1);
			//FireE->SetEmitterSetting(1);
			break;
		}
#pragma endregion
#pragma region Door
		case ObjectType::eDOOR:
		{
			ObjectToLoad& doorToLoad = ObjDataVec[i];
			GameObject*& pdoor = doorToLoad.pGO;

			pdoor->SetObjectColor(XMFLOAT4(1.0f, 0.75f, 0.2f, 1.0f));

			PhysicsComponent* doorPhysics = GF->MakePhysicsCompoment(pdoor);
			pdoor->SetPhysicsComponent(doorPhysics);

			OrientedBox* doorOBB = GF->MakeOBBShape(RT_FIXED);

			XMMATRIX doorTransform = XMLoadFloat4x4(&pdoor->GetWorldTransform());
			XMVECTOR xAxis = doorTransform.r[0];
			XMVECTOR zAxis = doorTransform.r[2];

			ObjDataVec[i].pGO->CreateAudioComponent(CF->GetSoundManager());


			XMFLOAT2 halfSize = XMFLOAT2(30 * 0.5f, 10 * 0.5f);
			doorOBB->SetHalfSize(XMLoadFloat2(&halfSize));

			/*XMVECTOR offset = zAxis*halfSize.y + xAxis*halfSize.x;
			offset = XMCVector3SwizzleXZ(offset);
			doorOBB->SetOffset(offset);*/

			XMVECTOR direction = XMCVector3SwizzleXZ(xAxis);
			doorOBB->SetDirection(direction);

			doorPhysics->SetCollisionShape(doorOBB, SU_BOUNDING_SHAPE);

			//GF->LoadEmitter("TorchFire", pdoor, CF);

			break;
		}
#pragma endregion
#pragma region SpiderWeb
		case eSPIDER_WEB:
		{


			break;
		}
#pragma endregion
#pragma region Decoration
		case eDECORATION:
		{
			break;
		}
#pragma endregion
#pragma region HitMark
		case eHITMARK:
		{
			break;
		}
#pragma endregion
#pragma region Paragon
		case ePARAGON:
		{
			GameObject*& pParagon = ObjDataVec[i].pGO;
			PhysicsComponent* paragonPhys = GF->MakePhysicsCompoment(pParagon);

			Circle* paragonCircle = GF->MakeCircleShape(RT_DYNAMIC);
			paragonCircle->SetRadius(6.0f);
			paragonPhys->SetMass(INFINITE_MASS);
			paragonPhys->SetCollisionShape(paragonCircle, SU_BOUNDING_SHAPE);
			pParagon->SetPhysicsComponent(paragonPhys);
			//paragonCircle

			pParagon->CreateAIData();
			pParagon->GetAIData()->bActionDone = true;
			pParagon->GetAIData()->fActionCooldownB = 1.0f;
			pParagon->GetAIData()->fTargetPos = pParagon->GetObjectTranslation();

			ObjDataVec[i].pGO->CreateAudioComponent(CF->GetSoundManager());

			XMFLOAT3 effectOffset(0.0f, 0.0f, 0.0f);
			XMFLOAT2 effectSize(4.5f, 4.5f);

			LoadEffect(pParagon, "SpiderHealthBar", "SpiderHealth.dds", effectSize, effectOffset, CF);

			//Storm Emitter
			Emitter * StormEmitter = GF->LoadEmitter("Lightning", ObjDataVec[i].pGO, CF);
			StormEmitter->SetEmitterSetting(1);
			StormEmitter->SetSpawning(true);
			StormEmitter->SetSpawnOnPlane(true);
			StormEmitter->SetPositionVariance(1.0f);
			StormEmitter->SetSpawnRate(10.0f);
			StormEmitter = GF->LoadEmitter("Lightning2", ObjDataVec[i].pGO, CF);
			StormEmitter->SetEmitterSetting(1);
			StormEmitter->SetSpawning(true);
			StormEmitter->SetSpawnRate(10.0f);
			StormEmitter->SetPositionVariance(1.0f);
			StormEmitter->SetSpawnOnPlane(true);

			//Spark Emitter
			Emitter * StormSparkEmitter = GF->LoadEmitter("Lightning_Sparks", ObjDataVec[i].pGO, CF);
			//StormSparkEmitter->SetEmitterSetting(1);
			StormSparkEmitter->SetSpawnRate(50.0f);
			StormSparkEmitter->SetSpawning(true);

			break;
		}
#pragma endregion
#pragma region Paragon Holders
		case eSAPPHIREHOLDER:
		case eRUBYHOLDER:
		case eDIAMONDHOLDER:
		{
			GameObject*& pHolder = ObjDataVec[i].pGO;
			PhysicsComponent* holderPhys = GF->MakePhysicsCompoment(pHolder);

			Circle* holderShape = GF->MakeCircleShape(RT_DYNAMIC);
			holderShape->SetRadius(3.0f);
			holderPhys->SetMass(INFINITE_MASS);
			holderPhys->SetCollisionShape(holderShape, SU_BOUNDING_SHAPE);
			pHolder->SetPhysicsComponent(holderPhys);
			//paragonCircle

			ObjDataVec[i].pGO->CreateAudioComponent(CF->GetSoundManager());

			pHolder->CreateAIData();
			pHolder->GetAIData()->health = 200;

			break;
		}
#pragma endregion
		}

		//Load in the objects assets 
		CF->m_AssetManager->LoadModel(&ObjDataVec[i]);


		//Add the object to the object manager
		CF->m_ObjectManager->AddGameObject(ObjDataVec[i].pGO);
	}

	//WriteToThreadLog("Should be finished with loading here");

	//CF->SetDoneLoading(true);

	return;
}

void LevelManager::LoadGem(GameObject* Parent, ObjectType gemType, CoreFacade * CF, GameFacade * GF)
{
	switch (gemType)
	{
	case eRUBYGEM:
	{
		//Creating Gem that will spawn once the gem node has been mined
		ObjectToLoad RubyGem;
		RubyGem.FBX_filename = "../Assets/Mesh/ENV_3D_Ruby_Gem.fbx";
		RubyGem.Texture_filename = "../Assets/Textures/T_Gems_D.dds";
		RubyGem.pGO = new GameObject();
		RubyGem.pGO->SetTransformToIdentiy();
		RubyGem.pGO->SetActive(false);
		RubyGem.pGO->SetTypeID(ObjectType::eRUBYGEM);
		RubyGem.pGO->SetTag("RubyGem");

		if (Parent)
			RubyGem.pGO->SetObjectTranslation(Parent->GetObjectTranslation());
		else
			RubyGem.pGO->SetTransformToIdentiy();

		//Effect when gems are dropped
		GF->LoadEmitter("GemRubyEmission", RubyGem.pGO, CF)->SetSpawning(false);
		GF->LoadEmitter("GemRubySpawn", RubyGem.pGO, CF)->SetSpawning(false);

		//Set up Gem Data
		RubyGem.pGO->SetAIData(NULL);

		PhysicsComponent* physicsGem = GF->MakePhysicsCompoment(RubyGem.pGO);
		physicsGem->SetVelocity({ 0, 0.0f });
		physicsGem->SetMass(INFINITE_MASS);
		RubyGem.pGO->SetPhysicsComponent(physicsGem);

		Circle* circleGem = GF->MakeCircleShape(RT_NONE);
		circleGem->SetRadius(2.0f);
		physicsGem->SetCollisionShape(circleGem, SU_BOUNDING_SHAPE);

		physicsGem->DeactivateCollision();

		RubyGem.pGO->CreateAIData();
		CF->m_AssetManager->LoadModel(&RubyGem);
		CF->m_ObjectManager->AddGameObject(RubyGem.pGO);

		if (Parent)
			Parent->AddGemChildObject(RubyGem.pGO);

		AddPointLight(RubyGem.pGO, 5.0f, 2.0f, XMFLOAT3(1.0f, 0.6f, 0.01f), XMFLOAT3(0.4f, 0.2f, 0.1f), XMFLOAT3(1.0f, 1.0f, 1.0f), XMFLOAT3(0.505f, 0.415f, 0.405f), "Sapp Gem Light", true, CF, false);

		break;
	}
	case eSAPPHIREGEM:
	{
		//Creating Gem that will spawn once the gem node has been mined
		ObjectToLoad SapphireGem;
		SapphireGem.FBX_filename = "../Assets/Mesh/ENV_3D_Sapphire_Gem.fbx";
		SapphireGem.Texture_filename = "../Assets/Textures/T_Gems_D.dds";
		SapphireGem.pGO = new GameObject();
		SapphireGem.pGO->SetTransformToIdentiy();
		SapphireGem.pGO->SetActive(false);
		SapphireGem.pGO->SetTypeID(ObjectType::eSAPPHIREGEM);
		SapphireGem.pGO->SetTag("SapphireGem");

		if (Parent)
			SapphireGem.pGO->SetObjectTranslation(Parent->GetObjectTranslation());
		else
			SapphireGem.pGO->SetTransformToIdentiy();

		//Gem drop particles
		GF->LoadEmitter("GemSapphireEmission", SapphireGem.pGO, CF)->SetSpawning(false);
		GF->LoadEmitter("GemSapphireSpawn", SapphireGem.pGO, CF)->SetSpawning(false);

		//Set up Gem Data
		SapphireGem.pGO->SetAIData(NULL);
		SapphireGem.pGO->CreateAIData();
		CF->m_AssetManager->LoadModel(&SapphireGem);
		CF->m_ObjectManager->AddGameObject(SapphireGem.pGO);



		PhysicsComponent* physicsGem = GF->MakePhysicsCompoment(SapphireGem.pGO);
		physicsGem->SetVelocity({ 0, 0.0f });
		physicsGem->SetMass(INFINITE_MASS);
		SapphireGem.pGO->SetPhysicsComponent(physicsGem);

		Circle* circleGem = GF->MakeCircleShape(RT_NONE);
		circleGem->SetRadius(2.0f);
		physicsGem->SetCollisionShape(circleGem, SU_BOUNDING_SHAPE);

		physicsGem->DeactivateCollision();
		if (Parent)
			Parent->AddGemChildObject(SapphireGem.pGO);

		AddPointLight(SapphireGem.pGO, 5.0f, 0.0f, XMFLOAT3(0.0f, 0.55f, 1.0f), XMFLOAT3(0.4f, 0.2f, 0.1f), XMFLOAT3(1.0f, 1.0f, 1.0f), XMFLOAT3(0.405f, 0.215f, 0.105f), "Sapp Gem Light", true, CF, false);

		break;
	}
	case eDIAMONDGEM:
	{
		//Creating Gem that will spawn once the gem node has been mined
		ObjectToLoad DiamondGem;
		DiamondGem.FBX_filename = "../Assets/Mesh/ENV_3D_Diamond_Gem.fbx";
		DiamondGem.Texture_filename = "../Assets/Textures/T_Gems_D.dds";
		DiamondGem.pGO = new GameObject();
		DiamondGem.pGO->SetTransformToIdentiy();
		DiamondGem.pGO->SetActive(false);
		DiamondGem.pGO->SetTypeID(ObjectType::eDIAMONDGEM);
		DiamondGem.pGO->SetTag("DiamondGem");

		if (Parent)
			DiamondGem.pGO->SetObjectTranslation(Parent->GetObjectTranslation());
		else
			DiamondGem.pGO->SetTransformToIdentiy();

		//Effect when gems are dropped
		GF->LoadEmitter("GemDiamondEmission", DiamondGem.pGO, CF)->SetSpawning(false);
		GF->LoadEmitter("GemDiamondSpawn", DiamondGem.pGO, CF)->SetSpawning(false);

		//Set up Gem Data
		DiamondGem.pGO->SetAIData(NULL);
		DiamondGem.pGO->CreateAIData();

		PhysicsComponent* physicsGem = GF->MakePhysicsCompoment(DiamondGem.pGO);
		physicsGem->SetVelocity({ 0, 0.0f });
		DiamondGem.pGO->SetPhysicsComponent(physicsGem);

		Circle* circleGem = GF->MakeCircleShape(RT_NONE);
		circleGem->SetRadius(2.0f);
		physicsGem->SetCollisionShape(circleGem, SU_BOUNDING_SHAPE);

		physicsGem->DeactivateCollision();

		CF->m_AssetManager->LoadModel(&DiamondGem);
		CF->m_ObjectManager->AddGameObject(DiamondGem.pGO);

		if (Parent)
			Parent->AddGemChildObject(DiamondGem.pGO);

		AddPointLight(DiamondGem.pGO, 5.0f, 2.0f, XMFLOAT3(1.0f, 0.6f, 0.01f), XMFLOAT3(0.4f, 0.2f, 0.1f), XMFLOAT3(1.0f, 1.0f, 1.0f), XMFLOAT3(0.505f, 0.415f, 0.405f), "Sapp Gem Light", true, CF, false);

		break;
	}
	default:
	{
		return;
	}
	}
}

void LevelManager::LoadStandardGameObjects(CoreFacade * CF, GameFacade * GF)
{
	// --- Reticle ---
#pragma region Reticle

	ObjectToLoad Reticle;
	Reticle.FBX_filename = "../Assets/Mesh/TestCylinder.fbx";
	Reticle.Texture_filename = "../Assets/Textures/Reference Placeholder Character Texture.dds";
	Reticle.pGO = new GameObject();
	Reticle.pGO->SetTag("Reticle");
	Reticle.pGO->SetTypeID(eRETICLE);

	ReticleComponent* reticleComp = new ReticleComponent(*Reticle.pGO);
	Reticle.pGO->SetReticleComponent(reticleComp);

	PhysicsComponent* physicsReticle = GF->MakePhysicsCompoment(Reticle.pGO);
	Reticle.pGO->SetPhysicsComponent(physicsReticle);

	Circle* circleReticle = GF->MakeCircleShape(RT_NONE);
	circleReticle->SetRadius(6.0f);
	physicsReticle->SetCollisionShape(circleReticle, SU_SCANNER);

	Circle* circleBoundingReticle = GF->MakeCircleShape(RT_NONE);
	circleBoundingReticle->SetRadius(2.0f);
	physicsReticle->SetCollisionShape(circleBoundingReticle, SU_BOUNDING_SHAPE);

	GF->LoadEmitter("GemRubyEmission", Reticle.pGO, CF)->SetSpawning(false);
	GF->LoadEmitter("GemSapphireEmission", Reticle.pGO, CF)->SetSpawning(false);
	GF->LoadEmitter("GemSapphireEmission", Reticle.pGO, CF)->SetSpawning(false);
	GF->LoadEmitter("GemSapphireEmission", Reticle.pGO, CF)->SetSpawning(false);
	GF->LoadEmitter("GemSapphireEmission", Reticle.pGO, CF)->SetSpawning(false);
	GF->LoadEmitter("GemSapphireEmission", Reticle.pGO, CF)->SetSpawning(false);
	GF->LoadEmitter("GemSapphireEmission", Reticle.pGO, CF)->SetSpawning(false);
	GF->LoadEmitter("GemSapphireEmission", Reticle.pGO, CF)->SetSpawning(false);

	AddPointLight(Reticle.pGO, 10.0f, 3.0f, XMFLOAT3(0.7f, 0.3f, 0.1f), XMFLOAT3(0.7f, 0.3f, 0.1f), XMFLOAT3(0.0f, 0.0f, 0.0f), XMFLOAT3(0.705f, 0.215f, 0.015f), "Reticle Light", true, CF, true, true);

	CF->m_AssetManager->LoadModel(&Reticle);
	CF->m_ObjectManager->AddGameObject(Reticle.pGO);
#pragma endregion

	// --- Hit Mark ---
#pragma region HitMark

	ObjectToLoad HitMark;
	HitMark.FBX_filename = "../Assets/Mesh/TestCylinder.fbx";
	HitMark.Texture_filename = "../Assets/Textures/Reference Placeholder Character Texture.dds";
	HitMark.pGO = new GameObject();
	HitMark.pGO->SetTag("HitMark");
	HitMark.pGO->SetTypeID(eHITMARK);
	AddPointLight(HitMark.pGO, 0.0f, 3.0f, XMCStoreFloat3(Colors::Honeydew), XMCStoreFloat3(Colors::Honeydew), XMCStoreFloat3(Colors::Black), XMFLOAT3(0.8f, 0.5f, 0.03f), "HitMark Light", true, CF, true, true);
	//Range is set on reticlecomp

	CF->m_AssetManager->LoadModel(&HitMark);
	CF->m_ObjectManager->AddGameObject(HitMark.pGO);
#pragma endregion

	//Loading Arrow waypoint
#pragma region Arrow Waypoint

	ObjectToLoad Arrow;
	Arrow.FBX_filename = "../Assets/Mesh/2D_Arrow_Marker.fbx";
	Arrow.Texture_filename = "../Assets/Textures/2D_Arrow.dds";
	Arrow.pGO = new GameObject();
	Arrow.pGO->SetTag("Arrow");
	Arrow.pGO->SetTypeID(eARROWMARKER);
	Arrow.pGO->CreateAIData();

	CF->m_AssetManager->LoadModel(&Arrow);
	CF->m_ObjectManager->AddGameObject(Arrow.pGO);

	//Loading in a Light For Testing! =D
	XMFLOAT3 TPos = CF->m_ObjectManager->GetPlayer()->GetObjectTranslation();
	float Range = 10.0f;
	//LoadingScreenState::LoadLock.lock();
	Paragon_Renderer::cbPOINT_LIGHT LightData;
	GameObject * TestPointLightGO = new GameObject;
	LightData.ambientColor = XMFLOAT3(1.0f, 0.65f, 0.0f);
	LightData.diffuseColor = XMFLOAT3(1.0f, 0.65f, 0.0f);
	LightData.specularColor = XMFLOAT3(0.2f, 0.2f, 0.2f);
	LightData.attenuation = XMFLOAT3(0.705f, 0.315f, 0.115f);
	LightData.position = XMFLOAT4(0.0f, 5.0f, 0.0f, 1.0f);
	LightData.range = Range;
	LightData.specularPower = 0.75f;
	LightData.specularIntensity = 0.75f;

	PointLightComponent * PL = new PointLightComponent(LightData);
	//LoadingScreenState::LoadLock.unlock();
	PL->FollowObject = CF->m_ObjectManager->GetPlayer();
	PL->Parent = TestPointLightGO;
	PL->OffsetFromForward = XMFLOAT3(0.5f, 0.0f, 5.0f);

	TestPointLightGO->SetTag("First Point Light");
	TestPointLightGO->SetTypeID(ePOINTLIGHT);
	TestPointLightGO->SetActive(true);
	TestPointLightGO->SetPointLightComponent(PL);



	//Create a sphere to render for the point light
	ObjectToLoad PointLightSphere;
	PointLightSphere.pGO = TestPointLightGO;
	PointLightSphere.FBX_filename = "../Assets/Mesh/PointLightSphere.fbx";
	PointLightSphere.Texture_filename = "None";
	PointLightSphere.pGO->GetRendererComponent()->TextureFlags.ApplyNormals = false;

	//Set up matrix
	XMMATRIX PointLightTransform = XMMatrixIdentity();

	//Apply Scale
	PointLightTransform = XMMatrixMultiply(PointLightTransform, XMMatrixScaling(Range, Range, Range));

	//Apply Translation
	PointLightTransform = XMMatrixMultiply(PointLightTransform, XMMatrixTranslation(TPos.x, 5.0f, TPos.z));

	PointLightSphere.pGO->SetObjectTransform(PointLightTransform);

	CF->m_AssetManager->LoadModel(&PointLightSphere);
	CF->m_ObjectManager->AddGameObject(TestPointLightGO);
#pragma endregion

	//Testing objects
#pragma region Testing Objects

	//Test 0
	//ObjectToLoad TestObject;
	//TestObject.FBX_filename = "../Assets/Mesh/Env_3D_StoneRubble.fbx";
	//TestObject.Texture_filename = "../Assets/Textures/Env_StoneRubble_Diffuse.dds";
	//
	//GameObject * Object = new GameObject;
	//Object->SetTransformToIdentiy();
	//Object->SetObjectTranslation(-16.0f, 0, 0.0f);
	//Object->SetTypeID(ObjectType::eDECORATION);
	//Object->SetScale(5);
	//Object->SetActive(true);
	//TestObject.pGO = Object;
	//
	//CF->m_AssetManager->LoadModel(&TestObject);
	//CF->m_ObjectManager->AddGameObject(Object);
	//
	////Test 1
	//TestObject.FBX_filename = "../Assets/Mesh/Env_3D_StoneRubble_v2.fbx";
	//TestObject.Texture_filename = "../Assets/Textures/Env_StoneRubble_Diffuse_v2.dds";
	//
	//Object = new GameObject;
	//Object->SetTransformToIdentiy();
	//Object->SetObjectTranslation(-16.0f, 0, 4.0f);
	//Object->SetTypeID(ObjectType::eDECORATION);
	//Object->SetScale(5);
	//Object->SetActive(true);
	//TestObject.pGO = Object;
	//
	//CF->m_AssetManager->LoadModel(&TestObject);
	//CF->m_ObjectManager->AddGameObject(Object);
	//
	////Test 2
	//TestObject.FBX_filename = "../Assets/Mesh/Env_3D_StoneRubble_v3.fbx";
	//TestObject.Texture_filename = "../Assets/Textures/Env_StoneRubble_Diffuse_v3.dds";
	//
	//Object = new GameObject;
	//Object->SetTransformToIdentiy();
	//Object->SetObjectTranslation(-16.0f, 0, -4.0f);
	//Object->SetTypeID(ObjectType::eDECORATION);
	//Object->SetScale(5.0f);
	//Object->SetActive(true);
	//TestObject.pGO = Object;
	//
	//CF->m_AssetManager->LoadModel(&TestObject);
	//CF->m_ObjectManager->AddGameObject(Object);
#pragma endregion

#pragma region Hammer
	//ObjectToLoad hammer;
	//GameObject * hammerGO = new GameObject;
	//hammer.pGO = hammerGO;
	//hammer.FBX_filename = "../Assets/Mesh/3D_Hammer.fbx";
	//hammer.Texture_filename = "../Assets/Textures/asdfadsfasd.dds";
	//hammer.NormTexture_filename = "../Assets/Textures/";
	//hammer.SpecTexture_filename = "../Assets/Textures/";

	//hammerGO->SetTypeID(eHAMMER);
	//hammerGO->SetActive(true);
	//hammerGO->SetAnimComponent(new CAnimComponent(HAMMER_HIT));

	/////Remove this from code when starting
	//hammerGO->SetObjectTranslation(CF->GetObjectManager()->GetHammer()->GetObjectTranslation());

	//AnimToLoad hammer_hit(HAMMER_HIT, "../Assets/Animations/3D_Hammer_Animation.fbx");

	//CF->GetAssetManager()->LoadAnimation(&hammer_hit);
	//CF->m_AssetManager->LoadModel(&hammer);
	//CF->m_ObjectManager->AddGameObject(hammerGO);


#pragma endregion

	//Load Gems
	for (size_t i = 0; i < 15; i++)
	{
		LoadGem(NULL, eRUBYGEM, CF, GF);
		LoadGem(NULL, eSAPPHIREGEM, CF, GF);
		LoadGem(NULL, eDIAMONDGEM, CF, GF);
	}


	////Worms attack circle.
	//ObjectToLoad AttackCircle;
	//AttackCircle.FBX_filename = "../Assets/Mesh/TestCylinder.fbx";
	//AttackCircle.Texture_filename = "../Assets/Textures/Reference Placeholder Character Texture.dds";
	//AttackCircle.pGO = new GameObject();
	//AttackCircle.pGO->SetTag("WormAttack");
	//AttackCircle.pGO->SetTypeID(eWORMATTACK);
	//AttackCircle.pGO->SetActive(false);
	//AttackCircle.pGO->SetObjectColor(Colors::Red, 1.0f);

	////PhysicsComponent * attackPhysics = GF->MakePhysicsCompoment(AttackCircle.pGO);
	////AttackCircle.pGO->SetPhysicsComponent(attackPhysics);
	//AttackCircle.pGO->SetTransformToIdentiy();

	//XMMATRIX scale = XMMatrixScaling(3.75f, 0.5f, 3.75f);
	//XMMATRIX objmat = AttackCircle.pGO->GetWorldTransformMat();
	//AttackCircle.pGO->SetObjectTransform(scale * objmat);

	//CF->m_AssetManager->LoadModel(&AttackCircle);
	//CF->m_ObjectManager->AddGameObject(AttackCircle.pGO);
}

EffectComponent* LevelManager::LoadEffect(GameObject* pGO, const string& tag, const string& texture, const XMFLOAT2& size, const XMFLOAT3& Offset, CoreFacade * CF)
{

	GameObject * pEffectGO = new GameObject;

	EffectToLoad effectToLoad;
	EffectComponent * pEffect = new EffectComponent(pEffectGO, pGO, size, Offset, XMFLOAT2(0, 0));
	effectToLoad.TextureFilePath = "../Assets/Textures/" + texture;

	pEffectGO->SetTypeID(eEFFECT);
	pEffectGO->SetTag(tag + "Effect");
	pEffectGO->SetActive(true);
	pEffectGO->SetEffectComponent(pEffect);
	effectToLoad.pGO = pEffectGO;

	if (pGO) pGO->AddEffectChildObject(pEffectGO);

	CF->m_AssetManager->LoadEfftectAsset(&effectToLoad);
	CF->m_ObjectManager->AddGameObject(pEffectGO);

	return pEffect;
}

void LevelManager::LoadGeodes(CoreFacade * CF, GameFacade * GF)
{

	//Test Geode
	ObjectToLoad Geodes[MAX_GEODE_COUNT];
	for (unsigned int index = 0; index < MAX_GEODE_COUNT; index++)
	{
		unsigned int OneThird = (MAX_GEODE_COUNT / 3);

		GameObject*& pGeode = Geodes[index].pGO;

		if (index < OneThird) /// Create Ruby Geodes
		{
			//Geodes[index].FBX_filename = "../Assets/Mesh/3D_Ruby_Geode.fbx";
			Geodes[index].FBX_filename = "../Assets/Mesh/3D_Ruby_Geode_Animation_Idle.fbx";
			pGeode = new GameObject();
			Geodes[index].Texture_filename = "../Assets/Textures/Ruby_Geode_D.dds";
			Geodes[index].SpecTexture_filename = "../Assets/Textures/Ruby_Geode_S.dds";
			Geodes[index].NormTexture_filename = "../Assets/Textures/Ruby_Geode_N.dds";
			Geodes[index].GlowTexture_filename = "../Assets/Textures/Ruby_Geode_E.dds";
			pGeode->SetTag("Geode_R");
			pGeode->SetTypeID(ObjectType::eRUBYGEODE);
			pGeode->GhostColor = XMFLOAT4(1.0f, 0.2f, 0.2f, 1.0f);

			pGeode->SetAnimComponent(new CAnimComponent(RUBY_IDLE));
			pGeode->SetIsAnimated(true);
		}
		else if (index < (OneThird * 2)) /// Create Sapphire Geodes*/
		{
			Geodes[index].FBX_filename = "../Assets/Mesh/3D_Sapphire_Geode_Animation_Idle.fbx";
			pGeode = new GameObject();
			Geodes[index].Texture_filename = "../Assets/Textures/Sapphire_Geode_D.dds";
			Geodes[index].SpecTexture_filename = "../Assets/Textures/Sapphire_Geode_S.dds";
			Geodes[index].NormTexture_filename = "../Assets/Textures/Sapphire_Geode_N.dds";
			Geodes[index].GlowTexture_filename = "../Assets/Textures/Sapphire_Geode_E.dds";
			pGeode->SetTag("Geode_S");
			pGeode->SetTypeID(ObjectType::eSAPPHIREGEODE);
			pGeode->GhostColor = XMFLOAT4(0.2f, 0.6f, 1.0f, 1.0f);

			pGeode->SetAnimComponent(new CAnimComponent(SAPPHIRE_IDLE));
			pGeode->SetIsAnimated(true);
		}
		else
		{
			Geodes[index].FBX_filename = "../Assets/Mesh/3D_Diamond_Geode_Animation_Idle.fbx";
			pGeode = new GameObject();
			Geodes[index].Texture_filename = "../Assets/Textures/Diamond_Geode_Diffuse.dds";
			Geodes[index].SpecTexture_filename = "../Assets/Textures/Diamond_Geode_Specular.dds";
			Geodes[index].NormTexture_filename = "../Assets/Textures/Diamond_Geode_Normal.dds";
			Geodes[index].GlowTexture_filename = "../Assets/Textures/Diamond_Geode_Emmisive.dds";
			pGeode->SetTag("Geode_D");
			pGeode->SetTypeID(ObjectType::eDIAMONDGEODE);
			pGeode->GhostColor = XMFLOAT4(0.7f, 0.7f, 0.9f, 1.0f);

			pGeode->SetAnimComponent(new CAnimComponent(DIAMOND_IDLE));
			pGeode->SetIsAnimated(true);
		}


		pGeode->SetTransformToIdentiy();
		XMFLOAT3 PositionG((rand() % 5 - 2) * 3.0f, 2.0f, (rand() % 5 - 2) * 3.0f); // Replace once flocking behind player is done
		pGeode->SetObjectTranslation(PositionG);

		pGeode->CreateAIData();
		AIData * data = pGeode->GetAIData();
		data->geodeState = AIData::GeFollowing;
		data->health = 1;
		data->fActionCooldownB = 0.0f;
		data->ObjTarget = nullptr;
		pGeode->SetAIData(data);

		//Geode Physics
		PhysicsComponent* physicsGeode = GF->MakePhysicsCompoment(pGeode);
		physicsGeode->SetVelocity({ 0, 0.0f });
		pGeode->SetPhysicsComponent(physicsGeode);

		Circle* circleGeode = GF->MakeCircleShape(RT_DYNAMIC);
		circleGeode->SetRadius(1.90f);
		physicsGeode->SetCollisionShape(circleGeode, SU_BOUNDING_SHAPE);

		Circle* circleGScan = GF->MakeCircleShape(RT_NONE);
		circleGScan->SetRadius(15.0f);
		physicsGeode->SetCollisionShape(circleGScan, SU_SCANNER);

		/*Segment * forwardVel = m_GameFacade->MakeSegmentShape(RT_NONE);
		forwardVel->SetExtent(XMFLOAT2(0.0f, 7.0f));
		physicsGeode->SetCollisionShape(forwardVel, SU_SLOWSEG);*/

		NavAgent* pGeodeNavAgent = new NavAgent(pGeode);
		pGeodeNavAgent->Initialize(CF);
		pGeode->SetNavAgent(pGeodeNavAgent);

		pGeode->SetActive(false);
		pGeode->GetPhysicsComponent()->DeactivateCollision();

		pGeode->CreateAudioComponent(CF->GetSoundManager());

		//---EFFECTS---

		XMFLOAT3 effectOffset(0.0f, 5.0f, 0.0f);
		XMFLOAT2 effectSize(4.5f, 4.5f);

		LoadEffect(pGeode, "GeodeSend", "2D_Send_To.dds", XMFLOAT2(2.0f, 4.0f), effectOffset, CF);
		//LoadEffect(pGeode, "GeodeAttack", "UniversalAttack.dds", XMFLOAT2(3.0f, 3.0f), XMFLOAT3(0.0f, 6.0f, 0.0f), CF);
		LoadEffect(pGeode, "GeodeSuperAttack", "Geode_Attack_Super.dds", XMFLOAT2(3.0f, 3.0f), XMFLOAT3(0.0f, 3.0f, 0.0f), CF);
		LoadEffect(pGeode, "GeodeDeath", "GeodeDeathEffect.dds", effectSize, effectOffset, CF);
		LoadEffect(pGeode, "GeodePickup", "GeodeGemPickupEffect.dds", effectSize, effectOffset, CF);
	//	LoadEffect(pGeode, "GeodeMining", "GeodeMining.dds", XMFLOAT2(2.0f, 2.0f), effectOffset, CF);
		LoadEffect(pGeode, "GeodeStun", "StunEffect.dds", effectSize, effectOffset, CF);
		LoadEffect(pGeode, "GeodeFear", "GeodeInFear.dds", effectSize, effectOffset, CF);
		LoadEffect(pGeode, "GeodeKnockback", "KnockbackEffect.dds", effectSize, effectOffset, CF);
		LoadEffect(pGeode, "GeodeScan", "2D_State_Scanning.dds", XMFLOAT2(4.0f, 4.0f), effectOffset, CF);
		LoadEffect(pGeode, "GeodeConfusion", "Geode_Confusion.dds", effectSize, effectOffset, CF);
		LoadEffect(pGeode, "GeodeEnemyFound", "2D_Enemy_Found.dds", XMFLOAT2(2.0f, 4.0f), effectOffset, CF);
	//	LoadEffect(pGeode, "GeodeNodeFound", "2D_Node_Found.dds", effectSize, effectOffset, CF);
		LoadEffect(pGeode, "GeodeWebTrapped", "ParagonGimpWeb.dds", effectSize, effectOffset, CF);
		
		EffectComponent* pBarrierEffect = LoadEffect(pGeode, "GeodeBarrier", "2D_Geode_Barrier.dds", XMFLOAT2(5.0f, 7.5f), XMFLOAT3(0, -2.5f, 0), CF);
		pBarrierEffect->SetIsTimed(false);
		pBarrierEffect->isEnabled = true;
		XMVECTOR barrierColor;
		switch (pGeode->GetType())
		{
		case eSAPPHIREGEODE: barrierColor = Colors::Aquamarine; break;
		case eRUBYGEODE: barrierColor = Colors::Crimson; break;
		case eDIAMONDGEODE: barrierColor = Colors::Honeydew; break;
		}
		pBarrierEffect->GetHolder()->SetObjectColor(barrierColor, 1.0f);
		pBarrierEffect->GetHolder()->SetObjectColorAlpha(0.0f);

		//Emitter Sets
		GF->LoadEmitter("GeodeTrail", pGeode, CF);
		GF->LoadEmitter("GeodePop", pGeode, CF)->SetSpawning(false);
		//GF->LoadEmitter("GeodeHitTrail", pGeode, CF);

		CF->m_AssetManager->LoadModel(&Geodes[index]);

		CF->m_ObjectManager->AddGameObject(pGeode);
	}

	// Animation Load ins for Geodes
#pragma region Geode Animations 
	AnimToLoad RubyIdle(RUBY_IDLE, "../Assets/Animations/Ruby_Anim_Idle.fbx");
	AnimToLoad RubyAttack(RUBY_ATTACK, "../Assets/Animations/Ruby_Anim_LightAttack.fbx");
	AnimToLoad RubyMove(RUBY_MOVE, "../Assets/Animations/Ruby_Anim_Move.fbx");
	AnimToLoad RubyDeath(RUBY_DEATH, "../Assets/Animations/Ruby_Anim_Death.fbx");
	AnimToLoad RubyHAttack(RUBY_HATTACK, "../Assets/Animations/Ruby_Anim_HeavyAttack.fbx");
	AnimToLoad RubyScan(RUBY_SCAN, "../Assets/Animations/Ruby_Anim_Scan.fbx");
	AnimToLoad RubyDance(RUBY_DANCE, "../Assets/Animations/Ruby_Anim_Dance.fbx");

	AnimToLoad SapphireIdle(SAPPHIRE_IDLE, "../Assets/Animations/Sapphire_Anim_Idle.fbx");
	AnimToLoad SapphireAttack(SAPPHIRE_ATTACK, "../Assets/Animations/Sapphire_Anim_LightAttack.fbx");
	AnimToLoad SapphireMove(SAPPHIRE_MOVE, "../Assets/Animations/Sapphire_Anim_Move.fbx");
	AnimToLoad SapphireDeath(SAPPHIRE_DEATH, "../Assets/Animations/Sapphire_Anim_Death.fbx");
	AnimToLoad SapphireHAttack(SAPPHIRE_HATTACK, "../Assets/Animations/Sapphire_Anim_HeavyAttack.fbx");
	AnimToLoad SapphireScan(SAPPHIRE_SCAN, "../Assets/Animations/Sapphire_Anim_Scan.fbx");
	AnimToLoad SapphireDance(SAPPHIRE_DANCE, "../Assets/Animations/Sapphire_Anim_Dance.fbx");

	AnimToLoad DiamondIdle(DIAMOND_IDLE, "../Assets/Animations/Diamond_Anim_Idle.fbx");
	AnimToLoad DiamondAttack(DIAMOND_ATTACK, "../Assets/Animations/Diamond_Anim_LightAttack.fbx");
	AnimToLoad DiamondMove(DIAMOND_MOVE, "../Assets/Animations/Diamond_Anim_Move.fbx");
	AnimToLoad DiamondDeath(DIAMOND_DEATH, "../Assets/Animations/Diamond_Anim_Death.fbx");
	AnimToLoad DiamondHAttack(DIAMOND_HATTACK, "../Assets/Animations/Diamond_Anim_HeavyAttack.fbx");
	AnimToLoad DiamondScan(DIAMOND_SCAN, "../Assets/Animations/Diamond_Anim_Scan.fbx");
	AnimToLoad DiamondDance(DIAMOND_DANCE, "../Assets/Animations/Diamond_Anim_Dance.fbx");

	CF->m_AssetManager->LoadAnimation(&RubyIdle);
	CF->m_AssetManager->LoadAnimation(&RubyMove);
	CF->m_AssetManager->LoadAnimation(&RubyDeath);
	CF->m_AssetManager->LoadAnimation(&RubyAttack);
	CF->m_AssetManager->LoadAnimation(&RubyHAttack);
	CF->m_AssetManager->LoadAnimation(&RubyScan);
	CF->m_AssetManager->LoadAnimation(&RubyDance);

	CF->m_AssetManager->LoadAnimation(&SapphireIdle);
	CF->m_AssetManager->LoadAnimation(&SapphireMove);
	CF->m_AssetManager->LoadAnimation(&SapphireDeath);
	CF->m_AssetManager->LoadAnimation(&SapphireAttack);
	CF->m_AssetManager->LoadAnimation(&SapphireHAttack);
	CF->m_AssetManager->LoadAnimation(&SapphireScan);
	CF->m_AssetManager->LoadAnimation(&SapphireDance);

	CF->m_AssetManager->LoadAnimation(&DiamondIdle);
	CF->m_AssetManager->LoadAnimation(&DiamondMove);
	CF->m_AssetManager->LoadAnimation(&DiamondDeath);
	CF->m_AssetManager->LoadAnimation(&DiamondAttack);
	CF->m_AssetManager->LoadAnimation(&DiamondHAttack);
	CF->m_AssetManager->LoadAnimation(&DiamondScan);
	CF->m_AssetManager->LoadAnimation(&DiamondDance);

#pragma endregion

}

EventComponent* LevelManager::LoadEvent(ObjectToLoad obj, GameObject* pGO, EventType eventType, int targetsRemaining, CoreFacade * CF, GameFacade * GF, XMVECTOR location)
{
	EventComponent* pEvent = new EventComponent;
	pEvent->TargetsRemaining = targetsRemaining;
	pEvent->InitialTargets = targetsRemaining;
	pEvent->SetEventType(eventType);
	pEvent->SetLocation(location);
	for (size_t i = 0; i < obj.WayPoints.size(); i++)
		pEvent->CameraToDoorWaypoints.push(obj.WayPoints[i]);

	pGO->SetEventComponent(pEvent);
	return pEvent;
}


HUDElement*	LevelManager::LoadHudElement(string tag, string filePath, float posX, float posY, float width, float height, CoreFacade * CF, GameFacade * GF)
{
	HUDtoLoad hudLoader;

	HUDElement* pHudElement = new HUDElement;
	pHudElement->m_XSceenPos = posX;
	pHudElement->m_YScreenPos = posY;
	pHudElement->m_Width = height;
	pHudElement->m_Height = width;
	pHudElement->m_Color = XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f);
	pHudElement->m_ColorRatio = 0;
	hudLoader.TextureFilePath = "../Assets/Textures/" + filePath;

	GameObject * hudGameObj = new GameObject;
	hudGameObj->SetActive(true);
	hudGameObj->SetTypeID(eHUD);
	hudGameObj->SetTag(tag);
	hudGameObj->SetHUDComponent(pHudElement);
	hudLoader.pGO = hudGameObj;
	CF->m_AssetManager->LoadHudAsset(&hudLoader);
	CF->m_ObjectManager->AddGameObject(hudGameObj);
	return pHudElement;
}

TextBox* LevelManager::LoadTextBox(float posX, float posY, float scale, const XMFLOAT4& glyphColor, const XMFLOAT4& outlineColor, string font, CoreFacade * CF, GameFacade * GF)
{
	TextBox* pTextBox = new TextBox;
	pTextBox->SetFont(CF->m_TextManager->GetFont(font));
	pTextBox->SetTextColor(glyphColor, outlineColor);
	pTextBox->SetPosition(posX, posY);
	pTextBox->SetScale(scale);

	GameObject * TextBoxOBJ = new GameObject;
	TextBoxOBJ->SetTypeID(eTEXTBOX);
	TextBoxOBJ->SetTag("Text Box Filler Tag");
	TextBoxOBJ->SetActive(true);
	TextBoxOBJ->SetTextBoxComponent(pTextBox);
	CF->m_ObjectManager->AddGameObject(TextBoxOBJ);
	return pTextBox;
}

void LevelManager::LoadStandardEffects(CoreFacade * CF)
{
	//Player Waypoint Pointer
	LoadEffect(NULL, "PlayerWaypointPointer", "PlayerWaypointMarker.dds", XMFLOAT2(4.5f, 4.5f), XMFLOAT3(0.0f, 0.0f, 0.0f), CF);

}

void LevelManager::AddPointLight(GameObject * GO, float Range, float PosY, XMFLOAT3 DiffColor, XMFLOAT3 AmbColor, XMFLOAT3 SpecColor, XMFLOAT3 Atten, string LightName, bool FollowY, CoreFacade * CF, bool Active, bool lock)
{
	//Point Light
	XMFLOAT4 TPos = XMCStoreFloat4(GO->GetObjectTranslationVec());

	if (lock)
		LoadingScreenState::LoadLock.lock();
	Paragon_Renderer::cbPOINT_LIGHT LightData;
	GameObject * PointLightGO = new GameObject;
	LightData.ambientColor = AmbColor;
	LightData.diffuseColor = DiffColor;
	LightData.specularColor = SpecColor;
	LightData.attenuation = Atten;
	LightData.position = XMFLOAT4(TPos.x, PosY, TPos.z, 1.0f);
	LightData.range = Range;
	LightData.specularPower = 1.0f;
	LightData.specularIntensity = 1.0f;
	PointLightComponent * PL = new PointLightComponent(LightData);
	if (lock)
		LoadingScreenState::LoadLock.unlock();
	PL->AddFlicker = false;
	PL->FollowObject = GO;
	PL->Parent = PointLightGO;
	PL->FollowParent = true;
	PL->FollowParentY = FollowY;

	PointLightGO->SetTypeID(ePOINTLIGHT);
	PointLightGO->SetActive(Active);
	PointLightGO->SetPointLightComponent(PL);
	PointLightGO->SetTag(LightName);

	//Create a sphere to render for the point light
	ObjectToLoad PointLightSphere;
	PointLightSphere.pGO = PointLightGO;
	PointLightSphere.FBX_filename = "../Assets/Mesh/PointLightSphere.fbx";
	PointLightSphere.Texture_filename = "None";
	PointLightSphere.pGO->GetRendererComponent()->TextureFlags.ApplyNormals = false;

	//Set up matrix
	XMMATRIX PointLightTransform = XMMatrixIdentity();
	PointLightTransform = XMMatrixMultiply(PointLightTransform, XMMatrixScaling(Range, Range, Range));
	PointLightTransform = XMMatrixMultiply(PointLightTransform, XMMatrixTranslation(TPos.x, PosY, TPos.z));
	PointLightSphere.pGO->SetObjectTransform(PointLightTransform);

	CF->m_AssetManager->LoadModel(&PointLightSphere);
	CF->m_ObjectManager->AddGameObject(PointLightGO);
	GO->AddPointLightChild(PointLightGO);
}

Telegraph* LevelManager::LoadTelegraph(CoreFacade* CF, GameObject* pGO, string tag, string texture, XMVECTOR color)
{
	tag += " Telegraph";
	texture = "../Assets/Textures/" + texture;
	TelegraphToLoad telegraphToLoad;
	Telegraph * pTelegraph = new Telegraph;
	pTelegraph->SetTelegraphColor(color);

	GameObject * TelegraphGO = new GameObject;
	TelegraphGO->SetTypeID(eTELEGRAPH);
	TelegraphGO->SetTag(tag);
	TelegraphGO->SetTelegraphComponenet(pTelegraph);
	TelegraphGO->SetActive(true);
	telegraphToLoad.pGO = TelegraphGO;
	telegraphToLoad.TextureFilePath = texture;

	pGO->AddTelegraphChildObject(TelegraphGO);

	CF->GetAssetManager()->LoadTelegraphAsset(&telegraphToLoad);
	CF->GetObjectManager()->AddGameObject(TelegraphGO);

	return pTelegraph;
}
