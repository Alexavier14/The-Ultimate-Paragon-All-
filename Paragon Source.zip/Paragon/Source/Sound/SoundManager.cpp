#include "../Application/stdafx.h"

#include "SoundManager.h"
#include "AudioSystemWwise.h"
#include "Entity3D.h"
#include "Wwise_IDs.h"
#include "../Util/Util.h"

#define DEFAULT_MUSIC_VOLUME 20.0f
#define DEFAULT_SFX_VOLUME 30.0f

SoundManager::SoundManager()
{
	m_fSfxVolume = DEFAULT_SFX_VOLUME;
	m_fMusicVolume = DEFAULT_MUSIC_VOLUME;

	m_pListenerEntity = new Entity3D();
}


SoundManager::~SoundManager()
{
	SAFE_DELETE(m_pListenerEntity);
	delete m_pListenerEntity;
	m_pListenerEntity = nullptr;
}

void SoundManager::Initialize()
{
	bool temp;
	temp = m_AudioSystem.Initialize();
	//m_AudioSystem.SetBasePath(L"../Assets/SoundBanks/");
	temp = m_AudioSystem.LoadSoundBank(L"InitNew.bnk");
	temp = m_AudioSystem.LoadSoundBank(L"SoundBankNew.bnk");

	m_AudioSystem.RegisterListener(m_pListenerEntity, "Listener");
	m_AudioSystem.RegisterEntity(&m_pEntity, "Main Entity");
	m_fSfxVolume = DEFAULT_SFX_VOLUME;
	m_fMusicVolume = DEFAULT_MUSIC_VOLUME;
	m_AudioSystem.SetRTCPValue(AK::GAME_PARAMETERS::MUSIC_VOLUME, m_fMusicVolume);
	m_AudioSystem.SetRTCPValue(AK::GAME_PARAMETERS::SFX_VOLUME, m_fSfxVolume);
	m_AudioSystem.SetRTCPValue(AK::GAME_PARAMETERS::DIALOGUE_VOLUME, m_fSfxVolume);
}
void SoundManager::Shutdown()
{
	m_AudioSystem.UnRegisterEntity(&m_pEntity);
	m_AudioSystem.UnRegisterListener(m_pListenerEntity);
	
	m_AudioSystem.UnloadSoundBank(L"SoundBankNew.bnk");
	m_AudioSystem.UnloadSoundBank(L"InitNew.bnk");

	//m_AudioSystem.Shutdown();
}

void SoundManager::Update()
{
	m_AudioSystem.SetRTCPValue(AK::GAME_PARAMETERS::MUSIC_VOLUME, m_fMusicVolume);
	m_AudioSystem.SetRTCPValue(AK::GAME_PARAMETERS::SFX_VOLUME, m_fSfxVolume);
	m_AudioSystem.SetRTCPValue(AK::GAME_PARAMETERS::DIALOGUE_VOLUME, m_fSfxVolume);
	m_AudioSystem.Update();
}

AudioSystemWwise* SoundManager::GetAudioSystem(void)
{
	return m_AudioSystem.Get();
}

void SoundManager::UpdateEntityMat(XMFLOAT4X4& _mat1, XMFLOAT4X4& _mat2)
{
	m_pListenerEntity->m_mWorld = _mat1;
	m_pEntity.m_mWorld = _mat2;
}
