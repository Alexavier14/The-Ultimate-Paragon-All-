#pragma once
#include "Entity3D.h"
#include "AudioSystemWwise.h"

class SoundManager
{
	AudioSystemWwise m_AudioSystem;
	Entity3D* m_pListenerEntity;
	Entity3D  m_pEntity;

	float m_fSfxVolume;
	float m_fMusicVolume;
	float m_fMasterVolume;

public:
	void Initialize();
	void Shutdown();
	void Update(void);
	AudioSystemWwise* GetAudioSystem(void);
	SoundManager();
	~SoundManager();
	float GetSfxVolume(void){ return m_fSfxVolume; }
	float GetMusicVolume(void){ return m_fMusicVolume; }
	void SetSfxVolume(float _mSfx){ m_fSfxVolume = _mSfx; }
	void SetMusicVolume(float _mMus){ m_fMusicVolume = _mMus; }

	void UpdateEntityMat(XMFLOAT4X4& _mat1, XMFLOAT4X4& _mat2);

};

