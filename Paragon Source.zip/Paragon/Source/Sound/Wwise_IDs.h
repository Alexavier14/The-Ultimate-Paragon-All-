/////////////////////////////////////////////////////////////////////////////////////////////////////
//
// Audiokinetic Wwise generated include file. Do not edit.
//
/////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef __WWISE_IDS_H__
#define __WWISE_IDS_H__

#include <AK/SoundEngine/Common/AkTypes.h>

namespace AK
{
    namespace EVENTS
    {
        static const AkUniqueID PAUSE_ALL = 3864097025U;
        static const AkUniqueID PLAY_ADR_BALIN_DEATH = 4172958707U;
        static const AkUniqueID PLAY_ADR_BALIN_GEODE_SEND_DIAMOND = 2417273773U;
        static const AkUniqueID PLAY_ADR_BALIN_GEODE_SEND_RUBY = 905916079U;
        static const AkUniqueID PLAY_ADR_BALIN_GEODE_SEND_SAFFIRE = 2942578779U;
        static const AkUniqueID PLAY_ADR_BALIN_GEODE_TOGGLE_DIAMOND = 3123562855U;
        static const AkUniqueID PLAY_ADR_BALIN_GEODE_TOGGLE_RUBY = 756484637U;
        static const AkUniqueID PLAY_ADR_BALIN_GEODE_TOGGLE_SAFFIRE = 3180026117U;
        static const AkUniqueID PLAY_ADR_BALIN_HURT = 3583928252U;
        static const AkUniqueID PLAY_ADR_BALIN_IDLE = 1390553629U;
        static const AkUniqueID PLAY_ADR_BALIN_RECALL = 186678076U;
        static const AkUniqueID PLAY_ADR_DIAMOND_ATTACK = 655442423U;
        static const AkUniqueID PLAY_ADR_DIAMOND_COLLECTED_GEM = 278019260U;
        static const AkUniqueID PLAY_ADR_GEODE_DIAMOND_COMMAND_FAILED = 1521041771U;
        static const AkUniqueID PLAY_ADR_GEODE_DIAMOND_DEATH = 3804486360U;
        static const AkUniqueID PLAY_ADR_GEODE_DIAMOND_FEARED = 1593808543U;
        static const AkUniqueID PLAY_ADR_GEODE_DIAMOND_IDLE_HOVER = 3321530443U;
        static const AkUniqueID PLAY_ADR_GEODE_DIAMOND_KNOCKBACK = 510334495U;
        static const AkUniqueID PLAY_ADR_GEODE_DIAMOND_RECALL = 2953786445U;
        static const AkUniqueID PLAY_ADR_GEODE_DIAMOND_SEND = 201015528U;
        static const AkUniqueID PLAY_ADR_GEODE_DIAMOND_STUNNED = 43468711U;
        static const AkUniqueID PLAY_ADR_GEODE_DIAMOND_VICTORY = 695716412U;
        static const AkUniqueID PLAY_ADR_GEODE_RUBY_ATTACK = 48955048U;
        static const AkUniqueID PLAY_ADR_GEODE_RUBY_ATTACK_01 = 2400141054U;
        static const AkUniqueID PLAY_ADR_GEODE_RUBY_COLLECTED_GEM = 2623700365U;
        static const AkUniqueID PLAY_ADR_GEODE_RUBY_COMMAND_FAILED = 3539170373U;
        static const AkUniqueID PLAY_ADR_GEODE_RUBY_DEATH = 18727338U;
        static const AkUniqueID PLAY_ADR_GEODE_RUBY_FEARED = 1432379005U;
        static const AkUniqueID PLAY_ADR_GEODE_RUBY_IDLE_HOVER = 2877777977U;
        static const AkUniqueID PLAY_ADR_GEODE_RUBY_KNOCKBACK = 4284052057U;
        static const AkUniqueID PLAY_ADR_GEODE_RUBY_RECALL = 652131963U;
        static const AkUniqueID PLAY_ADR_GEODE_RUBY_SEND = 3736834070U;
        static const AkUniqueID PLAY_ADR_GEODE_RUBY_STUNNED = 3274854157U;
        static const AkUniqueID PLAY_ADR_GEODE_RUBY_VICTORY = 1260289830U;
        static const AkUniqueID PLAY_ADR_GEODE_SAFFIRE_ATTACK = 3069703480U;
        static const AkUniqueID PLAY_ADR_GEODE_SAFFIRE_COLLECTED_GEM = 2372787773U;
        static const AkUniqueID PLAY_ADR_GEODE_SAFFIRE_COMMAND_FAILED = 3742977205U;
        static const AkUniqueID PLAY_ADR_GEODE_SAFFIRE_DEATH = 97859578U;
        static const AkUniqueID PLAY_ADR_GEODE_SAFFIRE_FEARED = 305110637U;
        static const AkUniqueID PLAY_ADR_GEODE_SAFFIRE_IDLE_HOVER = 3524140969U;
        static const AkUniqueID PLAY_ADR_GEODE_SAFFIRE_KNOCKBACK = 1170752137U;
        static const AkUniqueID PLAY_ADR_GEODE_SAFFIRE_RECALL = 716106731U;
        static const AkUniqueID PLAY_ADR_GEODE_SAFFIRE_SEND = 749833862U;
        static const AkUniqueID PLAY_ADR_GEODE_SAFFIRE_STUNNED = 2289181U;
        static const AkUniqueID PLAY_ADR_GEODE_SAFFIRE_VICTORY = 2596623574U;
        static const AkUniqueID PLAY_BGM_GAUNTLET = 1300947213U;
        static const AkUniqueID PLAY_BGM_GOT_1 = 3134208851U;
        static const AkUniqueID PLAY_BGM_GOT_2 = 3134208848U;
        static const AkUniqueID PLAY_BGM_GOT_3 = 3134208849U;
        static const AkUniqueID PLAY_BGM_GOT_4 = 3134208854U;
        static const AkUniqueID PLAY_BGM_LVL_COMPLETED = 3245277001U;
        static const AkUniqueID PLAY_BGM_PARAGON_LOOP_01 = 3735510038U;
        static const AkUniqueID PLAY_BGM_PARAGON_LOOP_02 = 3735510037U;
        static const AkUniqueID PLAY_BGM_PARAGON_LOOP_03 = 3735510036U;
        static const AkUniqueID PLAY_BGM_PARAGON_LOOP_04 = 3735510035U;
        static const AkUniqueID PLAY_BGM_PARAGON_LOOP_05 = 3735510034U;
        static const AkUniqueID PLAY_BGM_PARAGON_LOOP_06 = 3735510033U;
        static const AkUniqueID PLAY_BGM_PARAGON_LOOP_07 = 3735510032U;
        static const AkUniqueID PLAY_BGM_VICTORY = 967734091U;
        static const AkUniqueID PLAY_SFX_ELECTRICSTORM = 3838538266U;
        static const AkUniqueID PLAY_SFX_ELEVATOR = 3460507464U;
        static const AkUniqueID PLAY_SFX_GEM_PICKUP_01 = 3187580800U;
        static const AkUniqueID PLAY_SFX_GEM_PICKUP_02 = 3187580803U;
        static const AkUniqueID PLAY_SFX_GEODE_ATTACK = 1149658647U;
        static const AkUniqueID PLAY_SFX_GEODE_COLLISION = 1553759245U;
        static const AkUniqueID PLAY_SFX_GEODE_MINE = 1681016698U;
        static const AkUniqueID PLAY_SFX_GOLEM_ATTACK = 1405824461U;
        static const AkUniqueID PLAY_SFX_GOLEM_DEATH = 875292177U;
        static const AkUniqueID PLAY_SFX_GOLEM_FOOTSTEP = 4216371799U;
        static const AkUniqueID PLAY_SFX_GOLEM_SMASH = 1858881887U;
        static const AkUniqueID PLAY_SFX_GOLEM_STUN = 1505245489U;
        static const AkUniqueID PLAY_SFX_MENU_RETURN = 3678608392U;
        static const AkUniqueID PLAY_SFX_MENU_SCROLL = 2151728965U;
        static const AkUniqueID PLAY_SFX_MENU_SELECT = 3759090466U;
        static const AkUniqueID PLAY_SFX_NODE_DESTROYED = 490561534U;
        static const AkUniqueID PLAY_SFX_PRESSURE_PLATE = 1979222986U;
        static const AkUniqueID PLAY_SFX_ROCK_DOOR_OPEN = 1544696807U;
        static const AkUniqueID PLAY_SFX_ROCK_LARGE = 3448864689U;
        static const AkUniqueID PLAY_SFX_ROCK_SMALL = 3512062713U;
        static const AkUniqueID PLAY_SFX_SPIDER_ATTACK = 2106147432U;
        static const AkUniqueID PLAY_SFX_SPIDER_DEATH = 1828297322U;
        static const AkUniqueID PLAY_SFX_SPIDER_FEAR = 1482407970U;
        static const AkUniqueID PLAY_SFX_SPIDER_FOOTSTEP = 359261814U;
        static const AkUniqueID PLAY_SFX_SPIDER_JUMP = 2948520568U;
        static const AkUniqueID PLAY_SFX_SPIDER_LAND = 86293555U;
        static const AkUniqueID PLAY_SFX_SPIDER_STRIKE = 4030209122U;
        static const AkUniqueID PLAY_SFX_SPIDER_TRAP = 3412675357U;
        static const AkUniqueID PLAY_SFX_SPIDER_WEB_TRAP = 675368632U;
        static const AkUniqueID PLAY_SFX_TORCH_FLICKER = 1909991913U;
        static const AkUniqueID PLAY_SFX_WORM_BURROW = 2182814815U;
        static const AkUniqueID PLAY_SFX_WORM_EMERGE = 582574021U;
        static const AkUniqueID PLAY_SFX_WORM_STRIKE = 1038683856U;
        static const AkUniqueID PLAY_SFX_WORM_SWEEP = 2237019890U;
        static const AkUniqueID RESUME_ALL = 3679762312U;
        static const AkUniqueID STOP_ALL = 452547817U;
        static const AkUniqueID STOP_BGM_GAUNTLET = 3321045607U;
        static const AkUniqueID STOP_BGM_GOT_1 = 749074925U;
        static const AkUniqueID STOP_BGM_GOT_2 = 749074926U;
        static const AkUniqueID STOP_BGM_GOT_3 = 749074927U;
        static const AkUniqueID STOP_BGM_GOT_4 = 749074920U;
        static const AkUniqueID STOP_BGM_LVL_COMPLETED = 3631796023U;
        static const AkUniqueID STOP_BGM_PARAGON_LOOP_01 = 640408084U;
        static const AkUniqueID STOP_BGM_PARAGON_LOOP_02 = 640408087U;
        static const AkUniqueID STOP_BGM_PARAGON_LOOP_03 = 640408086U;
        static const AkUniqueID STOP_BGM_PARAGON_LOOP_04 = 640408081U;
        static const AkUniqueID STOP_BGM_PARAGON_LOOP_05 = 640408080U;
        static const AkUniqueID STOP_BGM_PARAGON_LOOP_06 = 640408083U;
        static const AkUniqueID STOP_BGM_PARAGON_LOOP_07 = 640408082U;
        static const AkUniqueID STOP_BGM_VICTORY = 1900123545U;
        static const AkUniqueID STOP_SFX_ELECTRICSTORM = 963907152U;
    } // namespace EVENTS

    namespace GAME_PARAMETERS
    {
        static const AkUniqueID DIALOGUE_VOLUME = 725232568U;
        static const AkUniqueID MASTER_VOLUME = 4179668880U;
        static const AkUniqueID MUSIC_VOLUME = 1006694123U;
        static const AkUniqueID SFX_VOLUME = 1564184899U;
        static const AkUniqueID SS_AIR_FEAR = 1351367891U;
        static const AkUniqueID SS_AIR_FREEFALL = 3002758120U;
        static const AkUniqueID SS_AIR_FURY = 1029930033U;
        static const AkUniqueID SS_AIR_MONTH = 2648548617U;
        static const AkUniqueID SS_AIR_PRESENCE = 3847924954U;
        static const AkUniqueID SS_AIR_RPM = 822163944U;
        static const AkUniqueID SS_AIR_SIZE = 3074696722U;
        static const AkUniqueID SS_AIR_STORM = 3715662592U;
        static const AkUniqueID SS_AIR_TIMEOFDAY = 3203397129U;
        static const AkUniqueID SS_AIR_TURBULENCE = 4160247818U;
    } // namespace GAME_PARAMETERS

    namespace BANKS
    {
        static const AkUniqueID INIT = 1355168291U;
        static const AkUniqueID SOUNDBANK = 1661994096U;
    } // namespace BANKS

    namespace BUSSES
    {
        static const AkUniqueID DIALOGUE = 3930136735U;
        static const AkUniqueID MASTER_AUDIO_BUS = 3803692087U;
        static const AkUniqueID MASTER_SECONDARY_BUS = 805203703U;
        static const AkUniqueID MUSIC = 3991942870U;
        static const AkUniqueID SFX = 393239870U;
    } // namespace BUSSES

}// namespace AK

#endif // __WWISE_IDS_H__
