#include "../Application/stdafx.h"

#include "AnimationSystem.h"
#include "Node.h"
#include "../Application/CoreFacade.h"
#include "../Object Manager/GameObject.h"
#include "../Object Manager/AnimComponent.h"
#include "../Asset Manager/AssetManager.h"
#include "../Physics/Physics.h"
#include "../Util/TimeManager.h"
#include "../Util/Util.h"
//#include "../Input Manager/InputManager.h"

#define CONTROLLED_ANIM 0


AnimationSystem::AnimationSystem()
{

}

AnimationSystem::~AnimationSystem()
{
}

void AnimationSystem::Initialize(CoreFacade * pCore)
{
	pCoreFacade = pCore;
}
void AnimationSystem::Shutdown()
{

}

void AnimationSystem::Update()
{
	vector<GameObject *> gameList = pCoreFacade->m_ObjectManager->GetRenderSet();
	for (size_t i = 0; i < gameList.size(); i++)
	{
		if (!gameList[i]->IsAnimated() || !gameList[i]->GetActive() || gameList[i]->GetAnimComponent() == nullptr)
			continue;


		CAnimComponent * animComp = gameList[i]->GetAnimComponent();

		//Check to see if animations have changed or if animation held is null
		if (animComp->GetCurrAnimation() == nullptr || (animComp->GetAnimName() != animComp->GetCurrAnimation()->GetAnimTag() && !animComp->IsTransitioning()))
		{
			//pCoreFacade->GetAssetManager()->GetAnimation(animComp->GetAnimName());
			animComp->SetAnimation(pCoreFacade->GetAssetManager()->GetAnimation(animComp->GetAnimName()), 0.25f);
			if (animComp->GetNextAnimation() == nullptr)
				animComp->SetInterpolatedFrame(*animComp->GetCurrAnimation()->GetFrame(0));
		}

#if CONTROLLED_ANIM
		float currFrame, nextFrame;

		currFrame = nextFrame = animComp->GetKeyTime();
		if (pCoreFacade->IsPressing(ButtonID::BT_LEFT))
		{
			animComp->AddTime(-TimeManager::GetTimeDelta());
			nextFrame = animComp->GetKeyTime();

			if (nextFrame < 0)
				nextFrame += animComp->GetAnimation()->GetAnimTime();

			PrintConsole("Anim Time: ", nextFrame);
		}

		if (pCoreFacade->IsPressing(ButtonID::BT_RIGHT))
		{
			animComp->AddTime(TimeManager::GetTimeDelta());
			nextFrame = animComp->GetKeyTime();
			if (nextFrame >= animComp->GetAnimation()->GetAnimTime())
				nextFrame -= animComp->GetAnimation()->GetAnimTime();

			PrintConsole("Anim Time: ", nextFrame);
		}

		if (nextFrame != currFrame)
		{
			InterpolateProcess(animComp, nextFrame);
			animComp->SetKeyTime(nextFrame);
		}

#endif // CONTROLLED_ANIM

#if CONTROLLED_ANIM == 0
		animComp->AddTime(TimeManager::GetTimeDelta());
		InterpolateProcess(animComp);
#endif // CONTROLLED_ANIM == 0



	}
}

void AnimationSystem::InterpolateProcess(CAnimComponent * pAnimComp)
{
	unsigned int currFrame_Anim1 = 0, nextFrame_Anim1 = 0;
	unsigned int currFrame_Anim2 = 0, nextFrame_Anim2 = 0;
	float ratio_Anim1 = 0.0f;
	float ratio_Anim2 = 0.0f;
	float currTime_Anim1 = 0.0f;
	float currTime_Anim2 = 0.0f;
	XMMATRIX interpolated;

	const CAnimation * pCurrAnim, * pNextAnim;

	if (pAnimComp->IsTransitioning())
	{
		currTime_Anim1 = pAnimComp->GetCurrKeyTime();
		currTime_Anim2 = pAnimComp->GetNextKeyTime();
		pCurrAnim = pAnimComp->GetCurrAnimation();
		pNextAnim = pAnimComp->GetNextAnimation();

		FindFrameAndRatio(pCurrAnim, currTime_Anim1, currFrame_Anim1, nextFrame_Anim1, ratio_Anim1);
		FindFrameAndRatio(pNextAnim, currTime_Anim2, currFrame_Anim2, nextFrame_Anim2, ratio_Anim2);

		XMMATRIX interpolated_Anim1;
		XMMATRIX interpolated_Anim2;
		float blend_ratio = pAnimComp->GetTransitionTime() / pAnimComp->GetTransitionTotalTime();
		Physics::XMCClamp(blend_ratio);

		for (size_t i = 0; i < pCurrAnim->GetFrame(currFrame_Anim1)->m_Bones.size(); i++)
		{
			interpolated_Anim1 = AnimInterpolation(pCurrAnim, currFrame_Anim1, nextFrame_Anim1, ratio_Anim1, i);
			interpolated_Anim2 = AnimInterpolation(pNextAnim, currFrame_Anim2, nextFrame_Anim2, ratio_Anim2, i);

			interpolated = BlendInterpoloation(interpolated_Anim1, interpolated_Anim2, blend_ratio);

			XMStoreFloat4x4(&pAnimComp->GetInterpolatedFrame().m_Bones[i]->GetWorldMat(), interpolated);
		}
	}
	else
	{
		currTime_Anim1 = pAnimComp->GetCurrKeyTime();
		pCurrAnim = pAnimComp->GetCurrAnimation();

		FindFrameAndRatio(pCurrAnim, currTime_Anim1, currFrame_Anim1, nextFrame_Anim1, ratio_Anim1);

		for (size_t i = 0; i < pCurrAnim->GetFrame(currFrame_Anim1)->m_Bones.size(); i++)
		{
			interpolated = AnimInterpolation(pCurrAnim, currFrame_Anim1, nextFrame_Anim1, ratio_Anim1, i);
			XMStoreFloat4x4(&pAnimComp->GetInterpolatedFrame().m_Bones[i]->GetWorldMat(), interpolated);

		}
	}


}

void AnimationSystem::FindFrameAndRatio(const CAnimation* pAnim, float time, unsigned int& currFrame, unsigned int& nextFrame, float& ratio)
{
	//Find Where the currTime lies in between which frames
	for (size_t i = 0; i < pAnim->GetFrames().size(); i++)
	{
		if (time > pAnim->GetFrame(i)->fKeyTime)
		{
			if ((i + 1) < pAnim->GetFrames().size() && time < pAnim->GetFrame(i + 1)->fKeyTime)
			{
				currFrame = i;
				nextFrame = i + 1;
				break;
			}
			else if (i + 1 >= pAnim->GetFrames().size())
			{
				currFrame = i;
				nextFrame = 0;
			}
		}
	}

	//Find the ratio of between the two frames.
	if (nextFrame > 0)
		ratio = (time - pAnim->GetFrame(currFrame)->fKeyTime) / (pAnim->GetFrame(nextFrame)->fKeyTime - pAnim->GetFrame(currFrame)->fKeyTime);
	else
		ratio = (time - pAnim->GetFrame(currFrame)->fKeyTime) / (pAnim->GetAnimTime() - pAnim->GetFrame(currFrame)->fKeyTime);

	//Clamping ratio
	Physics::XMCClamp(ratio);
}

XMMATRIX AnimationSystem::AnimInterpolation(const CAnimation* pAnim, const unsigned int currFrame, const unsigned int nextFrame, const float ratio, const unsigned int bone)
{

		//XMMATRIX bindMat = XMLoadFloat4x4(&pAnim->m_pBindPose->m_Bones[i]->GetWorldMat());
		//bindMat = XMMatrixInverse(NULL, bindMat);

		XMMATRIX matA = XMLoadFloat4x4(&pAnim->GetFrame(currFrame)->m_Bones[bone]->GetWorldMat());
		XMMATRIX matB = XMLoadFloat4x4(&pAnim->GetFrame(nextFrame)->m_Bones[bone]->GetWorldMat());

		XMMATRIX interpolated;
		XMVECTOR vecRot1, vecScale1, vecTrans1;
		XMVECTOR vecRot2, vecScale2, vecTrans2;
		XMMatrixDecompose(&vecScale1, &vecRot1, &vecTrans1, matA);
		XMMatrixDecompose(&vecScale2, &vecRot2, &vecTrans2, matB);

		XMVECTOR newRot = XMQuaternionSlerp(vecRot1, vecRot2, ratio);
		XMVECTOR newScale = XMVectorLerp(vecScale1, vecScale2, ratio);
		XMVECTOR newTrans = XMVectorLerp(vecTrans1, vecTrans2, ratio);
		XMVECTOR nullVector = XMLoadFloat3(&XMFLOAT3(0.0f, 0.0f, 0.0f));

		interpolated = XMMatrixAffineTransformation(newScale, nullVector, newRot, newTrans);

		//interpolated.r[0] = matA.r[0] + ((matB.r[0] - matA.r[0]) * ratio);
		//interpolated.r[1] = matA.r[1] + ((matB.r[1] - matA.r[1]) * ratio);
		//interpolated.r[2] = matA.r[2] + ((matB.r[2] - matA.r[2]) * ratio);
		//interpolated.r[3] = matA.r[3] + ((matB.r[3] - matA.r[3]) * ratio);

		return interpolated;
}

XMMATRIX AnimationSystem::BlendInterpoloation(XMMATRIX& left, XMMATRIX& right, float ratio)
{
	XMMATRIX interpolated;
	XMVECTOR vecRot1, vecScale1, vecTrans1;
	XMVECTOR vecRot2, vecScale2, vecTrans2;
	XMMatrixDecompose(&vecScale1, &vecRot1, &vecTrans1, left);
	XMMatrixDecompose(&vecScale2, &vecRot2, &vecTrans2, right);

	XMVECTOR newRot = XMQuaternionSlerp(vecRot1, vecRot2, ratio);
	XMVECTOR newScale = XMVectorLerp(vecScale1, vecScale2, ratio);
	XMVECTOR newTrans = XMVectorLerp(vecTrans1, vecTrans2, ratio);
	XMVECTOR nullVector = XMLoadFloat3(&XMFLOAT3(0.0f, 0.0f, 0.0f));

	interpolated = XMMatrixAffineTransformation(newScale, nullVector, newRot, newTrans);

	//interpolated.r[0] = matA.r[0] + ((matB.r[0] - matA.r[0]) * ratio);
	//interpolated.r[1] = matA.r[1] + ((matB.r[1] - matA.r[1]) * ratio);
	//interpolated.r[2] = matA.r[2] + ((matB.r[2] - matA.r[2]) * ratio);
	//interpolated.r[3] = matA.r[3] + ((matB.r[3] - matA.r[3]) * ratio);

	return interpolated;
}