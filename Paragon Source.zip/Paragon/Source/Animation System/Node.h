#include "../Application/stdafx.h"

//I used EDNode and EDFrame from RTA's animation system for our code.
//All credit goes to the creator(s) of the containing solution.

#ifndef _NODE_H_
#define _NODE_H_

using namespace DirectX;

class CNode
{
	// The local space matrix of the frame.
	XMFLOAT4X4 m_LocalMat;

	// The world space matrix of the frame.
	//
	// If the frame has a parent,
	//
	//	m_WorldMat = m_LocalMat * m_pParent->m_WorldMat
	//
	// Else,
	//
	//	m_WorldMat = m_LocalMat;
	XMFLOAT4X4 m_WorldMat;

	bool m_bDirty;

public:

	std::string Node_name;
	CNode *m_pParent;
	unsigned char m_nParentIndex;
	std::vector< CNode * > m_Children;
	std::vector< unsigned char > m_ChildrenIndex;

public:

	CNode(void) : m_pParent(nullptr), m_bDirty(false) {}
	virtual ~CNode(void) 
	{
		m_pParent = nullptr;
		//m_Children.clear();
	}

	CNode *GetParent(void){ return m_pParent; }
	void SetParent(CNode * parent) { m_pParent = parent; }

	std::vector< CNode *> &GetChildren(void)
	{ 
		return m_Children;
	}

	CNode * GetChild(size_t index)
	{
		return m_Children[index];
	}

	CNode *AddChild(CNode *node)
	{
		if (node->GetParent())
			return NULL;

		node->m_pParent = this;
		m_Children.push_back(node);
		return node;
	}

	CNode *RemoveChild(CNode *node)
	{
		if (node->GetParent() != this)
			return NULL;

		for (unsigned int i = 0; i < m_Children.size(); ++i)
		{
			if (m_Children[i] == node)
			{
				m_Children.erase(m_Children.begin() + i);
				node->m_pParent = NULL;
				return node;
			}
		}

		return NULL;
	}

	//Update sets the frame and it's children as dirtied
	//When the world matrix is accessed it will clean up the matrix.
	void Update()
	{
		if (!m_bDirty)
		{
			m_bDirty = !m_bDirty;

			for (size_t i = 0; i < GetChildren().size(); i++)
			{
				reinterpret_cast<CNode *>(GetChild(i))->Update();
			}
		}
	}

	XMFLOAT4X4 & GetLocalMat()
	{
		return m_LocalMat;
	}

	XMFLOAT4X4 & GetWorldMat()
	{
		if (m_bDirty)
		{
			if (GetParent())
			{
				XMMATRIX world = XMLoadFloat4x4(&reinterpret_cast<CNode *>(GetParent())->GetWorldMat());
				XMMATRIX local = XMLoadFloat4x4(&m_LocalMat);

				XMStoreFloat4x4(&m_WorldMat, XMMatrixMultiply(world, local));
			}
			else
				m_WorldMat = m_LocalMat;

			m_bDirty = !m_bDirty;
		}
		return m_WorldMat;
	}
};

#endif