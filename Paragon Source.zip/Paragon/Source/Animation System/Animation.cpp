#include "../Application/stdafx.h"

#include "Animation.h"
#include "../Util/Util.h"

CAnimation::CAnimation()
{
	m_pBindPose = nullptr;
	
}


CAnimation::~CAnimation()
{
	ClearFrames();

	if (m_pBindPose)
	{
		for (size_t j = 0; j < m_pBindPose->m_Bones.size(); j++)
		{
			delete m_pBindPose->m_Bones[j];
			m_pBindPose->m_Bones[j] = nullptr;
		}

		delete m_pBindPose;
		m_pBindPose = nullptr;
	}
}

void CAnimation::ClearFrames()
{
	tKeyFrame * curr_frame = nullptr;
	CNode * curr_node = nullptr;
	for (size_t i = 0; i < m_Frames.size(); i++)
	{
		curr_frame = m_Frames[i];
		for (size_t j = 0; j < m_Frames[i]->m_Bones.size(); j++)
		{
			curr_node = curr_frame->m_Bones[j];
			SAFE_DELETE(curr_node);
			//delete m_Frames[i]->m_Bones[j];
			//m_Frames[i]->m_Bones[j] = nullptr;
		}
		curr_frame->m_Bones.clear();
		SAFE_DELETE(curr_frame);
	}
	m_Frames.clear();
}

std::vector<tKeyFrame *> CAnimation::GetFrames() const
{
	return m_Frames;
}

tKeyFrame * CAnimation::GetFrame(int index) const
{
	return m_Frames[index];
}

float CAnimation::GetAnimTime() const
{
	return m_fAnimTime;
}

void CAnimation::SetAnimTime(float time) 
{
	m_fAnimTime = time;
}

std::string CAnimation::GetAnimTag() const
{
	return m_sAnimTag;
}

void CAnimation::SetAnimTag(std::string tag)
{
	m_sAnimTag = tag;
}

void CAnimation::AddFrames(tKeyFrame * frames)
{
	if (frames != nullptr)
		m_Frames.push_back(frames);
}

