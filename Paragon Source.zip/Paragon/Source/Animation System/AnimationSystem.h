#pragma once

class CoreFacade;
class CAnimComponent;
class CAnimation;

class AnimationSystem
{
	CoreFacade * pCoreFacade;

public:
	void Initialize(CoreFacade * pCore);
	void Shutdown();

	void Update();

	AnimationSystem();
	~AnimationSystem();

private:
	//Private Functions
	void InterpolateProcess(CAnimComponent * pAnimComp);
	void FindFrameAndRatio(const CAnimation* pAnim, float time, unsigned int& currFrame, unsigned int& nextFrame, float& ratio);
	XMMATRIX AnimInterpolation(const CAnimation* pAnim, const unsigned int currFrame, const unsigned int nextFrame, const float ratio, const unsigned int bone);
	XMMATRIX BlendInterpoloation(XMMATRIX& left, XMMATRIX& right, float ratio);
};