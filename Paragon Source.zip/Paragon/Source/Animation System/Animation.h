#include "../Application/stdafx.h"


#pragma once

#include "Node.h"

struct tAnim_Bin_Header
{
	//string file_version;
	unsigned int num_of_frames;
	unsigned int num_of_bones;
	float anim_time;
};

struct tKeyFrame
{
	std::vector<CNode *> m_Bones;
	float fKeyTime;

	tKeyFrame() : m_Bones(NULL), fKeyTime(NULL) {}
};

struct tJointInfluence
{
	unsigned int	joint_index[4];
	XMFLOAT4		weight;

	tJointInfluence() : weight(0.0f, 0.0f, 0.0f, 0.0f)
	{
		joint_index[0] = 0;
		joint_index[1] = 0;
		joint_index[2] = 0;
		joint_index[3] = 0;
	}
};

class CAnimation
{
	std::string m_sAnimTag;
	float m_fAnimTime;

	std::vector<tKeyFrame *> m_Frames;

public:
	tKeyFrame * m_pBindPose;

	CAnimation();
	~CAnimation();

	void ClearFrames();

	std::vector<tKeyFrame *> GetFrames() const;
	tKeyFrame * GetFrame(int index) const;
	void AddFrames(tKeyFrame * frames);

	float GetAnimTime() const;
	void SetAnimTime(float time);

	std::string GetAnimTag() const;
	void SetAnimTag(std::string tag);

};

