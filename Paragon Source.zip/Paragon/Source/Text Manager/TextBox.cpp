#include "../Application/stdafx.h"

#include "TextBox.h"
#include "Font.h"
#include "Symbol.h"

using namespace DirectX;

TEXT_COLOR::TEXT_COLOR( ) :
glyphColor(1,1,1,1),
outlineColor(0,0,0,1)
{
}


TextBox::TextBox( ) :
m_bActive(true),
m_Position(0,0),
m_Text(L""),
m_Scale(1)
{
}


TextBox::~TextBox( )
{
}



void TextBox::SetPosition( float posX, float posY )
{
	m_Position.x = posX;
	m_Position.y = posY;
}

void TextBox::SetScale( float scale )
{
	m_Scale = scale;
}

/*
void TextBox::SetSize( float width, float height )
{
	m_Size.x = width;
	m_Size.y = height;
}
*/
void TextBox::SetText( const std::wstring& text )
{
	m_Text = text;

	if (text.size() > MAX_CHARACTERS)
	{
		PrintConsole( "Max number of characters surpassed");
		SetText(L"---");
		return;
	}

	XMFLOAT2 cursor = m_Position;
	for (size_t i = 0; i < text.size(); i++)
	{
		wchar_t ch = text[i];
		if( m_TextAlignment == TAL_RIGHT )
			ch = text[ text.size() - 1 - i ];

		if( text[i] == L'\n' ) 
		{
			cursor.y += m_pFont->GetLineHeight(); 
			cursor.x = m_Position.x;		
		}
		else
		{
			Symbol* symbol = m_pFont->GetSymbol(ch);
			if( !symbol ) continue;

			XMFLOAT2 imgSize = m_pFont->GetImageSize();
			
			XMFLOAT2 screenSize(800,600);
			XMFLOAT2 scale;
			scale.x = 2.0f*m_Scale/screenSize.x;
			scale.y = 2.0f*m_Scale/screenSize.y;


			XMFLOAT2 size;
			size.x = scale.x*symbol->size.x;
			size.y = scale.y*symbol->size.y;
			XMFLOAT2 posOffset;
			posOffset.x =  scale.x*symbol->offset.x;
			posOffset.y = -scale.y*symbol->offset.y;
			float posAdvance = scale.x*symbol->advance;
			
			if( m_TextAlignment == TAL_RIGHT )
				cursor.x -= posAdvance;

			m_TextVerts[i*2].pos.x = cursor.x + posOffset.x;
			m_TextVerts[i*2].pos.y = cursor.y + posOffset.y;
			m_TextVerts[i*2].uv.x = symbol->position.x/imgSize.x;
			m_TextVerts[i*2].uv.y = symbol->position.y/imgSize.y;


			m_TextVerts[i*2+1].pos.x = cursor.x + posOffset.x + size.x;
			m_TextVerts[i*2+1].pos.y = cursor.y + posOffset.y - size.y;
			m_TextVerts[i*2+1].uv.x = (symbol->position.x + symbol->size.x)/imgSize.x;
			m_TextVerts[i*2+1].uv.y = (symbol->position.y + symbol->size.y)/imgSize.y;


			if( m_TextAlignment == TAL_LEFT )
				cursor.x += posAdvance;
		}
	}
}


void TextBox::SetFont( Font* pFont )
{
	m_pFont = pFont;
}

void TextBox::SetTextColor( const DirectX::XMFLOAT4& glyphColor, const DirectX::XMFLOAT4& outlineColor )
{
	m_TextColor.glyphColor = glyphColor;
	m_TextColor.outlineColor = outlineColor;
}

void TextBox::SetIsActive(bool active)
{
	this->m_bActive = active;
}

void TextBox::SetTextAlignment(TextAlignment textAlignment)
{
	m_TextAlignment = textAlignment;
}


bool TextBox::IsActive( ) const						{ return m_bActive;}
DirectX::XMFLOAT2	TextBox::GetPosition( )	const	{ return m_Position; }
//DirectX::XMFLOAT2	TextBox::GetSize( )				{ return m_Size; }
const std::wstring& TextBox::GetText( ) const		{ return m_Text; }
Font*			TextBox::GetFont( )	const			{ return m_pFont; }
float				TextBox::GetScale( ) const		{ return m_Scale; }

const TEXT_VERT*	TextBox::GetTextVerts( ) const	{ return m_TextVerts; }

const TEXT_COLOR* TextBox::GetTextColor( ) const	{ return &m_TextColor; }

