#include "../Application/stdafx.h"

#include "TextManager.h"

#include "Font.h"
#include "TextBox.h"

#include "../Application/CoreFacade.h"
#include "../Asset Manager/AssetManager.h"


//#define FONT_PATH L"Fonts/"

using namespace std;

#define MAX_CHARACTER_AMOUNT 10

TextManager::TextManager( )
{

}

TextManager::~TextManager( )
{

}

Font* TextManager::GetFont( std::string name ) const
{
	return m_FontMap.at(name);
}


void TextManager::Initialize( CoreFacade* pCoreFacade )
{
}


void TextManager::Shutdown( CoreFacade* pCoreFacade )
{
	UnloadFonts();
}

void TextManager::Update( CoreFacade* pCoreFacade )
{
}



void TextManager::AddTextBox( TextBox* pTextBox )
{
	m_TextBoxes.push_back(pTextBox);
}


void TextManager::LoadFont(CoreFacade* pCoreFacade, string xmlName)
{
	Font* pFont = new Font;
	pFont->LoadFont( pCoreFacade, xmlName );
	
	if (m_FontMap[xmlName] == nullptr)
		m_FontMap[xmlName] = pFont;
}

void TextManager::UnloadFonts()
{
	for ( auto it = m_FontMap.begin( ); it != m_FontMap.end( ); it++ )
	{
		Font* pFont = it->second;
		pFont->ShutDown();
		SAFE_DELETE(pFont);
	}
	
	m_FontMap.clear();
}



