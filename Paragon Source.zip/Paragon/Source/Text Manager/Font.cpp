#include "../Application/stdafx.h"

#include "Font.h"

#include "Symbol.h"

#define ReleaseCOM(x) { if(x){ x->Release(); x = 0; } }

#include "../Application/CoreFacade.h"
#include "../Asset Manager/AssetManager.h"
using namespace std;
using namespace DirectX;

#define TEXTURE_PATH "../Assets/Textures/"


void Font::ShutDown()
{
	//ReleaseCOM(m_pOutlineTexture);
	//ReleaseCOM(m_pGlyphTexture);
	if(symbols)
		delete [] symbols;
	symbols = NULL;

	m_pGlyphTexture = nullptr;
	m_pOutlineTexture = nullptr;
}
ID3D11ShaderResourceView* Font::GetGlyphTexture( ) const
{
	return m_pGlyphTexture;
}

ID3D11ShaderResourceView* Font::GetOutlineTexture( ) const
{
	return m_pOutlineTexture;
}

void Font::SetGlyphTexture( ID3D11ShaderResourceView* pTexture )
{
	m_pGlyphTexture = pTexture;
}
void Font::SetOutlineTexture( ID3D11ShaderResourceView* pTexture )
{
	m_pOutlineTexture = pTexture;
}

string Font::GetTag( ) const
{
	return m_Tag;
}

void Font::SetTag( std::string tag )
{
	m_Tag = tag;
}

float Font::GetLineHeight( ) const
{
	return lineHeight;
}

DirectX::XMFLOAT2 Font::GetImageSize( ) const
{
	return m_imageSize;
}


Symbol* Font::GetSymbol( wchar_t ch ) const
{
	for ( size_t iSym = 0; iSym < numSymbols; iSym++ )
	{
		if ( symbols[iSym].id == ch )
			return &symbols[iSym];
	}
	
	return NULL;
}



void Font::RenderSymbol( wchar_t ch, DirectX::XMFLOAT2& position )
{
	size_t iSym;
	for ( iSym = 0; iSym < numSymbols; iSym++ )
		if ( symbols[iSym].id == ch )
			break;

	if ( iSym == numSymbols )
		return;

	position.x += symbols[iSym].advance;
}


void Font::LoadFont( CoreFacade* pCoreFacade, string xmlName )
{
	string xmlPath = XML_PATH + (string)"Fonts/" + xmlName + ".fnt";
	TiXmlDocument document( xmlPath.c_str( ) );

	bool result = document.LoadFile( );
	if ( !result ) OutputDebugString( L"Failure to Load Font file." );


	TiXmlElement* pFont = document.FirstChildElement( "font" );
	if ( !pFont ) OutputDebugString( L"Failure to Find \"font\" root." );

	FontToLoad fontLoader;
	fontLoader.pFont = this;

	TiXmlElement* pInfo = pFont->FirstChildElement( "info" );
	if ( !pInfo ) OutputDebugString( L"Failure to Find \"info\" element." );

	TiXmlElement* pCommon = pFont->FirstChildElement( "common" );
	if ( !pCommon ) OutputDebugString( L"Failure to Find \"common\" element." );

	TiXmlElement* pPage = pFont->FirstChildElement( "pages" )->FirstChildElement("page");
	if ( !pPage ) OutputDebugString( L"Failure to Find \"page\" element." );

	fontLoader.glyphTextureFilePath = TEXTURE_PATH + (string) pPage->Attribute( "file" );
	fontLoader.pFont->SetTag( xmlName );
	pCoreFacade->LoadFontAsset( &fontLoader );


	m_imageSize.x = (float) atoi( pCommon->Attribute( "scaleW" ) );
	m_imageSize.y = (float) atoi( pCommon->Attribute( "scaleH" ) );
	lineHeight = (float)atoi( pCommon->Attribute( "lineHeight" ) );

	TiXmlElement* pChars = pFont->FirstChildElement( "chars" );
	if ( !pChars ) OutputDebugString( L"Failure to Find \"chars\" element." );


	numSymbols = atoi( pChars->Attribute( "count" ) );
	symbols = new Symbol[numSymbols];

	XMFLOAT2 position, size;

	TiXmlHandle hchars = TiXmlHandle( pChars );
	for ( size_t i = 0; i < numSymbols; i++ )
	{
		TiXmlElement* pChar = hchars.ChildElement( "char", i ).Element( );
		symbols[i].id = (wchar_t) atoi( pChar->Attribute( "id" ) );
		symbols[i].position.x = (float)atoi( pChar->Attribute( "x" ) ) ;
		symbols[i].position.y =	(float) atoi( pChar->Attribute( "y" ) ) ;
		symbols[i].size.x =		(float)atoi( pChar->Attribute( "width" ) ) ;
		symbols[i].size.y =		(float)atoi( pChar->Attribute( "height" ) ) ;

		symbols[i].offset.x =	(float) atoi( pChar->Attribute( "xoffset" ) ) ;
		symbols[i].offset.y =	(float)atoi( pChar->Attribute( "yoffset" ) ) ;
		symbols[i].advance =	(float)atoi( pChar->Attribute( "xadvance" ) ) ;
	}


}