#include "../Application/stdafx.h"

#pragma once

struct Symbol;
struct ID3D11ShaderResourceView;
class CoreFacade;

#define XML_PATH "../Assets/XML/"

class Font
{
	std::string m_Tag;
	size_t numSymbols;
	Symbol* symbols;
	float lineHeight;

	DirectX::XMFLOAT2 m_imageSize;
	
	ID3D11ShaderResourceView * m_pGlyphTexture;
	ID3D11ShaderResourceView * m_pOutlineTexture;
	
	public:
		void ShutDown();

	std::string GetTag() const;
	void SetTag( std::string tag );

	float GetLineHeight() const;
	DirectX::XMFLOAT2 GetImageSize() const;
	Symbol* GetSymbol(wchar_t ch) const;
	ID3D11ShaderResourceView* GetGlyphTexture() const;
	ID3D11ShaderResourceView* GetOutlineTexture() const;

	void SetGlyphTexture( ID3D11ShaderResourceView* pTexture );
	void SetOutlineTexture( ID3D11ShaderResourceView* pTexture );


	void RenderSymbol(wchar_t ch, DirectX::XMFLOAT2& position);

	void LoadFont(CoreFacade* pCoreFacade, std::string xmlName);

};