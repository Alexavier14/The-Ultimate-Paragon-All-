#include "../Application/stdafx.h"

#pragma once

class Font;

enum TextAlignment { TAL_LEFT, TAL_RIGHT };

struct TEXT_VERT
{
	DirectX::XMFLOAT2 pos;
	DirectX::XMFLOAT2 uv;
};

struct TEXT_COLOR
{
	DirectX::XMFLOAT4 glyphColor;
	DirectX::XMFLOAT4 outlineColor;
	TEXT_COLOR();
};

class TextBox
{
	public:
	static const size_t MAX_CHARACTERS = 20;
	
	private:
	TextAlignment m_TextAlignment;

	bool m_bActive;

	//Clip-space coordinate of the top-left coordinate of the box
	DirectX::XMFLOAT2 m_Position;
	// Width and height of the box
	//DirectX::XMFLOAT2 m_Size;
	std::wstring m_Text;
	float m_Scale;

	Font* m_pFont;

	TEXT_COLOR m_TextColor;

	TEXT_VERT m_TextVerts[MAX_CHARACTERS*2];

	public:
	TextBox( );
	~TextBox( );

	bool IsActive() const;

	void SetPosition( float posX, float posY);
	//void SetSize( float width, float height );
	void SetFont( Font* pFont );
	void SetTextColor( 	const DirectX::XMFLOAT4& glyphColor, const DirectX::XMFLOAT4& outlineColor );
	void SetScale( float scale );
	// Use this function after the other properties are set for those properties to show, i.e. font, position, scale.
	void SetText( const std::wstring& text);
	void SetIsActive(bool active);
	void SetTextAlignment( TextAlignment textAlignment );

	DirectX::XMFLOAT2	GetPosition() const;
	//DirectX::XMFLOAT2	GetSize();
	const std::wstring& GetText() const;
	Font*			GetFont() const;
	float				GetScale() const;
	const TEXT_VERT*	GetTextVerts() const; 
	const TEXT_COLOR*	GetTextColor( ) const;


};

