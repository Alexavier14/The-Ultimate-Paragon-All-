#pragma once

#include <DirectXMath.h>

struct Symbol
{
	wchar_t id;
	DirectX::XMFLOAT2 position;
	DirectX::XMFLOAT2 size;
	DirectX::XMFLOAT2 offset;

	float advance;
};