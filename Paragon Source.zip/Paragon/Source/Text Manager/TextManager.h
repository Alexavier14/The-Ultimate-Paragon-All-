#include "../Application/stdafx.h"

#pragma once

#include "../Object Manager/HUDElement.h"

#include "Font.h"

class CoreFacade;
class TextBox;

//enum TextFormat { BOOK_BIG, BOOK_SMALL, NUM_FORMATS };


class TextManager
{

	std::map<std::string, Font*> m_FontMap;
	//std::vector<HUDElement> m_CharacterQuads;
	std::list<TextBox* > m_TextBoxes;

	public:
	TextManager();
	~TextManager();

	Font* GetFont( std::string name ) const;

	void Initialize( CoreFacade* pCoreFacade );
	void Shutdown( CoreFacade* pCoreFacade );
	void Update( CoreFacade* pCoreFacade );

	void LoadFont( CoreFacade* pCoreFacade, std::string xmlName);
	void UnloadFonts();

	void AddTextBox(TextBox* pTextBox);

};

