#pragma once

#include "Particle.h"
#include "EmitterData.h"
class CoreFacade;
class ParticleSystem;


class Emitter
{
	bool m_b3D;
	bool m_bActive;
	string m_Tag;
	ParticleSystem& m_ParticleSystem;

	cbEMITTER_DATA m_EmitterData;

	bool m_bSpawning;
	float m_SpawnTimer; // Whenever m_bSpawning is false, this timer is used and updated to spawn for a set time
	float m_SpawnRate;

	XMFLOAT3 m_Position;
	XMFLOAT3 m_PositionOffset;
	float m_PositionVariance;
	XMFLOAT3 m_VelocityAverage;
	float m_SpeedVariance;

	float m_StartAngleAverage;
	float m_StartAngleVariance;

	float m_AngularSpeedAverage;
	float m_AngularSpeedVariance;
	float m_Sprite_Sheet_Index;

	// TODO Integrate to xml
	bool m_SpawnOnPlane; 


	vector<Particle> m_Particles;
	//vector<XMFLOAT3> m_Velocities;

	float toSpawn;
	size_t spawnIndex;

public:

	GameObject * m_pParent; // This should not be here
	ID3D11ShaderResourceView *  m_pParticleTexture; // NOTE: Should not hold d3d11 classes

	Emitter(ParticleSystem* pParticleSystem);
	~Emitter();


	// Accessors
	
	bool Is3D() const;
	bool IsActive() const;
	const string& GetTag() const;
	bool IsSpawning() const;
	XMFLOAT3 GetPositionOffset() const;
	const vector<Particle> &GetParticles() const;
	cbEMITTER_DATA GetEmitterData() const;

	// Mutators

	void SetTag(const string tag);
	void Set3D(bool b3D);
	void SetActive(bool bActive);
	void SetSpawning( bool bSpawning );
	void SetParticleTexture( ID3D11ShaderResourceView * pParticleTexture );
	void SetColor( USHORT pivotIndex, const XMFLOAT4& color );
	void SetScale( USHORT pivotIndex, const XMFLOAT2& scale );
	void SetSpawnRate( float spawnRate ); 
	void SetLifeTime( float lifeTime );
	void SetPosition( const XMFLOAT3& position ); //Used by game Object to update position
	void SetPositionOffset( const XMFLOAT3& offset );
	void SetPositionVariance( float posVar );
	void SetVelocityAverage( const XMFLOAT3& velAvg );
	void SetSpeedVariance( float speedVar );
	void SetGravity( const XMFLOAT3& gravity );
	void SetStartAngleAverage( float angleAverage );
	void SetStartAngleVariance( float angleVariance );
	void SetAngularSpeedAverage( float angularSpeedAverage );
	void SetAngularSpeedVariance( float angularSpeedVariance );
	void SetEmitterSetting(UINT setting);
	void SetSpawnOnPlane(bool spawnOnPlane);
	void SetSpawnTimer(float spawnTime, bool autoreset = true); // if autoreset is false, ongoing timers are not altered.
	void SetSpriteSheetSizes(int row, int col);
	// Methods

	void Update();

	//This function spawns a set number of particles
	//Returns the last spawned particle
	size_t SpawnParticleSet(size_t num_of_particles);

	//Grab the Particles current Position.
	//The w component of the vector tells whether 
	//the particle is alive or not.
	//Dead Particle: w = -1;
	//Alive Particle: w = 1;
	XMFLOAT4 GetParticlePositions(size_t index);

	private:

	void SpawnParticle( size_t index );
};

