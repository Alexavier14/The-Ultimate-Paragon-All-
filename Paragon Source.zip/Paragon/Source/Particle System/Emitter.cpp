#include "../Application/stdafx.h"
#include "Emitter.h"

#include "../Application/CoreFacade.h"
#include "ParticleSystem.h"
#include "../Physics/Physics.h"
#include <assert.h>

using namespace Physics;



Emitter::Emitter(ParticleSystem* pParticleSystem) :
m_ParticleSystem(*pParticleSystem)
{
	m_Particles.resize(ParticleSystem::MAX_PARTICLES);
	//	m_Velocities.resize( MAX_PARTICLES );
	for (size_t i = 0; i < ParticleSystem::MAX_PARTICLES; i++)
		m_Particles[i].m_Lifetime = 0.0f;

	toSpawn = 0.0f;
	spawnIndex = 0;
	m_SpawnRate = 8.0f;
	m_bSpawning = true;
	m_SpawnTimer = 0;
	m_b3D = false;

	m_Position = XMFLOAT3(0, 0, 0);
	m_PositionOffset = XMFLOAT3(0, 0, 0);
	m_PositionVariance = 0.0f;

	m_VelocityAverage = XMFLOAT3(0, 0, 0);
	m_SpeedVariance = 1.0f;

	m_EmitterData.gravity = XMFLOAT3(0, -10.0f, 0);
	m_EmitterData.totalLifetime = 3.0f;
	m_EmitterData.start.color = XMFLOAT4(0.9f, 0.4f, 0.0f, 1.0f);
	m_EmitterData.end.color = XMFLOAT4(0.2f, 0.0f, 0.0f, 0.1f);
	m_EmitterData.Max_Col_Slots = 1.0f;
	m_EmitterData.Max_Row_Slots = 1.0f; 
	m_EmitterData.Current_Frame_Index = 1.0f;

	m_EmitterData.start.scale = XMFLOAT2(1.0f, 1.0f);
	m_EmitterData.end.scale = XMFLOAT2(1.0f, 1.0f);
	m_EmitterData.Particle_Setting = FALSE;

	m_StartAngleAverage = 0.0f;
	m_StartAngleVariance = 0.0f;

	m_AngularSpeedAverage = 0.0f;
	m_AngularSpeedVariance = 0.0f;

	m_SpawnOnPlane = false;

	m_pParent = nullptr;
}


Emitter::~Emitter()
{
}

#pragma region Accessors

bool Emitter::Is3D() const { return m_b3D; }

bool Emitter::IsActive() const { return m_bActive; }

const string& Emitter::GetTag() const { return m_Tag; }

bool Emitter::IsSpawning() const { return m_bSpawning; }

const vector<Particle> &Emitter::GetParticles() const
{
	return m_Particles;
}

cbEMITTER_DATA Emitter::GetEmitterData() const
{
	return m_EmitterData;
}

XMFLOAT3 Emitter::GetPositionOffset() const
{
	return this->m_PositionOffset;
}


#pragma endregion

#pragma region Mutators

void Emitter::Set3D(bool b3D)
{
	m_b3D = b3D;
}

void Emitter::SetActive(bool bActive)
{
	m_bActive = bActive;
}
void Emitter::SetSpawning(bool bSpawning)
{
	m_bSpawning = bSpawning;
}
void Emitter::SetTag(const string tag)
{
	m_Tag = tag;
}

void Emitter::SetParticleTexture(ID3D11ShaderResourceView * pParticleTexture)
{
	m_pParticleTexture = pParticleTexture;
}

void Emitter::SetColor(USHORT pivotIndex, const XMFLOAT4& color)
{
	switch (pivotIndex)
	{
	case 0: m_EmitterData.start.color = color; break;
	case 1: m_EmitterData.end.color = color; break;
	}
}

void Emitter::SetScale(USHORT pivotIndex, const XMFLOAT2& scale)
{
	switch (pivotIndex)
	{
	case 0: m_EmitterData.start.scale = scale; break;
	case 1: m_EmitterData.end.scale = scale; break;
	}
}

void Emitter::SetSpawnRate(float spawnRate)
{
	m_SpawnRate = spawnRate;
}

void Emitter::SetLifeTime(float lifeTime)
{
	m_EmitterData.totalLifetime = lifeTime;
}

void Emitter::SetPosition(const XMFLOAT3& position)
{
	m_Position = position;
}

void Emitter::SetPositionOffset(const XMFLOAT3& offset)
{
	m_PositionOffset = offset;
}

void Emitter::SetPositionVariance(float posVar)
{
	m_PositionVariance = posVar;
}

void Emitter::SetVelocityAverage(const XMFLOAT3& velAvg)
{
	m_VelocityAverage = velAvg;
}

void Emitter::SetSpeedVariance(float speedVar)
{
	m_SpeedVariance = speedVar;
}

void Emitter::SetGravity(const XMFLOAT3& gravity)
{
	m_EmitterData.gravity = gravity;
}

void Emitter::SetStartAngleAverage(float angleAverage)
{
	m_StartAngleAverage = angleAverage;
}

void Emitter::SetStartAngleVariance(float angleVariance)
{
	m_StartAngleVariance = angleVariance;
}

void Emitter::SetAngularSpeedAverage(float angularSpeedAverage)
{
	m_AngularSpeedAverage = angularSpeedAverage;
}

void Emitter::SetAngularSpeedVariance(float angularSpeedVariance)
{
	m_AngularSpeedVariance = angularSpeedVariance;
}

void Emitter::SetEmitterSetting(UINT setting)
{
	m_EmitterData.Particle_Setting = setting;
}
void Emitter::SetSpawnOnPlane(bool spawnOnPlane)
{
	m_SpawnOnPlane = spawnOnPlane;
}
void Emitter::SetSpawnTimer(float spawnTime, bool autoreset)
{
	if(!(!autoreset && m_SpawnTimer > 0))
		m_SpawnTimer = spawnTime;
}
#pragma endregion

#pragma region Methods

void Emitter::Update()
{
	float dt = TimeManager::GetTimeDelta();

	m_SpawnTimer = max(0, m_SpawnTimer - dt);
	if (m_bSpawning || m_SpawnTimer > 0)
	{
		toSpawn += m_SpawnRate*dt;

		size_t spawnAmount = (size_t)floorf(toSpawn);
		for (size_t i = 0; i < spawnAmount; i++)
		{
			SpawnParticle(spawnIndex);
			spawnIndex = (spawnIndex + 1) % m_ParticleSystem.PARTICLE_DENSITY;
		}
		toSpawn -= (float)spawnAmount;
	}

	for (size_t i = 0; i < m_ParticleSystem.PARTICLE_DENSITY; i++)
	{
		Particle& particle = m_Particles[i];
		particle.m_Lifetime -= dt;
		if (particle.m_Lifetime < 0)
		{
			particle.m_Lifetime = 0;
			continue;
		}
	}
}

void Emitter::SpawnParticle(size_t index)
{

	XMVECTOR StartPos = XMLoadFloat3(&m_Position);
	StartPos += XMLoadFloat3(&m_PositionOffset);
	if (m_SpawnOnPlane)//Change to reflect flag settings
		StartPos += XMCVector2SwizzleXZ(XMCRandomUnitVector2()) * UnitRand() * m_PositionVariance;
	else
		StartPos += XMCRandomUnitVector3() * UnitRand() * m_PositionVariance;
	XMStoreFloat3(&m_Particles[index].m_StartPos, StartPos);

	XMVECTOR StartVel = XMLoadFloat3(&m_VelocityAverage);
	StartVel += XMLoadFloat3(&XMFLOAT3(SignedUnitRand(), SignedUnitRand(), SignedUnitRand())) * m_SpeedVariance;
	XMStoreFloat3(&m_Particles[index].m_StartVel, StartVel);

	m_Particles[index].m_StartAngle = m_StartAngleAverage + SignedUnitRand()*m_StartAngleVariance;
	m_Particles[index].m_AngularSpeed = m_AngularSpeedAverage + SignedUnitRand()*m_AngularSpeedVariance;

	m_Particles[index].m_Lifetime = m_EmitterData.totalLifetime;

	//Solve Time of Impact when spawning if colliding
	if (m_EmitterData.Particle_Setting == 1)//Change to reflect flag settings
	{
		float a = m_EmitterData.gravity.y;
		float b = m_Particles[index].m_StartVel.y;
		float c = m_Particles[index].m_StartPos.y;

		float square_value = b * b - 4 * a * 0.5f* c;
		square_value = sqrtf(square_value);

		float quadratic_value1 = (-b + square_value) / (2.0f * a * 0.5f);
		float quadratic_value2 = (-b - square_value) / (2.0f * a * 0.5f);

		m_Particles[index].m_TOI = max(quadratic_value1, quadratic_value2);
	}
	else if(m_EmitterData.Particle_Setting == 0)
		m_Particles[index].m_TOI = 0.0f;
	else if (m_EmitterData.Particle_Setting == 2)
	{
		m_EmitterData.gravity = m_Position;
		m_Particles[index].m_StartPos = XMCStoreFloat3( XMCRandomUnitVector3()*m_PositionVariance );
	}	

}

size_t Emitter::SpawnParticleSet(size_t num_of_particles)
{
	for (size_t i = 0; i < num_of_particles; i++)
	{
		SpawnParticle(spawnIndex);
		spawnIndex = (spawnIndex + 1) % m_ParticleSystem.PARTICLE_DENSITY;
	}

	return spawnIndex;
}
void Emitter::SetSpriteSheetSizes(int row, int col)
{
	m_EmitterData.Max_Row_Slots = (float)row;
	m_EmitterData.Max_Col_Slots = (float)col;
}

XMFLOAT4 Emitter::GetParticlePositions(size_t index)
{


	if (m_Particles[index].m_Lifetime <= 0.0f)
		return{ 0.0f, 0.0f, 0.0f, -1.0f };

	XMFLOAT4 curr_Positions;

	XMVECTOR startPos, velocity, finalPos;
	XMVECTOR gravity = XMLoadFloat3(&m_EmitterData.gravity) * 0.5f;

	//Get delta time
	float totalTime = m_EmitterData.totalLifetime - m_Particles[index].m_Lifetime; //total time
	float toi = m_Particles[index].m_TOI; //Time of Impact


	//Get Start Position
	startPos = XMLoadFloat3(&m_Particles[index].m_StartPos);
	//Get the velocity
	velocity = XMLoadFloat3(&m_Particles[index].m_StartVel);



	if (m_EmitterData.Particle_Setting == TRUE //Need to change to reflect flag settings
		&& totalTime >= toi && m_Particles[index].m_StartAngle == 0.0f)
	{
		finalPos = startPos + velocity * toi + gravity * toi * toi;
		finalPos.m128_f32[3] = 2.0f;
		m_Particles[index].m_StartAngle = XM_2PI;
	}
	else
	{
		finalPos = startPos + velocity*totalTime + gravity * totalTime * totalTime;
		finalPos.m128_f32[3] = 1.0f;
	}

	XMStoreFloat4(&curr_Positions, finalPos);


	return curr_Positions;
}
#pragma endregion
