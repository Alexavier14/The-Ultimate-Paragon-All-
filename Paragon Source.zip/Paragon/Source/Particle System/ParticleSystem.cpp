#include "../Application/stdafx.h"
#include "ParticleSystem.h"
#include "../Application/CoreFacade.h"
#include "../Asset Manager/AssetManager.h"



#define ReleaseCOM(x) { if(x){ x->Release(); x = 0; } }

#define XML_EMITTER_PATH "../Assets/XML/Emitters/"
#define TEXTURE_PATH "../Assets/Textures/"

#define MAX_EMITTERS 1000

ParticleSystem::ParticleSystem()
{
	PARTICLE_DENSITY = 200;
}


ParticleSystem::~ParticleSystem()
{
}

void ParticleSystem::Initialize(CoreFacade * pCoreFacade)
{
	m_Emitters.reserve(MAX_EMITTERS);
}

void ParticleSystem::Shutdown()
{
	m_Emitters.clear();
}

vector<Emitter>& ParticleSystem::GetEmitters()
{
	return m_Emitters;
}


void ParticleSystem::Update()
{
	for (size_t i = 0; i < m_Emitters.size(); i++)
	{
		m_Emitters[i].Update();
	}
}



Emitter* LoadError(string emitterName, Emitter*pEmitter)
{
	string eMessage = "Fail to load Emitter - " + emitterName+ ".xml";
	wstring wEMessage = std::wstring(eMessage.begin(), eMessage.end());
	const wchar_t* widecstr = wEMessage.c_str();

	MessageBox(NULL, widecstr, L"ERROR", NULL);
	return pEmitter;
}
Emitter* ParticleSystem::LoadEmitter(string filename, GameObject* pHolder, CoreFacade* pCoreFacade)
{
	if (m_Emitters.size() >= MAX_EMITTERS)
		return NULL;
	
	m_Emitters.push_back(Emitter(this));
	Emitter* pEmitter = &m_Emitters.back();
	pEmitter->SetTag(pHolder->GetTag() + " : " + filename);

	EmitterToLoad emitterLoader;
	emitterLoader.pEmitter = pEmitter;

	string xmlPath = XML_EMITTER_PATH + filename + ".xml";
	TiXmlDocument document( xmlPath.c_str( ) );

	bool result = document.LoadFile( );
	if(!result) return LoadError(filename,pEmitter);

	TiXmlElement* pEmitterRoot = document.FirstChildElement( "Emitter" );
	if(!pEmitterRoot) return LoadError(filename,pEmitter);
	
	float SpawnRate;
	XMFLOAT3 PositionOffset;
	float PositionVariance;
	float StartAngleAverage; 
	float StartAngleVariance;
	XMFLOAT3 VelocityAverage;
	float SpeedVariance;
	float AngularSpeedAverage;
	float AngularSpeedVariance;
	XMFLOAT3 Gravity;
	float LifeTime;
	float RowCount; 
	float ColCount;

	TiXmlElement* pEmitterAttributes = pEmitterRoot->FirstChildElement( "EmitterAttributes" );
	emitterLoader.textureFilePath = string(TEXTURE_PATH) + pEmitterAttributes->FirstChildElement( "Texture" )->Attribute("v");
	RowCount = (float)atof(pEmitterAttributes->FirstChildElement("SpriteSheetRC")->Attribute("x"));
	ColCount = (float)atof(pEmitterAttributes->FirstChildElement("SpriteSheetRC")->Attribute("y"));
	SpawnRate = (float) atof( pEmitterAttributes->FirstChildElement("SpawnRate")->Attribute("v") );
	PositionOffset.x = (float) atof( pEmitterAttributes->FirstChildElement("PositionOffset")->Attribute("x") );
	PositionOffset.y = (float) atof( pEmitterAttributes->FirstChildElement("PositionOffset")->Attribute("y") );
	PositionOffset.z = (float) atof( pEmitterAttributes->FirstChildElement("PositionOffset")->Attribute("z") );
	PositionVariance = (float) atof( pEmitterAttributes->FirstChildElement("PositionVariance")->Attribute("v") );
	StartAngleAverage = (float) atof( pEmitterAttributes->FirstChildElement("StartAngleAverage")->Attribute("v") );
	StartAngleVariance = (float) atof( pEmitterAttributes->FirstChildElement("StartAngleVariance")->Attribute("v") );
	VelocityAverage.x = (float) atof( pEmitterAttributes->FirstChildElement("VelocityAverage")->Attribute("x") );
	VelocityAverage.y = (float) atof( pEmitterAttributes->FirstChildElement("VelocityAverage")->Attribute("y") );
	VelocityAverage.z = (float) atof( pEmitterAttributes->FirstChildElement("VelocityAverage")->Attribute("z") );
	SpeedVariance = (float) atof( pEmitterAttributes->FirstChildElement("SpeedVariance")->Attribute("v") );
	AngularSpeedAverage = (float) atof( pEmitterAttributes->FirstChildElement("AngularSpeedAverage")->Attribute("v") );
	AngularSpeedVariance = (float) atof( pEmitterAttributes->FirstChildElement("AngularSpeedVariance")->Attribute("v") );
	Gravity.x = (float) atof( pEmitterAttributes->FirstChildElement("Gravity")->Attribute("x") );
	Gravity.y = (float) atof( pEmitterAttributes->FirstChildElement("Gravity")->Attribute("y") );
	Gravity.z = (float) atof( pEmitterAttributes->FirstChildElement("Gravity")->Attribute("z") );
	LifeTime = (float) atof(pEmitterAttributes->FirstChildElement("LifeTime")->Attribute("v"));

	pEmitter->SetSpawnRate(SpawnRate);
	pEmitter->SetPositionOffset(PositionOffset);
	pEmitter->SetPositionVariance(PositionVariance);
	pEmitter->SetStartAngleAverage(StartAngleAverage);
	pEmitter->SetStartAngleVariance(StartAngleVariance);
	pEmitter->SetVelocityAverage(VelocityAverage);
	pEmitter->SetSpeedVariance(SpeedVariance);
	pEmitter->SetAngularSpeedAverage(AngularSpeedAverage);
	pEmitter->SetAngularSpeedVariance(AngularSpeedVariance);
	pEmitter->SetGravity(Gravity);
	pEmitter->SetLifeTime(LifeTime);
	pEmitter->SetSpriteSheetSizes((int)RowCount,(int)ColCount);

	TiXmlElement* pPivots = pEmitterRoot->FirstChildElement( "Pivots" );
	size_t pivotAmount = atoi( pPivots->Attribute("amount") );
	TiXmlHandle hPivots = (TiXmlHandle)pPivots;
	for (size_t i = 0; i < pivotAmount; i++)
	{
		TiXmlElement* pPivot = hPivots.ChildElement( "Pivot", i ).Element();

		XMFLOAT4 Color;
		XMFLOAT2 Scale;

 		Color.x = (float) atof( pPivot->FirstChildElement("Color")->Attribute("r") );
		Color.y = (float) atof( pPivot->FirstChildElement("Color")->Attribute("g") );
		Color.z = (float) atof( pPivot->FirstChildElement("Color")->Attribute("b") );
		Color.w = (float) atof( pPivot->FirstChildElement("Color")->Attribute("a") );
		Scale.x = (float) atof( pPivot->FirstChildElement("Scale")->Attribute("x") );
		Scale.y = (float) atof( pPivot->FirstChildElement("Scale")->Attribute("y") );

		pEmitter->SetColor(i, Color);
		pEmitter->SetScale(i, Scale);

	}

	pCoreFacade->LoadEmitterAsset(&emitterLoader);

	GameObject * pEmitterGameObject = new GameObject();
	pEmitterGameObject->SetActive(true);
	pEmitterGameObject->SetTypeID(eEMITTER);
	pEmitterGameObject->SetTag(pHolder->GetTag() + " (Object): " + filename);
	pEmitterGameObject->SetEmitterComponent(pEmitter);
	pCoreFacade->GetObjectManager()->AddGameObject(pEmitterGameObject);
	pHolder->AddEmitterChildObject(pEmitterGameObject);

	return pEmitter;
}