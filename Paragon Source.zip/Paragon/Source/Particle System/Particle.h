#include "../Application/stdafx.h"

#pragma once

struct Particle
{
	DirectX::XMFLOAT3 m_StartPos;
	DirectX::XMFLOAT3 m_StartVel;
	float m_StartAngle;
	float m_AngularSpeed;
	float m_Lifetime;
	float m_TOI; // Time of Impact
};

