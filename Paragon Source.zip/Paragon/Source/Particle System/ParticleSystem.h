#pragma once

#include "Emitter.h"

class CoreFacade;

//enum EmitterType { ET_CLOUD, ET_FLASH,  ET_AMOUNT };
enum EmitterType { ET_FLASH, ET_CLOUD,  ET_STAR, ET_DEBRIS, ET_BOULDERS, ET_AMOUNT };

class ParticleSystem
{
	vector<Emitter> m_Emitters;

	public:
	static const size_t MAX_PARTICLES = 200;
	unsigned int PARTICLE_DENSITY;


	ParticleSystem();
	~ParticleSystem();

	void Initialize( CoreFacade * pCoreFacade );
	void Shutdown( );

	void Update();

	Emitter* LoadEmitter(string filename, GameObject* pHolder, CoreFacade* pCoreFacade);
	
	vector<Emitter>& GetEmitters();
};

