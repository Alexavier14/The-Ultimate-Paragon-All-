#ifdef __cplusplus

#pragma once
typedef float			FLOAT;
typedef XMFLOAT2		FLOAT2;
typedef XMFLOAT3		FLOAT3;
typedef XMFLOAT4		FLOAT4;
typedef XMFLOAT4X4		FLOAT4X4;
typedef unsigned int	UINT;
#include <DirectXMath.h>
using namespace DirectX;

#define _POSITION
#define _COLOR
#define _TEXCOORD
#define _NORMAL

#else

typedef float			FLOAT;
typedef float2			FLOAT2;
typedef float3			FLOAT3;
typedef float4			FLOAT4;
typedef float4x4		FLOAT4X4;
typedef uint			UINT;

#define _POSITION :POSITION
#define _COLOR :COLOR
#define _TEXCOORD :TEXCOORD
#define _NORMAL :NORMAL

#endif


struct EmitterPivot
{
	FLOAT4	color;
	FLOAT2 scale;
	FLOAT2 padding;
};

struct cbEMITTER_DATA 
{
	//vector<Pivot> m_Pivots;
	EmitterPivot start;
	EmitterPivot end;
	FLOAT3 gravity;
	FLOAT totalLifetime;
	UINT Particle_Setting;
	FLOAT Max_Row_Slots;
	FLOAT Max_Col_Slots;
	FLOAT Current_Frame_Index;
	//FLOAT3 padding;
};

