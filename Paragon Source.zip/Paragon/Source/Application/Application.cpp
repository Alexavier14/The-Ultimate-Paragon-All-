#include "../Application/stdafx.h"

#include "Application.h"
#include "../State Manager/GameStateMachine.h"
#include "../Util/Util.h"

Application::Application(){}
Application::~Application(){}

void Application::Initialize(HWND hWnd, HINSTANCE hInstance, int nWidth, int nHeight, bool bIsWindowed)
{
	//Set to running
	IsRunning = true;

	cStateMachine = new GameStateMachine;
	cStateMachine->Initialize(hWnd, hInstance, nWidth, nHeight, bIsWindowed);
	appTime.Initialize();
}

void Application::Shutdown()
{
	ShutDownTriggered = true;
	//Clean up the state machine if there is a state machine
	if (cStateMachine != nullptr)
	{
		cStateMachine->Shutdown();
		delete cStateMachine;
	}

	appTime.Shutdown();
}

void Application::Update()
{
	appTime.Update();

	cStateMachine->Update();
}

void Application::GetInput( RAWINPUT rawInput )
{
	if( cStateMachine != nullptr )
		cStateMachine->GetInput( rawInput );
}
