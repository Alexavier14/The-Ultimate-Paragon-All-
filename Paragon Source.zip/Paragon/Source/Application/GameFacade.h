#pragma once

class AISystem;
class PhysicsSystem;
class EventSystem;
class AssetManager;
class ParticleSystem;
class EventSystem;
class NavMesh;

class CoreFacade;
#include "../Physics/CollisionShape.h"
#include "../Particle System/ParticleSystem.h"

namespace Physics
{
	class Circle;
	class OrientedBox;
	class Segment;
	class Cone;
}

class GameFacade
{
	//AssetManager	* m_AssetManager;
	PhysicsSystem	* m_PhysicsSystem;
	AISystem		* m_AISystem;
	ParticleSystem	* m_ParticleSystem;
	EventSystem		* m_EventSystem;
	NavMesh			* m_NavMesh;

public:
	GameFacade();
	~GameFacade();

	bool Initialize(CoreFacade * m_Facade);
	void Shutdown();

	void PostInitialize(CoreFacade * m_Facade); // Sceond part of initialization after game objects have been loaded by the level manager
	void Update();

	// --- Physics System Function ---
	Physics::Circle* MakeCircleShape( Physics::ResolutionType resolutionType );
	Physics::OrientedBox* MakeOBBShape( Physics::ResolutionType resolutionType );
	Physics::Segment* MakeSegmentShape( Physics::ResolutionType resolutionType );
	Physics::Cone* MakeConeShape(Physics::ResolutionType resolutionType, float angle_in_degrees, float radius);
	PhysicsComponent* MakePhysicsCompoment( GameObject* pHolder );

	// --- Particle System Functions ---

	Emitter* LoadEmitter(string filename, GameObject* pHolder, CoreFacade* pCoreFacade);


	// -----------------
	// --- Accessors ---
	// -----------------
	PhysicsSystem & GetPhysicsSystem();
	ParticleSystem & GetParticleSystem();
	EventSystem & GetEventSystem();
	NavMesh* GetNavMesh();
};

