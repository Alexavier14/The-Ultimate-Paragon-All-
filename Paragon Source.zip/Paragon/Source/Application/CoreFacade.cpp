#include "../Application/stdafx.h"
#include "CoreFacade.h"
//#include "../Renderer/Renderer.h"
#include "../Renderer/RenderController.h"
#include "../Util/TimeManager.h"
#include "../Animation System/AnimationSystem.h"
#include "../Sound/SoundManager.h"
#include "../Input Manager/InputManager.h"
#include "../Physics/Circle.h"
#include "../Physics/OrientedBox.h"
#include "../Physics/Segment.h"
#include "../Physics/Physics.h"
#include "../Event System/EventSystem.h"
#include "../Text Manager/TextManager.h"
#include "../Util/Util.h"
#include "GameFacade.h"
#include "../Particle System/ParticleSystem.h"
#include "../Object Manager/EventComponent.h"
#include "../Object Manager/PointLightComponent.h"
#include "../Object Manager/RendererComponent.h"
#include "../Object Manager/TrapComponent.h"
#include "../Event System/EventSystem.h"
#include "../State Manager/LoadingScreenState.h"
#include "../Level Manager/LevelManager.h"
#include "../AI System/NavMesh.h"

#include <ShlObj.h>


using namespace DirectX;
using namespace Physics;

CoreFacade::CoreFacade() :
m_AnimSystem(nullptr),
m_Render_Controller(nullptr),
m_SoundManager(nullptr),
m_AssetManager(nullptr),
m_InputManager(nullptr),
m_ObjectManager(nullptr),
m_GameFacade(nullptr),
m_nRooms(0)
{
	CurrentLevel = 1;
}
CoreFacade::~CoreFacade(){}

void CoreFacade::Initialize(HWND hWnd, HINSTANCE hInstance, int nWidth, int nHeight, bool bIsWindowed)
{
	IsWindowed = bIsWindowed;
	GameInstance = hInstance;
	GameWindow = hWnd;

	SETWIDTH = nWidth;
	SETHEIGHT = nHeight;

	m_AnimSystem = new AnimationSystem();
	m_Render_Controller = new RenderController();
	m_SoundManager = new SoundManager();
	m_AssetManager = new AssetManager();
	m_InputManager = new InputManager();
	m_ObjectManager = new ObjectManager();
	m_TextManager = new TextManager();
	m_LevelManager = new LevelManager();
	m_GameFacade = nullptr;

	m_Render_Controller->Initialize(hWnd, hInstance, bIsWindowed);
	m_AssetManager->Initialize(hWnd, m_Render_Controller->GetDevice());
	m_AnimSystem->Initialize(this);
	m_SoundManager->Initialize();
	m_TextManager->Initialize(this);

	m_ToClearObject = false;

	m_isPaused = false;

	m_RubyUnlocked = false;

	m_nCurrentSelectedGeode = GS_NONE;

	m_fCameraTransitionTime = 0.0f;

	//Now Tell the systems the correct settings.
	InitializeSettings();

	srand((unsigned int)time(nullptr));

}
void CoreFacade::ClearLoadingCounts()
{
	m_AssetManager->AssetsLoadedCount = 0;
	m_AssetManager->AssetsUnloadedCount = 0;
}
void CoreFacade::Shutdown()
{
	SaveSettings();
	ClearAllObjects();

	m_AnimSystem->Shutdown();
	m_TextManager->Shutdown(this);
	m_SoundManager->Shutdown();

	this->DestroyGameFacade();

	m_AssetManager->Shutdown();
	m_Render_Controller->Shutdown();


	SAFE_DELETE(m_LevelManager);
	SAFE_DELETE(m_SoundManager);
	SAFE_DELETE(m_InputManager);
	SAFE_DELETE(m_GameFacade);
	SAFE_DELETE(m_ObjectManager);
	SAFE_DELETE(m_AnimSystem);
	SAFE_DELETE(m_TextManager);
	SAFE_DELETE(m_AssetManager);
	SAFE_DELETE(m_Render_Controller);

}
RenderController * CoreFacade::GetRenderController()
{
	return m_Render_Controller;
}
void CoreFacade::RenderCurrentSets(CoreFacade * CF)
{
	if (CF->m_Render_Controller != nullptr)
		CF->m_Render_Controller->Render();
}
void CoreFacade::Update()
{
	//Update the Elevators
	for (size_t i = 0; i < m_ObjectManager->GetElevators().size(); i++)
	{
		XMFLOAT3 Position = m_ObjectManager->GetElevators()[i]->GetObjectTranslation();
		if (Position.y > 0.0f)
		{
			Position.y -= 4.5f * TimeManager::GetTimeDelta();

			//Set Player Pos Here
			GameObject * Player = m_ObjectManager->GetPlayer();
			XMFLOAT3 PlayerPos = Player->GetObjectTranslation();
			PlayerPos.y = Position.y;
			Player->SetObjectTranslation(PlayerPos);
		}
		else
			Position.y = 0.0f;

		m_ObjectManager->GetElevators()[i]->SetObjectTranslation(Position);
	}

	FocusOnPlayer = true;
	float CameraMovementTotalTime = 2.0f;

	if (m_ToClearObject == false)
	{
		//Code for "cutscenes for doors"
		//Grabs doors and checks if the camera is focusing on them. 
		//By lerp-ing the distance between the player and the door, the camera slides to the door
		//The m_fCameraTransitionTime is the current time to transition between the two entities
		//The CameraMovementTotalTime represents the speed to move it.
		//The cutscene stops the player a moment after the event is done
		for (size_t i = 0; i < m_ObjectManager->GetDoors().size(); i++)
		{
			if (m_ObjectManager->GetDoors()[i]->IsFocused())
			{
				//XMVECTOR Initial = m_ObjectManager->GetPlayer()->GetObjectTranslationVec();
				////XMVECTOR Final = m_ObjectManager->GetDoors()[i]->GetObjectTranslationVec();
				//XMVECTOR Final = XMLoadFloat3(&m_GameFacade->GetEventSystem().DoorFirstPosition);

				//float TimeRatio = m_fCameraTransitionTime / CameraMovementTotalTime;

				//if (m_fCameraTransitionTime < CameraMovementTotalTime)
				//{
				//	XMVECTOR ResultingPosition = Initial + (Final - Initial) * TimeRatio;
				//	m_Render_Controller->UpdateMainCamera(XMCStoreFloat3(ResultingPosition));
				//}
				//else
				//	m_Render_Controller->UpdateMainCamera(m_GameFacade->GetEventSystem().DoorFirstPosition);
				FocusOnPlayer = false;
				m_ObjectManager->GetPlayer()->GetPlayerComponent()->StopPlayer(true, 0.1f);

				//m_Render_Controller->UpdateCinematicCamera(m_GameFacade->GetEventSystem().DoorFirstPosition);
				//m_fCameraTransitionTime += TimeManager::GetTimeDelta();
				break;
			}
		}

		for (size_t i = 0; i < m_ObjectManager->GetAllEnemies().size(); i++)
		{
			if (m_ObjectManager->GetAllEnemies()[i]->IsFocused())
			{
				//XMVECTOR Initial = m_ObjectManager->GetPlayer()->GetObjectTranslationVec();
				////XMVECTOR Final = m_ObjectManager->GetDoors()[i]->GetObjectTranslationVec();
				//XMVECTOR Final = XMLoadFloat3(&m_GameFacade->GetEventSystem().DoorFirstPosition);

				//float TimeRatio = m_fCameraTransitionTime / CameraMovementTotalTime;

				//if (m_fCameraTransitionTime < CameraMovementTotalTime)
				//{
				//	XMVECTOR ResultingPosition = Initial + (Final - Initial) * TimeRatio;
				//	m_Render_Controller->UpdateMainCamera(XMCStoreFloat3(ResultingPosition));
				//}
				//else
				//	m_Render_Controller->UpdateMainCamera(m_GameFacade->GetEventSystem().DoorFirstPosition);
				FocusOnPlayer = false;
				m_ObjectManager->GetPlayer()->GetPlayerComponent()->StopPlayer(true, 0.1f);

				//m_Render_Controller->UpdateCinematicCamera(m_GameFacade->GetEventSystem().DoorFirstPosition);
				//m_fCameraTransitionTime += TimeManager::GetTimeDelta();
				break;
			}
		}

		if (m_ObjectManager->GetPlayer() != nullptr && FocusOnPlayer)
		{
			bool Engaged = false;

			vector<XMFLOAT3> TargetsLocked;

			for (unsigned int i = 0; i < m_ObjectManager->GetAllEnemies().size(); i++)
			{
				if (m_ObjectManager->GetAllEnemies()[i]->GetAIData()->enemyState != AIData::EnPatrol
					&& m_ObjectManager->GetAllEnemies()[i]->GetAIData()->enemyState != AIData::EnScan)
				{
					if (m_ObjectManager->GetAllEnemies()[i]->GetAIData()->enemyState == AIData::EnDeath
						&& !m_ObjectManager->GetAllEnemies()[i]->GetActive())
						continue;

					XMVECTOR EnemyPos = m_ObjectManager->GetAllEnemies()[i]->GetObjectTranslationVec();
					XMVECTOR PlayerPos = m_ObjectManager->GetPlayer()->GetObjectTranslationVec();

					XMVECTOR PlToEn = EnemyPos - PlayerPos;
					float VecLength = XMCVector3Length(PlToEn);

					if (VecLength > 60.0f)
						continue;


					VecLength /= 2.0f;


					XMVECTOR ToDestination = XMVector3Normalize(PlToEn) * VecLength;
					XMVECTOR FinalDestination = PlayerPos + ToDestination;
					XMFLOAT3 DestinationFloat;
					XMStoreFloat3(&DestinationFloat, FinalDestination);
					TargetsLocked.push_back(DestinationFloat);

					Engaged = true;

				}


				XMVECTOR Inbetween = XMVectorZero();
				XMFLOAT3 InbetweenFloat = XMFLOAT3(0, 0, 0);
				XMStoreFloat3(&InbetweenFloat, Inbetween);

				for (unsigned int InterpIndex = 0; InterpIndex < TargetsLocked.size(); InterpIndex++)
				{
					Inbetween += XMLoadFloat3(&TargetsLocked[InterpIndex]);
				}

				if (TargetsLocked.size() > 1)
					Inbetween /= (float)TargetsLocked.size();

				XMStoreFloat3(&InbetweenFloat, Inbetween);


				if (Engaged)
					m_Render_Controller->UpdateMainCamera(InbetweenFloat);
			}

			if (!Engaged)
				m_Render_Controller->UpdateMainCamera(m_ObjectManager->GetPlayer()->GetObjectTranslation());

			m_fCameraTransitionTime = 0.0f;
		}

		RenderCurrentSets(this);
	}

	m_SoundManager->Update();

	if (!m_isPaused) // Should stop all updates while game is paused
	{
		m_AnimSystem->Update();
		m_ObjectManager->Update(this);
	}



	//Checks to see if a cutscene is playing. If it is, only update the event and nothing else
	if (m_GameFacade != nullptr && !m_isPaused && FocusOnPlayer)
	{
		m_GameFacade->Update();
	}
	else if (m_GameFacade != nullptr && !m_isPaused)
	{
		m_GameFacade->GetEventSystem().Update();
		m_GameFacade->GetParticleSystem().Update();
	}

	if (m_ToClearObject == true)
	{
		//Trying to prevent issues here

		m_ToClearObject = false;
	}
	//m_InputManager->ReleaseAllToggles();

	CheckSpecialCases();
}


bool CoreFacade::IsPaused() const { return m_isPaused; }
bool CoreFacade::GetRubyUnlock(void) { return m_RubyUnlocked; }
bool CoreFacade::GetDiamondUnlock(void) { return m_DiamondUnlocked; }
GeodeSelection CoreFacade::GetSelectedGeode(void) { return m_nCurrentSelectedGeode; }

void CoreFacade::SetIsPaused(bool pause) { m_isPaused = pause; }
void CoreFacade::SetRubyUnlock(bool _unlock) { m_RubyUnlocked = _unlock; }
void CoreFacade::SetDiamondUnlock(bool _unlock) { m_DiamondUnlocked = _unlock; }
void CoreFacade::SetSelectedGeode(GeodeSelection _geode) { m_nCurrentSelectedGeode = _geode; PrintConsole("Set Geode Called ", _geode); }

void CoreFacade::CreateGameFacade()
{
	m_GameFacade = new GameFacade();
	m_GameFacade->Initialize(this);
}

void CoreFacade::DestroyGameFacade()
{
	if (m_GameFacade != nullptr)
		m_GameFacade->Shutdown();
	SAFE_DELETE(m_GameFacade);
}

// --- Object Manager Functions ---

void CoreFacade::AddTextBox(TextBox* textBox)
{
	GameObject * TextBoxOBJ = new GameObject;
	TextBoxOBJ->SetTypeID(eTEXTBOX);
	TextBoxOBJ->SetTag("Text Box Filler Tag");
	TextBoxOBJ->SetActive(true);
	TextBoxOBJ->SetTextBoxComponent(textBox);
	m_ObjectManager->AddGameObject(TextBoxOBJ);
}

void CoreFacade::ClearAllObjects()
{
	m_ToClearObject = true;
	m_Render_Controller->ClearAllRenderSets();
	m_ObjectManager->ClearAllLoadedObjects();
	//m_AssetManager->ClearAllLoadedAssets();
}


// -- Physics System Functions ---

PhysicsSystem* CoreFacade::GetPhysicsSystem()
{
	if (m_GameFacade)
		return &m_GameFacade->GetPhysicsSystem();
	return NULL;
}

Circle * CoreFacade::MakeCircleCollisionShape(Physics::ResolutionType type)
{
	return m_GameFacade->MakeCircleShape(type);
}

// --- Renderer Functions ---

ID3D11Device* CoreFacade::GetRenderDevice()
{
	//return m_Renderer->GetRenderDevice();
	return m_Render_Controller->GetDevice();
}
void CoreFacade::CreateRenderSets()
{
	m_Render_Controller->CreateRenderSets(m_ObjectManager);
}

XMFLOAT4X4 CoreFacade::GetViewMatrix()
{
	//return m_Renderer->GetViewMatrix();
	return m_Render_Controller->GetViewMatrix();
}

XMFLOAT4X4 CoreFacade::GetProjectionMatrix()
{
	//return m_Renderer->GetProjectionMatrix();
	return m_Render_Controller->GetProjMatrix();
}

void CoreFacade::SetCinCameraPosition(XMFLOAT3 Waypoint, XMFLOAT3 DoorLocation)
{
	m_Render_Controller->UpdateCinematicCamera(Waypoint, DoorLocation);
	ConstantBuffers::GetInstance()->cbUpdate_Camera_Proj();
}

XMVECTOR CoreFacade::GetCameraPosition()
{
	return m_Render_Controller->GetCameraPosition();
}


// --- Asset Manager Functions ---

void CoreFacade::BeginAssetLoad()
{
	m_AssetManager->CreateFBXManager();
}

void CoreFacade::EndAssetLoad()
{
	m_AssetManager->DestroyFBXManager();
}

void CoreFacade::LoadAsset(ObjectToLoad* asset)
{
	m_AssetManager->LoadModel(asset);
}

void CoreFacade::LoadHudAsset(HUDtoLoad* hudAsset)
{
	m_AssetManager->LoadHudAsset(hudAsset);
}

void CoreFacade::LoadFontAsset(FontToLoad* fontAsset)
{
	m_AssetManager->LoadFontAsset(fontAsset);
}

void CoreFacade::LoadEmitterAsset(EmitterToLoad* emitterAsset)
{
	m_AssetManager->LoadEmitterAsset(emitterAsset);
}


AssetManager * CoreFacade::GetAssetManager() const
{
	return this->m_AssetManager;
}


// --- Input Manager Functions ---

void CoreFacade::GetInput(RAWINPUT rawInput)
{
	if (m_InputManager)
		m_InputManager->ReadInput(rawInput);
}

bool CoreFacade::IsPressing(ButtonID action) const
{
	return m_InputManager->IsPressing(action);
}

bool CoreFacade::IsToggled(ButtonID action, bool untoggle)
{
	return m_InputManager->IsToggled(action, untoggle);
}

bool CoreFacade::IsPressingKey(int keycode) const
{
	return m_InputManager->KeyboardIsPressing(keycode);
}

bool CoreFacade::IsToggledKey(int action, bool untoggle)
{
	return m_InputManager->KeyboardIsToggled(action, untoggle);
}

XMFLOAT2 CoreFacade::GetMousePos() const
{
	return m_InputManager->GetMousePos();
}

void CoreFacade::ClearToggles()
{
	m_InputManager->ReleaseAllToggles();
}

void CoreFacade::CheckSpecialCases()
{
	//Check for special key
	//Creating 
	//WPARAM temp;
	//LPARAM stupid;

	//Checking for Alt + F4 case
	if ((IsPressingKey(VK_MENU) || IsPressingKey(VK_RMENU)) && IsPressingKey(VK_F4))
		PostQuitMessage(WM_QUIT);
	else if ((IsPressingKey(VK_MENU) || IsPressingKey(VK_RMENU)) && IsPressingKey(VK_TAB))
	{
		SetIsPaused(true);
		PostMessage(this->GameWindow, WM_ACTIVATE, NULL, NULL);
	}
}

// --- Text Manager Functions ---

void CoreFacade::LoadFont(std::string name)
{
	m_TextManager->LoadFont(this, name);
}

Font* CoreFacade::GetFont(std::string name) const
{
	return m_TextManager->GetFont(name);
}
void CoreFacade::UnloadFonts()
{
	m_TextManager->UnloadFonts();
}

// -- Play Sound -- 

void CoreFacade::PlaySound(AkUniqueID sound)
{
	GetSoundManager()->GetAudioSystem()->PostEvent(sound);
}


// --- Get System Functions ---

ParticleSystem* CoreFacade::GetParticleSystem()
{
	if (m_GameFacade)
		return &m_GameFacade->GetParticleSystem();
	return NULL;
}

SoundManager* CoreFacade::GetSoundManager()
{
	return m_SoundManager;
}
ObjectManager* CoreFacade::GetObjectManager()
{
	return m_ObjectManager;
}

NavMesh*	CoreFacade::GetNavMesh()
{
	if (m_GameFacade)
		return m_GameFacade->GetNavMesh();
	return NULL;
}

void CoreFacade::ChangeResolution(bool MoveUp)
{
	if (MoveUp && SETWIDTH == 1920)
	{
		SETWIDTH = 800;
		SETHEIGHT = 600;
	}
	else if (!MoveUp && SETWIDTH == 1920)
	{
		SETWIDTH = 1024;
		SETHEIGHT = 768;
	}
	else if (MoveUp && SETWIDTH == 1024)
	{
		SETWIDTH = 1920;
		SETHEIGHT = 1080;
	}
	else if (!MoveUp && SETWIDTH == 1024)
	{
		SETWIDTH = 800;
		SETHEIGHT = 600;
	}

	else if (MoveUp && SETWIDTH == 800)
	{
		SETWIDTH = 1024;
		SETHEIGHT = 768;
	}
	else if (!MoveUp && SETWIDTH == 800)
	{
		SETWIDTH = 1920;
		SETHEIGHT = 1080;
	}

	GetRenderController()->SetResolution(SETHEIGHT, SETWIDTH, GetRenderController()->IsWindowed);

}

bool CoreFacade::LoadNextLevel(CoreFacade * CF)
{
	if (LoadingScreenState::GetLoadingComplete() == false)
	{
		switch (CF->CurrentLevel)
		{
		case 1:
		{
			CF->LoadInLevel("../Assets/XML/Paragon_Level1.xml");
			CF->GetRenderController()->SetCameraPosition(CF->GetObjectManager()->GetPlayer()->GetObjectTranslation());
			break;
		}
		case 2:
		{
			CF->LoadInLevel("../Assets/XML/Paragon_Level2.xml");
			CF->SetDiamondUnlock(true);
			CF->SetRubyUnlock(true);

			CF->GetRenderController()->SetCameraPosition(CF->GetObjectManager()->GetPlayer()->GetObjectTranslation());
			break;
		}
		case 3:
		{
			CF->LoadInLevel("../Assets/XML/Paragon_Level3.xml");
			CF->SetDiamondUnlock(true);
			CF->SetRubyUnlock(true);

			CF->GetRenderController()->SetCameraPosition(CF->GetObjectManager()->GetPlayer()->GetObjectTranslation());
			break;
		}
		}
		LoadingScreenState::SetLoadingComplete();
	}
	return true;
}
void CoreFacade::LoadInLevel(string LevelToLoad)
{

	OldGoal = 0;
	CurrentDoor = 1;
	//Obect thats basic data has been loaded and need to be created
	vector<ObjectToLoad> LevelObjectsToLoad;

	TiXmlDocument document;
	if (document.LoadFile(LevelToLoad.c_str()) == true)
	{
		//Get the root and check if valid
		TiXmlElement* root = document.RootElement();
		if (root == nullptr)
			return;

		//Read in the ammount of game objects that are to be loaded
		TiXmlElement* pGoCountElement = root->FirstChildElement();
		int GameObjectCount = std::atoi(pGoCountElement->GetText());

		TiXmlElement* GameObjectElement;
		TiXmlElement* GameObjectValues;

		//Get the First Game Object
		GameObjectElement = pGoCountElement->NextSiblingElement();
		//Loop through and load the game objects
		for (int i = 0; i < GameObjectCount; i++)
		{
			//Set up variables to load the file in with
			XMFLOAT3 Translation;
			XMFLOAT3 Rotation;
			XMFLOAT3 Scale;

			string GlowTexturePath;
			string NormTexturePath;
			string SpecTexturePath;
			string DiffuseTexturePath;
			string FBXfilename;
			ObjectType objType;
			string GameObjectTag;
			int DoorOpenRequirement;

			//Get the first element value - Object Type
			GameObjectValues = GameObjectElement->FirstChildElement();
			objType = (ObjectType)std::atoi(GameObjectValues->GetText());

			//Next element - FBX path
			GameObjectValues = GameObjectValues->NextSiblingElement();
			FBXfilename = GameObjectValues->GetText();

			//DoorRequirement
			GameObjectValues = GameObjectValues->NextSiblingElement();
			DoorOpenRequirement = (int)std::atoi(GameObjectValues->GetText());


			//Next element - Game Object Tag
			GameObjectValues = GameObjectValues->NextSiblingElement();
			GameObjectTag = GameObjectValues->GetText();

			//Next element - Textures - TODO::Loop through all of the textures for the object
			GameObjectValues = GameObjectValues->NextSiblingElement();
			DiffuseTexturePath = GameObjectValues->GetText();

			GameObjectValues = GameObjectValues->NextSiblingElement();
			NormTexturePath = GameObjectValues->GetText();

			GameObjectValues = GameObjectValues->NextSiblingElement();
			SpecTexturePath = GameObjectValues->GetText();

			GameObjectValues = GameObjectValues->NextSiblingElement();
			GlowTexturePath = GameObjectValues->GetText();

			TiXmlElement* TransformRows;
			TiXmlElement* TransformIndicies;

			//Next element - Transform 
			GameObjectValues = GameObjectValues->NextSiblingElement();
			TransformRows = GameObjectValues->FirstChildElement();

			//Position b
			TransformIndicies = TransformRows->FirstChildElement();
			Translation.x = (float)std::atof(TransformIndicies->GetText());

			TransformIndicies = TransformIndicies->NextSiblingElement();
			Translation.y = (float)std::atof(TransformIndicies->GetText());

			TransformIndicies = TransformIndicies->NextSiblingElement();
			Translation.z = (float)std::atof(TransformIndicies->GetText());

			//Move to Scale
			TransformRows = TransformRows->NextSiblingElement();

			//Scale
			TransformIndicies = TransformRows->FirstChildElement();
			Scale.x = (float)std::atof(TransformIndicies->GetText());

			TransformIndicies = TransformIndicies->NextSiblingElement();
			Scale.y = (float)std::atof(TransformIndicies->GetText());

			TransformIndicies = TransformIndicies->NextSiblingElement();
			Scale.z = (float)std::atof(TransformIndicies->GetText());

			//Move to rot
			TransformRows = TransformRows->NextSiblingElement();

			//Rotation
			TransformIndicies = TransformRows->FirstChildElement();
			Rotation.x = (float)std::atof(TransformIndicies->GetText());

			TransformIndicies = TransformIndicies->NextSiblingElement();
			Rotation.y = (float)std::atof(TransformIndicies->GetText());

			TransformIndicies = TransformIndicies->NextSiblingElement();
			Rotation.z = (float)std::atof(TransformIndicies->GetText());

			//Create world matrix
			XMMATRIX ObjectWorld = XMMatrixIdentity();

			//Apply Scale
			ObjectWorld = ObjectWorld * XMMatrixScaling(Scale.x, Scale.y, Scale.z);

			//Apply Rotation
			ObjectWorld = ObjectWorld * XMMatrixRotationX(-Rotation.x);
			ObjectWorld = ObjectWorld * XMMatrixRotationY(-Rotation.y);
			ObjectWorld = ObjectWorld * XMMatrixRotationZ(-Rotation.z);

			//Apply Translation
			ObjectWorld = ObjectWorld * XMMatrixTranslation(-Translation.x, Translation.y, Translation.z);

			//Next Element Waypoiny count
			GameObjectValues = GameObjectValues->NextSiblingElement();
			int WayPointCount = std::atoi(GameObjectValues->GetText());

			TiXmlElement* WayPointIndices;

			//Object we are going to load
			ObjectToLoad CurrentGameObject;
			CurrentGameObject.WayPoints.clear();

			//Move to next waypoint
			if (WayPointCount > 0)
			{
				GameObjectValues = GameObjectValues->NextSiblingElement();
				WayPointIndices = GameObjectValues->FirstChildElement();

				//Loop through the count and load in the way points
				for (int w = 0; w < WayPointCount; w++)
				{
					XMFLOAT3 WayPoint;

					//X
					WayPoint.x = (float)std::atof(WayPointIndices->GetText());
					WayPoint.x *= -1.0f;

					//Y
					WayPointIndices = WayPointIndices->NextSiblingElement();
					WayPoint.y = (float)std::atof(WayPointIndices->GetText());

					//Z
					WayPointIndices = WayPointIndices->NextSiblingElement();
					WayPoint.z = (float)std::atof(WayPointIndices->GetText());

					CurrentGameObject.WayPoints.push_back(WayPoint);
					//Move to next waypoint
					if (w + 1 != WayPointCount)
					{
						GameObjectValues = GameObjectValues->NextSiblingElement();
						WayPointIndices = GameObjectValues->FirstChildElement();
					}
				}
			}


			//Game Object Data
			CurrentGameObject.pGO = new GameObject();
			CurrentGameObject.pGO->SetTag(GameObjectTag);
			CurrentGameObject.pGO->SetTypeID(objType);
			CurrentGameObject.pGO->SetObjectTransform(ObjectWorld);

			if (CurrentGameObject.pGO->GetType() == eDOOR)
			{
				//GameObject* pDoor = CurrentGameObject.pGO;
				LoadEvent(CurrentGameObject, eDOOR_EVENT, DoorOpenRequirement, CurrentGameObject.pGO->GetObjectTranslationVec());
			}

			if (CurrentGameObject.pGO->GetType() == eTORCH && CurrentGameObject.pGO->GetTag() == "DoorTorch")
			{
				//GameObject* pTorch = CurrentGameObject.pGO;
				LoadEvent(CurrentGameObject, eDOOR_EVENT, DoorOpenRequirement, CurrentGameObject.pGO->GetObjectTranslationVec());
			}

			//File Path Data
			//FILE * file = nullptr;
			//fopen_s(&file, "test.txt", "wb");
			//fwrite(file, sizeof(file), 1, file);
			//fclose(file);

			CurrentGameObject.FBX_filename = "../Assets/Mesh/" + FBXfilename;
			CurrentGameObject.Texture_filename = "../Assets/Textures/" + DiffuseTexturePath;

			if (SpecTexturePath != "None")
				CurrentGameObject.SpecTexture_filename = "../Assets/Textures/" + SpecTexturePath;

			if (NormTexturePath != "None")
				CurrentGameObject.NormTexture_filename = "../Assets/Textures/" + NormTexturePath;

			if (GlowTexturePath != "None")
				CurrentGameObject.GlowTexture_filename = "../Assets/Textures/" + GlowTexturePath;

			LevelObjectsToLoad.push_back(CurrentGameObject);
			GameObjectElement = GameObjectElement->NextSiblingElement();
		}

		//Load the objects 
		m_AssetManager->CreateFBXManager();
		m_LevelManager->LoadGameObjects(LevelObjectsToLoad, this, m_GameFacade);
		m_LevelManager->LoadStandardGameObjects(this, m_GameFacade);
		m_LevelManager->LoadGeodes(this, m_GameFacade);
		m_AssetManager->DestroyFBXManager();
		m_LevelManager->LoadStandardEffects(this);
	}
	m_GameFacade->PostInitialize(this);

}


EventComponent* CoreFacade::LoadEvent(ObjectToLoad object, EventType eventType, int targetsRemaining, XMVECTOR location)
{
	return m_LevelManager->LoadEvent(object, object.pGO, eventType, targetsRemaining, this, m_GameFacade, location);
}

HUDElement*	CoreFacade::LoadHudElement(string tag, string filePath, float posX, float posY, float width, float height)
{
	return m_LevelManager->LoadHudElement(tag, filePath, posX, posY, width, height, this, m_GameFacade);
}

TextBox* CoreFacade::LoadTextBox(float posX, float posY, float scale, const XMFLOAT4& glyphColor, const XMFLOAT4& outlineColor, string font)
{
	return m_LevelManager->LoadTextBox(posX, posY, scale, glyphColor, outlineColor, font, this, m_GameFacade);
}


bool CoreFacade::GetDoneLoading()
{
	DLLock.lock();
	if (DoneLoading == true)
	{
		DLLock.unlock();
		return true;
	}
	DLLock.unlock();
	return false;
}
void CoreFacade::SetDoneLoading(bool DoneLoading)
{
	DLLock.lock();
	this->DoneLoading = DoneLoading;
	DLLock.unlock();
}

//Game Settings manager
void CoreFacade::InitializeSettings()
{
	FILE * save_file = nullptr;

	//Find the AppData file path
	PWSTR szPath;
	SHGetKnownFolderPath(FOLDERID_RoamingAppData, NULL, NULL, &szPath);
	wstring wfilepath = szPath;
	bool found_file = true;

	//See if the folder is in AppData else create it.
	wfilepath += L"\\Brainstorm Studio";
	TCHAR file[MAX_PATH];
	memcpy_s(file, MAX_PATH, wfilepath.c_str(), wfilepath.size());
	if (!GetWindowsDirectory(file, wfilepath.size()))
	{
		CreateDirectory(wfilepath.c_str(), NULL);
		found_file = false;
	}

	wfilepath += L"\\Paragon";
	memcpy_s(file, MAX_PATH, wfilepath.c_str(), wfilepath.size());
	if (!GetWindowsDirectory(file, wfilepath.size()))
	{
		CreateDirectory(wfilepath.c_str(), NULL);
		found_file = false;
	}

	//See if the settings file is there.
	else
	{
		settings_filepath = string(wfilepath.begin(), wfilepath.end());
		settings_filepath += "\\Paragon_Settings.bin";

		fopen_s(&save_file, settings_filepath.c_str(), "rb");
		if (save_file)
		{
			fread(&m_tSettings, sizeof(tGameSettings), 1, save_file);
			if (m_tSettings.bFirstTime)
			{
				m_tSettings.bFirstTime = false;
				fclose(save_file);
				SaveSettings();
			}
			fclose(save_file);
			ApplySettings();
		}
		else
			found_file = false;
	}

	if (!found_file)
	{
		settings_filepath = string(wfilepath.begin(), wfilepath.end());
		settings_filepath += "\\Paragon_Settings.bin";

		ZeroMemory(&m_tSettings, sizeof(tGameSettings));
		m_tSettings.ScreenSize = { 1920, 1080 };
		m_tSettings.WindowMode = eFULLSCREEN;
		m_tSettings.AAValue = eAAx4;
		m_tSettings.bEActive = true;
		m_tSettings.PDensity = eHIGH;
		m_tSettings.fMVolume = 30.0f;
		m_tSettings.fSFXVolume = 20.0f;
		m_tSettings.bFirstTime = true;
		m_tSettings.GammaValue = 50.0f;

		ApplySettings();
	}

}
void CoreFacade::SaveSettings()
{
	FILE * save_file = nullptr;
	fopen_s(&save_file, settings_filepath.c_str(), "wb");
	if (save_file)
	{
		fwrite(&m_tSettings, sizeof(tGameSettings), 1, save_file);
		fclose(save_file);
	}

}
void CoreFacade::ApplySettings()
{
	//Applying Volume Settings
	m_SoundManager->SetMusicVolume(m_tSettings.fMVolume);
	m_SoundManager->SetSfxVolume(m_tSettings.fSFXVolume);

	//Apply Video Settings
	bool windowed = true;
	if (m_tSettings.WindowMode == eFULLSCREEN)
		windowed = false;

	GetRenderController()->IsWindowed = windowed;

	GetRenderController()->SetResolution(m_tSettings.ScreenSize.y, m_tSettings.ScreenSize.x, GetRenderController()->IsWindowed);
	if (windowed)
		SetWindowPos(GameWindow, 0, 0, 0, m_tSettings.ScreenSize.x, m_tSettings.ScreenSize.y, SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE);

	//Here I would tell the Renderer if the emissive is on/off
	m_Render_Controller->SetEmmisiveActive(m_tSettings.bEActive);

	//Here I would tell the Renderer to what type of Anti-Aliasing
	m_Render_Controller->SetAAValue(m_tSettings.AAValue);

	//Here I would tell the Renderer to change the Gamma Value
	m_Render_Controller->SetGammaValue(m_tSettings.GammaValue);

	//Here I tell the Particle System and the Renderer the particle Density.
	if (m_GameFacade)
	{
		if (m_tSettings.PDensity & eLOW)
		{
			m_GameFacade->GetParticleSystem().PARTICLE_DENSITY = 100;
		}
		else if (m_tSettings.PDensity & eMEDIUM)
		{
			m_GameFacade->GetParticleSystem().PARTICLE_DENSITY = 150;
		}
		else if (m_tSettings.PDensity & eHIGH)
		{
			m_GameFacade->GetParticleSystem().PARTICLE_DENSITY = 200;
		}
	}
	//Saving the Settings
	SaveSettings();
}
tGameSettings& CoreFacade::GetSettings()
{
	return this->m_tSettings;
}
void CoreFacade::ApplyScreenSize(XMUINT2 screen)
{
	m_tSettings.ScreenSize = screen;
	//Apply Video Settings
	//bool windowed = false;
	//if (m_tSettings.WindowMode != eFULLSCREEN)
	//	windowed = true;

	//GetRenderController()->IsWindowed = windowed;

	GetRenderController()->SetResolution(m_tSettings.ScreenSize.y, m_tSettings.ScreenSize.x, GetRenderController()->IsWindowed);
	if (GetRenderController()->IsWindowed)
		SetWindowPos(GameWindow, 0, 0, 0, m_tSettings.ScreenSize.x, m_tSettings.ScreenSize.y, SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE);

}
void CoreFacade::ApplyEmmisive(bool active)
{
	m_tSettings.bEActive = active;
	m_Render_Controller->SetEmmisiveActive(active);
}
void CoreFacade::ApplyMusicVolume(float value)
{
	m_tSettings.fMVolume = value;
	m_SoundManager->SetMusicVolume(value);
}
void CoreFacade::ApplySfxVolume(float value)
{
	m_tSettings.fSFXVolume = value;
	m_SoundManager->SetSfxVolume(value);
}
void CoreFacade::ApplyParticleDensity(int value)
{
	m_tSettings.PDensity = (BYTE)value;

	if (m_GameFacade)
	{
		if (m_tSettings.PDensity & eLOW)
		{
			m_GameFacade->GetParticleSystem().PARTICLE_DENSITY = 100;
		}
		else if (m_tSettings.PDensity & eMEDIUM)
		{
			m_GameFacade->GetParticleSystem().PARTICLE_DENSITY = 150;
		}
		else if (m_tSettings.PDensity & eHIGH)
		{
			m_GameFacade->GetParticleSystem().PARTICLE_DENSITY = 200;
		}
	}
}
void CoreFacade::ApplyWindowMode(int value)
{
	m_tSettings.WindowMode = (BYTE)value;

	bool windowed = true;
	if (m_tSettings.WindowMode == eFULLSCREEN)
		windowed = false;

	GetRenderController()->IsWindowed = windowed;
	m_Render_Controller->SetResolution(m_tSettings.ScreenSize.x, m_tSettings.ScreenSize.y, windowed);
	if (windowed)
		SetWindowPos(GameWindow, 0, 0, 0, m_tSettings.ScreenSize.x, m_tSettings.ScreenSize.y, SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE);
}
void CoreFacade::ApplyAAValue(int value)
{
	m_tSettings.AAValue = (BYTE)value;
	m_Render_Controller->SetAAValue(value);
}
void CoreFacade::ApplyGamma(float value)
{
	m_tSettings.GammaValue = value;
	m_Render_Controller->SetGammaValue(value);
}