#include "../Application/stdafx.h"

#pragma comment(lib,"d3d11")

#if _DEBUG
#pragma comment(lib, "TinyXMLD.lib")
#else
#pragma comment(lib, "TinyXML.lib")
#endif