#include "../Application/stdafx.h"

#include "GameFacade.h"

#include "../AI System/AISystem.h"
#include "../Asset Manager/AssetManager.h"
#include "../Application/CoreFacade.h"
#include "../Physics/PhysicsSystem.h"
#include "../Physics/OrientedBox.h"
#include "../Event System/EventSystem.h"

#include "../Particle System/ParticleSystem.h"

#include "../AI System/PathPlanner.h"
#include "../AI System/NavMesh.h"
#include "../AI System/NavAgent.h"

using namespace Physics;

GameFacade::GameFacade()
{

}

GameFacade::~GameFacade()
{

}


bool GameFacade::Initialize(CoreFacade * m_Facade)
{
	//m_AssetManager = new AssetManager;
	m_PhysicsSystem = new PhysicsSystem;
	m_AISystem = new AISystem(m_Facade);
	m_EventSystem = new EventSystem(m_Facade);
	m_NavMesh = new NavMesh;


	m_ParticleSystem = new ParticleSystem;
	m_ParticleSystem->Initialize(m_Facade);



	return true;
}

void GameFacade::Shutdown()
{
	SAFE_DELETE(m_PhysicsSystem);
	//if (m_AssetManager != nullptr)
	//	m_AssetManager->Shutdown();
	//SAFE_DELETE(m_AssetManager);
	if (m_AISystem != nullptr)
		m_AISystem->Shutdown();
	SAFE_DELETE(m_AISystem);
	if( m_ParticleSystem )
		m_ParticleSystem->Shutdown();
	SAFE_DELETE( m_ParticleSystem );
	SAFE_DELETE(m_EventSystem);
	if( m_NavMesh )
	m_NavMesh->Shutdown();
	SAFE_DELETE(m_NavMesh);
}

void GameFacade::PostInitialize(CoreFacade* pCoreFacade)
{
	m_AISystem->Initialize();

	m_NavMesh->Initialize(pCoreFacade);
	m_NavMesh->CreateMap(XMSHORT2((short)100,(short)100));
}

void GameFacade::Update()
{
	m_AISystem->Update();
	m_ParticleSystem->Update();
	m_PhysicsSystem->Update();
	m_EventSystem->Update();
	//m_NavMesh->Update();
}


// --- Physics System Function ---

Physics::Circle* GameFacade::MakeCircleShape(Physics::ResolutionType resolutionType)
{
	return m_PhysicsSystem->MakeCircleShape(resolutionType);
}

Physics::OrientedBox* GameFacade::MakeOBBShape(Physics::ResolutionType resolutionType)
{
	return m_PhysicsSystem->MakeOBBShape(resolutionType);
}

Physics::Segment* GameFacade::MakeSegmentShape(Physics::ResolutionType resolutionType)
{
	return m_PhysicsSystem->MakeSegmentShape(resolutionType);
}

Physics::Cone* GameFacade::MakeConeShape(Physics::ResolutionType resolutionType, float angle_in_degrees, float radius)
{
	return m_PhysicsSystem->MakeConeShape(resolutionType, angle_in_degrees, radius);
}

PhysicsComponent* GameFacade::MakePhysicsCompoment(GameObject* pHolder)
{
	return m_PhysicsSystem->MakePhysicsCompoment(pHolder);
}

//TODO:: Used for debug, remove later
PhysicsSystem & GameFacade::GetPhysicsSystem()
{
	return *this->m_PhysicsSystem;
}

ParticleSystem & GameFacade::GetParticleSystem()
{
	return *m_ParticleSystem;
}

EventSystem & GameFacade::GetEventSystem()
{
	return *m_EventSystem;
}

// --- Particle System Functions ---

Emitter* GameFacade::LoadEmitter(string filename, GameObject* pHolder, CoreFacade* pCoreFacade)
{
	return m_ParticleSystem->LoadEmitter( filename, pHolder, pCoreFacade );
}


NavMesh* GameFacade::GetNavMesh()
{
	return m_NavMesh;
}