#include "../Application/stdafx.h"

#pragma once
#include "../Input Manager/InputManager.h"
#include "../Asset Manager/AssetManager.h"
#include "../Object Manager/ObjectManager.h"
#include "../Object Manager/PhysicsComponent.h"
#include "../Object Manager/PlayerComponent.h"
#include "../Object Manager/ReticleComponent.h"
#include "../Object Manager/EffectComponent.h"
#include "../Object Manager/AIData.h"
#include "../Object Manager/AnimComponent.h"
#include "../Physics/Circle.h"
#include "../Object Manager/TrapComponent.h"
#include "../Object Manager/EventComponent.h"
#include "../Sound/Wwise_IDs.h"

class RenderController;
class AnimationSystem;
class TimeManager;
class SoundManager;
class AssetManager;
class TextManager;
class GameFacade;
class PhysicsSystem;
class ParticleSystem;
class NavMesh;

//struct toLoad;
//struct HUDtoLoad;
//struct FontToLoad;
//class HUDElement;
//class TextBox;
//class Font;
class GameObject;
class LevelManager;

using namespace std;

using namespace AK;
using namespace EVENTS;

enum GeodeSelection { GS_RUBY, GS_SAPPHIRE, GS_DIAMOND, GS_NONE };
enum GameSettings {
	//Window Mode
	eWINDOWED_BORDERED = 1, eWINDOWED_BORDERLESS = 2, eFULLSCREEN = 4,

	//AA options
	eAA_OFF = 0, eAAx1 = 1, eAAx4 = 4, eAAx8 = 8,

	//Particle density
	eLOW = 1, eMEDIUM = 2, eHIGH = 4,
};

struct tGameSettings
{
	XMUINT2 ScreenSize;
	BYTE WindowMode;
	BYTE AAValue;
	bool bEActive;
	BYTE PDensity;
	float fMVolume;
	float fSFXVolume;
	float GammaValue;
	bool bFirstTime;
};

class CoreFacade
{
	friend LevelManager;
private:
		RenderController *  m_Render_Controller;
		AnimationSystem *	m_AnimSystem;
		SoundManager *		m_SoundManager;
		AssetManager *		m_AssetManager;
		InputManager *		m_InputManager;
		TextManager*		m_TextManager;
		LevelManager*		m_LevelManager;


		GameFacade *		m_GameFacade;

		float				m_fCameraTransitionTime;
		bool				m_isPaused;
		bool				m_ToClearObject;
		bool				m_RubyUnlocked;
		bool				m_DiamondUnlocked;

		GeodeSelection		m_nCurrentSelectedGeode;
		ObjectToLoad		TorchModel;
		int					OldGoal;
		unsigned int		m_nRooms;
		short				MaxDoorCount;
		short				CurrentDoor;

		//Level Loading
		void LoadInLevel(string LevelToLoad);

		//Trying to debug multithreading
		bool DoneLoading;
		std::mutex DLLock;

		//Game Settings to save and update.
		tGameSettings m_tSettings;
		//std::mutex savingMutex;
		//std::thread savingThread;
		string settings_filepath;
		bool m_bDoneSaving;
		bool m_bIsSaving;
public:

	//Windows Stuff
	bool IsWindowed;
	HINSTANCE GameInstance;
	HWND GameWindow;

	unsigned int SETWIDTH;
	unsigned int SETHEIGHT;

	bool GetDoneLoading();
	void SetDoneLoading(bool DoneLoading);

	//Focusing on the Player?
	bool FocusOnPlayer;


	//Temporary Hack 
	float GameTime;

	//Level Data
	unsigned int CurrentLevel;

	//Access to the systems for all of the objects
	ObjectManager *	m_ObjectManager;
	
	CoreFacade();
	~CoreFacade();

	void Initialize(HWND hWnd, HINSTANCE hInstance, int nWidth, int nHeight, bool bIsWindowed);
	void Update();
	void Shutdown();

	static void RenderCurrentSets(CoreFacade * CF);

	//Accessor to see if the game is paused
	//This should only be checked during GamePlayState!
	bool IsPaused() const;
	bool GetRubyUnlock(void);
	bool GetDiamondUnlock(void);
	GeodeSelection GetSelectedGeode(void);
	
	//Mutator to set the game to paused or not
	//This should only be set during GamePlayState and PauseMenuState!
	void SetIsPaused(bool pause);
	void SetRubyUnlock(bool _unlock);
	void SetDiamondUnlock(bool _unlock);
	void SetSelectedGeode(GeodeSelection _geode);


	// --- Object Manager Functions ---
	void AddObject( GameObject* Object_To_Add );
	void AddTextBox( TextBox* textBox );
	void ClearAllObjects();

	// -- Physics System Functions ---
	PhysicsSystem* GetPhysicsSystem();
	Physics::Circle * MakeCircleCollisionShape(Physics::ResolutionType type);
	
	// --- Renderer Functions ---
	ID3D11Device* GetRenderDevice();
	DirectX::XMFLOAT4X4 GetViewMatrix();
	DirectX::XMFLOAT4X4 GetProjectionMatrix();
	DirectX::XMVECTOR	GetCameraPosition();
	void				SetCinCameraPosition(XMFLOAT3 Waypoint, XMFLOAT3 DoorLocation);
	void CreateRenderSets();
	RenderController * GetRenderController();
	void ChangeResolution(bool MoveUp = true);

	// --- Asset Manager Functions ---
	void BeginAssetLoad();
	void EndAssetLoad();
	void LoadAsset(ObjectToLoad* asset);
	void LoadHudAsset( HUDtoLoad* hudAsset );
	void LoadFontAsset( FontToLoad* fontAsset );
	void LoadEmitterAsset( EmitterToLoad* emitterAsset);
	void ClearLoadingCounts();
	AssetManager * GetAssetManager() const;

	// --- Input Manager Functions ---
	void GetInput( RAWINPUT rawInput );
	bool IsPressing(ButtonID action) const;
	bool IsToggled(ButtonID action, bool untoggle = true);
	bool IsPressingKey(int keycode) const;
	bool IsToggledKey(int action, bool untoggle = true);
	void ClearToggles();

	//This checks for special presses that would send the appropriate window messages.
	void CheckSpecialCases();

	DirectX::XMFLOAT2 GetMousePos() const;

	// --- Text Manager Functions ---
	void LoadFont( std::string name );
	Font* GetFont( std::string name ) const;
	void UnloadFonts();

	// --- Game Facade Functions ---
	void CreateGameFacade();
	void DestroyGameFacade();

	// --- Level Loading ---
	static bool LoadNextLevel(CoreFacade * CF);


	void PlaySound( AkUniqueID sound );

	// --- Number of Rooms functions ---
	unsigned int GetNumberOfRooms() const { return m_nRooms; }
	void SetNumberOfRooms(unsigned int _numRooms){ m_nRooms = _numRooms; }

	// --- Get Systems ---
	ParticleSystem* GetParticleSystem( );
	SoundManager* GetSoundManager( );
	ObjectManager* GetObjectManager( );
	NavMesh*	GetNavMesh();

	// --- Level Manager Interface Functions ---
	EffectComponent* LoadEffect(GameObject* pGO, const string& tag, const string& texture, const XMFLOAT2& size, const XMFLOAT3& Offset);
	EventComponent* LoadEvent(ObjectToLoad object, EventType eventType, int targetsRemaining, XMVECTOR location = XMVectorZero());
	HUDElement*	LoadHudElement(string tag, string filePath,  float posX, float posY, float width, float height );
	TextBox* LoadTextBox(float posX, float posY, float scale, const XMFLOAT4& glyphColor, const XMFLOAT4& outlineColor = XMFLOAT4(0, 0, 0, 1), string font = "LeagueGothic");

	//Game Settings manager
	void InitializeSettings();
	void SaveSettings();
	void ApplySettings();
	void ApplyScreenSize(XMUINT2 screen);
	void ApplyEmmisive(bool active);
	void ApplyMusicVolume(float value);
	void ApplySfxVolume(float value);
	void ApplyParticleDensity(int value);
	void ApplyWindowMode(int value);
	void ApplyAAValue(int value);
	void ApplyGamma(float value);
	tGameSettings& GetSettings();


};

