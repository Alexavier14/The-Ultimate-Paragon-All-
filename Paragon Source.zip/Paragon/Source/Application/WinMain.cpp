#include "../Application/stdafx.h"

#ifndef MEM_LEAK_CHECK 
#define MEM_LEAK_CHECK 0
#endif

#if MEM_LEAK_CHECK == 0

//#include <stdlib.h>
//#include <crtdbg.h>
//#define _CRTDBG_MAP_ALLOC

//struct CrtBreakAllocSetter {
//	CrtBreakAllocSetter() {
//		_crtBreakAlloc = 64;
//	}
//};

// g_crtBreakAllocSetter;

#endif

#include <Windows.h> //Include Windows API for WIN32 
#include <windowsx.h>
#include <tchar.h>	  //Include UNICODE support
#include <process.h>  // Include Multi-Threading functions.
#include <time.h>
#include <ole2.h>	// COM functions
#include <stdio.h>
#include <io.h>
#include <fcntl.h>
#include <ShlObj.h>
#include "../Resources/resource.h"

//Windows debug for Dump file
#include <DbgHelp.h>
#pragma comment(lib, "dbghelp")

#include "Application.h"



#if _DEBUG
#define CREATE_CONSOLE
#define FULL_SCREEN FALSE
#else
#define FULL_SCREEN TRUE
#endif



int	 WINDOW_WIDTH = 1024;
int	 WINDOW_HEIGHT = 768;

//Foward Declarations:
LRESULT CALLBACK WindowProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
void OnPaint(HWND hWnd);
void OnLButtonDown(HWND hWnd, WPARAM wParam, LPARAM lParam);
void OnCommand(HWND hWnd, WPARAM wParam, LPARAM lParam);
void GetDesktopResolution(int& width, int& height);
LONG WINAPI errorFunc(_EXCEPTION_POINTERS * pExceptionInfo);

//The Game Instance
Application * Game = nullptr;

//Console Handles
HANDLE handle_out;
HANDLE handle_in;

// The Entry Point function
int WINAPI _tWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR lpCmdLine, int iCmdShow)
{
	//_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);

	//Setup the error function to create a dump file on crashes
	SetUnhandledExceptionFilter(errorFunc);

	// Initialize the COM Library.
	CoInitializeEx(NULL, COINIT_APARTMENTTHREADED | COINIT_DISABLE_OLE1DDE);


	//Initialize the Window Class.
	WNDCLASSEX wcex;
	wcex.cbSize = sizeof(wcex);
	wcex.cbClsExtra = 0;
	wcex.cbWndExtra = 0;
	wcex.hbrBackground = (HBRUSH) GetStockObject(BLACK_BRUSH);
	wcex.hCursor = LoadCursor(hInstance, MAKEINTRESOURCE(IDC_CURSOR1));
	wcex.hIcon = LoadIcon(NULL, NULL);
	wcex.hIconSm = LoadIcon(NULL, NULL);
	wcex.hInstance = hInstance;
	wcex.style = CS_DBLCLKS | CS_OWNDC | CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc = WindowProc;
	wcex.lpszMenuName = nullptr;
	wcex.lpszClassName = _T("PARAGON");
	RegisterClassEx(&wcex);

	//Load and set the cursor
	//HCURSOR CursorHandle = LoadCursor(hInstance, MAKEINTRESOURCE(IDC_CURSOR1));  
	//(CursorHandle);

#ifdef CREATE_CONSOLE
	//Create a console
	AllocConsole();

	handle_out = GetStdHandle(STD_OUTPUT_HANDLE);
	int hCrt = _open_osfhandle((long) handle_out, _O_TEXT);
	FILE* hf_out = _fdopen(hCrt, "w");
	setvbuf(hf_out, NULL, _IONBF, 1);
	*stdout = *hf_out;

	handle_in = GetStdHandle(STD_INPUT_HANDLE);
	hCrt = _open_osfhandle((long) handle_in, _O_TEXT);
	FILE* hf_in = _fdopen(hCrt, "r");
	setvbuf(hf_in, NULL, _IONBF, 128);
	*stdin = *hf_in;
#endif

	//GetDesktopResolution(WINDOW_WIDTH, WINDOW_HEIGHT);

#if FULL_SCREEN
	GetDesktopResolution(WINDOW_WIDTH, WINDOW_HEIGHT);

	HWND hWnd = CreateWindowEx(WS_EX_APPWINDOW, wcex.lpszClassName, _T("Paragon"), WS_VISIBLE | WS_POPUP, CW_USEDEFAULT, CW_USEDEFAULT,
							   WINDOW_WIDTH, WINDOW_HEIGHT, HWND_DESKTOP, NULL, hInstance, NULL);

	SetWindowLongPtr(hWnd, GWL_STYLE, WS_SYSMENU | WS_POPUP | WS_CLIPCHILDREN | WS_CLIPSIBLINGS | WS_VISIBLE);
	SetWindowPos(hWnd, HWND_TOP, 0, 0, WINDOW_WIDTH, WINDOW_HEIGHT, SWP_SHOWWINDOW);
#else
		HWND hWnd = CreateWindowEx(WS_EX_APPWINDOW, wcex.lpszClassName, _T("Paragon"), WS_OVERLAPPEDWINDOW | WS_VISIBLE, CW_USEDEFAULT, CW_USEDEFAULT,
							   WINDOW_WIDTH, WINDOW_HEIGHT, HWND_DESKTOP, NULL, hInstance, NULL);
#endif

	if (!hWnd)
	{
		MessageBox(HWND_DESKTOP, _T("ERROR: Failed to create main window!"),
				   _T("Paragon Main Window"), MB_OK | MB_ICONERROR);
		return -1;
	}

	// Activate raw input messages

	RAWINPUTDEVICE rid[2];

	//Keyboard
	rid[0].usUsagePage = 0x01;
	rid[0].usUsage = 0x06;
	rid[0].dwFlags = RIDEV_NOLEGACY;
	rid[0].hwndTarget = 0;

	//Mouse
	rid[1].usUsagePage = 0x01;
	rid[1].usUsage = 0x02;
	rid[1].dwFlags = 0;
	rid[1].hwndTarget = hWnd;

	RegisterRawInputDevices(rid, 2, sizeof(RAWINPUTDEVICE));


	// Create the game
	Game = new Application();

	
	// Initialize the COM Library.
	CoInitializeEx(NULL, COINIT_MULTITHREADED | COINIT_DISABLE_OLE1DDE);

	Game->Initialize(hWnd, (HINSTANCE) GetWindowLong(hWnd, GWL_HINSTANCE), WINDOW_WIDTH, WINDOW_HEIGHT, !FULL_SCREEN);

	ShowWindow(hWnd, iCmdShow);
	UpdateWindow(hWnd);

	MSG msg = { };
	while(true)
	{
		if(PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);

			if (msg.message == WM_QUIT)
				break;
		}
		else
		{
			Game->Update();
		}
	}

		
	// Uninitialize the COM Library.
	CoUninitialize();

	// Clean up Game
	if (Game != nullptr)
	{
		Game->Shutdown();
		delete Game;
	}

	//_CrtDumpMemoryLeaks();

	// Uninitialize the COM Library.
	CoUninitialize();


	return msg.wParam;
}

LRESULT CALLBACK WindowProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
		// Handle Window Creation:
	case WM_CREATE:
		break;

		// Handle Close Button [X] Pressed:
	case WM_CLOSE:
		//Begin shutting down the game

#ifdef CREATE_CONSOLE
		//CloseHandle(handle_out);
		//CloseHandle(handle_in);
		FreeConsole();
#endif

		// Wait until Game Thread terminates:
		Game->IsRunning = false;

		DestroyWindow(hWnd); // Begin WinMain shutdown.
		break;

		// Handle Window Destruction:
	case WM_DESTROY:
		PostQuitMessage(0);
		break;

	case WM_PAINT:
	{
		ValidateRect(hWnd, NULL);
	}break;

	//	Gain / lose focus
	case WM_ACTIVATE:
	{
		//TODO:: 
		if (/*Game != nullptr */ true)
		{
			if (LOWORD(wParam) != WA_INACTIVE)	//gaining focus
			{
				//TODO:: Unpause Game
			}
			else								//losing focus
			{
				//TODO:: Pause Game
			}
		}
	}break;

	case WM_STYLECHANGED:
	{
		return 0;
	}
		break;

		// Handle Menu Items:
	case WM_COMMAND:
		OnCommand(hWnd, wParam, lParam);
		break;

	case WM_PRINT:
	{
		UINT poop = 0;
	}
		break;

	case WM_INPUT:
	{
		UINT size = 100;
		BYTE data[100];
		RAWINPUT* rawInput = ( RAWINPUT* )&data;
		
		GetRawInputData((HRAWINPUT) lParam, RID_INPUT, rawInput,
 						&size, sizeof(RAWINPUTHEADER));
		Game->GetInput(*rawInput);
		InvalidateRect(hWnd, nullptr, TRUE);
	}break;
	case WM_MOUSEMOVE:
	{
		RAWINPUT rawInputMock;
		rawInputMock.header.dwType = RIM_TYPEMOUSE;
		rawInputMock.data.mouse.usFlags = MOUSE_MOVE_ABSOLUTE;
		rawInputMock.data.mouse.lLastX = GET_X_LPARAM(lParam);
		rawInputMock.data.mouse.lLastY = GET_Y_LPARAM(lParam);
		Game->GetInput(rawInputMock);

	}break;
	default:
		// Allow Windows to perform default processing.
		return DefWindowProc(hWnd, uMsg, wParam, lParam);
	}
	return 0;
}


void OnCommand(HWND hWnd, WPARAM wParam, LPARAM lParam)
{
	int menuid = LOWORD(wParam);
}

// Gets the resolution of the desktop.
void GetDesktopResolution(int& width, int& height)
{
	RECT desktop;

	const HWND hDesktop = GetDesktopWindow();

	GetWindowRect(hDesktop, &desktop);

	width = desktop.right;
	height = desktop.bottom;
}

LONG WINAPI errorFunc(_EXCEPTION_POINTERS * pExceptionInfo)
{
	//Find the AppData file path
	PWSTR szPath;
	SHGetKnownFolderPath(FOLDERID_RoamingAppData, NULL, NULL, &szPath);
	wstring filepath = szPath;

	//See if the folder is in AppData else create it.
	filepath += L"/Brainstorm Studio";
	TCHAR file[MAX_PATH];
	memcpy_s(file, MAX_PATH, filepath.c_str(), filepath.size());
	if (GetWindowsDirectory(file, filepath.size()))
		CreateDirectory(filepath.c_str(), NULL);

	filepath += L"/Paragon";
	memcpy_s(file, MAX_PATH, filepath.c_str(), filepath.size());
	if (GetWindowsDirectory(file, filepath.size()))
		CreateDirectory(filepath.c_str(), NULL);

	filepath += L"/Logs";
	memcpy_s(file, MAX_PATH, filepath.c_str(), filepath.size());
	if (GetWindowsDirectory(file, filepath.size()))
		CreateDirectory(filepath.c_str(), NULL);

	//spit out the dump file.
	filepath += L"/dumpfile.mdmp";
	HANDLE hFile = ::CreateFile(filepath.c_str(), GENERIC_WRITE, FILE_SHARE_WRITE, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);

	if (hFile != INVALID_HANDLE_VALUE)
	{
		_MINIDUMP_EXCEPTION_INFORMATION ExInfo;

		ExInfo.ThreadId = ::GetCurrentThreadId();
		ExInfo.ExceptionPointers = pExceptionInfo;
		ExInfo.ClientPointers = NULL;
		MiniDumpWriteDump(GetCurrentProcess(), GetCurrentProcessId(), hFile, MiniDumpNormal, &ExInfo, NULL, NULL);
		//MessageBox("Dump File Saved look x directory please email to developer at the following email adress crashdmp@gmail.com with the subject Gamename - Version ");
		::CloseHandle(hFile);
	}
	
	return 0;
}
