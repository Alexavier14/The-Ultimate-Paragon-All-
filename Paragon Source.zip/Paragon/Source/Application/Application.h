#include "../Application/stdafx.h"

#pragma once
#include "../Util/TimeManager.h"

class GameStateMachine;

class Application
{
private: 
	GameStateMachine * cStateMachine;

	TimeManager appTime;

public:
	bool IsRunning;

	void Initialize(HWND hWnd, HINSTANCE hInstance, int nWidth, int nHeight, bool bIsWindowed);
	void Shutdown();
	void Update();

	void GetInput( RAWINPUT rawInput );

	Application();
	~Application();
};

