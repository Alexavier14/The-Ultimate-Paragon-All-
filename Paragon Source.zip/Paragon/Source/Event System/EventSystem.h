#pragma once
#include "../Application/stdafx.h"

class GameObject;
class CoreFacade;


class EventSystem
{
	CoreFacade * c_pCoreFacade;
	
public:
	XMFLOAT3 DoorFirstPosition;
	EventSystem(CoreFacade * c_pCoreFacade);
	~EventSystem();
	void Initialize(CoreFacade * c_pCoreFacade);
	void Shutdown();
	void Update();
	void MoveCameraEvent(GameObject &Door);
	void DoorEvent(GameObject &Door);
	void TrapEvent(GameObject &Enemy);
	void WinEvent();
	void SetTrapVel(GameObject& GO);
	void MoveTrap(GameObject& GO);
};

