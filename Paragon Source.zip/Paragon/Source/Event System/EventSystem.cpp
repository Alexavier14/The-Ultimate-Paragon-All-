#include "../Application/stdafx.h"

#include "EventSystem.h"
#include "..\Object Manager\PhysicsComponent.h"
#include "../Application/CoreFacade.h"
#include "..\Object Manager\EventComponent.h"
#include "../Object Manager/PointLightComponent.h"
#include "../Object Manager/AudioComponent.h"
#include "../Physics/Physics.h"
#include "../Sound/SoundManager.h"
#include "../Sound/Wwise_IDs.h"
#include "../Util/TimeManager.h"


#define INTERPOLATION_RATIO 0.005f

using namespace Physics;

EventSystem::EventSystem(CoreFacade * c_pCoreFacade)
{
	Initialize(c_pCoreFacade);
}


EventSystem::~EventSystem()
{
	Shutdown();
}

void EventSystem::Initialize(CoreFacade * c_pCoreFacade)
{
	this->c_pCoreFacade = c_pCoreFacade;
}

void EventSystem::Shutdown()
{
}


void EventSystem::Update()
{

	vector<GameObject *> AllTorches = c_pCoreFacade->m_ObjectManager->GetTorches();
	vector<GameObject *> AllDoors = c_pCoreFacade->m_ObjectManager->GetDoors();
	vector<GameObject *> AllEnemies = c_pCoreFacade->m_ObjectManager->GetAllEnemies();
	bool AnyUpdating = false;

	for (size_t DoorIndex = 0; DoorIndex < AllDoors.size(); DoorIndex++)
	{
		EventComponent* pDoorEvent = AllDoors[DoorIndex]->GetEventComponent();
		if (pDoorEvent->TargetsRemaining <= 0 && !pDoorEvent->finished)
		{
			DoorEvent(*AllDoors[DoorIndex]);
			AnyUpdating = true;
		}

	}


	for (size_t i = 0; i < AllTorches.size(); i++)
	{
		GameObject * CurrentLight = AllTorches[i]->GetChildPointLight(0);

		if (CurrentLight->GetTag() == "DoorTorch")
		{
			EventComponent* pTorchEvent = AllTorches[i]->GetEventComponent();
			if (pTorchEvent->TargetsRemaining <= 0)
			{
				CurrentLight->GetPointLightComponent()->PointLightData.ambientColor = XMCStoreFloat3(
					XMVectorLerp(XMLoadFloat3(&CurrentLight->GetPointLightComponent()->PointLightData.ambientColor),
					XMLoadFloat3(&XMFLOAT3(0.1f, 0.8f, 0.1f)), INTERPOLATION_RATIO));

				CurrentLight->GetPointLightComponent()->PointLightData.diffuseColor = XMCStoreFloat3(
					XMVectorLerp(XMLoadFloat3(&CurrentLight->GetPointLightComponent()->PointLightData.ambientColor),
					XMLoadFloat3(&XMFLOAT3(0.1f, 0.8f, 0.1f)), INTERPOLATION_RATIO));
				CurrentLight->GetPointLightComponent()->PointLightData.specularColor = XMFLOAT3(0.1f, 0.8f, 0.1f);
				//CurrentLight->GetPointLightComponent()->PointLightData.attenuation = XMFLOAT3(0.505f, 0.315f, 0.015f);
				CurrentLight->GetPointLightComponent()->PointLightData.specularPower = 1.0f;
				CurrentLight->GetPointLightComponent()->PointLightData.specularIntensity = 1.0f;

			}
			else if (pTorchEvent->TargetsRemaining < pTorchEvent->InitialTargets)
			{
				CurrentLight->GetPointLightComponent()->PointLightData.ambientColor = XMCStoreFloat3(
					XMVectorLerp(XMLoadFloat3(&CurrentLight->GetPointLightComponent()->PointLightData.ambientColor),
					XMLoadFloat3(&XMFLOAT3(0.8f, 0.1f, 0.1f)), INTERPOLATION_RATIO));

				CurrentLight->GetPointLightComponent()->PointLightData.diffuseColor = XMCStoreFloat3(
					XMVectorLerp(XMLoadFloat3(&CurrentLight->GetPointLightComponent()->PointLightData.ambientColor),
					XMLoadFloat3(&XMFLOAT3(0.8f, 0.1f, 0.1f)), INTERPOLATION_RATIO));

				CurrentLight->GetPointLightComponent()->PointLightData.specularColor = XMFLOAT3(0.8f, 0.1f, 0.0f);
				//CurrentLight->GetPointLightComponent()->PointLightData.attenuation = XMFLOAT3(0.505f, 0.315f, 0.015f);
				CurrentLight->GetPointLightComponent()->PointLightData.specularPower = 1.0f;
				CurrentLight->GetPointLightComponent()->PointLightData.specularIntensity = 1.0f;
			}
			else
			{
				CurrentLight->GetPointLightComponent()->PointLightData.ambientColor = XMCStoreFloat3(
					XMVectorLerp(XMLoadFloat3(&CurrentLight->GetPointLightComponent()->PointLightData.ambientColor),
					XMLoadFloat3(&XMFLOAT3(1.0f, 0.1f, 0.1f)), INTERPOLATION_RATIO));

				CurrentLight->GetPointLightComponent()->PointLightData.diffuseColor = XMCStoreFloat3(
					XMVectorLerp(XMLoadFloat3(&CurrentLight->GetPointLightComponent()->PointLightData.ambientColor),
					XMLoadFloat3(&XMFLOAT3(1.0f, 0.1f, 0.1f)), INTERPOLATION_RATIO));

				CurrentLight->GetPointLightComponent()->PointLightData.specularColor = XMFLOAT3(0.5f, 0.1f, 0.0f);
				CurrentLight->GetPointLightComponent()->PointLightData.attenuation = XMFLOAT3(0.505f, 0.15f, 0.015f);
				CurrentLight->GetPointLightComponent()->PointLightData.specularPower = 1.0f;
				CurrentLight->GetPointLightComponent()->PointLightData.specularIntensity = 1.0f;
			}
		}
	}

	for (unsigned int i = 0; i < AllEnemies.size(); i++)
	{
		if (AllEnemies[i]->GetTag() == "FirstTrapSpider")
		{
			if (AllEnemies[i]->GetEventComponent()->TargetsRemaining <= 0 && !AllEnemies[i]->GetEventComponent()->finished)
			{

				TrapEvent(*AllEnemies[i]);
				AnyUpdating = true;
			}

			break;
		}
	}

	//if (!AnyUpdating)
	//{
	//	for (size_t i = 0; i < AllLights.size(); i++)
	//	{
	//		if (AllLights[i]->GetTag() != "Reticle Point Light"
	//			&& AllLights[i]->GetTag() != "First Point Light"
	//			&& AllLights[i]->GetTag() != "DoorTorch1")
	//		AllLights[i]->GetPointLightComponent()->PointLightData.ambientColor = XMFLOAT3(1.0f, 0.75f, 0.1f);
	//		AllLights[i]->GetPointLightComponent()->PointLightData.diffuseColor = XMFLOAT3(1.0f, 0.75f, 0.1f);
	//		AllLights[i]->GetPointLightComponent()->PointLightData.specularColor = XMFLOAT3(0.4f, 0.4f, 0.4f);
	//		AllLights[i]->GetPointLightComponent()->PointLightData.attenuation = XMFLOAT3(0.002f, 0.002f, 0.002f);
	//		AllLights[i]->GetPointLightComponent()->PointLightData.specularPower = 0.5f;
	//		AllLights[i]->GetPointLightComponent()->PointLightData.specularIntensity = 0.5f;
	//	}
	//}
}

void EventSystem::MoveCameraEvent(GameObject &Door)
{
	XMFLOAT3 Waypoint;
	XMVECTOR WaypointVec;

	if (Door.GetEventComponent()->CameraToDoorWaypoints.size() != 0)
	{
		Waypoint = Door.GetEventComponent()->CameraToDoorWaypoints.front();
		WaypointVec = XMLoadFloat3(&Waypoint);
	}
	else
	{
		Waypoint = Door.GetEventComponent()->m_Location;
		WaypointVec = XMLoadFloat3(&Waypoint);
	}

	XMVECTOR distanceVec = XMVector4Length(WaypointVec - c_pCoreFacade->GetCameraPosition());
	XMFLOAT3 distance;
	XMStoreFloat3(&distance, distanceVec);

	if (distance.x < 60.0f)
	{
		if (Door.GetEventComponent()->CameraToDoorWaypoints.size() > 1)
		{
			Door.GetEventComponent()->CameraToDoorWaypoints.pop();
			Waypoint = Door.GetEventComponent()->CameraToDoorWaypoints.front();
		}
		else
		{
			if (Door.GetEventComponent()->CameraToDoorWaypoints.size() != 0)
				Door.GetEventComponent()->CameraToDoorWaypoints.pop();
			Waypoint = Door.GetEventComponent()->m_Location;
		}

	}

	c_pCoreFacade->SetCinCameraPosition(Waypoint, Door.GetEventComponent()->m_Location);
}

void EventSystem::DoorEvent(GameObject &Door)
{
	MoveCameraEvent(Door);
	EventComponent * TriggeredEvent = Door.GetEventComponent();
	if (TriggeredEvent->Triggered)
	{
		Door.SetFocused(true);
		
		TriggeredEvent->m_Clock.Start();
		TriggeredEvent->Triggered = false;

		c_pCoreFacade->GetSoundManager()->SetMusicVolume(c_pCoreFacade->GetSoundManager()->GetMusicVolume() / 3.0f);
		//c_pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_SFX_ROCK_DOOR_OPEN);
		Door.GetAudioComponent()->PlayAudioFollow(PLAY_SFX_ROCK_DOOR_OPEN);
		//c_pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_BGM_PARAGON_LOOP_05);

		DoorFirstPosition = Door.GetObjectTranslation();
		Door.GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE)->SetActive(false);

		//Set Torch Event to finished
		for (size_t i = 0; i < c_pCoreFacade->m_ObjectManager->GetTorches().size(); i++)
		{
			GameObject * CurrentLight = c_pCoreFacade->m_ObjectManager->GetTorches()[i]->GetChildPointLight(0);
			if (CurrentLight->GetTag() == "DoorTorch")
			{
				if (c_pCoreFacade->m_ObjectManager->GetTorches()[i]->GetEventComponent()->TargetsRemaining <= 0)
				{
					c_pCoreFacade->m_ObjectManager->GetTorches()[i]->GetEventComponent()->finished = true;
					for (size_t RevisionIndex = 0; RevisionIndex < c_pCoreFacade->m_ObjectManager->GetTorches().size(); RevisionIndex++)
					{
						GameObject * IndexedLight = c_pCoreFacade->m_ObjectManager->GetTorches()[RevisionIndex]->GetChildPointLight(0);
						EventComponent* pFutureTorchEvent = c_pCoreFacade->m_ObjectManager->GetTorches()[RevisionIndex]->GetEventComponent();

						if (IndexedLight->GetTag() == "DoorTorch")
						{
							if (!pFutureTorchEvent->finished)
								pFutureTorchEvent->InitialTargets -= c_pCoreFacade->m_ObjectManager->GetTorches()[i]->GetEventComponent()->InitialTargets;
						}
					}
				}
			}
		}

	}

	PhysicsComponent * phyComDoor = Door.GetPhysicsComponent();
	/*XMFLOAT3 DistanceNeededF = XMFLOAT3(0, 0, 15.0f);
	XMVECTOR DistanceNeeded = XMLoadFloat3(&DistanceNeededF);*/
	XMMATRIX DoorLeft = XMLoadFloat4x4(&Door.GetWorldTransform());
	XMVECTOR DistanceNeeded = XMVector3Normalize(DoorLeft.r[0]) * -4.0f;

	if (Door.GetReactionTime() <= 0.0f)
		Door.SetReactionTime(0.4f);

	if (TriggeredEvent->m_Clock.Watch() > 10.0f)
	{
		TriggeredEvent->targeted = true;
		Door.GetEventComponent()->finished = true;
		//c_pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::STOP_BGM_PARAGON_LOOP_05);
		c_pCoreFacade->GetSoundManager()->SetMusicVolume(c_pCoreFacade->GetSoundManager()->GetMusicVolume() * 3.0f);
	}
	else if (TriggeredEvent->m_Clock.Watch() > 8.0f)
		Door.SetFocused(false);
	else if (TriggeredEvent->m_Clock.Watch() > 5.0f)
	{
		//c_pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::STOP_FX_3D_CAR_LOOP);
	}
	else
	{
		XMVECTOR FinalPos = XMLoadFloat3(&Door.GetEventComponent()->m_Location) + DistanceNeeded * (float)(TriggeredEvent->m_Clock.Watch() * 5.0f / 5.0f);
		XMFLOAT2 Velocity = XMFLOAT2(0, 0);
		//XMMATRIX DoorLeft = XMLoadFloat4x4(&Door.GetWorldTransform());
		//XMVECTOR ObjectSpeed = DoorLeft.r[2]  * 5.0f;
		XMVectorGetZPtr(&Velocity.y, FinalPos);
		XMVectorGetXPtr(&Velocity.x, FinalPos);

		//phyComDoor->SetPosition(Velocity);
		Door.SetObjectTranslation(FinalPos);
	}
}

void EventSystem::WinEvent()
{

}

void EventSystem::TrapEvent(GameObject &Enemy)
{
	MoveCameraEvent(Enemy);
	EventComponent * TriggeredEvent = Enemy.GetEventComponent();
	if (TriggeredEvent->Triggered)
	{
		Enemy.SetFocused(true);
		TriggeredEvent->m_Clock.Start();
		TriggeredEvent->Triggered = false;
		//c_pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::);
		Enemy.GetAudioComponent()->PlayAudioFollow(PLAY_SFX_SPIDER_TRAP);
		DoorFirstPosition = Enemy.GetObjectTranslation();
		//Enemy.GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE)->SetActive(false);
	}

	if (Enemy.GetReactionTime() <= 0.0f)
		Enemy.SetReactionTime(1.0f);

	if (TriggeredEvent->m_Clock.Watch() <= 8.0f)
	{
		std::vector<GameObject*> trapList = c_pCoreFacade->GetObjectManager()->GetSpiderTraps();
		for (unsigned int index = 0; index < trapList.size(); index++)
		{
			if (trapList[index]->GetTrapComponent()->GetParent() == &Enemy)
			{
				if (trapList[index]->GetActive() == false)
				{
					trapList[index]->GetTrapComponent()->SetOffset(XMFLOAT3(0.0f, 0.0f, 0.0f));
					trapList[index]->SetObjectTranslation(Enemy.GetObjectTranslation());
					trapList[index]->SetActive(true);
					trapList[index]->GetTrapComponent()->SetEnabled(true);
					trapList[index]->GetTrapComponent()->SetToMove(true);
					SetTrapVel(*trapList[index]);
					//TrapMove(*trapList[index]);
				}

				if (trapList[index]->GetTrapComponent()->GetToMove())
					MoveTrap(*trapList[index]);

				break;
			}
		}
	}

	if (TriggeredEvent->m_Clock.Watch() > 9.0f)
	{
		Enemy.GetEventComponent()->finished = true;
	}
	else if (TriggeredEvent->m_Clock.Watch() > 8.0f)
		Enemy.SetFocused(false);
}

void EventSystem::SetTrapVel(GameObject& GO)
{
	float g, t;
	g = -9.8f;
	t = 2.5f;
	XMFLOAT3 P; // = XMFLOAT3(p_mcfacade->GetObjectManager()->GetPlayer()->GetObjectTranslation());
	XMFLOAT3 O = XMFLOAT3(GO.GetObjectTranslation());

	//O.y += 5.0f;
	//P.y += 5.0f;
	XMFLOAT3 Vo;
	XMVECTOR C, Origin;
	//C = C * (-5.0f);

	Origin = XMLoadFloat3(&O);
	C = (GO.GetTrapComponent()->GetParent()->GetForwardVec() *(-10.0f)) + Origin;
	XMStoreFloat3(&P, C);
	//P.y += 15.0f;
	GO.GetAIData()->fJumpingPoint = O;
	Vo.x = (P.x - O.x) / t;
	Vo.z = (P.z - O.z) / t;
	Vo.y = -(P.y + ((1.0f * g) * (t * t)) - O.y) / t;

	GO.GetAIData()->fTempVel = Vo;
}

void EventSystem::MoveTrap(GameObject& GO)
{
	// Step 2 of 2 - Parabolic Arc:
	// This code is responsible for the actual movement of the object
	// DISCLAIMER: F.x and F.z in this code are set equal to the ObjectTranslation.x and ObjectTranslation.z respectively,
	// only for our code
	// F = Destination
	// t = Time in Air
	EventComponent * TriggeredEvent = GO.GetTrapComponent()->GetParent()->GetEventComponent();
	float t = GO.GetAIData()->m_fAirTime;
	XMFLOAT3 F;

	F.y = ((1.0f * -9.8f) * (t * t)) + (GO.GetAIData()->fTempVel.y * t) + GO.GetAIData()->fJumpingPoint.y;
	F.x = GO.GetObjectTranslation().x;
	F.z = GO.GetObjectTranslation().z;


	//if (F.y <= 0.01f && F.y >= 0.0f)
	//{
	//	Emitter* pTrailEmitter = GO.GetChildEmitterComponent(0);
	//	pTrailEmitter->SetSpawning(true);
	//}
	if ((F.y <= 0.0f && t > 0.0f) || c_pCoreFacade->IsToggledKey(VK_SPACE) || c_pCoreFacade->IsToggledKey(VK_RETURN)) //|| t >= 0.5f)
	{
		//vector<GameObject*>& Targets = pSpiderAI->AOETargets;
		c_pCoreFacade->ClearToggles();
		GO.GetPhysicsComponent()->SetVelocity(XMFLOAT2(0.0f, 0.0f));
		GO.GetPhysicsComponent()->SetForwardVelocity(0.0f);
		GO.SetObjectTranslation(F.x, 0.0f, F.z);
		GO.GetAIData()->m_fAirTime = 0.0f;
		GO.GetTrapComponent()->SetToMove(false);
	}

	else
	{
		GO.GetPhysicsComponent()->SetVelocity(XMFLOAT2(GO.GetAIData()->fTempVel.x, GO.GetAIData()->fTempVel.z));
		GO.SetObjectTranslation(F);
	}
	GO.GetAIData()->m_fAirTime += ((float)TriggeredEvent->m_Clock.Watch() * 0.25f);
	//GO.GetAIData()->m_fAirTime += TimeManager::GetTimeDelta();
	//GO.GetAIData()->fActionCooldown += (float)TimeManager::GetTimeDelta();
}