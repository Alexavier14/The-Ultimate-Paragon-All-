#pragma once
#include<string>
#include<iostream>
using namespace std;

class Logger
{
private:
	Logger();
	~Logger();

public:
	void PrintConsole(string debugtext);
	void LogToFile(string debuglogtext);

};

