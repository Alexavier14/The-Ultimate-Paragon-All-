#pragma once
#include "Logger.h"
#include <string>
#include <mutex>
using namespace std;

#if _DEBUG //Debug includes of helpers for debugging
#include <assert.h>
#else //Release includes of helpers for debugging
#endif

class GameObject;

//#include <DirectXMath.h>
using namespace DirectX;

//Macros
#define SAFE_DELETE(a) if( (a) != NULL ) delete (a); (a) = NULL;

#ifdef _DEBUG 
#define RUN_CONSOLE_PRINTING
#endif

#ifdef RUN_CONSOLE_PRINTING
#define PrintConsole printConsole
#else
#define PrintConsole __noop
#endif

//Helper Functions
void printConsole(string texttoprint);
void printConsole(string VariableName, int Value);
void printConsole(string VariableName, unsigned int Value);
void printConsole(string VariableName, float Value);
void printConsole(string VariableName, string Value);
void printConsole(string VariableName, XMFLOAT2 Value);
void printConsole(string VariableName, XMFLOAT3 Value);

static mutex WriteLogLock;
void ClearThreadLog(void);
void WriteToThreadLog(string Messgae);
void WriteObjectToThreadFile(string WhatsLocked, int ObjectLoadCount);

bool IsGeode(GameObject* GO);

wstring to_wstring(string str);

//IsShuttingDown
static bool ShutDownTriggered = false;

namespace Paragon_Renderer
{
#define ReleaseCOM(x) { if(x){ x->Release(); x = 0; } }

#if defined(DEBUG) | defined(_DEBUG)
#ifndef SetD3DName
#define SetD3DName(object, name)							\
	{															\
		if(name)												\
			object->SetPrivateData(WKPDID_D3DDebugObjectName,	\
				(UINT)strlen( name ), name );					\
	}
#endif
#else
#ifndef SetD3DName
#define SetD3DName(object, name) 
#endif
#endif 
}