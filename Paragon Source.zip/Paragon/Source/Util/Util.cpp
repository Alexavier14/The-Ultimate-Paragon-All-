#include "../Application/stdafx.h"
#include "Util.h"
#include "../Object Manager/GameObject.h"
#include <iostream>
#include <fstream>

wstring to_wstring(string str)
{
	return wstring(str.begin(), str.end());
}

void printConsole(string texttoprint)
{
	if (ShutDownTriggered == false)
	{
		string output = '\n' + texttoprint;
 		printf(output.c_str());
	}
}
void printConsole(string VariableName, int Value)
{
	//Create combined string
	string Combined = '\n' + VariableName + std::to_string(Value);
	printf(Combined.c_str());
}
void printConsole(string VariableName, unsigned int Value)
{
	//Create combined string
	string Combined = '\n' + VariableName + std::to_string(Value);
	printf(Combined.c_str());
}
void printConsole(string VariableName, float Value)
{
	//Create combined string
	string Combined = '\n' + VariableName + std::to_string(Value);
	printf(Combined.c_str());
}
void printConsole(string VariableName, string Value)
{
	//Create combined string
	string Combined = '\n' + VariableName + Value;
	printf(Combined.c_str());
}

void printConsole(string VariableName, XMFLOAT2 Value)
{
	//Create combined string
	string Combined = '\n' + VariableName + " x = " + std::to_string(Value.x) + " y = " + std::to_string(Value.y);
	printf(Combined.c_str());
}
void printConsole(string VariableName, XMFLOAT3 Value)
{
	//Create combined string
	string Combined = '\n' + VariableName + " x = " + std::to_string(Value.x) + " y = " + std::to_string(Value.y) + " z = " + std::to_string(Value.z);
	printf(Combined.c_str());
}

void ClearThreadLog()
{
	ofstream Writer;
	Writer.open("Thread_Log", ios::trunc);
	if (Writer.is_open())
	{
		Writer << "Clearing Previous File! \n Preparing to throw thread. \n";
		Writer.close();
	}
}
void WriteObjectToThreadFile(string WhatsLocked, int ObjectLoadCount)
{
	WriteLogLock.lock();
	ofstream Writer;
	Writer.open("Thread_Log", ios::app);
	if (Writer.is_open())
	{
		string Combined = '\n' + WhatsLocked + " = Current Locked Item which is the " + std::to_string(ObjectLoadCount) + " item to be loaded ";
		Writer << Combined.c_str();
		Writer.close();
	}
	WriteLogLock.unlock();
}

void WriteToThreadLog(string Messgae)
{
	WriteLogLock.lock();
	ofstream Writer;
	Writer.open("Thread_Log", ios::app);
	if (Writer.is_open())
	{
		Writer << '\n' << Messgae.c_str();
		Writer.close();
	}
	WriteLogLock.unlock();
}

bool IsGeode(GameObject* GO)
{
	if ((GO)->GetType() == eRUBYGEODE || (GO)->GetType() == eSAPPHIREGEODE || (GO)->GetType() == eDIAMONDGEODE)
		return true;
	else
		return false;
}
