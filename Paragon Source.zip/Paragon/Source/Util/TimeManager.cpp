#include "../Application/stdafx.h"

#include "TimeManager.h"

Clock TimeManager::appClock;
double TimeManager::dElapsedTime;
double TimeManager::dTimeDelta;

void TimeManager::Initialize()
{
	appClock.Start();
}

void TimeManager::Update()
{
	double dPrevTime = dElapsedTime;
	dElapsedTime = appClock.Watch();
	dTimeDelta = dElapsedTime - dPrevTime;
}

void TimeManager::Shutdown()
{

}

float TimeManager::GetElapsedTime( )
{
	return (float)dElapsedTime;
}

float TimeManager::GetTimeDelta( )
{
#if _DEBUG
	if ((float)dTimeDelta > 0.03f)
		return 0.03f;
#endif

	return (float)dTimeDelta;
}

float TimeManager::GetRawTimeDelta()
{
	return (float)dTimeDelta;
}

double TimeManager::GetElapsedTimeD( )
{
	return dElapsedTime;
}

double TimeManager::GetTimeDeltaD( )
{
	return dTimeDelta;
}

void TimeManager::ResetDelta( )
{
	dElapsedTime = appClock.Watch();
	dTimeDelta = 0.0f;
}
