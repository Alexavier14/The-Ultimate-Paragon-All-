#include "../Application/stdafx.h"

#include "Logger.h"

Logger::Logger(){}
Logger::~Logger(){}

void Print(string debugtext)
{
	printf(debugtext.c_str());
}
void LogToFile(string debuglogtext)
{
	//TODO::
}