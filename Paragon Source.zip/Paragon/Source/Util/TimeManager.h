#pragma once

#include "Clock.h"


/*
	Keeps track of the passing time in the application.
	This information can be read from any place from static methods.
	To update it one, and only one, instance of the class needs to be updated by the application.
*/
class TimeManager
{
	static Clock appClock;

public:
	void Initialize( );
	void Update( );
	void Shutdown( );

	// Static data
private:
	static double dElapsedTime;
	static double dTimeDelta;

public:
	static float GetElapsedTime( );
	static float GetTimeDelta( );
	static float GetRawTimeDelta( );

	static double GetElapsedTimeD( );
	static double GetTimeDeltaD( );

	static void ResetDelta();
};

