#pragma once

#include "CollisionShape.h"

#define HEIGHT 2.5f

namespace Physics
{

	class Circle;

	/**
	An oriented rectagle shape.
	The position variable corresponds to the center of the box.
	*/
	class OrientedBox :
		public CollisionShape
	{

		//Contains the half of the dimensions of the box. 
		//That is, width, height and depth, divided by 2
		DirectX::XMFLOAT2 hSize;

		//The normalizezd direction of the box 
		DirectX::XMFLOAT2 m_vDirection;

		public:
		virtual ~OrientedBox();

		virtual CollisionShapeType GetCollisionShapeType() const override { return OBB; };

		DirectX::XMVECTOR GetDirection() const;
		DirectX::XMVECTOR GetHalfSize() const;
		void SetDirection(DirectX::XMVECTOR direction);
		void SetHalfSize( DirectX::XMVECTOR halfSize);

		void SetSize(DirectX::XMFLOAT2 size);
		void SetSize(float x, float y);
		void SetDirection(DirectX::XMFLOAT2 dir);
		void SetDirection(float x, float y);

		virtual bool Collides(CollisionShape* other, float* toi = NULL) override;
		virtual bool Resolve(CollisionShape* other) override;


		private:

		bool CollidesWithOrientedBox(const OrientedBox& other);
		bool CollidesWithCircle(const Circle& other);


	};

};