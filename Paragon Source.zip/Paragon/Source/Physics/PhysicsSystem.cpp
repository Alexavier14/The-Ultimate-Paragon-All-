#include "../Application/stdafx.h"

#include "PhysicsSystem.h"

#include "Circle.h"
#include "Cone.h"
#include "../Object Manager/GameObject.h"
#include "../Object Manager/PhysicsComponent.h"
#include "../Util/TimeManager.h"
#include "Physics.h"

using namespace Physics;
using namespace std;

#define CIRCLE_MAX_AMOUNT 300
#define OBB_MAX_AMOUNT 150
#define SEGMENT_MAX_AMOUNT 100
#define CONE_MAX_AMOUNT 50

#define PHYSICS_COMPONENT_MAX_AMOUNT 600


//#define PHYSICS_DEBUG
#ifdef PHYSICS_DEBUG
#define PrintConsoleM PrintConsole
#else
#define PrintConsoleM __noop
#endif

PhysicsSystem::PhysicsSystem( )
{
	m_CircleArray.resize( CIRCLE_MAX_AMOUNT );
	m_OrientedBoxArray.resize( OBB_MAX_AMOUNT );
	m_SegmentArray.resize( SEGMENT_MAX_AMOUNT );
	m_ConeArray.resize(CONE_MAX_AMOUNT);
	m_PhysicsCompArray.resize( PHYSICS_COMPONENT_MAX_AMOUNT );

#if _DEBUG
	RenderCollisionCircles = true;
#else
	RenderCollisionCircles = true;
#endif

	RenderCollisionOBB = false;
	RenderCollisionSegments = false;
	RenderCollisionCones = false;
}
PhysicsSystem::~PhysicsSystem( )
{
}

// ---------------
// --- Methods ---
// ---------------


void PhysicsSystem::Update( )
{

	ClearShapeData();
	UpdateShapeData();

	CircleToCircleCheck();
	SolveContacts();

	CircleToObbCheck( );
	ConeToCircleCheck( );
	SegmentToCircleCheck( );
	SegmentToObbCheck( );
	AdvanceSimulation( );

	UpdateObjects();
}


// ---------------
// --- Factory ---
// ---------------

Circle* PhysicsSystem::MakeCircleShape( ResolutionType resolutionType )
{
	for ( size_t i = 0; i < CIRCLE_MAX_AMOUNT; i++ )
	{
		Circle& circle = m_CircleArray[i];
		if ( circle.IsAvailable( )  )
		{
			circle.SetActive( true );
			circle.SetAvailable( false );
			circle.SetResolutionType( resolutionType );
			return &circle;

		}
	}
	PrintConsoleM( "Overflown Circle Shape Pool. Size = ", CIRCLE_MAX_AMOUNT );
	return NULL;
}
OrientedBox* PhysicsSystem::MakeOBBShape( ResolutionType resolutionType )
{
	for ( size_t i = 0; i < OBB_MAX_AMOUNT; i++ )
	{
		OrientedBox& obb = m_OrientedBoxArray[i];
		if ( obb.IsAvailable( ) )
		{
			obb.SetActive( true );
			obb.SetAvailable( false );
			obb.SetResolutionType( resolutionType );

			return &obb;

		}
	}
	PrintConsoleM( "Overflown OBB Shape Pool. Size = ", OBB_MAX_AMOUNT );
	return NULL;
}
Segment* PhysicsSystem::MakeSegmentShape( ResolutionType resolutionType )
{
	for ( size_t i = 0; i < SEGMENT_MAX_AMOUNT; i++ )
	{
		Segment& segment = m_SegmentArray[i];
		if ( segment.IsAvailable( ) )
		{
			segment.SetActive( true );
			segment.SetAvailable( false );
			segment.SetResolutionType( resolutionType );

			return &segment;

		}
	}
	PrintConsoleM( "Overflown Segment Shape Pool. Size = ", SEGMENT_MAX_AMOUNT );
	return NULL;
}
Cone* PhysicsSystem::MakeConeShape(Physics::ResolutionType resolutionType, float angle, float radius)
{
	for (size_t i = 0; i < CONE_MAX_AMOUNT; i++)
	{
		Cone& cone = m_ConeArray[i];
		if (cone.IsAvailable())
		{
			cone.SetActive(true);
			cone.SetAvailable(false);
			cone.SetResolutionType(resolutionType);

			angle = XMConvertToRadians(angle);
			cone.SetRadius(radius);
			cone.SetAngle(angle);

			angle *= 0.5f;
			float x_Offset = cosf(angle);
			float y_Offset = sinf(angle);
			cone.SetUnitEdges(XMFLOAT2(-x_Offset, y_Offset), XMFLOAT2(x_Offset, y_Offset));

			return &cone;

		}
	}
	PrintConsoleM("Overflown Segment Shape Pool. Size = ", CONE_MAX_AMOUNT);
	return NULL;
}
PhysicsComponent* PhysicsSystem::MakePhysicsCompoment( GameObject* pHolder )
{
	for ( size_t i = 0; i < PHYSICS_COMPONENT_MAX_AMOUNT; i++ )
	{
		PhysicsComponent& physicsComp = m_PhysicsCompArray[i];
		if ( physicsComp.IsAvailable() )
		{
			physicsComp.Reset( );
			physicsComp.SetActive( true );
			physicsComp.SetAvailable( false );
			physicsComp.SetHolder( pHolder );

			return &physicsComp;
		}
	}
	return NULL;
}


std::vector<Physics::Circle> & PhysicsSystem::GetCircleCollisionShapes( )
{
	return this->m_CircleArray;
}
std::vector<Physics::OrientedBox> & PhysicsSystem::GetOrientedBoxCollisionShapes( )
{
	return this->m_OrientedBoxArray;
}
std::vector<Physics::Segment> & PhysicsSystem::GetSegmentCollisionShapes( )
{
	return this->m_SegmentArray;
}
std::vector<Physics::Cone> & PhysicsSystem::GetConeCollisionShapes( )
{
	return this->m_ConeArray;
}


float PhysicsSystem::RayCast(XMVECTOR start, XMVECTOR direction)
{
	float minLength = FLT_MAX;
	for ( size_t i = 0; i < CIRCLE_MAX_AMOUNT; i++ )
	{
		Circle& circle = m_CircleArray[i];
		if ( !circle.IsActive( ) ) continue;

		XMVECTOR circleCenter = circle.GetPosition();
		float circleRadius = circle.GetRadius();
		XMVECTOR intersection = IntersectRaySphere(circleCenter, circleRadius, direction, start);
		float intersectionLength = XMCVector3LengthSq(intersection);
		if (intersectionLength < minLength)
			minLength = intersectionLength;
	}
	return minLength;
}


// ---------------
// --- Helpers ---
// ---------------

void PhysicsSystem::CircleToCircleCheck( )
{
	for ( size_t i = 0; i < CIRCLE_MAX_AMOUNT; i++ )
	{
		Circle& circle = m_CircleArray[i];
		if ( !circle.IsActive( ) ) continue;

		CheckAgainstCircles( &circle, true, i + 1 );
	}
}

void PhysicsSystem::CircleToObbCheck( )
{
	for ( size_t i = 0; i < CIRCLE_MAX_AMOUNT; i++ )
	{
		Circle& circle = m_CircleArray[i];
		if ( !circle.IsActive( ) ) continue;

		CheckAgainstObbs(&circle);
	}
}

void PhysicsSystem::ConeToCircleCheck()
{
	for (size_t i = 0; i < CONE_MAX_AMOUNT; i++)
	{
		Cone& cone = m_ConeArray[i];
		if (!cone.IsActive()) continue;

		CheckAgainstCircles(&cone, true);
	}
}


void PhysicsSystem::SegmentToCircleCheck( )
{
	for ( size_t i = 0; i < SEGMENT_MAX_AMOUNT; i++ )
	{
		Segment& segment = m_SegmentArray[i];
		if ( !segment.IsActive( ) ) continue;

		CheckAgainstCircles( &segment, true );
	}
}

void PhysicsSystem::SegmentToObbCheck()
{
	for ( size_t i = 0; i < SEGMENT_MAX_AMOUNT; i++ )
	{
		Segment& segment = m_SegmentArray[i];
		if ( !segment.IsActive( ) ) continue;

		CheckAgainstObbs(&segment);
	}
}


void PhysicsSystem::CheckAgainstCircles( CollisionShape* shape, bool addDetected, size_t startIndex, CollisionShape* excluded )
{
	for ( size_t i = startIndex; i < CIRCLE_MAX_AMOUNT; i++ )
	{
		Circle& circle = m_CircleArray[i];
		if ( !circle.IsActive( ) ) continue;
		if ( shape->GetGameObjectHolder( ) == circle.GetGameObjectHolder( ) ) continue;
		if( &circle == excluded ) continue;

		float toi;

		if ( shape->Collides( &circle, &toi ) )
		{
			if ( addDetected )
			{
				shape->AddDetectedShape( &circle );
				circle.AddDetectedShape( shape );
			}
			if ( shape->WillResolveWith( &circle ) )
				AddContact( Contact( shape, &circle, toi ) );
		}
	}
}
void PhysicsSystem::CheckAgainstObbs( Physics::CollisionShape* shape )
{
	for ( size_t i = 0; i < OBB_MAX_AMOUNT; i++ )
	{
		OrientedBox& box = m_OrientedBoxArray[i];
		if ( !box.IsActive( ) ) continue;
		if ( shape->GetGameObjectHolder( ) == box.GetGameObjectHolder( ) ) continue;

		if ( shape->Collides( &box  ) )
		{
			shape->AddDetectedShape( &box );
			box.AddDetectedShape( shape );
			shape->Resolve( &box );
		}
	}
}

void PhysicsSystem::SolveContacts( )
{
	const int MAX_CHECKS = 30;
	int numChecks = 0;
	unsigned int ContactListTotal = m_ContactList.size();

	float delta = TimeManager::GetTimeDelta();

	PrintConsoleM("Solving contacts -------");

	if( m_ContactList.size() > MAX_CHECKS  )
		PrintConsoleM("Many Contacts found");

	while ( !m_ContactList.empty( ) )
	{
		
		m_ContactList.sort( 
			[]( Contact& left, Contact& right )
		{
			return left.toi < right.toi;
		} );
		
		Contact contact = m_ContactList.front( );
		PrintConsoleM( "Solving Contact. TOI = " + FloatToString( contact.toi, 20 ) + ". Iteration " + to_string(numChecks));
		m_ContactList.pop_front( );

		if(contact.toi > delta)
			break;

		//contact.toi = max( contact.toi + delta*0.25f, 0.0f );
		contact.toi = max( contact.toi, 0.0f );

		//Synchronize the shapes to the toi
		contact.shapeA->GetPhysicsComponentHolder( )->AdvanceSimulationTo( contact.toi );
		contact.shapeB->GetPhysicsComponentHolder( )->AdvanceSimulationTo( contact.toi );

		contact.shapeA->Resolve( contact.shapeB );

		//Remove invalid contacts
		RemoveContactsWith( contact.shapeA );
		RemoveContactsWith( contact.shapeB );

		//Re-check contacts
		CheckAgainstCircles( contact.shapeA, false, 0, contact.shapeB);
		CheckAgainstCircles( contact.shapeB, false, 0, contact.shapeA);

		contact.shapeA->AddContact(contact);
		contact.shapeB->AddContact(contact);

		if (++numChecks > MAX_CHECKS)
		{
			PrintConsoleM( "Reached Collision Check Max" );
			break;
		}
	}
	PrintConsoleM( "Number of contacts solved: ", numChecks );

	m_ContactList.clear();
}

void PhysicsSystem::AddContact( Contact& contact )
{
	// Remove pre-existing
	/*
	m_ContactList.remove_if(
		[&contact]( Contact& item )
	{
		return item.shapeA == contact.shapeA
			&& item.shapeB == contact.shapeB;
	} );
	*/

	//Add to the correct position in the list, based on toi
	/*
	for ( auto it = m_ContactList.cbegin( ); it != m_ContactList.cend( ); ++it )
	{
		const Contact& item = *it;
		if ( item.toi > contact.toi )
		{
			m_ContactList.emplace( it, contact );
			return;
		}
	}
	*/

	//Add at the end of the list.
	m_ContactList.emplace_front( contact );


}

void PhysicsSystem::RemoveContactsWith( Physics::CollisionShape* shape )
{
	m_ContactList.remove_if(
		[shape]( Contact& item )
	{
		return ( item.shapeA == shape || item.shapeB == shape );
	} );
}

void PhysicsSystem::AdvanceSimulation( )
{
	for ( size_t i = 0; i < PHYSICS_COMPONENT_MAX_AMOUNT; i++ )
	{
		PhysicsComponent& component = m_PhysicsCompArray[i];
		if ( component.IsActive( ) )
			component.AdvanceSimulationTo( TimeManager::GetTimeDelta( ) );
	}
}

void PhysicsSystem::UpdateObjects( )
{
	for ( size_t i = 0; i < PHYSICS_COMPONENT_MAX_AMOUNT; i++ )
	{
		PhysicsComponent& component = m_PhysicsCompArray[i];
		if ( component.IsActive( ) )
			component.Update( );
	}
}


void PhysicsSystem::ClearShapeData( )
{
	m_ContactList.clear( );
	for ( size_t i = 0; i < CIRCLE_MAX_AMOUNT; i++ )
	{
		Circle& circle = m_CircleArray[i];
		if ( !circle.IsActive( ) )	continue;

		circle.ClearDetectionList( );
		circle.ClearContactList( );
		circle.SetFrameTime( 0 );
	}

		for ( size_t i = 0; i < OBB_MAX_AMOUNT; i++ )
	{
		OrientedBox& obb = m_OrientedBoxArray[i];
		if ( !obb.IsActive( ) )	continue;

		obb.ClearDetectionList( );
		obb.SetFrameTime( 0 );
	}


	for (size_t i = 0; i < SEGMENT_MAX_AMOUNT; i++)
	{
		Segment& segment = m_SegmentArray[i];
		if (!segment.IsActive())	continue;

		segment.ClearDetectionList();
		segment.SetFrameTime(0);
	}

	for (size_t i = 0; i < CONE_MAX_AMOUNT; i++)
	{
		Cone& cone = m_ConeArray[i];
		if (!cone.IsActive())	continue;

		cone.ClearDetectionList();
		cone.SetFrameTime(0);
	}

}

void PhysicsSystem::UpdateShapeData()
{
	for (size_t i = 0; i < CONE_MAX_AMOUNT; i++)
	{
		Cone& cone = m_ConeArray[i];
		if (!cone.IsActive())	continue;

		cone.UpdateEdges();
	}
}

void PhysicsSystem::CheckAllColisions(CollisionShape* pShape, bool onlyResolvingBounds)
{
	pShape->ClearDetectionList();
	pShape->ClearContactList();

	for ( size_t i = 0; i < OBB_MAX_AMOUNT + CIRCLE_MAX_AMOUNT; i++ )
	{
		CollisionShape* pOther;
		if( i < OBB_MAX_AMOUNT)
			pOther = &m_OrientedBoxArray[i];
		else
			pOther = &m_CircleArray[i - OBB_MAX_AMOUNT];

		if ( !pOther->IsActive( ) ) continue;
		if ( pShape->GetGameObjectHolder( ) == pOther->GetGameObjectHolder( ) ) continue;
		if ( onlyResolvingBounds && (pOther->GetShapeUsage() != SU_BOUNDING_SHAPE || pOther->GetResolutionType( ) == RT_NONE )) continue;

		if ( pShape->Collides( pOther ) )
			pShape->AddDetectedShape( pOther );
	}
}