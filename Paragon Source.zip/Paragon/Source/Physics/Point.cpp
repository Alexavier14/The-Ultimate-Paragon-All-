#include "../Application/stdafx.h"

#include "Point.h"

#include "Circle.h"
#include "../Util/TimeManager.h"

using namespace DirectX;

namespace Physics
{
	Point::Point( )
	{
	}

	Point::~Point( )
	{
	}


	bool Point::Collides( CollisionShape*  other, float* toi )
	{
		if (other == nullptr)
			return false; 

		if( this->GetShapeUsage() != SU_BOUNDING_SHAPE && other->GetShapeUsage() != SU_BOUNDING_SHAPE )
			return false;

		switch ( other->GetCollisionShapeType( ) )
		{
		case CIRCLE:
			return CollidesWithCircle( *dynamic_cast<const Circle*>( other ) );

		}
		return false;
	}



	bool Point::CollidesWithCircle( const Circle& other )
	{
		float delta = (float) TimeManager::GetTimeDelta( );

		const float r = other.radius;

		XMVECTOR posA = this->GetPosition( );
		XMVECTOR posB = other.GetPosition( );
		XMVECTOR velA = this->GetVelocity( );
		XMVECTOR velB = other.GetVelocity( );

		posA = XMVectorAdd( posA, XMVectorScale( velA, delta ) );
		posB = XMVectorAdd( posB, XMVectorScale( velB, delta ) );

		XMVECTOR posMK = XMVectorSubtract( posA, posB );

		float distSq;
		XMStoreFloat( &distSq, XMVector2LengthSq( posMK ) );

		if ( distSq > r*r )
			return false;

		return true;
	}

}
