#pragma once
#include "CollisionShape.h"

namespace Physics
{
	class Triangle;
	class OrientedBox;


	class Circle :
		public CollisionShape
	{


		public:
		
		//The Circle's radius
		float radius;	

		Circle( );
		~Circle( );


		virtual CollisionShapeType GetCollisionShapeType( ) const override { return CIRCLE; };
		virtual bool Collides( CollisionShape* other, float* toi = NULL  ) override;
		virtual bool Resolve( CollisionShape* other ) override;
		virtual void SolveContacts( ) override;


		float GetRadius() const;
		void SetRadius(float radius);

		private:
		
		bool CollidesWithCircle( Circle& other, float* toi = NULL  );
		bool CollidesWithOrientedBox( OrientedBox& other, float* toi = NULL  );
		bool CollidesWithTriangle( Triangle& other, float* toi = NULL  );

		bool ResolveWithCircle( Circle& other );
		bool ResolveWithOrientedBox( OrientedBox& other );


	};

};