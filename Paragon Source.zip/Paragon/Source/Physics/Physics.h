#pragma once

#include "../Application/stdafx.h"

#include "../Util/TimeManager.h"

//Collision Shapes

#include "Segment.h"
#include "OrientedBox.h"
#include "Circle.h"
#include "Cone.h"




namespace Physics
{
	// Intersection Queries

	//Finds the intersection between a ray and a plane
	//Param planeN: 3D Vector for the normal of the plane
	//Param planeD: float for the distance from the plane to the origing
	//Param rayDir: 3D Vector for the direction of the ray
	//Param rayOrigin: 3D Vector for the origin of the ray
	//Return: 3D Vector for the intersection point or rayOrigin if there is no intersection
	XMVECTOR IntersectRayPlane( XMVECTOR planeN, float planeD, XMVECTOR rayDir, XMVECTOR rayOrigin );


	//Finds the intersection between a ray and a circle
	//Param sphereCenter: 3D Vector for the center of the circle
	//Param sphereRadius: float for the distance from the plane to the origing
	//Param rayDir: 3D Vector for the direction of the ray
	//Param rayOrigin: 3D Vector for the origin of the ray
	//Return: 3D Vector for the intersection point or rayOrigin if there is no intersection
	XMVECTOR IntersectRaySphere( XMVECTOR sphereCenter, float sphereRadius, XMVECTOR rayDir, XMVECTOR rayOrigin );


	//Finds the closest point from a point to a specified obb. 
	//Param point: 3D Vector for the worldspace position of the point whose distance to the box is going to be checked.
	//Param centerOBB: 3D Vector for worldspace position of the center of the OBB.
	//Param extents: 3 3D Vectors containing the extents of the box in world space.
	//Return: The closest point on the box.
	XMVECTOR ClosestPointOnOBB( XMVECTOR point, XMVECTOR centerOBB, XMVECTOR extents[3]);
	
	
	//Finds the closest point from a point to the outside of an obb. 
	//Param point: 3D Vector for the worldspace position of the point whose distance to the box is going to be checked.
	//Param centerOBB: 3D Vector for worldspace position of the center of the OBB.
	//Param extents: 3 3D Vectors containing the extents of the box in world space.
	//Return: The closest point on the box.	
	XMVECTOR ClosestPointOutOfOBB( XMVECTOR point, XMVECTOR centerOBB, XMVECTOR extents[3]);
	
	bool IsPointOnOBB( const XMVECTOR& point, const XMVECTOR& centerOBB, XMVECTOR extents[3]);


	// Returns wether the specified circle and aabb intersect.
	// All arguments are 2D vectors.
	bool IntersectCircleAABB(  const XMVECTOR& sphereCenter, float sphereRadius, const XMVECTOR& aabbCenter, const XMVECTOR& aabbExtents ); 

	// Returns wether the specified ray and aabb intersect.
	// All arguments are 2D vectors.
	bool IntersectRayAABB( const XMFLOAT2& rayOrigin, const XMFLOAT2& rayDir, const XMFLOAT2& aabbCenter, const XMFLOAT2&aabbExtents ); 
	
	// Returns wether the specified point is within the circle
	// All arguments are 2D vectors.
	bool IntersectPointCircle( const XMVECTOR& pointPos, const XMVECTOR& sphereCenter, float sphereRadius ); 


	// --- Random Functions ---

	float UnitRand();
	float SignedUnitRand();

	// Helper functions for directX

	XMVECTOR XMCUnitVector2( float orientation ); // create a vector with the specified orientation

	float XMCVector2Length( const XMVECTOR& vector );
	float XMCVector3Length( const XMVECTOR& vector );

	float XMCVector2LengthSq( const XMVECTOR& vector );
	float XMCVector3LengthSq( const XMVECTOR& vector );

	float XMCVector2Dot( const XMVECTOR& vectorA, const XMVECTOR& vectorB);
	float XMCVector3Dot( const XMVECTOR& vectorA, const XMVECTOR& vectorB );

	XMFLOAT2 XMCVector2GetXZ( const XMVECTOR& vector );
	XMFLOAT3 XMCVector3GetXZ( const XMVECTOR& vector, float y = 0.0f );
	XMVECTOR XMCVector3LoadXZ( const XMFLOAT2& float2, float y = 0 );
	XMVECTOR XMCVector2LoadXZ( const XMFLOAT3&  float3 );
	XMVECTOR XMCVector3SwizzleXZ( const XMVECTOR& vector );	// Returns a 2D vector that replaces the y-component with the z-component. result = <vector.x,vector.z, vecctor.w, vecctor.w>
	XMVECTOR XMCVector2SwizzleXZ( const XMVECTOR& vector );	// Returns a 3D vector that replaces the z-component with the y-component. result = <vector.x,vector.w, vecctor.y, vecctor.w>

	XMFLOAT2 XMCStoreFloat2( const XMVECTOR& vector );
	XMFLOAT3 XMCStoreFloat3( const XMVECTOR& vector );
	XMFLOAT4 XMCStoreFloat4( const XMVECTOR& vector );
	XMFLOAT4X4 XMCStoreFloat4x4( const XMMATRIX& matrix );

	XMVECTOR XMCLoadFloat2( float x, float y );
	XMVECTOR XMCLoadFloat3( float x, float y, float z );
	XMVECTOR XMCLoadFloat4( float x, float y, float z, float w );

	XMVECTOR XMCRandomUnitVector2();
	XMVECTOR XMCRandomUnitVector3();

	XMVECTOR XMCRotateVector2(XMVECTOR vector, float angle);



	//Clamps values in the vector to be within the _min and _max values.
	void XMCClamp(XMVECTOR & _value, float _min = 0.0f, float _max = 1.0f);
	//Clamps single values to be within the _min and _max values.
	void XMCClamp(float & _value, float _min = 0.0f, float _max = 1.0f);
	
	extern const float EPSILON;
	extern const float EPSILON_DIST; // Number used to approximate distance values
	extern const float EPSILON_SPEED; // Number used to approximate speed values
	extern const float EPSILON_TIME; // Number used to approximate time values
	
	bool FloatEquals(float a, float b, float e = EPSILON);			// a == b ?
	bool FloatGreater(float a, float b, float e = EPSILON);			// a > b ?
	bool FloatLess(float a, float b, float e = EPSILON);			// a < b ?
	bool FloatGreaterEquals( float a, float b, float e = EPSILON);	// a >= b ?
	bool FloatLessEquals( float a, float b, float e = EPSILON);		// a <= b ?

	std::string FloatToString( float a, int n = 6);
	std::wstring FloatToWString( float a, int n = 6);
	std::string FixedFloatToString( float a, int integers, int decimals);
	std::wstring FixedFloatToWString( float a, int integers, int decimals);

	std::string VectorToString( XMVECTOR vector, int n = 6 );

};