#pragma once
#include "CollisionShape.h"

namespace Physics
{
	class Circle;
	class OrientedBox;

	/**
	A collidable line segment.
	Its position and variable correspond to one of the ends of the segment.
	The other end can be obtained by adding extent to the position
	*/
	class Segment :
		public CollisionShape
	{
		
		// The distance from the end of the segment, that corresponds to position, to the other end
		DirectX::XMFLOAT2 m_vExtent; 
		//DirectX::XMFLOAT2 m_vExtentRotated; 

		bool m_bRotating; //If this setting is true, the segment will rotate with its owner

		public:

		virtual ~Segment( );

		virtual CollisionShapeType GetCollisionShapeType( ) const override { return SEGMENT; };
		virtual bool Collides( CollisionShape* other, float* toi = NULL) override;
		virtual bool Resolve( CollisionShape* other ) override;


		virtual DirectX::XMVECTOR	GetPosition( ) const; // A 2D Vector with the position Value

		const DirectX::XMFLOAT2& GetExtent() const;
		DirectX::XMVECTOR GetRotatedExtent() const; // Gets the extent as a 3D vector that rotates along the holders transform
		DirectX::XMVECTOR GetRotatedOffset() const; // Gets the offset as a 3D vector that rotates along the holders transform

		void SetExtent( DirectX::XMFLOAT2 extent );
		void SetRotating(bool rotating);


		XMVECTOR Intersection( const CollisionShape* pShape );
		XMVECTOR BoxIntersection( const OrientedBox& box );
		XMVECTOR CircleIntersection( const Circle& circle );


		private:
		bool CollidesWithSegment( Segment& other );
		bool CollidesWithCircle( Circle& other );
		bool CollidesWithOrientedBox( OrientedBox& other );
	};

};