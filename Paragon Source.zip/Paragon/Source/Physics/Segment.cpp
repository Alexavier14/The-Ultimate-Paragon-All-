#include "../Application/stdafx.h"

#include "Segment.h"

#include "Circle.h"
#include "../Util/TimeManager.h"
#include "Physics.h"
#include "../Object Manager/PhysicsComponent.h"
#include "../Object Manager/GameObject.h"

#include <cmath>

using namespace Physics;
using namespace DirectX;

Segment::~Segment( )
{
}

XMVECTOR Segment::GetPosition() const
{
	XMVECTOR position = XMLoadFloat2( &m_pPhysicsComponent->GetPosition( ) );
	return  position + GetRotatedOffset();
}

void Segment::SetExtent( XMFLOAT2 extent )
{
	m_vExtent = extent;
}

const DirectX::XMFLOAT2& Segment::GetExtent( ) const
{
	return m_vExtent;
}
void Segment::SetRotating(bool rotating)
{
	m_bRotating = rotating;
}


DirectX::XMVECTOR Segment::GetRotatedExtent( ) const
{
	if( !m_bRotating)
		return XMLoadFloat2( &m_vExtent );

	XMMATRIX transform = GetGameObjectHolder( )->GetWorldTransformMat( );
	XMVECTOR extent = XMCVector2SwizzleXZ( XMLoadFloat2( &m_vExtent ) );
	XMVECTOR rotExtent = XMVector3TransformNormal(extent,transform);
	return XMCVector3SwizzleXZ(rotExtent);
}

DirectX::XMVECTOR Segment::GetRotatedOffset( ) const
{
	XMMATRIX transform = GetGameObjectHolder( )->GetWorldTransformMat( );
	XMVECTOR offset = XMCVector2SwizzleXZ( XMLoadFloat2( &m_vOffset ) );
	XMVECTOR rotOffset = XMVector3TransformNormal(offset,transform);
	return XMCVector3SwizzleXZ(rotOffset);
}


bool Segment::Collides( CollisionShape* other, float* toi )
{

	if ( this->GetGameObjectHolder() == other->GetGameObjectHolder() )
		return false;

	switch ( other->GetCollisionShapeType( ) )
	{
	case SEGMENT:	return CollidesWithSegment( *dynamic_cast<Segment*>( other ) );
	case CIRCLE:	return CollidesWithCircle( *dynamic_cast<Circle*>( other ) );
	case OBB:		return CollidesWithOrientedBox( *dynamic_cast<OrientedBox*>( other ) );
	}
	return false;
}

bool Segment::Resolve( CollisionShape* other )
{
	// TODO 
	return false;
}

bool Segment::CollidesWithSegment( Segment& other )
{
	//TODO
	return false;
}

bool Segment::CollidesWithCircle( Circle& other )
{
	float delta = (float) TimeManager::GetTimeDelta( );

	XMVECTOR start = this->GetPosition( ) + this->GetVelocity( )*delta;
	XMVECTOR center = other.GetPosition( ) + other.GetVelocity( )*delta;
	XMVECTOR M = center - start;
	XMVECTOR D = GetRotatedExtent();
	float d = XMCVector2Length(D);
	XMVECTOR end = start + D;
	XMVECTOR D_n = D/d; // Normalized ray direction
	float c = XMCVector2Dot(M, D_n); // Distance from ray start to closest point 
	XMVECTOR C; // Closest point on ray
	if( c < 0 )
		C = start;
	else if ( c > d )
		C = end;
	else 
		C = start + D_n*c;

	XMVECTOR S = center - C;
	float s = XMCVector2Length(S);
	if( s > other.radius )
		return false;
	else 
		return true;

}

bool Segment::CollidesWithOrientedBox(OrientedBox& other)
{
	XMVECTOR boxPos = other.GetPosition();
	XMVECTOR N = other.GetDirection();
	XMVECTOR Np = XMVector2Orthogonal(N);

	XMVECTOR rayPos = GetPosition();
	XMVECTOR D_Dir = GetRotatedExtent()*0.5f;
	XMVECTOR M_Pos = rayPos - boxPos + D_Dir;
	XMFLOAT2 M, D; 
	M.x = XMCVector2Dot( M_Pos, N );
	M.y = XMCVector2Dot( M_Pos, Np );
	D.x = XMCVector2Dot( D_Dir, N );
	D.y = XMCVector2Dot( D_Dir, Np );
	XMFLOAT2 HS = XMCStoreFloat2( other.GetHalfSize() );

	if( abs(M.x) > HS.x + abs(D.x) ) return false;
	if( abs(M.y) > HS.y + abs(D.y) ) return false;
	
	if( abs(M.x*D.y - M.y*D.x) > HS.x*abs(D.y) + HS.y*abs(D.x) ) return false;
	
	return true;
}

XMVECTOR Segment::Intersection(const CollisionShape* pShape)
{
	switch (pShape->GetCollisionShapeType())
	{
		case OBB: return BoxIntersection( *dynamic_cast<const OrientedBox*>(pShape) );
		case CIRCLE: return CircleIntersection( *dynamic_cast<const Circle*>(pShape) );
	}
	return GetPosition();
}


XMVECTOR Segment::BoxIntersection(const OrientedBox& box)
{
	XMVECTOR boxPos = box.GetPosition();
	XMVECTOR N = box.GetDirection();
	XMVECTOR Np = XMVector2Orthogonal(N);

	XMVECTOR rayPos = GetPosition();
	XMVECTOR posMk = rayPos - boxPos;
	XMVECTOR rayExtent = GetRotatedExtent();
	XMVECTOR rayDir = XMVector2Normalize(rayExtent);
	XMFLOAT2 O, D; 


	O.x = XMCVector2Dot( posMk, N );
	O.y = XMCVector2Dot( posMk, Np );
	D.x = XMCVector2Dot( rayDir, N );
	D.y = XMCVector2Dot( rayDir, Np );
	XMFLOAT2 HS = XMCStoreFloat2( box.GetHalfSize() );

	float tMin = -FLT_MAX;
	float tMax = +FLT_MAX;


	if (D.x != 0)
	{
		float tx1 = ( HS.x - O.x )/D.x;
		float tx2 = ( -HS.x - O.x )/D.x;

		tMin = max(tMin, min(tx1, tx2));
		tMax = min(tMax, max(tx1, tx2));
	}

	if (D.y != 0)
	{
		float ty1 = ( HS.y - O.y )/D.y;
		float ty2 = ( -HS.y - O.y )/D.y;

		tMin = max(tMin, min(ty1, ty2));
		tMax = min(tMax, max(ty1, ty2));
	}

	return rayPos + rayDir*tMin;
}

XMVECTOR Segment::CircleIntersection(const Circle& circle)
{
	// Adapted from: http://www.scratchapixel.com/lessons/3d-basic-lessons/lesson-7-intersecting-simple-shapes/ray-sphere-intersection/

	XMVECTOR rayPos = GetPosition();
	XMVECTOR rayDir = XMVector2Normalize(GetRotatedExtent());
	XMVECTOR circlePos = circle.GetPosition();
	float radius = circle.GetRadius();
	float r2 = radius*radius;

	XMVECTOR posMk = circlePos - rayPos;
	float p2 = XMCVector2LengthSq(posMk);

	float x = XMCVector2Dot(posMk,rayDir); // x = |P - O|, with P being the closest point to circle on ray, and O being tha ray's origin 
	float d2 = p2 - x*x;		//squared closest distance between ray and circle
	float c = sqrt(r2 - d2);
	float t = x - c;

	return rayPos + t*rayDir;
}
