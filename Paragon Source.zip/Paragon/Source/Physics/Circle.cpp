#include "../Application/stdafx.h"

#include "Circle.h"

#include "Physics.h"

#include "../Object Manager/PhysicsComponent.h"
using namespace Physics;

#include "../Util/TimeManager.h"
using namespace DirectX;

#include "../Object Manager/GameObject.h"


//#define PHYSICS_DEBUG
#ifdef PHYSICS_DEBUG
#define PrintConsoleM PrintConsole
#else
#define PrintConsoleM __noop
#endif

#if _DEBUG
#define SEPARATION_IMPULSE 80.0f
#else
#define  SEPARATION_IMPULSE 150.0f
#endif


Circle::Circle( )
{
	radius = 0;
}


Circle::~Circle( )
{
}


float Circle::GetRadius( ) const
{
	return radius;
}

void Circle::SetRadius( float radius )
{
	this->radius = radius;
}

bool Circle::Collides( CollisionShape* other, float* toi )
{
	if (other == nullptr)
		return false;

	if ( this->GetGameObjectHolder() == other->GetGameObjectHolder() )
		return false;

	if( this->GetShapeUsage() != SU_BOUNDING_SHAPE && other->GetShapeUsage() != SU_BOUNDING_SHAPE )
		return false;

	switch ( other->GetCollisionShapeType( ) )
	{
	case CIRCLE:
		return CollidesWithCircle( *dynamic_cast<Circle*>( other ), toi );
	case OBB:
		return CollidesWithOrientedBox( *dynamic_cast<OrientedBox*>( other ), toi );
	}
	return false;
}



bool Circle::CollidesWithCircle( Circle& other, float* toi )
{


	const float rMk = this->radius + other.radius;

	float timeA = this->GetFrameTime( );
	float timeB = this->GetFrameTime( );

	float maxTime = max( timeA, timeB ); // Objects are synchronized at this time
	float dt = TimeManager::GetTimeDelta( ) - maxTime;

	XMVECTOR velA = this->GetVelocity( );
	XMVECTOR velB = other.GetVelocity( );
	XMVECTOR velMk = velB - velA;			// Relative velocity
	float velMk_m = XMCVector2Length( velMk );

	XMVECTOR posA = this->GetPosition( ) + velA*( maxTime - timeA );
	XMVECTOR posB = other.GetPosition( ) + velA*( maxTime - timeB );
	XMVECTOR posMk = posB - posA;			// Relative position

	float posMk_mSq = XMCVector2LengthSq( posMk );
	float rMkSq = rMk*rMk;

	//const string& thisTag = this->GetGameObjectHolder( )->GetTag( );
	//const string& othrTag = other.GetGameObjectHolder( )->GetTag( );

	// Simple collision check for collisions that don't need to resolve.
	if ( !WillResolveWith( &other ) )
	{
		if ( posMk_mSq < rMkSq )
			return true;
		else
			return false;
	}

	if ( posMk_mSq < rMkSq )
	{
		//PrintConsoleM( "Penetration at Detect ----" );
		//PrintConsoleM( "between " + thisTag + " and " + othrTag + "." );
		//PrintConsoleM( "PosMk_m = " + FloatToString( posMk_m, 10 ) );
		if ( toi )
		{
			float posMk_m = sqrtf(posMk_mSq);
			dt = (rMk - posMk_m)/SEPARATION_IMPULSE;
			//dt = 0;
			*toi = maxTime - dt;
		}
		return true;

		// Posible solution to handle penetration
		// Resolve the penetration as it happens, but don't report it (return false).
		// Since the toi is negative, this resolution will be done at the appropiate time
	}


	XMVECTOR moveMk = velMk*dt;
	float moveMk_m = XMCVector2Length( moveMk );
	float posMk_m = sqrtf(posMk_mSq);

	if ( posMk_m - rMk >= moveMk_m )
		return false;	// Proximity check

	if ( XMCVector2Dot( posMk, velMk ) > 0 )
	{
		return false; // Moving away
	}

	XMVECTOR velMk_n = XMVector2Normalize( velMk );
	float posMk_v = XMCVector2Dot( posMk, -velMk_n );	// distance along the velocity's direction
	float posMk_vp = sqrt( posMk_mSq - posMk_v*posMk_v ); // distance perperndicular to velocity (distance at closest point)


	if ( posMk_vp > rMk )
	{
		return false;	// spheres won't ever get close enough to collide
	}

	float posC_v = posMk_v - sqrt( rMk*rMk - posMk_vp*posMk_vp ); // Distance to collision

	if ( posC_v > moveMk_m )
	{
		return false; // Collision distance is not reached.
	}
	if ( toi )
	{
		*toi = maxTime + dt * posC_v / moveMk_m;
		if ( *toi < maxTime )
		{
			//*toi = maxTime;
		}
		else
		{
			*toi -= ( *toi - maxTime )*0.0001f;
		}
		PrintConsoleM( "TOI: ", *toi );
	}

	return true;

}

bool Circle::CollidesWithOrientedBox( OrientedBox& other, float* toi )
{

	XMVECTOR posA = this->GetPosition( );
	XMVECTOR posB = other.GetPosition( );
	XMVECTOR posMK = posB - posA;



	float delta = (float) TimeManager::GetTimeDelta( );

	XMVECTOR velA = this->GetVelocity( );
	XMVECTOR velB = other.GetVelocity( );

	posA = posA + velA*delta;
	posB = posB + velB*delta;


	XMFLOAT2 boxHSize = XMCStoreFloat2( other.GetHalfSize( ) );


	XMVECTOR boxDir = other.GetDirection( );

	XMVECTOR obbExtends[3];
	obbExtends[0] = boxDir*boxHSize.x;
	obbExtends[1] = XMVector2Orthogonal( boxDir )*boxHSize.y;
	obbExtends[2] = XMVectorSet( 0, 0, 1, 0 )*1.0f;

	XMVECTOR closestOnObb = ClosestPointOnOBB( posA, posB, obbExtends );
	//posB - posMK;

	float distSq = XMCVector2LengthSq( closestOnObb - posA );
	float radius = this->GetRadius( );
	if ( distSq > radius*radius )
		return false;

	return true;
}

// ------------------
// --- Resolution ---
// ------------------

bool Circle::Resolve( CollisionShape* other )
{

	if ( !WillResolveWith( other ) )
		return false;

	switch ( other->GetCollisionShapeType( ) )
	{
	case CIRCLE:
		return ResolveWithCircle( *dynamic_cast<Circle*>( other ) );
	case OBB:
		return ResolveWithOrientedBox( *dynamic_cast<OrientedBox*>( other ) );
	}
	return false;
}

bool Circle::ResolveWithCircle( Circle& other )
{
	// Plan: The time of impact is already calculated on detection.
	// So I can use it from the physics system to advance the simulation to it.
	// Resulting assumptions:
	// - Objects should be just touching at this point.
	// - Objects' frame time should be the toi.
	// - Resolution won't move the objects



	//const string& thisTag = this->GetGameObjectHolder( )->GetTag( );
	//const string& othrTag = other.GetGameObjectHolder( )->GetTag( );

	float rMk = this->radius + other.radius;

	XMVECTOR posA = this->GetPosition( );
	XMVECTOR posB = other.GetPosition( );
	XMVECTOR posMk = posB - posA;		// from A to B
	float posMk_m = XMCVector2Length( posMk );
	if (posMk_m == 0.0f)
		posMk_m = 0.001f;
	XMVECTOR posMk_n = posMk/posMk_m;

	XMVECTOR velA = this->GetVelocity( );
	XMVECTOR velB = other.GetVelocity( );
	XMVECTOR velMk = velB - velA;
	float velMk_nm = XMCVector2Dot( velMk, posMk_n );
	
	if ( velMk_nm > 0 ) 
		return false;	// Already Separating

	float massA = this->GetPhysicsComponentHolder( )->GetMass( );
	float massB = other.GetPhysicsComponentHolder( )->GetMass( );

	float massMk_inv = 1.0f / ( massA + massB );


	XMVECTOR dP = 2.0f* velMk_nm*massMk_inv*posMk_n;

	if ( massA == INFINITE_MASS || massB == INFINITE_MASS )
	{
		if ( massA != INFINITE_MASS )
			velA += velMk_nm*posMk_n;
		else if ( massB != INFINITE_MASS )
			velB -= velMk_nm*posMk_n;
	}
	else
	{
		velA += massB*dP;
		velB -= massA*dP;
	}

	if ( posMk_m < rMk - EPSILON_DIST)
	{
		// Anti-penetration impulse
		// Plan: If the objects are not moving apart add an impulse that pushes the objects apart.

		float delta = TimeManager::GetTimeDelta() - this->GetFrameTime();
		float separation = rMk - posMk_m;
		//float impulseSpeed = SEPARATION_IMPULSE*( 1.0f - 0.5f*(posMk_m)/rMk); // 100% on center 50% on edge
		 
		//float impulseSpeed = 500.0f;
		//if( delta > 0 )
		//	impulseSpeed += separation/delta ;
		float impulseSpeed = separation/delta;

		PrintConsoleM( "Separating at " + FloatToString(impulseSpeed,10) + " speed." );

		velMk_nm = XMCVector2Dot( velMk, posMk_n );

		if ( velMk_nm < impulseSpeed ) // Not separating (fast enough)
		{
			PrintConsoleM( "Adding separation impulse" );
			//XMVECTOR impulse = (velMk_nm - impulseSpeed)*posMk_n;
			XMVECTOR impulse = (velMk_nm - impulseSpeed)*posMk_n;
			if ( massA == INFINITE_MASS || massB == INFINITE_MASS )
			{
				if ( massA != INFINITE_MASS )
					velA += impulse;
				else if ( massB != INFINITE_MASS )
					velB -= impulse;

				// dont resolve penetration for two objects with infinite mass
			}
			else
			{
				velA += impulse*massB*massMk_inv;
				velB -= impulse*massA*massMk_inv;
			}
		}
		else
			PrintConsole( "Already Separating" );
	}


	this->SetVelocity(velA);
	other.SetVelocity(velB);

	return true;
}

bool Circle::ResolveWithOrientedBox( OrientedBox& other )
{
	float delta = (float) TimeManager::GetTimeDelta( );

	XMVECTOR posA = this->GetPosition( );
	XMVECTOR posB = other.GetPosition( );
	XMVECTOR velA = this->GetVelocity( );
	XMVECTOR velB = other.GetVelocity( );

	XMVECTOR posMK = posB - posA;
	XMVECTOR velMK = velB - velA;

	XMFLOAT2 boxHSize; XMStoreFloat2( &boxHSize, other.GetHalfSize( ) );

	XMVECTOR boxDir = other.GetDirection( );

	XMVECTOR obbExtents[3];

	obbExtents[0] = boxDir*boxHSize.x;
	obbExtents[1] = XMVector2Orthogonal( boxDir )*boxHSize.y;
	obbExtents[2] = XMVectorSet( 0, 0, 1, 0 )*1.0f;

	XMVECTOR closestOnObb = ClosestPointOnOBB( posA, posB, obbExtents );

	XMVECTOR toOBB = closestOnObb - posA;

	XMVECTOR separation = toOBB - XMVector2Normalize( toOBB )* ( radius );

	float collisionDistance = XMCVector2Dot( separation, XMVector2Normalize( velMK ) ); // Distance along the velocity direction
	float moveDistance = XMCVector2Length( velMK*delta );
	float toi = 1.0f;
	if ( collisionDistance != 0.0f )
		toi = collisionDistance / moveDistance;

	if ( toi < 0 || toi > 1 )
	{
		//OutputDebugString( L"Circle-OBB Bad Intersection\n" );
		//return false;
	}

	//velA *= toi;
	//velB *= toi;


	//if ( collisionDistance <= 0 )
	if ( XMCVector2Dot( separation, toOBB ) < 0 )
	{
		//OutputDebugString( L"Circle-OBB Penetration detected\n" );

		//XMVECTOR closestOutOfObb = ClosestPointOutOfOBB(closestOnObb + separation, posB, obbExtents);
		ResolutionType thisRT = this->GetResolutionType( );
		ResolutionType otherRT = other.GetResolutionType( );
		if ( thisRT == RT_DYNAMIC )
		{
			//separation = closestOutOfObb  - posA;
			//separation += XMVector2Normalize(separation)*radius;
			posA -= separation*1.01f;
			this->SetPosition( posA );
		}
		if ( otherRT == RT_DYNAMIC )
		{
			posB += ( closestOnObb - posB )*1.01f;
			other.SetPosition( posB );
		}

	}

	this->SetVelocity( velA );
	other.SetVelocity( velB );

	return true;
}


void Circle::SolveContacts( )
{
	/*
	for each( Contact contact in m_CurrentContacts )
	{
	XMVECTOR vel = GetVelocity( );
	XMVECTOR n = XMLoadFloat2( &contact.normal );
	XMVECTOR vel_n = XMVector2Dot( vel, n )*n;
	vel = vel - vel_n;
	SetVelocity( vel );
	}
	*/
	m_CurrentContacts.clear( );
}

