#pragma once
#include "CollisionShape.h"

namespace Physics
{
	class Circle;

	class Point :
		public CollisionShape
	{
		DirectX::XMFLOAT2 position;

		public:
		Point( );
		~Point( );

		virtual CollisionShapeType GetCollisionShapeType( ) const override { return POINT; };
		virtual bool Collides( CollisionShape*  other, float* toi = NULL ) override;

		private:
		bool CollidesWithCircle( const Circle& other );

	};
}
