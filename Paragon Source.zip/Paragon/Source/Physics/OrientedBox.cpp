#include "../Application/stdafx.h"

#include "OrientedBox.h"

#include "Physics.h"

using namespace Physics;
using namespace DirectX;
OrientedBox::~OrientedBox( )
{
}

XMVECTOR OrientedBox::GetDirection() const
{
	return XMLoadFloat2( &m_vDirection );
}

XMVECTOR OrientedBox::GetHalfSize() const
{
	return XMLoadFloat2( &hSize );
}

void OrientedBox::SetDirection(XMVECTOR direction)
{
	XMStoreFloat2( &m_vDirection, XMVector2Normalize(direction) );
}


void OrientedBox::SetHalfSize(XMVECTOR halfSize)
{
	XMStoreFloat2( &hSize, halfSize );
}

bool OrientedBox::Collides( CollisionShape* other, float* toi )
{
	if ( const OrientedBox* orientedBox = dynamic_cast<const OrientedBox*>( other ) )
		return CollidesWithOrientedBox( *orientedBox );


	return false;
}

bool OrientedBox::Resolve( CollisionShape* other )
{
	// TODO 
	return false;
}

bool OrientedBox::CollidesWithOrientedBox( const OrientedBox& other )
{
	// TODO 
	return false;
}



bool OrientedBox::CollidesWithCircle( const Circle& other )
{
		float delta = (float)TimeManager::GetTimeDelta();

	XMVECTOR posA = this->GetPosition();
	XMVECTOR posB = other.GetPosition();
	XMVECTOR velA = this->GetVelocity();
	XMVECTOR velB = other.GetVelocity();

	posA = XMVectorAdd( posA, XMVectorScale(velA, delta) );
	posB = XMVectorAdd( posB, XMVectorScale(velB, delta) );

	XMVECTOR posMK = XMVectorSubtract( posA, posB );

	XMVECTOR uDir = XMLoadFloat2( &m_vDirection );
	XMVECTOR vDir = XMVector2Orthogonal( uDir );


	float uDist, vDist;
	XMStoreFloat( &uDist, XMVector2Dot(posMK, uDir));		// Distance Components in the box's coodrinate system (u,v)
	XMStoreFloat( &vDist, XMVector2Dot(posMK, vDir));

	float distSq;
	XMStoreFloat( &distSq, XMVector2LengthSq( posMK ) );

	if( abs(uDist) > hSize.x + other.radius )
		return false;
	if( abs(vDist) > hSize.y + other.radius )
		return false;

	return true;

}

void OrientedBox::SetSize(DirectX::XMFLOAT2 size)
{
	hSize = size;
}
void OrientedBox::SetSize(float x, float y)
{
	hSize.x = x;
	hSize.y = y;
}
void OrientedBox::SetDirection(DirectX::XMFLOAT2 dir)
{
	m_vDirection = dir;
}
void OrientedBox::SetDirection(float x, float y)
{
	m_vDirection.x = x;
	m_vDirection.y = y;
}