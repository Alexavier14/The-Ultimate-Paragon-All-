#pragma once
#include "CollisionShape.h"

namespace Physics
{

	class Circle;

	// Represents a Circular Sector.
	class Cone :
		public CollisionShape
	{
		//Member Variables
		// Two unit vectors for the two radii edges of the circular section
		DirectX::XMFLOAT2 unitEdges[2];

		// The radius of the circular sector.
		float m_fRadius;
		float m_fAngle;

		public:
		virtual ~Cone( );


		virtual CollisionShapeType GetCollisionShapeType( ) const override { return CONE; };
		
		virtual bool Collides( CollisionShape* other, float* toi = NULL ) override;
		virtual bool Resolve( CollisionShape* other ) override;

		//Accessors
		void GetUnitEdges(XMFLOAT2& edge_0, XMFLOAT2& edge_1) const;
		float GetRadius() const;
		float GetAngle() const;

		//Mutators
		void SetUnitEdges(XMFLOAT2 edge_0, XMFLOAT2 edge_1);
		void SetRadius(float _radius);
		void SetAngle(float _angle);

		//Methods
		void UpdateEdges();

		//Helper Functions
		private:

		bool CollidesWithCircle( const Circle& other );
	};

}