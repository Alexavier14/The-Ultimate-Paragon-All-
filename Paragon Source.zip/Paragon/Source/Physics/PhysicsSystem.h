#include "../Application/stdafx.h"

#pragma once
#include "Cone.h"
#include "Circle.h"
#include "OrientedBox.h"
#include "Segment.h"
#include "AlignedBox.h"
#include "../Object Manager/PhysicsComponent.h"

#include "Contact.h"

class PhysicsSystem
{
	private:
	// ---------------
	// --- Members ---
	// ---------------

	std::vector<Physics::Circle> m_CircleArray;
	std::vector<Physics::OrientedBox> m_OrientedBoxArray;
	std::vector<Physics::Segment> m_SegmentArray;
	std::vector<Physics::Cone> m_ConeArray;
	std::vector<PhysicsComponent> m_PhysicsCompArray;

	std::list<Physics::Contact> m_ContactList;

	public:
	PhysicsSystem( );
	~PhysicsSystem( );

	bool RenderCollisionCircles;
	bool RenderCollisionOBB;
	bool RenderCollisionSegments;
	bool RenderCollisionCones;

	// ---------------
	// --- Methods ---
	// ---------------

	void Update( );

	void CheckAllColisions(Physics::CollisionShape* pShape, bool onlyResolvingBounds = true); // Checks for collsions between the specified shape and all boxes and circles

	// ---------------
	// --- Factory ---
	// ---------------

	Physics::Circle* MakeCircleShape( Physics::ResolutionType resolutionType );							// Returns and activates an instance of a circle shape
	Physics::OrientedBox* MakeOBBShape( Physics::ResolutionType resolutionType );						// Returns and activates an instance of a oriented box shape
	Physics::Segment* MakeSegmentShape(Physics::ResolutionType resolutionType);							// Returns and activates an instance of a segment shape
	Physics::Cone* MakeConeShape(Physics::ResolutionType resolutionType, float angle, float radius);	// Returns and activates an instance of a cone shape
	PhysicsComponent* MakePhysicsCompoment( GameObject* pHolder );										// Returns a 'bare' Physics Component with no Collision Shapes

	std::vector<Physics::Segment> & PhysicsSystem::GetSegmentCollisionShapes( );
	std::vector<Physics::OrientedBox> & PhysicsSystem::GetOrientedBoxCollisionShapes( );
	std::vector<Physics::Circle> & PhysicsSystem::GetCircleCollisionShapes();
	std::vector<Physics::Cone> & PhysicsSystem::GetConeCollisionShapes();

	float RayCast(XMVECTOR start, XMVECTOR direction); //Checks for collisions and returns the distance to the closest point of intersection, or FLT_MAX if there is none.

	private:
	// ---------------
	// --- Helpers ---
	// ---------------

	void CircleToCircleCheck( );
	void CircleToObbCheck( );
	void ConeToCircleCheck();
	void SegmentToCircleCheck( );
	void SegmentToObbCheck( );

	// Checks collision for the specified shape against all circles
	// If addDetected is true, the specified shape and any other shape it collides with add each other to their detection list.
	// If specified, collision with the excluded shape will be ignored.
	void CheckAgainstCircles( Physics::CollisionShape* shape, bool addDetected = false, size_t startIndex = 0, Physics::CollisionShape* exculude = NULL );
	
	void CheckAgainstObbs( Physics::CollisionShape* shape );

	void SolveContacts( );

	void AddContact( Physics::Contact& contact ); // Adds the contact to the list maintaining its order based on toi. Removes a pre-existing contact with the same pair of shapes if it exists.
	void RemoveContactsWith( Physics::CollisionShape* shape ); // Removes all contacts where the specified shape participates

	void AdvanceSimulation(); // Advances all physics Components in their corresponding simulation times.
	void UpdateObjects();
	void UpdateShapeData(); // Updates any data for shapes.
	void ClearShapeData();
};

