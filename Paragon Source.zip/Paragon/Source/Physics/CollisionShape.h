#pragma once

#include "../Application/stdafx.h"
#include <list>

class PhysicsComponent;
class GameObject;

#include "Contact.h"

enum ShapeUsage { SU_BOUNDING_SHAPE, SU_SCANNER, SU_ATTACK, SU_CC, SU_EVENT, SU_NAVTESTER, SU_RANGEDATTACK, NUM_SHAPE_USES };

namespace Physics
{

	enum ResolutionType { RT_NONE, RT_FIXED, RT_DYNAMIC };

	/**
	Handles collision detection and resolution.
	Needs to be instatiated as derived class with a specific shape
	Collisions Shapes are expected to have a valid pointer for position set.
	The velocity however, may be left as NULL for static objects.
	*/
	class CollisionShape
	{
		public:

		enum CollisionShapeType { POINT, SEGMENT, CIRCLE, OBB, TRIANGLE, CONE };

		private:

		bool m_bActive;
		bool m_bAvailable;
		ResolutionType m_eResolutionType;
		ShapeUsage m_eShapeUsage;

		// A list of all the objects that collided with this collision shape.
		std::list<CollisionShape*> m_DetectedCollisions;

		protected:

		// Keeps track of the collision contacts
		std::list<CollisionShape*> m_CurrentContacts;

		PhysicsComponent* m_pPhysicsComponent;

		// The offset between the Game Object holder and a special point in the shape.
		DirectX::XMFLOAT2 m_vOffset;


		public:

		CollisionShape( );
		virtual ~CollisionShape( ) = 0 {}


		// --------------------------
		// --- Accessors/Mutators ---
		// --------------------------


		virtual CollisionShapeType GetCollisionShapeType( ) const = 0; // Indicates the collision type of the instance
		bool IsActive( ) const;
		bool IsAvailable() const;
		virtual DirectX::XMVECTOR	GetPosition( ) const; // A 2D Vector with the position Value
		virtual DirectX::XMVECTOR	GetVelocity( ) const; // A 2D Vector with the velocity Value
		virtual DirectX::XMVECTOR	GetOffset( ) const; // A 2D Vector with the offset Value
		ResolutionType		GetResolutionType() const;
		ShapeUsage			GetShapeUsage() const;
		float				GetFrameTime() const;
		GameObject*			GetGameObjectHolder( ) const;
		PhysicsComponent*	GetPhysicsComponentHolder( );
		const std::list<CollisionShape*>& GetDetectedShapes() const;
		const std::list<CollisionShape*>& GetContacts() const;

		void SetActive( bool active );
		void SetAvailable( bool available );
		void SetPosition( DirectX::XMVECTOR position );
		void SetVelocity( DirectX::XMVECTOR velocity );
		void SetOffset( DirectX::XMVECTOR offset );
		void SetResolutionType(ResolutionType resolutionType );
		void SetShapeUsage(ShapeUsage shapeUsage );
		void SetFrameTime(float frameTime );
		void SetPhysicsComponentHolder( PhysicsComponent* holder );
		void AddDetectedShape( CollisionShape*  collisionShape );
		void ClearDetectionList( );
		void ClearContactList( );
		void AddContact( Contact contact );

		// --------------------------
		// --- Methods ---
		// --------------------------

		// Checks whether the to collision shapes will collide with each other.
		// If toi is not null, the time of impact is recorded.
		virtual bool Collides( CollisionShape*  other, float* toi = NULL ) = 0;

		// Resolves the collision. It adjusts the velocities of both CS to avoid penetration
		virtual bool Resolve( CollisionShape*  other ) = 0;

		virtual void SolveContacts( );


		bool WillResolveWith(CollisionShape* other);

	};

}
