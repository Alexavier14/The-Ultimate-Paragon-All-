#pragma once
#include "CollisionShape.h"

namespace Physics
{
	class AlignedBox :
		public CollisionShape
	{

		DirectX::XMFLOAT2 m_vCenter;
		DirectX::XMFLOAT2 m_vHSize;

		public:

		AlignedBox( );
		~AlignedBox( );
	};

}