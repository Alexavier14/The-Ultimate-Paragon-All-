#include "../Application/stdafx.h"

#include "Cone.h"

#include "Physics.h"
#include "../Object Manager/PhysicsComponent.h"
#include "../Object Manager/GameObject.h"

using namespace Physics;
using namespace DirectX;

Cone::~Cone()
{
}



bool Cone::Collides(CollisionShape* other, float* toi)
{
	switch (other->GetCollisionShapeType())
	{
	case CIRCLE:
		return CollidesWithCircle(*dynamic_cast<const Circle*>(other));

	}
	return false;
}

bool Cone::Resolve(CollisionShape* other)
{
	//TODO

	return false;
}


bool Cone::CollidesWithCircle(const Circle& other)
{
	float delta = (float)TimeManager::GetTimeDelta();

	const float &Ra = this->m_fRadius; //Cone's Radius
	const float &Rb = other.radius; //Circle's Radius
	const XMVECTOR u = XMLoadFloat2(&unitEdges[0]);
	const XMVECTOR v = XMLoadFloat2(&unitEdges[1]);

	const XMVECTOR A = XMVectorScale(u, Ra);
	const XMVECTOR B = XMVectorScale(v, Rb);

	XMVECTOR posA = this->GetPosition();
	XMVECTOR posB = other.GetPosition();
	XMVECTOR velA = this->GetVelocity();
	XMVECTOR velB = other.GetVelocity();

	posA = XMVectorAdd(posA, XMVectorScale(velA, delta));
	posB = XMVectorAdd(posB, XMVectorScale(velB, delta));

	XMVECTOR posMK = XMVectorSubtract(posA, posB);


	float distSq = 0.0f;

	XMStoreFloat(&distSq, XMVector2LengthSq(posMK));

	if (this->GetPhysicsComponentHolder()->GetHolder()->GetTag() == "DumbSpider")
		int poop = 0;

	if (distSq > pow(Ra + Rb, 2))
		return false;

	//XMVECTOR upVec = XMCLoadFloat2(0, 1.0f);
	XMVECTOR u_prime = XMVector2Orthogonal(u);
	XMVECTOR v_prime = -XMVector2Orthogonal(v);
	XMVECTOR ForwardVec = XMCVector3SwizzleXZ(m_pPhysicsComponent->GetHolder()->GetForwardVec());
	float Rb_sq = Rb * Rb;
	float result = 0.0f;

	static const float angle_check = XMConvertToRadians(180.0f); //Only need this once and don't need to change.

	if (m_fAngle < angle_check)
	{
		//Get the dot product result of the edge1 normal
		result = XMCVector2Dot(u_prime, posMK);
		if (result < 0 && result < -Rb)
		{
			float distC1 = XMVector2LengthSq(posB - A).m128_f32[0]; // Corner Check 1
			if (distC1 <= Rb_sq)
				return true;

			return false;
		}

		//Get the dot product result of the edge2 normal
		result = XMCVector2Dot(v_prime, posMK);
		if (result < 0 && result < -Rb)
		{
			float distC2 = XMVector2LengthSq(posB - B).m128_f32[0]; // Corner Check 2
			if (distC2 <= Rb_sq)
				return true;

			return false;
		}
	}
	else if (m_fAngle == angle_check)
	{
		//Get the dot product result of the Forward vector
		result = XMCVector2Dot(ForwardVec, posMK);
		if (result > 0 && result > Rb)
			return false;
	}
	else if (m_fAngle > angle_check)
	{
		//Get the dot product result of the Forward vector
		result = XMCVector2Dot(ForwardVec, posMK);
		if (result > 0 && result > Rb)
		{
			result = XMCVector2Dot(u_prime, posMK);
			if (result >= -Rb)
				return true;

			//Get the dot product result of the edge2 normal
			result = XMCVector2Dot(v_prime, posMK);
			if (result >= -Rb)
				return true;

			float distC1 = XMVector2LengthSq(posB - A).m128_f32[0]; // Corner Check 1
			if (distC1 <= Rb_sq)
				return true;

			float distC2 = XMVector2LengthSq(posB - B).m128_f32[0]; // Corner Check 2
			if (distC2 <= Rb_sq)
				return true;

			return false;
		}
	}
	//TODO: Finish other cases
	return true;
}

//Accessors
void Cone::GetUnitEdges(XMFLOAT2& edge_0, XMFLOAT2& edge_1) const
{
	edge_0 = unitEdges[0];
	edge_1 = unitEdges[1];
}

float Cone::GetRadius() const
{
	return m_fRadius;
}

float Cone::GetAngle() const
{
	return m_fAngle;
}

//Mutators
void Cone::SetUnitEdges(XMFLOAT2 edge_0, XMFLOAT2 edge_1)
{
	unitEdges[0] = edge_0;
	unitEdges[1] = edge_1;
}

void Cone::SetRadius(float _radius)
{
	m_fRadius = _radius;
}

void Cone::SetAngle(float _angle)
{
	m_fAngle = _angle;
}

void Cone::UpdateEdges()
{
	XMVECTOR result;
	XMVECTOR ForwardVec = this->m_pPhysicsComponent->GetHolder()->GetForwardVec();
	ForwardVec = XMCVector3SwizzleXZ(ForwardVec);

	float halfAngle = m_fAngle * 0.5f;	 //Angle of the cone.

	XMMATRIX rotations = XMMatrixRotationZ(halfAngle); // get the rotation mat first half
	result = XMVector2Transform(ForwardVec, rotations);
	result = XMVector2Normalize(result);
	unitEdges[0] = XMCStoreFloat2(result);

	rotations = XMMatrixRotationZ(-halfAngle); // get the rotation mat second half
	result = XMVector2Transform(ForwardVec, rotations);
	result = XMVector2Normalize(result);
	unitEdges[1] = XMCStoreFloat2(result);
}
