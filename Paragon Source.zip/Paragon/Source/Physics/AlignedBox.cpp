#include "../Application/stdafx.h"

#include "AlignedBox.h"

namespace Physics
{

	AlignedBox::AlignedBox( )
	{
	}


	AlignedBox::~AlignedBox( )
	{
	}

};