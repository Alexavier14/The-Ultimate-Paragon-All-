#include "../Application/stdafx.h"

#include "CollisionShape.h"
#include "../Object Manager/PhysicsComponent.h"

using namespace DirectX;


namespace Physics
{

	CollisionShape::CollisionShape( ) :
		m_bActive( false ),
		m_bAvailable( true ),
		m_pPhysicsComponent( NULL ),
		m_vOffset( 0, 0 )
	{
		m_CurrentContacts.clear();
		m_DetectedCollisions.clear();
	}

	bool CollisionShape::IsActive( ) const
	{
		return m_bActive;
	}
	bool CollisionShape::IsAvailable() const 
	{
		return m_bAvailable;
	}
	XMVECTOR CollisionShape::GetPosition( ) const
	{
		XMVECTOR position = XMLoadFloat2( &m_pPhysicsComponent->GetPosition( ) );
		XMVECTOR offset = XMLoadFloat2( &m_vOffset );
		return  position + offset;
	}
	XMVECTOR CollisionShape::GetVelocity( ) const
	{
		return XMLoadFloat2( &m_pPhysicsComponent->GetVelocity( ) );
	}
	XMVECTOR CollisionShape::GetOffset( ) const
	{
		return XMLoadFloat2( &m_vOffset );
	}
	ResolutionType CollisionShape::GetResolutionType( ) const
	{
		return m_eResolutionType;
	}
	ShapeUsage CollisionShape::GetShapeUsage( ) const
	{
		return m_eShapeUsage;
	}
	float CollisionShape::GetFrameTime( ) const
	{
		return m_pPhysicsComponent->GetFrameTime( );
	}
	GameObject* CollisionShape::GetGameObjectHolder( ) const 
	{
		return m_pPhysicsComponent->GetHolder( );
	}
	PhysicsComponent* CollisionShape::GetPhysicsComponentHolder( )
	{
		return m_pPhysicsComponent;
	}
	const std::list<CollisionShape*>& CollisionShape::GetDetectedShapes( ) const
	{
		return m_DetectedCollisions;
	}
	const std::list<CollisionShape*>& CollisionShape::GetContacts( ) const
	{
		return m_CurrentContacts;
	}


	void CollisionShape::SetPosition( DirectX::XMVECTOR position )
	{
		XMFLOAT2 positionSt; XMStoreFloat2( &positionSt, position );
		m_pPhysicsComponent->SetPosition( positionSt );
	}
	void CollisionShape::SetVelocity( XMVECTOR velocity )
	{
		XMFLOAT2 velocitySt; XMStoreFloat2( &velocitySt, velocity );
		m_pPhysicsComponent->SetVelocity( velocitySt );
	}
	void CollisionShape::SetOffset( XMVECTOR offset )
	{
		XMStoreFloat2( &m_vOffset, offset );
	}
	void CollisionShape::SetResolutionType( ResolutionType resolutionType )
	{
		m_eResolutionType = resolutionType;
	}
	void CollisionShape::SetShapeUsage( ShapeUsage shapeUsage )
	{
		m_eShapeUsage = shapeUsage;
	}
	void CollisionShape::SetFrameTime( float frameTime )
	{
		m_pPhysicsComponent->SetFrameTime( frameTime );
	}
	void CollisionShape::SetActive( bool active )
	{
		m_bActive = active;
	}
	void CollisionShape::SetAvailable( bool available )
	{
		m_bAvailable = available;
	}
	void CollisionShape::SetPhysicsComponentHolder( PhysicsComponent* holder )
	{
		m_pPhysicsComponent = holder;
	}
	void CollisionShape::AddDetectedShape( CollisionShape*  collisionShape )
	{
		m_DetectedCollisions.emplace_front( collisionShape );
	}
	void CollisionShape::ClearDetectionList( )
	{
		m_DetectedCollisions.clear( );
	}
	void CollisionShape::ClearContactList( )
	{
		m_CurrentContacts.clear( );
	}

	void CollisionShape::AddContact( Contact contact )
	{
		if( this == contact.shapeA )
			m_CurrentContacts.push_back( contact.shapeB );
		else
			m_CurrentContacts.push_back( contact.shapeA );
	}

	void CollisionShape::SolveContacts( )
	{
		m_CurrentContacts.clear( );
	}

	bool CollisionShape::WillResolveWith( CollisionShape* other )
	{
		ResolutionType thisRT = this->GetResolutionType( );
		ResolutionType otherRT = other->GetResolutionType( );
		if ( thisRT == RT_NONE )
			return false;
		if ( otherRT == RT_NONE )
			return false;
		if ( thisRT == RT_FIXED && otherRT == RT_FIXED )
			return false;

		return true;
	}


};