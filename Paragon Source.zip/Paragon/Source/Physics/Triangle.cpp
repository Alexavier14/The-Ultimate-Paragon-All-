#include "../Application/stdafx.h"

#include "Triangle.h"

using namespace Physics;


Triangle::~Triangle( )
{
}


bool Triangle::Collides( CollisionShape* other, float* toi )
{
	//TODO
	return false;
}

bool Triangle::Resolve( CollisionShape* other )
{
	//TODO
	return false;
}