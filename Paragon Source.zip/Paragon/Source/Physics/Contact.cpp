#include "../Application/stdafx.h"

#include "Contact.h"

using namespace Physics;

Contact::Contact( CollisionShape* shapeA, CollisionShape* shapeB, float toi ) :
shapeA(shapeA),
shapeB(shapeB),
toi(toi)
{
}
