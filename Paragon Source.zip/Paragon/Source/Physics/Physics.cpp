#include "../Application/stdafx.h"

#include "Physics.h"
#include <iostream>
#include <iomanip>

using namespace DirectX;

const float Physics::EPSILON		= 1.0e-8f;
const float Physics::EPSILON_DIST	= 0.15f; 
const float Physics::EPSILON_SPEED	= 0.50f;
const float Physics::EPSILON_TIME	= 0.001f;

// Intersection Queries


XMVECTOR Physics::IntersectRayPlane( XMVECTOR planeN, float planeD, XMVECTOR rayDir, XMVECTOR rayOrigin )
{
	// t = -(Po*N + d)/(V*N)

	float pn_dot, pv_dot;
	XMStoreFloat( &pn_dot, XMVector3Dot( planeN, rayOrigin ) );
	XMStoreFloat( &pv_dot, XMVector3Dot( planeN, rayDir ) );

	if ( pv_dot == 0 )
		return rayOrigin;

	float t = -( pn_dot + planeD ) / pv_dot;

	if ( t < 0 )
		return rayOrigin;


	return XMVectorAdd( rayOrigin, XMVectorScale( rayDir, t ) );
}

XMVECTOR Physics::IntersectRaySphere( XMVECTOR sphereCenter, float sphereRadius, XMVECTOR rayDir, XMVECTOR rayOrigin )
{
	//Code adapted from ED3 Lecture
	XMVECTOR M = rayOrigin - sphereCenter;
	float b = XMVectorGetX( XMVector3Dot( M, rayDir ) );
	float c = XMVectorGetX( XMVector3Dot( M, M ) ) - sphereRadius*sphereRadius; // Squared distance from start of ray to sphere surface

	XMVECTOR intersection = rayOrigin;

	if ( c > 0.0f && b > 0.0f )
		return intersection; // Ray starts outside and points away

	float discr = b*b - c;
	if ( discr < 0.0f )
		return intersection; // Negative discriminant means ray missed

	float t = -b - sqrt( discr );
	if ( t < 0.0f )
		t = 0.0f; // Ray starts inside sphere, clamp to 0
	intersection += t * rayDir;

	return intersection;
}

XMVECTOR Physics::ClosestPointOnOBB( XMVECTOR point, XMVECTOR centerOBB, XMVECTOR extents[3] )
{
	XMVECTOR D = centerOBB - point;

	for ( size_t i = 0; i < 3; i++ )
	{
		XMVECTOR extentDir = XMVector3Normalize( extents[i] );
		float extentSeparation = XMCVector2Dot( D, extentDir );
		float extentLength = XMCVector3Length( extents[i] );
		if ( extentSeparation > extentLength )
			point -= extentDir*( extentSeparation - extentLength );
		else if ( extentSeparation < -extentLength )
			point -= extentDir*( extentSeparation + extentLength );
	}
	return point;
}

DirectX::XMVECTOR Physics::ClosestPointOutOfOBB( DirectX::XMVECTOR point, DirectX::XMVECTOR centerOBB, DirectX::XMVECTOR extents[3] )
{
	XMVECTOR D = point - centerOBB;
	float minDist = FLT_MAX;
	XMVECTOR closestPoint;
	for ( size_t i = 0; i < 3; i++ )
	{
		XMVECTOR extentDir = XMVector3Normalize( extents[i] );
		float extentSeparation = XMCVector2Dot( D, extentDir );
		float extentLength = XMCVector3Length( extents[i] );

		if(extentSeparation > 0)
			extentSeparation = extentLength - extentSeparation;
		else
			extentSeparation = -extentLength - extentSeparation;

		if ( abs( extentSeparation ) < abs( minDist ) )
		{
			minDist = extentSeparation;
			closestPoint = point + extentSeparation*extentDir;
		}

	}
	return closestPoint;
}

bool Physics::IsPointOnOBB(const XMVECTOR& point, const XMVECTOR& centerOBB, DirectX::XMVECTOR extents[3])
{
	XMVECTOR D = centerOBB - point;

	for ( size_t i = 0; i < 3; i++ )
	{
		XMVECTOR extentDir = XMVector3Normalize( extents[i] );
		float extentSeparation = XMCVector2Dot( D, extentDir );
		float extentLength = XMCVector3Length( extents[i] );
		if ( abs(extentSeparation) > extentLength )
			return false;
	}
	return true;
}

bool Physics::IntersectCircleAABB(const XMVECTOR& sphereCenter, float sphereRadius, const XMVECTOR& aabbCenter, const XMVECTOR& aabbExtents)
{
	XMVECTOR distance = XMVectorAbs(sphereCenter - aabbCenter);
	XMVECTOR minSeparation = aabbExtents + XMCLoadFloat2(sphereRadius, sphereRadius);

	if( XMVectorGetX( distance ) > XMVectorGetX( minSeparation ) )
	   return false;
	if( XMVectorGetY( distance ) > XMVectorGetY( minSeparation ) )
		return false;

	return true;
}


bool Physics::IntersectRayAABB(const XMFLOAT2& rayOrigin, const XMFLOAT2& rayDir, const XMFLOAT2& aabbCenter, const XMFLOAT2& aabbExtents)
{
	//Adapted from: http://tavianator.com/2011/05/fast-branchless-raybounding-box-intersections/

	float tMin = -FLT_MAX;
	float tMax = +FLT_MAX;

	if (!FloatEquals(rayDir.x, 0))
	{
		float tx1 = ( (aabbCenter.x - aabbExtents.x) - rayOrigin.x )/rayDir.x;
		float tx2 = ( (aabbCenter.x + aabbExtents.x) - rayOrigin.x )/rayDir.x;

		tMin = max(tMin, min(tx1, tx2));
		tMax = min(tMax, max(tx1, tx2));
	}

	if (!FloatEquals(rayDir.y, 0))
	{
		float ty1 = ( (aabbCenter.y - aabbExtents.y) - rayOrigin.y )/rayDir.y;
		float ty2 = ( (aabbCenter.y + aabbExtents.y) - rayOrigin.y )/rayDir.y;

		tMin = max(tMin, min(ty1, ty2));
		tMax = min(tMax, max(ty1, ty2));
	}

	return tMax > 0 && tMax >= tMin;
}

bool Physics::IntersectPointCircle(const XMVECTOR& pointPos, const XMVECTOR& sphereCenter, float sphereRadius)
{
	XMVECTOR distance = pointPos - sphereCenter;
	return XMCVector2LengthSq(distance) < sphereRadius*sphereRadius;
}



// --- Random Functions ---


float Physics::UnitRand( )
{
	return float( rand( ) % RAND_MAX ) / ( RAND_MAX - 1 );
}

float Physics::SignedUnitRand()
{
	return UnitRand()*2.0f - 1.0f;
}


XMVECTOR Physics::XMCUnitVector2( float orientation )				{	return XMLoadFloat2( &XMFLOAT2( cos( orientation ), sin( orientation ) ) ); }

float Physics::XMCVector2Length( const XMVECTOR& vector )		{ return XMVectorGetX( XMVector2Length( vector ) ); }
float Physics::XMCVector3Length( const XMVECTOR& vector )		{ return XMVectorGetX( XMVector3Length( vector ) ); }

float Physics::XMCVector2LengthSq( const XMVECTOR& vector )	{ return XMVectorGetX( XMVector2LengthSq( vector ) ); }
float Physics::XMCVector3LengthSq( const XMVECTOR& vector )	{ return XMVectorGetX( XMVector3LengthSq( vector ) ); }

float Physics::XMCVector2Dot( const XMVECTOR& vectorA, const XMVECTOR& vectorB )	{ return XMVectorGetX( XMVector2Dot( vectorA, vectorB ) ); }
float Physics::XMCVector3Dot( const XMVECTOR& vectorA, const XMVECTOR& vectorB )	{ return XMVectorGetX( XMVector3Dot( vectorA, vectorB ) ); }

XMFLOAT2 Physics::XMCVector2GetXZ( const XMVECTOR& vector )				{ return XMFLOAT2( XMVectorGetX( vector ), XMVectorGetZ( vector ) ); }
XMFLOAT3 Physics::XMCVector3GetXZ( const XMVECTOR& vector, float y )	{ return XMFLOAT3( XMVectorGetX( vector ), y, XMVectorGetY( vector ) ); }
XMVECTOR Physics::XMCVector3LoadXZ( const XMFLOAT2& float2, float y )			{ return XMLoadFloat3( &XMFLOAT3( float2.x, y, float2.y ) ); }
XMVECTOR Physics::XMCVector2LoadXZ( const XMFLOAT3& float3 )					{ return XMLoadFloat2( &XMFLOAT2( float3.x, float3.z ) ); }

XMVECTOR Physics::XMCVector3SwizzleXZ( const XMVECTOR& vector) 
{
	XMVECTOR swizzled = XMVectorSwizzle(vector, 0, 2, 3, 3);
	swizzled = XMVectorSetZ(swizzled, 0);
	swizzled = XMVectorSetW(swizzled, 0);
	return swizzled;
}
XMVECTOR Physics::XMCVector2SwizzleXZ( const XMVECTOR& vector) 
{
	XMVECTOR swizzled = XMVectorSwizzle(vector, 0, 3, 1, 3);
	swizzled = XMVectorSetY(swizzled, 0);
	swizzled = XMVectorSetW(swizzled, 0);
	return swizzled;
}

XMFLOAT2 Physics::XMCStoreFloat2( const XMVECTOR& vector )
{
	XMFLOAT2 float2;
	XMStoreFloat2( &float2, vector );
	return float2;
}

XMFLOAT3 Physics::XMCStoreFloat3( const XMVECTOR& vector )
{
	XMFLOAT3 float3;
	XMStoreFloat3( &float3, vector );
	return float3;
}

XMFLOAT4 Physics::XMCStoreFloat4( const XMVECTOR& vector )
{
	XMFLOAT4 float4;
	XMStoreFloat4( &float4, vector );
	return float4;
}

XMFLOAT4X4 Physics::XMCStoreFloat4x4( const XMMATRIX& matrix )
{
	XMFLOAT4X4 float4x4;
	XMStoreFloat4x4(&float4x4, matrix);
	return float4x4;
}

XMVECTOR Physics::XMCLoadFloat2(float x, float y) 
{
	return XMLoadFloat2(&XMFLOAT2(x, y)); 
}
XMVECTOR Physics::XMCLoadFloat3( float x, float y, float z ) 
{
	return XMLoadFloat3(&XMFLOAT3(x, y, z)); 
}
XMVECTOR Physics::XMCLoadFloat4( float x, float y, float z, float w ) 
{
	return XMLoadFloat4(&XMFLOAT4(x, y, z, w)); 
}
XMVECTOR Physics::XMCRandomUnitVector2()
{
	XMMATRIX rotation = XMMatrixRotationZ(UnitRand()*XM_2PI);
	XMVECTOR unitZ = XMCLoadFloat2(0,1);
	return XMVector3Transform(unitZ, rotation);
}
XMVECTOR Physics::XMCRandomUnitVector3()
{
	XMMATRIX rotation = XMMatrixRotationRollPitchYaw(UnitRand()*XM_2PI,UnitRand()*XM_2PI,0);
	XMVECTOR unitZ = XMCLoadFloat3(0,0,1);
	return XMVector3Transform(unitZ, rotation);
}

XMVECTOR Physics::XMCRotateVector2(XMVECTOR vector, float angle)
{
	return XMVector2TransformNormal(vector, XMMatrixRotationZ(angle));
}



void Physics::XMCClamp(XMVECTOR & _value, float _min, float _max)
{
	//Get values into XMVECTOR
	XMVECTOR _vMin = XMLoadFloat(&_min);
	XMVECTOR _vMax = XMLoadFloat(&_max);

	_value = XMVectorClamp(_value, _vMin, _vMax);
}

void Physics::XMCClamp(float & _value, float _min, float _max)
{
	if (_value < _min)
		_value = _min;
	else if (_value > _max)
		_value = _max;
}

bool Physics::FloatEquals( float a, float b, float e )
{
	return ! (  (a + e > b) || (a - e < b) );
}
bool Physics::FloatGreater( float a, float b, float e )
{
	return a + e > b;
}
bool Physics::FloatLess( float a, float b, float e )
{
	return a - e < b;
}
bool Physics::FloatGreaterEquals( float a, float b, float e )
{
	return a - e > b;
}
bool Physics::FloatLessEquals( float a, float b, float e )
{
	return a + e < b;
}

string Physics::FloatToString( float a, int n)
{
	std::ostringstream out;
	out << std::setprecision(n) << a;
    return out.str();
}

wstring Physics::FloatToWString( float a, const int n)
{
	std::wostringstream out;
    out << std::setprecision(n) << a;
    return out.str();
}

string Physics::FixedFloatToString( float a, int integers, int decimals )
{
	std::ostringstream out;
	out << std::fixed;
    out << std::setprecision(decimals);
    out << std::setfill('0') << std::setw(integers+decimals);
	out << a;
    return out.str();
}
wstring Physics::FixedFloatToWString( float a, int integers, int decimals )
{
	std::wostringstream out;
	out << std::fixed;
    out << std::setprecision(decimals);
    out << std::setfill(L'0') << std::setw(integers+decimals);
	out << a;
    return out.str();
}

string Physics::VectorToString(XMVECTOR vector, int n )
{
	std::ostringstream out;
	out << std::setprecision(n) << "("
		<< XMVectorGetX(vector) << "," 
		<< XMVectorGetY(vector) << "," 
		<< XMVectorGetZ(vector) << "," 
		<< XMVectorGetW(vector) << ")";
    return out.str();
}