#pragma once

namespace Physics
{

	class CollisionShape;

	struct Contact
	{
		Physics::CollisionShape* shapeA;
		Physics::CollisionShape* shapeB;
		float toi;	// Time of impact [0,dt]

		Contact( CollisionShape* shapeA, CollisionShape* shapeB, float toi);
	};

}