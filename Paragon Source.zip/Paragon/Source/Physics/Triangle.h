#pragma once
#include "CollisionShape.h"

namespace Physics
{
	class Triangle :
		public CollisionShape
	{
		union
		{
			struct {
				DirectX::XMFLOAT2 pointA, pointB, pointC;
			};
			struct {
				DirectX::XMFLOAT2 points[3];
			};
		};
		
		public:
		
		~Triangle( );

		virtual CollisionShapeType GetCollisionShapeType( ) const override { return TRIANGLE; };

		virtual bool Collides( CollisionShape* other, float* toi = NULL) override;
		virtual bool Resolve( CollisionShape* other ) override;

	};

}