#include "../Application/stdafx.h"

#include "AssetManager.h"
#include "Mesh.h"
#include "../Object Manager/RendererComponent.h"
#include "../Animation System/Animation.h"
#include "../Animation System/Node.h"
#include "../Util/Util.h"
#include "../Particle System/Emitter.h"
#include "../State Manager/LoadingScreenState.h"

#include <fstream> 
#include <istream> 
#include <string>

#include <DXGIDebug.h>
#pragma comment( lib, "dxguid.lib")

//Hack need to fix
map<int, tJointInfluence> inf;
vector<FbxNode*> nodeList;
vector<double> uniqueTimes;

//Prototype for Animation importer.
void RecursiveAnimFunc(FbxNode * pNode, FbxMesh * pMesh, tKeyFrame * bind, int index, int parent = NULL);
void LoadSkin(FbxCluster * pCluster, int joint_index);
void LoadCurve(FbxNode * pNode, FbxAnimLayer * currLayer, const char * comp);

//Helper functions to create a unique vert list 

AssetManager::AssetManager()
{
	int AssetsLoadedCount = 0;
	int AssetsUnloadedCount = 0;
	StoringInLoadMaps = false;
}

AssetManager::~AssetManager()
{
}

void AssetManager::LoadingComplete()
{
	//Turn off storing in load maps
	StoringInLoadMaps = false;

	//Transfer Load Map Data to Base Map Containers
	for (auto iter = Loading_Anim_List.begin(); iter != Loading_Anim_List.end()  ; ++iter)
	{
		if (Anim_List.at(iter->first) != nullptr)
		Anim_List.at(iter->first) = iter->second;
	}

	for (auto iter = Loading_Mesh_List.begin(); iter != Loading_Mesh_List.end(); ++iter)
	{
		if (Mesh_List.at(iter->first) != nullptr)
		Mesh_List.at(iter->first) = iter->second;
	}

	for (auto iter = Loading_Texture_List.begin(); iter != Loading_Texture_List.end(); ++iter)
	{
		if (Texture_List.at(iter->first) != nullptr)
		Texture_List.at(iter->first) = iter->second;
	}

}
void AssetManager::SetForLoading()
{
	StoringInLoadMaps = true;
}

void AssetManager::Initialize(HWND hWnd, CComPtr<ID3D11Device> theDevice = nullptr)
{
	pWindow = hWnd;
	pDevice = theDevice;

	CreateDDSTextureFromFile(pDevice, L"../Assets/Textures/Default_Texture.dds", NULL, &pDefault_Texture);
}

void AssetManager::Shutdown()
{
	this->ClearAllLoadedAssets();
	if (pManager)
		DestroyFBXManager();

	pDefault_Texture.Release();
}

//Creates the FbxManager to be used for loading the fbx files
//Should only be called once for each loading screen.
void AssetManager::CreateFBXManager()
{
	pManager = FbxManager::Create();
}

//Destroys the FbxManager
//Should only be called once for each loading screen.
void AssetManager::DestroyFBXManager()
{
	pManager->Destroy();
	pManager = nullptr;
}

void AssetManager::ClearAllLoadedAssets()
{
	//Clear Mesh List
	for (auto itter = Mesh_List.begin(); itter != Mesh_List.end(); itter++)
	{

		(itter)->second->ShutDown();
		SAFE_DELETE((itter)->second);
		//ID3D11Debug * CurrentDebug;
		//CurrentDebug->ReportLiveDeviceObjects(D3D11_RLDO_DETAIL);
		//ReleaseCOM(CurrentDebug);

		//AssetsUnloadedCount++;
		//ostringstream OSS;
		//OSS << AssetsUnloadedCount;
		//string CurrentAssetsunloaded = string(" Current Assets Unloaded Count = ");
		//CurrentAssetsunloaded += OSS.str();
		//PrintConsole(CurrentAssetsunloaded);
		//OSS.clear();

	}
	Mesh_List.clear();
	

	//Clear Texture List
	for (auto itter = Texture_List.begin(); itter != Texture_List.end(); itter++)
	{
		int poop = 0;
		//(itter)->second.p->Release();
		poop = (itter)->second->Release();
		//ReleaseCOM(itter->second);
		itter->second = nullptr;
		if (poop != 0)
			poop = 0;


		//AssetsUnloadedCount++;
		//ostringstream OSS;
		//OSS << AssetsUnloadedCount;
		//string CurrentAssetsunloaded = string(" Current Assets Unloaded Count = ");
		//CurrentAssetsunloaded += OSS.str();
		//CurrentAssetsunloaded += (itter)->first;
		//PrintConsole(CurrentAssetsunloaded);
		//OSS.clear();
	}
	Texture_List.clear();

	for (auto animItter = Anim_List.begin(); animItter != Anim_List.end(); animItter++)
	{
		SAFE_DELETE(animItter->second);
	}
	Anim_List.clear();

	Loading_Anim_List.clear();
	Loading_Texture_List.clear();
	Loading_Mesh_List.clear();
}

bool AssetManager::IsMeshLoaded(string mesh_name)
{
	if (StoringInLoadMaps == false)
	{
		if (Mesh_List.find(mesh_name) == Mesh_List.end())
			return false;
	}
	else
	{
		if (Loading_Mesh_List.find(mesh_name) == Loading_Mesh_List.end())
			return false;
	}
	return true;
}

bool AssetManager::IsAnimationLoaded(string anim_name)
{
	if (StoringInLoadMaps == false)
	{
		if (Anim_List.find(anim_name) == Anim_List.end())
			return false;
	}
	else
	{
		if (Loading_Anim_List.find(anim_name) == Loading_Anim_List.end())
			return false;
	}
	return true;
}

bool AssetManager::IsTextureLoaded(string texture_name)
{
	if (StoringInLoadMaps == false)
	{
		if (Texture_List.find(texture_name) == Texture_List.end())
			return false;
	}
	else
	{
		if (Loading_Texture_List.find(texture_name) == Loading_Texture_List.end())
			return false;
	}

	return true;

	//if (texture_name != "None")
	//{
	//	//AssetsLoadedCount++;
	//	//ostringstream OSS;
	//	//OSS << AssetsLoadedCount;
	//	//string CurrentAssetsLoaded = string(" Current Assets Loaded Count = ");
	//	//CurrentAssetsLoaded += OSS.str();
	//	//CurrentAssetsLoaded += texture_name;
	//	//PrintConsole(CurrentAssetsLoaded);
	//	//OSS.clear();
	//}
}

CMesh * AssetManager::GetMesh(std::string mesh_name)
{
	if (IsMeshLoaded(mesh_name))
		return Mesh_List[mesh_name];

	return NULL;
}

CComPtr<ID3D11ShaderResourceView> AssetManager::GetTexture(std::string texture_name)
{
	if (IsTextureLoaded(texture_name))
		return Texture_List[texture_name];

	return NULL;
}

CAnimation * AssetManager::GetAnimation(string anim_name)
{
	if (IsAnimationLoaded(anim_name))
		return Anim_List[anim_name];

	return NULL;
}

#pragma region Load Functions

bool AssetManager::LoadModel(ObjectToLoad * object)
{
	CMesh* currentMesh = nullptr;
	ID3D11ShaderResourceView * currentDiffuse = nullptr;
	ID3D11ShaderResourceView * currentNormal = nullptr;
	ID3D11ShaderResourceView * currentSpec = nullptr;
	ID3D11ShaderResourceView * currentGlow = nullptr;


	string binFilename = object->FBX_filename;
	binFilename.replace(binFilename.size() - 4, 4, ".bin");


	if (IsMeshLoaded(object->FBX_filename))
	{
		currentMesh = GetMesh(object->FBX_filename);
	}
	else
	{
		FILE * toRead = nullptr;
		fopen_s(&toRead, binFilename.c_str(), "rb");
		if (toRead)
		{
			currentMesh = LoadMeshBinFile(toRead);
			if (currentMesh == nullptr)
			{
				printConsole("Could not load the binary file of " + object->FBX_filename);
				return false;
			}
			Mesh_List[object->FBX_filename] = currentMesh;
		}
		else
		{
			//AssetsLoadedCount++;
			//ostringstream OSS;
			//OSS << AssetsLoadedCount;
			//string CurrentAssetsLoaded = string(" Current Assets Loaded Count = ");
			//CurrentAssetsLoaded += OSS.str();
			//PrintConsole(CurrentAssetsLoaded);
			//OSS.clear();

			if (pManager == nullptr)
			{
				MessageBox(pWindow, L"FbxManager was not created.", L"ERROR", NULL);
				return false;
			}

			FbxString Filename = object->FBX_filename.c_str();
			if (!FbxFileUtils::Exist(Filename.Buffer()))
				if (FbxFileUtils::Exist(object->FBX_filename.c_str()) != true)
				{
				string eMessage = "File - " + object->FBX_filename + " does not exist for loading assets.";
				wstring wEMessage = std::wstring(eMessage.begin(), eMessage.end());
				const wchar_t* widecstr = wEMessage.c_str();

				MessageBox(pWindow, widecstr, L"ERROR", NULL);
				return false;
				}

			FbxImporter * pImporter = FbxImporter::Create(pManager, "");



			pImporter->Initialize(Filename.Buffer());

			int major, minor, rev;
			pImporter->GetFileVersion(major, minor, rev);

			FbxScene * pScene = FbxScene::Create(pManager, Filename.Buffer());


			if (!pImporter->Import(pScene))
			{
				MessageBox(pWindow, (L"FBX file cannnot be imported: " + to_wstring(Filename.Buffer())).c_str(), L"ERROR", NULL);
				return false;
			}

			pImporter->Destroy();

			//Read Data for Asset
			if (object->pGO->IsAnimated())
				currentMesh = LoadMesh(object->FBX_filename, pScene, true);
			else
				currentMesh = LoadMesh(object->FBX_filename, pScene);
			if (currentMesh == nullptr)
			{
				string eMessage = "File - " + object->FBX_filename + " Problem reading the mesh from FBX file.";
				wstring wEMessage = std::wstring(eMessage.begin(), eMessage.end());
				const wchar_t* widecstr = wEMessage.c_str();

				MessageBox(pWindow, widecstr, L"ERROR", NULL);
				return false;
			}
		}

		//Put the mesh into the list
		if ( StoringInLoadMaps == false)
		Mesh_List[object->FBX_filename] = currentMesh;
		else
			Loading_Mesh_List[object->FBX_filename] = currentMesh;
	}
	//Todo: Get Textures' Filenames from FBX
	//for (int i = 0; i < pScene->GetTextureCount(); i++)
	//{
	//	FbxFileTexture* textureFile = pScene->GetSrcObject<FbxFileTexture>(i);
	//	
	//	string file = textureFile->GetRelativeFileName();

	//	const size_t last_slash_idx = file.find_last_of("\\/");
	//	if (string::npos != last_slash_idx)
	//	{
	//		file.erase(0, last_slash_idx + 1);
	//	}
	//}

	//if (IsTextureLoaded(object->Texture_filename))
	//	{
	//	currentDiffuse = GetTexture(object->Texture_filename);
	//	}
	//	else if (){}
	//{
	//	Texture_List[object->Texture_filename] = currentDiffuse;
	//}
	//else if (object->Texture_filename != "None")
	//{
	//	string eMessage = "File - " + object->Texture_filename + " DDS file un readable.";
	//	wstring wEMessage = std::wstring(eMessage.begin(), eMessage.end());
	//	const wchar_t* widecstr = wEMessage.c_str();
	//	currentDiffuse = this->pDefault_Texture;
	//	MessageBox(pWindow, widecstr, L"ERROR", NULL);
	//}

	LoadTexture(object->Texture_filename, pDevice, &currentDiffuse);
	LoadTexture(object->NormTexture_filename, pDevice, &currentNormal);
	LoadTexture(object->SpecTexture_filename, pDevice, &currentSpec);
	LoadTexture(object->GlowTexture_filename, pDevice, &currentGlow);

	//if (IsTextureLoaded(object->NormTexture_filename))
	//{
	//	currentNormal = GetTexture(object->NormTexture_filename);
	//}
	//else if ()
	//{
	//	Texture_List[object->NormTexture_filename] = currentNormal;
	//}
	//if (IsTextureLoaded(object->SpecTexture_filename))
	//{
	//	currentSpec = GetTexture(object->SpecTexture_filename);
	//}
	//else if ()
	//{
	//	Texture_List[object->SpecTexture_filename] = currentSpec;
	//}
	//Debug name 
	//string DebugName = object->pGO->GetTag() + std::to_string(AssetsLoaded);
	//new_Asset->pDiffuseSRV->SetPrivateData(WKPDID_D3DDebugObjectName, DebugName.length(), DebugName.c_str());
	//AssetsLoaded++;

	//Get Name from GO and use it for the asset
	object->pGO->SetRendererComponent(currentDiffuse, currentNormal, currentSpec, currentGlow, currentMesh);



	return true;
}

bool AssetManager::LoadAnimation(AnimToLoad * anim)
{
	CAnimation * animation = nullptr;

	if (this->GetAnimation(anim->animName) != nullptr)
	{
		//MessageBox(pWindow, L"Animation name already used or duplicate animation is being made.", L"Aniimation: ERROR", NULL);
		return false;
	}
	else
	{
		FILE * toRead = nullptr;
		string binAnimName = anim->AnimFilePath;
		binAnimName.replace(binAnimName.size() - 4, 4, ".bin");

		fopen_s(&toRead, binAnimName.c_str(), "rb");

		if (toRead != nullptr)
		{
			animation = LoadAnimBinFile(toRead);
			fclose(toRead);

			if (animation == nullptr)
			{
				printConsole("Could not load Bin File " + binAnimName);
				return false;
			}

			animation->SetAnimTag(anim->animName);
			this->Anim_List[anim->animName] = animation;
		}
		else
		{

			if (pManager == nullptr)
			{
				MessageBox(pWindow, L"FbxManager was not created.", L"Aniimation: ERROR", NULL);
				return false;
			}


			FbxString Filename = anim->AnimFilePath.c_str();
			if (!FbxFileUtils::Exist(Filename.Buffer()))
				if (FbxFileUtils::Exist(Filename) != true)
				{
				string eMessage = "File - " + Filename + " does not exist for loading assets.";
				wstring wEMessage = std::wstring(eMessage.begin(), eMessage.end());
				const wchar_t* widecstr = wEMessage.c_str();

				MessageBox(pWindow, widecstr, L"Aniimation: ERROR", NULL);
				return false;
				}

			FbxImporter * pImporter = FbxImporter::Create(pManager, "");

			pImporter->Initialize(Filename.Buffer());

			int major, minor, rev;
			pImporter->GetFileVersion(major, minor, rev);

			FbxScene * pScene = FbxScene::Create(pManager, Filename.Buffer());



			if (!pImporter->Import(pScene))
			{
				MessageBox(pWindow, (L"FBX file cannnot be imported: " + to_wstring(Filename.Buffer())).c_str(), L"Animation: ERROR", NULL);
				return false;
			}

			pImporter->Destroy();

			//All this did was load the Bind Pose and its skin!
			///Essentially the model and it's vert's influences.
			FbxMesh * pMesh = nullptr;

			FbxNode * pNode = nullptr;
			FbxNode * pGroupNode = nullptr;
			FbxNode * pRootNode = pScene->GetRootNode();
			int rootCount = pRootNode->GetChildCount();

			for (int i = 0; i < rootCount; i++)
			{
				pNode = pRootNode->GetChild(i);

				pMesh = pNode->GetMesh();
				if (pMesh)
				{
					if (pRootNode->GetChild(i + 1))
						pNode = pRootNode->GetChild(i + 1);
					else if (pRootNode->GetChild(i - 1))
						pNode = pRootNode->GetChild(i - 1);
					break;
				}
			}

			string name = pNode->GetName();
			if (name == "NimbusGroupNode")
			{
				pGroupNode = pNode;
				pNode = pNode->GetChild(0);
			}


			if (pNode == nullptr)
			{
				MessageBox(pWindow, L"FBX file cannnot find the Bind Pose.", L"Aniimation: ERROR", NULL);
				return false;
				///used for debugging heirarchy
				//pNode = pScene->GetRootNode();
				//break;
			}

			//Create the bind frame
			tKeyFrame * bindFrame = new tKeyFrame;

			//Load
			RecursiveAnimFunc(pNode, pMesh, bindFrame, 0);

			//Now load the animation!
			animation = new CAnimation;
			animation->m_pBindPose = bindFrame;


			FbxAnimStack * animStack = pScene->GetSrcObject<FbxAnimStack>(0);
			///Commented out to get more frames.
			//FbxAnimLayer * animLayer = animStack->GetMember<FbxAnimLayer>(0);

			////Get a list of unique times for the animation
			//for (size_t i = 0; i < nodeList.size(); i++)
			//{
			//	LoadCurve(nodeList[i], animLayer, FBXSDK_CURVENODE_COMPONENT_X);
			//	LoadCurve(nodeList[i], animLayer, FBXSDK_CURVENODE_COMPONENT_Y);
			//	LoadCurve(nodeList[i], animLayer, FBXSDK_CURVENODE_COMPONENT_Z);
			//}


			FbxTakeInfo * takeInfo = pScene->GetTakeInfo(animStack->GetName());
			FbxTime start = takeInfo->mLocalTimeSpan.GetStart();
			FbxTime end = takeInfo->mLocalTimeSpan.GetStop();
			FbxTime dur = end - start;
			animation->SetAnimTime((float)dur.GetSecondDouble());

			int frameCount = (int)dur.GetFrameCount();

			for (int i = 1; i < frameCount; i++)
			{
				tKeyFrame * newFrame = new tKeyFrame;
				FbxTime currTime;
				currTime.SetFrame(i, FbxTime::eFrames24);

				for (size_t j = 0; j < nodeList.size(); j++)
				{
					//Getting the Matrix for this KeyFrame
					CNode * mat = new CNode;
					FbxAMatrix bindOffset = nodeList[j]->EvaluateGlobalTransform(currTime);
					FbxAMatrix bindPose;
					static_cast<FbxSkin*>(pMesh->GetDeformer(0))->GetCluster(j)->GetTransformLinkMatrix(bindPose);
					FbxAMatrix offset = bindOffset * bindPose.Inverse();

					//Converting the matrix to DirectX
					XMFLOAT4X4 toStore(
						(float)offset[0][0], (float)offset[0][1], -(float)offset[0][2], (float)offset[0][3],
						(float)offset[1][0], (float)offset[1][1], -(float)offset[1][2], (float)offset[1][3],
						-(float)offset[2][0], -(float)offset[2][1], (float)offset[2][2], -(float)offset[2][3],
						(float)offset[3][0], (float)offset[3][1], -(float)offset[3][2], (float)offset[3][3]);

					mat->GetWorldMat() = toStore;
					newFrame->m_Bones.push_back(mat);

					mat->m_ChildrenIndex = bindFrame->m_Bones[j]->m_ChildrenIndex;
					mat->m_nParentIndex = bindFrame->m_Bones[j]->m_nParentIndex;

				}

				//Letting the Joints know what their parents and children are.
				for (size_t j = 0; j < newFrame->m_Bones.size(); j++)
				{
					if (newFrame->m_Bones[j]->m_nParentIndex == j)
						newFrame->m_Bones[j]->m_pParent = nullptr;
					else
						newFrame->m_Bones[j]->m_pParent = newFrame->m_Bones[newFrame->m_Bones[j]->m_nParentIndex];

					for (size_t x = 0; x < newFrame->m_Bones[j]->m_ChildrenIndex.size(); x++)
						newFrame->m_Bones[j]->AddChild(newFrame->m_Bones[newFrame->m_Bones[j]->m_ChildrenIndex[x]]);
				}

				//Finally adding it to the animations
				newFrame->fKeyTime = (float)currTime.GetSecondDouble();
				animation->AddFrames(newFrame);
			}

			animation->SetAnimTag(anim->animName);
			this->Anim_List[anim->animName] = animation;

			inf.clear();
			nodeList.clear();

			CreateBinFile(anim->AnimFilePath, *animation);

		}
	}

	return true;
}

CMesh* AssetManager::LoadMesh(string filename, FbxScene * pScene, bool bAnimated)
{


	std::vector<XMFLOAT3> mesh;
	std::vector<XMFLOAT3> normals;
	std::vector<XMFLOAT2> uvs;
	std::vector<XMFLOAT3> tangents;
	std::vector<XMFLOAT3> bitangents;
	std::vector<unsigned short> indicies;
	std::vector<float> binormals;


	FbxNode * pRoot = nullptr;
	FbxMesh * pMesh = nullptr;
	FbxNode * pNode = nullptr;
	FbxNode * pGroupNode = nullptr;
	int nodeCount = 0;

	//if (bAnimated)
	//{
	//	pRoot = pScene->GetRootNode();
	//	nodeCount = pRoot->GetChildCount();
	//}
	//else
	nodeCount = pScene->GetNodeCount();

	//Find the first node with a mesh;
	for (int i = 0; i < nodeCount; i++)
	{
		//if (bAnimated)
		//	pNode = pRoot->GetChild(i);
		//else
		pNode = pScene->GetNode(i);

		//string name = pNode->GetName();
		//if (name == "NimbusGroupNode")
		//{
		//	pGroupNode = pNode;
		//	pRoot = pNode;
		//	i = 0;
		//	nodeCount = pRoot->GetChildCount();
		//	continue;
		//}

		pMesh = pNode->GetMesh();
		if (pMesh)
			break;

	}

	if (pMesh == nullptr)
	{
		return NULL;
	}

	//Parse information and store into CMesh;
	CMesh * new_Mesh = new CMesh;

	FbxVector4 tempVector; //Used for temp storage of vectors.
	FbxVector2 tempUV; //Used for temp storage of UVs.

	int tri_Count = pMesh->GetPolygonCount();
	int vert_count = pMesh->GetPolygonVertexCount();
	uvs.resize(vert_count);
	normals.resize(vert_count);
	tangents.resize(vert_count);
	mesh.resize(vert_count);

	//Grab the index array
	int numIndicies = pMesh->GetPolygonVertexCount();
	for (int i = 0; i < numIndicies; i++)
		indicies.push_back((unsigned short)pMesh->GetPolygonVertices()[i]);

	//Grab the Tangent and normals from the FbxMesh.
	FbxGeometryElementTangent* vertTangents = pMesh->GetElementTangent();
	FbxGeometryElementNormal* vertNormals = pMesh->GetElementNormal();

	//Grab the UV names
	FbxStringList texture_names;
	pMesh->GetUVSetNames(texture_names);
	int num_of_sets = texture_names.GetCount();

	if (vertTangents == nullptr)
		new_Mesh->SetIsUsingTangets(false);
	else
		new_Mesh->SetIsUsingTangets(true);



	for (int triIndex = 0; triIndex < tri_Count; triIndex++)
	{
		int startIndex = pMesh->GetPolygonVertexIndex(triIndex);
		for (int vertIndex = 0; vertIndex < 3; vertIndex++, startIndex++)//Count only see how many times it's been through the loop.
		{
			//Read the vert for this index.
			int ctrl_Point = pMesh->GetPolygonVertex(triIndex, vertIndex);
			XMFLOAT3 vert((float)pMesh->GetControlPointAt(ctrl_Point)[0], (float)pMesh->GetControlPointAt(ctrl_Point)[1], -(float)pMesh->GetControlPointAt(ctrl_Point)[2]);
			mesh[indicies[startIndex]] = vert;

			//Read Tangent for this vert.
			if (vertTangents != nullptr)
			{
				switch (vertTangents->GetReferenceMode())
				{
				case FbxGeometryElement::eDirect:
				{
					tangents[indicies[startIndex]] = XMFLOAT3((float)vertTangents->GetDirectArray().GetAt(indicies[startIndex])[0], (float)vertTangents->GetDirectArray().GetAt(indicies[startIndex])[1], -(float)vertTangents->GetDirectArray().GetAt(indicies[startIndex])[2]);
				}
					break;
				case FbxGeometryElement::eIndexToDirect:
				{
					int index = vertTangents->GetIndexArray().GetAt(startIndex);
					tangents[indicies[startIndex]] = XMFLOAT3((float)vertTangents->GetDirectArray().GetAt(index).mData[0], (float)vertTangents->GetDirectArray().GetAt(index).mData[1], -(float)vertTangents->GetDirectArray().GetAt(index).mData[2]);
				}
					break;
				default:
				{
					//int bad = 0;
					break;
				}
				}
			}

			//Read the normal for this vert.
			if (vertNormals)
			{
				switch (vertNormals->GetReferenceMode())
				{
				case FbxGeometryElement::eDirect:
				{
					normals[indicies[startIndex]] = XMFLOAT3((float)vertNormals->GetDirectArray().GetAt(indicies[startIndex])[0], (float)vertNormals->GetDirectArray().GetAt(indicies[startIndex])[1], -(float)vertNormals->GetDirectArray().GetAt(indicies[startIndex])[2]);
				}
					break;
				case FbxGeometryElement::eIndex:
				{
					pMesh->GetPolygonVertexNormal(triIndex, vertIndex, tempVector);
					normals[indicies[startIndex]] = XMFLOAT3((float)tempVector[0], (float)tempVector[1], -(float)tempVector[2]);
				}
					break;
				case FbxGeometryElement::eIndexToDirect:
				{
					int index = vertNormals->GetIndexArray().GetAt(startIndex);
					normals[indicies[startIndex]] = XMFLOAT3((float)vertNormals->GetDirectArray().GetAt(index).mData[0], (float)vertNormals->GetDirectArray().GetAt(index).mData[1], -(float)vertNormals->GetDirectArray().GetAt(index).mData[2]);
				}
					break;
				default:
				{
					//int bad = 0;
					break;
				}
				}
			}

			//Read the UV for this vert.
			for (int i = 0; i < num_of_sets; i++)
			{
				FbxGeometryElementUV * vertUV = pMesh->GetElementUV(texture_names[0]);
				switch (vertUV->GetReferenceMode())
				{
				case FbxGeometryElement::eDirect:
				{
					uvs[indicies[startIndex]] = XMFLOAT2((float)vertUV->GetDirectArray().GetAt(indicies[startIndex])[0], 1.0f - (float)vertUV->GetDirectArray().GetAt(indicies[startIndex])[1]);
				}
					break;
				case FbxGeometryElement::eIndex:
				{
					bool mapped = true;
					pMesh->GetPolygonVertexUV(triIndex, vertIndex, texture_names[i], tempUV, mapped);
					uvs[indicies[startIndex]] = XMFLOAT2((float)tempUV[0], 1.0f - (float)tempUV[1]);
				}
					break;
				case FbxGeometryElement::eIndexToDirect:
				{
					int index = vertUV->GetIndexArray().GetAt(startIndex);
					uvs[indicies[startIndex]] = XMFLOAT2((float)vertUV->GetDirectArray().GetAt(index).mData[0], 1.0f - (float)vertUV->GetDirectArray().GetAt(index).mData[1]);
				}
					break;
				default:
				{
					break;
				}
				}
			}
		}
	}

	//Reverse the index array to work with directX.
	reverse(indicies.begin(), indicies.end());

	//Add initialize the CMesh
	vector<tJointInfluence> infList;

	if (!bAnimated)
	{
		new_Mesh->CreateStaticMesh(mesh, tangents, normals, uvs, indicies, pDevice);
		CreateBinFile(filename, mesh, normals, uvs, tangents, indicies, false, infList);
	}
	else
	{
		int deformerCount = pMesh->GetDeformerCount();
		FbxSkin * pSkin = static_cast<FbxSkin*>(pMesh->GetDeformer(0));

		int clusterCount = pSkin->GetClusterCount();

		for (int index = 0; index < clusterCount; index++)
			LoadSkin(pSkin->GetCluster(index), index);

		for (int i = 0; i < (int)mesh.size(); i++)
			infList.push_back(inf[i]);
		new_Mesh->CreateAnimatedMesh(mesh, tangents, normals, uvs, indicies, pDevice, infList);

		CreateBinFile(filename, mesh, normals, uvs, tangents, indicies, true, infList);

		infList.clear();
		inf.clear();
	}


	//Destroy Scene and return true;
	//pScene->Destroy();

	return new_Mesh;
}

bool AssetManager::LoadTexture(string filename, ID3D11Device * pDevice, ID3D11ShaderResourceView ** new_Texture)
{
	//Checking to see if we have the texture already.
	if (filename.empty() || filename == "None")
		return false;

	if (filename == "../Assets/Textures/LeagueGothic_Glyph.dds" || filename == "../Assets/Textures/BookAntiquaBig.dds")
		int poop = 0;

	if (IsTextureLoaded(filename))
	{
		*new_Texture = GetTexture(filename);
		return true;
	}

	wstring wEMessage = std::wstring(filename.begin(), filename.end());
	const wchar_t* wFilePath = wEMessage.c_str();

	HRESULT result = CreateDDSTextureFromFile(pDevice, wFilePath, NULL, new_Texture);

	if (result != S_OK)
	{
		string Error = "Texture (" + filename + ") not Found.";
		printConsole(Error);

		*new_Texture = pDefault_Texture;
		return false;
	}
	else
	{
		if (StoringInLoadMaps == false)
			Texture_List[filename] = *new_Texture;
		else
			Loading_Texture_List[filename] = *new_Texture;

	}

	return true;
}

bool AssetManager::LoadSound(char const * filename)
{

	return true;
}

bool AssetManager::LoadHudAsset(HUDtoLoad * HTL)
{
	return LoadTexture(HTL->TextureFilePath, pDevice, &HTL->pGO->GetRendererComponent()->DiffuseTexture);
}

bool AssetManager::LoadTelegraphAsset(TelegraphToLoad * TTL)
{
	return LoadTexture(TTL->TextureFilePath, pDevice, &TTL->pGO->GetRendererComponent()->DiffuseTexture);
}

bool AssetManager::LoadEfftectAsset(EffectToLoad * ETL)
{
	return LoadTexture(ETL->TextureFilePath, pDevice, &ETL->pGO->GetRendererComponent()->DiffuseTexture);
}

bool AssetManager::LoadFontAsset(FontToLoad* FTL)
{
	//if (IsTextureLoaded(FTL->glyphTextureFilePath) && IsTextureLoaded(FTL->outlineTextureFilePath))
	//{
	//	FTL->pFont->SetGlyphTexture(Texture_List[FTL->glyphTextureFilePath]);
	//	FTL->pFont->SetOutlineTexture(Texture_List[FTL->outlineTextureFilePath]);
	//}
	//else
	//{
	ID3D11ShaderResourceView* pTexture = nullptr;
	//Glyph Texture loading
	LoadTexture(FTL->glyphTextureFilePath, pDevice, &pTexture);
	FTL->pFont->SetGlyphTexture(pTexture);

	//DebugName = FTL->pFont->GetTag() + " - Glyph" + std::to_string(AssetsLoaded);
	//pTexture->SetPrivateData(WKPDID_D3DDebugObjectName, DebugName.length(), DebugName.c_str());
	//AssetsLoaded++;

	LoadTexture(FTL->outlineTextureFilePath, pDevice, &pTexture);
	FTL->pFont->SetOutlineTexture(pTexture);


	//DebugName = FTL->pFont->GetTag() + " - Outline" + std::to_string(AssetsLoaded);
	//pTexture->SetPrivateData(WKPDID_D3DDebugObjectName, DebugName.length(), DebugName.c_str());
	//AssetsLoaded++;
	//}
	return true;
}

bool AssetManager::LoadEmitterAsset(EmitterToLoad* ETL)
{

	ID3D11ShaderResourceView* pTexture = nullptr;

	LoadTexture(ETL->textureFilePath, pDevice, &pTexture);

	ETL->pEmitter->SetParticleTexture(pTexture);

	return true;
}

#pragma endregion

#pragma region Binary Read/Write Section

bool AssetManager::CreateBinFile(string filename, vector<XMFLOAT3> pos, vector<XMFLOAT3> normals, vector<XMFLOAT2> UVs, vector<XMFLOAT3> tangents, vector<index_type> indicies, bool animated, vector<tJointInfluence> infList)
{
	//tempC();
	tMesh_Bin_Header header;
	ZeroMemory(&header, sizeof(tMesh_Bin_Header));

	if (tangents.size() > 0)
		header.hasTangents = true;

	//Create the file
	FILE * file_create = nullptr;
	unsigned int byte_write = 0;
	unsigned int total_bytes = 0;
	unsigned int array_size = 0;

	unsigned int found = filename.find_first_of("*.fbx");
	filename.replace(filename.size() - 4, 4, ".bin");
	fopen_s(&file_create, filename.c_str(), "wb");

	if (file_create == nullptr)
		return false;

	////Write out whether it is animated or not.
	//byte_write = fwrite(&animated, sizeof(bool), sizeof(animated), file_create);

	////Write out whether it is tangent or not.
	//byte_write = fwrite(&isTangent, sizeof(bool), sizeof(isTangent), file_create);

	header.size_of_verts = pos.size();
	header.size_of_indicies = indicies.size();
	header.index_size = sizeof(indicies[0]);
	header.isAnimated = animated;

	if (animated)
	{
		if (header.hasTangents)
		{
			header.vert_struct_size = sizeof(CMesh::tAnimated_Tan_Verts);

			//Write out the header of the bin file.
			byte_write = fwrite(&header, sizeof(tMesh_Bin_Header), 1, file_create);
			total_bytes += sizeof(tMesh_Bin_Header);

			CMesh::tAnimated_Tan_Verts * vert_list = new CMesh::tAnimated_Tan_Verts[header.size_of_verts];
			for (unsigned int i = 0; i < pos.size(); i++)
			{
				vert_list[i].norms = normals[i];
				vert_list[i].pos = pos[i];
				vert_list[i].tangent = tangents[i];
				vert_list[i].uvs = UVs[i];
				memcpy(vert_list[i].joint_index, infList[i].joint_index, sizeof(XMUINT4));
				vert_list[i].weights = infList[i].weight;
			}

			//Write the verts out.
			array_size = header.size_of_verts * header.vert_struct_size;
			byte_write = fwrite(vert_list, header.vert_struct_size, header.size_of_verts, file_create);
			total_bytes += array_size;

			delete[] vert_list;
		}
		else
		{
			header.vert_struct_size = sizeof(CMesh::tAnimated_Verts);

			//Write out the header of the bin file.
			byte_write = fwrite(&header, sizeof(tMesh_Bin_Header), 1, file_create);
			total_bytes += sizeof(tMesh_Bin_Header);

			CMesh::tAnimated_Verts * vert_list = new CMesh::tAnimated_Verts[header.size_of_verts];
			for (unsigned int i = 0; i < pos.size(); i++)
			{
				vert_list[i].norms = normals[i];
				vert_list[i].pos = pos[i];
				vert_list[i].uvs = UVs[i];
				memcpy(vert_list[i].joint_index, infList[i].joint_index, sizeof(XMUINT4));
				vert_list[i].weights = infList[i].weight;
			}

			//Write the verts out.
			array_size = header.size_of_verts * header.vert_struct_size;
			byte_write = fwrite(vert_list, header.vert_struct_size, header.size_of_verts, file_create);
			total_bytes += array_size;

			delete[] vert_list;
		}
	}
	else
	{
		if (header.hasTangents)
		{
			header.vert_struct_size = sizeof(CMesh::tStatic_Tan_Verts);

			//Write out the header of the bin file.
			byte_write = fwrite(&header, sizeof(tMesh_Bin_Header), 1, file_create);
			total_bytes += sizeof(tMesh_Bin_Header);

			CMesh::tStatic_Tan_Verts * vert_list = new CMesh::tStatic_Tan_Verts[header.size_of_verts];
			for (unsigned int i = 0; i < pos.size(); i++)
			{
				vert_list[i].norms = normals[i];
				vert_list[i].pos = pos[i];
				vert_list[i].tangent = tangents[i];
				vert_list[i].uvs = UVs[i];
			}
			//Write the verts out.
			array_size = header.size_of_verts * header.vert_struct_size;
			byte_write = fwrite(vert_list, header.vert_struct_size, header.size_of_verts, file_create);
			total_bytes += array_size;

			delete[] vert_list;
		}
		else
		{
			header.vert_struct_size = sizeof(CMesh::tStatic_Verts);

			//Write out the header of the bin file.
			byte_write = fwrite(&header, sizeof(tMesh_Bin_Header), 1, file_create);
			total_bytes += sizeof(tMesh_Bin_Header);

			CMesh::tStatic_Verts * vert_list = new CMesh::tStatic_Verts[header.size_of_verts];

			for (unsigned int i = 0; i < pos.size(); i++)
			{
				vert_list[i].norms = normals[i];
				vert_list[i].pos = pos[i];
				vert_list[i].uvs = UVs[i];
			}

			//Write the verts out.

			array_size = header.size_of_verts * header.vert_struct_size;
			byte_write = fwrite(vert_list, header.vert_struct_size, header.size_of_verts, file_create);
			total_bytes += array_size;

			delete[] vert_list;
		}
	}

	//Write the indicies out.
	byte_write = fwrite(&indicies[0], sizeof(index_type), indicies.size(), file_create);
	total_bytes += header.size_of_indicies * header.index_size;
	fclose(file_create);

	printConsole("Mesh Binary File Created at " + filename + "\ntotal bytes: ", total_bytes);

	return true;
}

bool AssetManager::CreateBinFile(string filename, CAnimation& animation)
{
	string no_name = "No Name";
	unsigned int total_bytes = 0;

	//Create the file
	FILE * file_write = nullptr;
	filename.replace(filename.size() - 4, 4, ".bin");
	fopen_s(&file_write, filename.c_str(), "wb");


	if (file_write == false)
		return false;

	//Create the Header.
	tAnim_Bin_Header header;
	ZeroMemory(&header, sizeof(tAnim_Bin_Header));

	//Write out the number of frames
	vector<tKeyFrame*>& frames = animation.GetFrames();
	header.num_of_frames = frames.size();

	//Write out the number of joints
	vector<CNode*> bones = frames[0]->m_Bones;
	header.num_of_bones = bones.size();

	//Write out the total time of the animation.
	header.anim_time = animation.GetAnimTime();

	//Write out the header.
	fwrite(&header, sizeof(tAnim_Bin_Header), 1, file_write);
	total_bytes += sizeof(tAnim_Bin_Header);

	unsigned int vec_size = 0;

	for (unsigned int i = 0; i < header.num_of_frames; i++)
	{
		//Write out the frame's time
		fwrite(&frames[i]->fKeyTime, sizeof(float), 1, file_write);
		total_bytes += sizeof(float);

		//Get this frame's set of bone positions.
		bones = frames[i]->m_Bones;
		for (unsigned int j = 0; j < header.num_of_bones; j++)
		{
			//Write out the node name 
			vec_size = bones[j]->Node_name.size();
			if (vec_size > 0)
			{
				fwrite(&vec_size, sizeof(unsigned int), 1, file_write);
				fwrite(bones[j]->Node_name.c_str(), sizeof(BYTE), vec_size, file_write);
			}
			else
			{
				vec_size = no_name.size();
				fwrite(&vec_size, sizeof(unsigned int), 1, file_write);
				fwrite(no_name.c_str(), sizeof(BYTE), vec_size, file_write);
			}
			total_bytes += vec_size;

			//Write out the bone transforms
			fwrite(&bones[j]->GetWorldMat(), sizeof(XMFLOAT4X4), 1, file_write);
			fwrite(&bones[j]->GetLocalMat(), sizeof(XMFLOAT4X4), 1, file_write);
			total_bytes += sizeof(XMFLOAT4X4) * 2;

			//Write out the parent index
			fwrite(&bones[j]->m_nParentIndex, sizeof(BYTE), 1, file_write);
			total_bytes++;

			//Write out how many children there are.
			vec_size = bones[j]->m_ChildrenIndex.size();
			fwrite(&vec_size, sizeof(unsigned int), 1, file_write);
			total_bytes += sizeof(unsigned int);

			//Only write out the children if there are children.
			if (vec_size > 0)
			{
				//Write out all the children of this bone.
				fwrite(&bones[j]->m_ChildrenIndex[0], sizeof(BYTE), vec_size, file_write);
			}
			total_bytes += vec_size;
		}
	}

	fclose(file_write);
	printConsole("Anim Binary File Created at " + filename + "\ntotal bytes: ", total_bytes);

	return true;
}

CMesh* AssetManager::LoadMeshBinFile(FILE * file_read)
{
	CMesh * mesh = nullptr;
	vector<byte> mesh_data;
	vector<byte> index_data;

	tMesh_Bin_Header header;
	ZeroMemory(&header, sizeof(tMesh_Bin_Header));

	unsigned int bytes_read = 0;

	if (file_read)
	{
		bytes_read = fread(&header, sizeof(tMesh_Bin_Header), 1, file_read);

		//mesh_data = alloca(header.size_of_verts * header.vert_struct_size);
		mesh_data.resize(header.size_of_verts * header.vert_struct_size);
		bytes_read = fread(&mesh_data[0], mesh_data.size(), 1, file_read);

		//index_data = alloca(header.size_of_indicies * header.index_size);
		index_data.resize(header.size_of_indicies * header.index_size);
		bytes_read = fread(&index_data[0], index_data.size(), 1, file_read);

		mesh = new CMesh;
		bool good = mesh->LoadModelVerts(pDevice, mesh_data, index_data, header);

		if (!good)
		{
			mesh->ShutDown();
			delete mesh;
			mesh = nullptr;
		}
	}

	mesh_data.clear();
	index_data.clear();

	return mesh;
}

CAnimation* AssetManager::LoadAnimBinFile(FILE * file_read)
{
	CAnimation* anim = nullptr;
	tKeyFrame* frame = nullptr;
	CNode* bone = nullptr;
	string node_name;
	unsigned int vec_size;

	tAnim_Bin_Header header;
	ZeroMemory(&header, sizeof(tAnim_Bin_Header));

	if (file_read)
	{
		anim = new CAnimation;
		fread(&header, sizeof(tAnim_Bin_Header), 1, file_read);

		//read in the animation total time.
		anim->SetAnimTime(header.anim_time);

		for (unsigned int i = 0; i < header.num_of_frames; i++)
		{
			//Create new Frame
			frame = new tKeyFrame;
			//Read Frame's time
			fread(&frame->fKeyTime, sizeof(float), 1, file_read);

			for (unsigned int j = 0; j < header.num_of_bones; j++)
			{
				bone = new CNode;
				//Read in node name 
				fread(&vec_size, sizeof(unsigned int), 1, file_read);
				node_name.clear();
				node_name.resize(vec_size);
				fread(&node_name[0], sizeof(BYTE), vec_size, file_read);

				//Read in the node's name just to be safe.
				bone->Node_name = node_name;

				//Read in the transform data.
				fread(&bone->GetWorldMat(), sizeof(XMFLOAT4X4), 1, file_read);
				fread(&bone->GetLocalMat(), sizeof(XMFLOAT4X4), 1, file_read);

				//Read in the parent index
				fread(&bone->m_nParentIndex, sizeof(BYTE), 1, file_read);

				//Read in the children indicies
				fread(&vec_size, sizeof(unsigned int), 1, file_read);

				//Only read the children if there are children.
				if (vec_size > 0)
				{
					bone->m_ChildrenIndex.resize(vec_size);
					fread(&bone->m_ChildrenIndex[0], sizeof(BYTE), vec_size, file_read);
				}


				frame->m_Bones.push_back(bone);
			}

			//Letting the Joints know what their parents and children are.
			for (size_t j = 0; j < frame->m_Bones.size(); j++)
			{
				if (frame->m_Bones[j]->m_nParentIndex == j)
					frame->m_Bones[j]->m_pParent = nullptr;
				else
					frame->m_Bones[j]->m_pParent = frame->m_Bones[frame->m_Bones[j]->m_nParentIndex];

				for (size_t x = 0; x < frame->m_Bones[j]->m_ChildrenIndex.size(); x++)
					frame->m_Bones[j]->AddChild(frame->m_Bones[frame->m_Bones[j]->m_ChildrenIndex[x]]);
			}

			anim->AddFrames(frame);
		}

		fclose(file_read);
	}

	return anim;
}

#pragma endregion


//Prototype functions
void RecursiveAnimFunc(FbxNode * pNode, FbxMesh * pMesh, tKeyFrame * bind, int index, int parent)
{
	if (pNode == nullptr || bind == nullptr)
		return;

	//Create a new CFrame
	CNode * pFrame = new CNode;
	pFrame->Node_name = pNode->GetName();
	nodeList.push_back(pNode);

	if (bind->m_Bones.size() != parent)
	{
		pFrame->m_nParentIndex = parent;
		pFrame->m_pParent = bind->m_Bones[parent];
		pFrame->m_pParent->m_Children.push_back(pFrame);
		pFrame->m_pParent->m_ChildrenIndex.push_back(index);
	}

	bind->m_Bones.push_back(pFrame);

	if (pMesh)
	{
		//Process the nodes to load the skin for the mesh.
		///Transforms
		FbxAMatrix bindMatrix, currentMatrix;

		//Get the Skin for this model 
		FbxDeformer * pDeformer = pMesh->GetDeformer(0);
		FbxSkin * pSkin = static_cast<FbxSkin *>(pDeformer);
		//Figure out how many clusters there are
		int cluster_count = pSkin->GetClusterCount();

		//Make sure the current node is within the number of clusters
		if (index < cluster_count)
		{
			FbxCluster * pCluster = pSkin->GetCluster(index);
			pCluster->GetTransformLinkMatrix(bindMatrix);
			pCluster->GetTransformMatrix(currentMatrix);

			FbxAMatrix transform = bindMatrix.Inverse() * currentMatrix;
			XMFLOAT4X4 toStore(
				(float)transform[0][0], (float)transform[0][1], -(float)transform[0][2], (float)transform[0][3],
				(float)transform[1][0], (float)transform[1][1], -(float)transform[1][2], (float)transform[1][3],
				-(float)transform[2][0], -(float)transform[2][1], (float)transform[2][2], -(float)transform[2][3],
				(float)transform[3][0], (float)transform[3][1], -(float)transform[3][2], (float)transform[3][3]);

			pFrame->GetWorldMat() = toStore;
		}
	}

	int count = pNode->GetChildCount();
	for (int i = 0; i < count; i++)
	{
		RecursiveAnimFunc(pNode->GetChild(i), pMesh, bind, bind->m_Bones.size(), index);
	}
}

void LoadSkin(FbxCluster * pCluster, int joint_index)
{
	int count = pCluster->GetControlPointIndicesCount();
	for (int j = 0; j < count; j++)
	{
		int point = pCluster->GetControlPointIndices()[j];
		double weight = pCluster->GetControlPointWeights()[j];

		if (inf[point].weight.x != NULL)
		{
			if (weight < 1.0)
			{
				if (inf[point].joint_index[1] == NULL)
					inf[point].joint_index[1] = joint_index;
				else if (inf[point].joint_index[2] == NULL)
					inf[point].joint_index[2] = joint_index;
				else if (inf[point].joint_index[3] == NULL)
					inf[point].joint_index[3] = joint_index;

				if (inf[point].weight.y == NULL)
					inf[point].weight.y = (float)weight;
				else if (inf[point].weight.z == NULL)
					inf[point].weight.z = (float)weight;
				else if (inf[point].weight.w == NULL)
					inf[point].weight.w = (float)weight;
			}
		}
		else
		{
			tJointInfluence stuff;
			stuff.joint_index[0] = joint_index;
			stuff.weight.x = (float)weight;

			inf[point] = stuff;
		}
	}
}

void LoadCurve(FbxNode * pNode, FbxAnimLayer * currLayer, const char * comp)
{
	FbxAnimCurve * pCurve = nullptr;
	int keyCount = 0;

	pCurve = pNode->LclTranslation.GetCurve(currLayer, comp);
	keyCount = pCurve->KeyGetCount();

	for (int i = 0; i < keyCount; i++)
	{
		double time = pCurve->KeyGetTime(i).GetSecondDouble();

		if (uniqueTimes.size())
		{
			for (size_t j = 0; j < uniqueTimes.size(); j++)
			{
				if (uniqueTimes[j] == time)
					break;

				if (uniqueTimes[j] > time)
				{
					uniqueTimes.insert(uniqueTimes.begin(), time);
					break;
				}
				else if (j < (uniqueTimes.size() - 1) && (uniqueTimes[j] < time && uniqueTimes[j + 1] > time))
				{
					auto iter = uniqueTimes.begin();
					for (size_t index = 0; index <= j; index++, iter++);
					uniqueTimes.insert(iter, time);
					break;
				}
				else if (uniqueTimes[j] < time && j == (uniqueTimes.size() - 1))
				{
					uniqueTimes.push_back(time);
					break;
				}
			}
		}
		else
			uniqueTimes.push_back(time);
	}

	pCurve = pNode->LclRotation.GetCurve(currLayer, comp);
	keyCount = pCurve->KeyGetCount();

	for (int i = 0; i < keyCount; i++)
	{
		double time = pCurve->KeyGetTime(i).GetSecondDouble();

		if (uniqueTimes.size())
		{
			for (size_t j = 0; j < uniqueTimes.size(); j++)
			{
				if (uniqueTimes[j] == time)
					break;

				if (uniqueTimes[j] > time)
				{
					uniqueTimes.insert(uniqueTimes.begin(), time);
					break;
				}
				else if (j < (uniqueTimes.size() - 1) && (uniqueTimes[j] < time && uniqueTimes[j + 1] > time))
				{
					auto iter = uniqueTimes.begin();
					for (size_t index = 0; index <= j; index++, iter++);
					uniqueTimes.insert(iter, time);
					break;
				}
				else if (uniqueTimes[j] < time && j == (uniqueTimes.size() - 1))
				{
					uniqueTimes.push_back(time);
					break;
				}
			}
		}
		else
			uniqueTimes.push_back(time);
	}

	pCurve = pNode->LclScaling.GetCurve(currLayer, comp);
	keyCount = pCurve->KeyGetCount();

	for (int i = 0; i < keyCount; i++)
	{
		double time = pCurve->KeyGetTime(i).GetSecondDouble();

		if (uniqueTimes.size())
		{
			for (size_t j = 0; j < uniqueTimes.size(); j++)
			{
				if (uniqueTimes[j] == time)
					break;

				if (uniqueTimes[j] > time)
				{
					uniqueTimes.insert(uniqueTimes.begin(), time);
					break;
				}
				else if (j < (uniqueTimes.size() - 1) && (uniqueTimes[j] < time && uniqueTimes[j + 1] > time))
				{
					auto iter = uniqueTimes.begin();
					for (size_t index = 0; index <= j; index++, iter++);
					uniqueTimes.insert(iter, time);
					break;
				}
				else if (uniqueTimes[j] < time && j == (uniqueTimes.size() - 1))
				{
					uniqueTimes.push_back(time);
					break;
				}
			}
		}
		else
			uniqueTimes.push_back(time);
	}
}