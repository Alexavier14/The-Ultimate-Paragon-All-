#include "../Application/stdafx.h"

#include "Mesh.h"

//Macro to clean up com objects
#define ReleaseCOM(x) { if(x){ x->Release(); x = 0; } }

CMesh::CMesh()
{
	m_pVertexBuffer	= NULL;
	m_nVertexSize	= NULL; 
	m_pIndexBuffer	= NULL;
	m_nIndexSize	= NULL;

	UsesTangents = false;
}

CMesh::~CMesh()
{

}

ID3D11Buffer ** CMesh::GetVertexBuffer()
{
	return &m_pVertexBuffer.p;
}

ID3D11Buffer * CMesh::GetIndexArray() 
{
	return this->m_pIndexBuffer.p;
}

bool CMesh::CreateStaticMesh(vector<XMFLOAT3> mesh, vector<XMFLOAT3> tangests, vector<XMFLOAT3> normals, vector<XMFLOAT2> uvs, vector<index_type> indicies, ID3D11Device * pDevice)
{
	if (tangests.size() > 0)
	{
		tStatic_Tan_Verts * vertexArray = new tStatic_Tan_Verts[mesh.size()];
		for (size_t i = 0; i < mesh.size(); i++)
		{
			vertexArray[i].pos = mesh[i];
			vertexArray[i].norms = normals[i];
			vertexArray[i].uvs = uvs[i];
		}


		this->UsesTangents = true;
		for (size_t i = 0; i < tangests.size(); i++)
		{
			vertexArray[i].tangent = tangests[i];
		}

		m_nVertexSize = mesh.size();
		D3D11_BUFFER_DESC BufferDESC;
		ZeroMemory(&BufferDESC, sizeof(D3D11_BUFFER_DESC));
		BufferDESC.BindFlags = D3D11_BIND_VERTEX_BUFFER;
		BufferDESC.Usage = D3D11_USAGE_DEFAULT;
		BufferDESC.ByteWidth = sizeof(tStatic_Tan_Verts)* m_nVertexSize;

		D3D11_SUBRESOURCE_DATA initData;
		initData.pSysMem = vertexArray;
		initData.SysMemPitch = NULL;
		initData.SysMemSlicePitch = NULL;

		HRESULT hr = pDevice->CreateBuffer(&BufferDESC, &initData, &m_pVertexBuffer);
		SetD3DName(m_pVertexBuffer, "Obj Vert Buffer");
		SetD3DName(m_pVertexBuffer, "Static Mesh Vert Buffer");

		if (hr != S_OK)
		{
			delete[] vertexArray;
			return false;
		}

		ZeroMemory(&BufferDESC, sizeof(D3D11_BUFFER_DESC));
		BufferDESC.BindFlags = D3D11_BIND_INDEX_BUFFER;
		BufferDESC.Usage = D3D11_USAGE_IMMUTABLE;
		BufferDESC.ByteWidth = sizeof(WORD)* indicies.size();
		initData.pSysMem = &indicies[0];
		m_nIndexSize = indicies.size();

		hr = pDevice->CreateBuffer(&BufferDESC, &initData, &m_pIndexBuffer);
		SetD3DName(m_pIndexBuffer, "Obj Ind Buffer");

		SetD3DName(m_pIndexBuffer, "Static Mesh Index Buffer");

		if (hr != S_OK)
		{
			delete[] vertexArray;
			return false;
		}

		delete[] vertexArray;
		return true;
	}
	else
	{
		tStatic_Verts * vertexArray = new tStatic_Verts[mesh.size()];
		for (size_t i = 0; i < mesh.size(); i++)
		{
			vertexArray[i].pos = mesh[i];
			vertexArray[i].norms = normals[i];
			vertexArray[i].uvs = uvs[i];
			vertexArray[i].Filler = XMFLOAT3(0.0f, 0.0f, 0.0f);
		}

		this->UsesTangents = false;

		m_nVertexSize = mesh.size();
		D3D11_BUFFER_DESC BufferDESC;
		ZeroMemory(&BufferDESC, sizeof(D3D11_BUFFER_DESC));
		BufferDESC.BindFlags = D3D11_BIND_VERTEX_BUFFER;
		BufferDESC.Usage = D3D11_USAGE_DEFAULT;
		BufferDESC.ByteWidth = sizeof(tStatic_Verts)* m_nVertexSize;

		D3D11_SUBRESOURCE_DATA initData;
		initData.pSysMem = vertexArray;
		initData.SysMemPitch = NULL;
		initData.SysMemSlicePitch = NULL;

		HRESULT hr = pDevice->CreateBuffer(&BufferDESC, &initData, &m_pVertexBuffer);

		SetD3DName(m_pVertexBuffer, "Static Mesh Vert Buffer");

		if (hr != S_OK)
		{
			delete[] vertexArray;
			return false;
		}

		ZeroMemory(&BufferDESC, sizeof(D3D11_BUFFER_DESC));
		BufferDESC.BindFlags = D3D11_BIND_INDEX_BUFFER;
		BufferDESC.Usage = D3D11_USAGE_IMMUTABLE;
		BufferDESC.ByteWidth = sizeof(WORD)* indicies.size();
		initData.pSysMem = &indicies[0];
		m_nIndexSize = indicies.size();

		hr = pDevice->CreateBuffer(&BufferDESC, &initData, &m_pIndexBuffer);

		SetD3DName(m_pIndexBuffer, "Static Mesh Index Buffer");

		if (hr != S_OK)
		{
			delete[] vertexArray;
			return false;
		}

		delete[] vertexArray;
		return true;
	}
}

bool CMesh::CreateAnimatedMesh(vector<XMFLOAT3> mesh, vector<XMFLOAT3> tangests, vector<XMFLOAT3> normals, vector<XMFLOAT2> uvs, vector<index_type> indicies, ID3D11Device * pDevice, vector<tJointInfluence> inf)
{
	if (tangests.size() < 1)
	{ 
		UsesTangents = false;

		tAnimated_Verts * vertexArray = new tAnimated_Verts[mesh.size()];
		for (size_t i = 0; i < mesh.size(); i++)
		{
			vertexArray[i].pos = mesh[i];
			vertexArray[i].norms = normals[i];
			vertexArray[i].uvs = uvs[i];
			vertexArray[i].tangent = XMFLOAT3(0.0f, 0.0f, 0.0f);

			memcpy_s(vertexArray[i].joint_index, sizeof(unsigned int) * 4, inf[i].joint_index, sizeof(unsigned int) * 4);
			vertexArray[i].weights = inf[i].weight;
		}

		m_nVertexSize = mesh.size();
		D3D11_BUFFER_DESC BufferDESC;
		ZeroMemory(&BufferDESC, sizeof(D3D11_BUFFER_DESC));
		BufferDESC.BindFlags = D3D11_BIND_VERTEX_BUFFER;
		BufferDESC.Usage = D3D11_USAGE_DEFAULT;
		BufferDESC.ByteWidth = sizeof(tAnimated_Verts)* m_nVertexSize;

		D3D11_SUBRESOURCE_DATA initData;
		initData.pSysMem = vertexArray;
		initData.SysMemPitch = NULL;
		initData.SysMemSlicePitch = NULL;

		HRESULT hr = pDevice->CreateBuffer(&BufferDESC, &initData, &m_pVertexBuffer);

		SetD3DName(m_pVertexBuffer, "Anim Mesh Vert Buffer");

		if (hr != S_OK)
		{
			delete[] vertexArray;
			return false;
		}


		ZeroMemory(&BufferDESC, sizeof(D3D11_BUFFER_DESC));
		BufferDESC.BindFlags = D3D11_BIND_INDEX_BUFFER;
		BufferDESC.Usage = D3D11_USAGE_IMMUTABLE;
		BufferDESC.ByteWidth = sizeof(WORD)* indicies.size();
		initData.pSysMem = &indicies[0];
		m_nIndexSize = indicies.size();

		hr = pDevice->CreateBuffer(&BufferDESC, &initData, &m_pIndexBuffer);

		SetD3DName(m_pIndexBuffer, "Anim Mesh Index Buffer");

		if (hr != S_OK)
		{
			delete[] vertexArray;
			return false;
		}

		delete[] vertexArray;
		return true;
	}
	else
	{
		UsesTangents = true;
		tAnimated_Tan_Verts * vertexArray = new tAnimated_Tan_Verts[mesh.size()];
		for (size_t i = 0; i < mesh.size(); i++)
		{
			vertexArray[i].pos = mesh[i];
			vertexArray[i].norms = normals[i];
			vertexArray[i].uvs = uvs[i];

			memcpy_s(vertexArray[i].joint_index, sizeof(unsigned int) * 4, inf[i].joint_index, sizeof(unsigned int) * 4);
			vertexArray[i].weights = inf[i].weight;
			vertexArray[i].tangent = tangests[i];
		}

		m_nVertexSize = mesh.size();
		D3D11_BUFFER_DESC BufferDESC;
		ZeroMemory(&BufferDESC, sizeof(D3D11_BUFFER_DESC));
		BufferDESC.BindFlags = D3D11_BIND_VERTEX_BUFFER;
		BufferDESC.Usage = D3D11_USAGE_DEFAULT;
		BufferDESC.ByteWidth = sizeof(tAnimated_Tan_Verts)* m_nVertexSize;

		D3D11_SUBRESOURCE_DATA initData;
		initData.pSysMem = vertexArray;
		initData.SysMemPitch = NULL;
		initData.SysMemSlicePitch = NULL;

		HRESULT hr = pDevice->CreateBuffer(&BufferDESC, &initData, &m_pVertexBuffer);

		SetD3DName(m_pVertexBuffer, "Anim Mesh Vert Buffer");

		if (hr != S_OK)
		{
			delete[] vertexArray;
			return false;
		}


		ZeroMemory(&BufferDESC, sizeof(D3D11_BUFFER_DESC));
		BufferDESC.BindFlags = D3D11_BIND_INDEX_BUFFER;
		BufferDESC.Usage = D3D11_USAGE_IMMUTABLE;
		BufferDESC.ByteWidth = sizeof(WORD)* indicies.size();
		initData.pSysMem = &indicies[0];
		m_nIndexSize = indicies.size();

		hr = pDevice->CreateBuffer(&BufferDESC, &initData, &m_pIndexBuffer);

		SetD3DName(m_pIndexBuffer, "Anim Mesh Index Buffer");

		if (hr != S_OK)
		{
			delete[] vertexArray;
			return false;
		}

		delete[] vertexArray;
		return true;
	}
}
	

void CMesh::ShutDown()
{
	m_pIndexBuffer.Release();
	m_pVertexBuffer.Release();
}

bool CMesh::LoadModelVerts(ID3D11Device * pDevice, vector<byte>& model, vector<byte>& indicies, tMesh_Bin_Header& header)
{
	UsesTangents = header.hasTangents;

	D3D11_BUFFER_DESC BufferDESC;
	ZeroMemory(&BufferDESC, sizeof(D3D11_BUFFER_DESC));
	BufferDESC.BindFlags = D3D11_BIND_VERTEX_BUFFER;
	BufferDESC.Usage = D3D11_USAGE_DEFAULT;
	BufferDESC.ByteWidth = header.vert_struct_size * header.size_of_verts;
	m_nVertexSize = header.size_of_verts;

	D3D11_SUBRESOURCE_DATA initData;
	initData.pSysMem = &model[0];
	initData.SysMemPitch = NULL;
	initData.SysMemSlicePitch = NULL;

	HRESULT hr = pDevice->CreateBuffer(&BufferDESC, &initData, &m_pVertexBuffer);

	if (hr != S_OK)
	{
		printConsole("Failed to create Static Mesh Vert Buffer.");
		m_pVertexBuffer.Release();
		return false;
	}

	SetD3DName(m_pVertexBuffer, "Static Mesh Vert Buffer");

	ZeroMemory(&BufferDESC, sizeof(D3D11_BUFFER_DESC));
	BufferDESC.BindFlags = D3D11_BIND_INDEX_BUFFER;
	BufferDESC.Usage = D3D11_USAGE_IMMUTABLE;
	BufferDESC.ByteWidth = header.index_size * header.size_of_indicies;
	initData.pSysMem = &indicies[0];
	m_nIndexSize = header.size_of_indicies;

	hr = pDevice->CreateBuffer(&BufferDESC, &initData, &m_pIndexBuffer);

	if (hr != S_OK)
	{
		printConsole("Failed to create Static Mesh Index Buffer.");
		m_pVertexBuffer.Release();
		return false;
	}

	SetD3DName(m_pIndexBuffer, "Static Mesh Index Buffer");

	return true;
}

//bool CMesh::LoadModelVerts(ID3D11Device * pDevice, tStatic_Tan_Verts model[], index_type indicies[], unsigned int vert_size, unsigned int index_size)
//{
//	UsesTangents = true;
//	D3D11_BUFFER_DESC BufferDESC;
//	ZeroMemory(&BufferDESC, sizeof(D3D11_BUFFER_DESC));
//	BufferDESC.BindFlags = D3D11_BIND_VERTEX_BUFFER;
//	BufferDESC.Usage = D3D11_USAGE_DEFAULT;
//	BufferDESC.ByteWidth = sizeof(tStatic_Tan_Verts)* vert_size;
//
//	D3D11_SUBRESOURCE_DATA initData;
//	initData.pSysMem = model;
//	initData.SysMemPitch = NULL;
//	initData.SysMemSlicePitch = NULL;
//
//	HRESULT hr = pDevice->CreateBuffer(&BufferDESC, &initData, &m_pVertexBuffer);
//
//	if (hr != S_OK)
//	{
//		printConsole("Failed to create Static Mesh Vert Buffer with Tangents.");
//		m_pVertexBuffer.Release();
//		return false;
//	}
//
//	SetD3DName(m_pVertexBuffer, "Static Mesh Vert Buffer");
//
//	ZeroMemory(&BufferDESC, sizeof(D3D11_BUFFER_DESC));
//	BufferDESC.BindFlags = D3D11_BIND_INDEX_BUFFER;
//	BufferDESC.Usage = D3D11_USAGE_IMMUTABLE;
//	BufferDESC.ByteWidth = sizeof(WORD)* index_size;
//	initData.pSysMem = indicies;
//	m_nIndexSize = index_size;
//
//	hr = pDevice->CreateBuffer(&BufferDESC, &initData, &m_pIndexBuffer);
//
//	if (hr != S_OK)
//	{
//		printConsole("Failed to create Static Mesh Index Buffer.");
//		m_pVertexBuffer.Release();
//		return false;
//	}
//
//	SetD3DName(m_pIndexBuffer, "Static Mesh Index Buffer");
//}
//
//bool CMesh::LoadModelVerts(ID3D11Device * pDevice, tAnimated_Verts model[], index_type indicies[], unsigned int vert_size, unsigned int index_size)
//{
//	UsesTangents = false;
//	D3D11_BUFFER_DESC BufferDESC;
//	ZeroMemory(&BufferDESC, sizeof(D3D11_BUFFER_DESC));
//	BufferDESC.BindFlags = D3D11_BIND_VERTEX_BUFFER;
//	BufferDESC.Usage = D3D11_USAGE_DEFAULT;
//	BufferDESC.ByteWidth = sizeof(tAnimated_Verts)* vert_size;
//
//	D3D11_SUBRESOURCE_DATA initData;
//	initData.pSysMem = model;
//	initData.SysMemPitch = NULL;
//	initData.SysMemSlicePitch = NULL;
//
//	HRESULT hr = pDevice->CreateBuffer(&BufferDESC, &initData, &m_pVertexBuffer);
//
//	if (hr != S_OK)
//	{
//		printConsole("Failed to create Anim Mesh Vert Buffer.");
//		m_pVertexBuffer.Release();
//		return false;
//	}
//
//	SetD3DName(m_pVertexBuffer, "Anim Mesh Vert Buffer");
//
//	ZeroMemory(&BufferDESC, sizeof(D3D11_BUFFER_DESC));
//	BufferDESC.BindFlags = D3D11_BIND_INDEX_BUFFER;
//	BufferDESC.Usage = D3D11_USAGE_IMMUTABLE;
//	BufferDESC.ByteWidth = sizeof(WORD)* index_size;
//	initData.pSysMem = indicies;
//	m_nIndexSize = index_size;
//
//	hr = pDevice->CreateBuffer(&BufferDESC, &initData, &m_pIndexBuffer);
//
//	if (hr != S_OK)
//	{
//		printConsole("Failed to create Anim Mesh Index Buffer.");
//		m_pVertexBuffer.Release();
//		return false;
//	}
//
//	SetD3DName(m_pIndexBuffer, "Anim Mesh Index Buffer");
//}
//
//bool CMesh::LoadModelVerts(ID3D11Device * pDevice, tAnimated_Tan_Verts model[], index_type indicies[], unsigned int vert_size, unsigned int index_size)
//{
//	UsesTangents = true;
//	D3D11_BUFFER_DESC BufferDESC;
//	ZeroMemory(&BufferDESC, sizeof(D3D11_BUFFER_DESC));
//	BufferDESC.BindFlags = D3D11_BIND_VERTEX_BUFFER;
//	BufferDESC.Usage = D3D11_USAGE_DEFAULT;
//	BufferDESC.ByteWidth = sizeof(tAnimated_Tan_Verts)* vert_size;
//
//	D3D11_SUBRESOURCE_DATA initData;
//	initData.pSysMem = model;
//	initData.SysMemPitch = NULL;
//	initData.SysMemSlicePitch = NULL;
//
//	HRESULT hr = pDevice->CreateBuffer(&BufferDESC, &initData, &m_pVertexBuffer);
//
//	if (hr != S_OK)
//	{
//		printConsole("Failed to create Anim Mesh Vert Buffer with Tangents.");
//		m_pVertexBuffer.Release();
//		return false;
//	}
//
//	SetD3DName(m_pVertexBuffer, "Anim Mesh Vert Buffer");
//
//	ZeroMemory(&BufferDESC, sizeof(D3D11_BUFFER_DESC));
//	BufferDESC.BindFlags = D3D11_BIND_INDEX_BUFFER;
//	BufferDESC.Usage = D3D11_USAGE_IMMUTABLE;
//	BufferDESC.ByteWidth = sizeof(WORD)* index_size;
//	initData.pSysMem = indicies;
//	m_nIndexSize = index_size;
//
//	hr = pDevice->CreateBuffer(&BufferDESC, &initData, &m_pIndexBuffer);
//
//	if (hr != S_OK)
//	{
//		printConsole("Failed to create Anim Mesh Index Buffer.");
//		m_pVertexBuffer.Release();
//		return false;
//	}
//
//	SetD3DName(m_pIndexBuffer, "Anim Mesh Index Buffer");
//}