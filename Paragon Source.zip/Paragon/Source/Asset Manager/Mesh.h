#include "../Application/stdafx.h"

#pragma once

#include "../Animation System/Animation.h"
#include <atlcomcli.h>

//Header Includes
//#include "Math/Math.h"

using namespace std;
using namespace DirectX;

//#defines for lists
#define DIFFUSE "diffuse"
#define SPEC "specular"
#define NORMAL "normal"
#define EMISSIVE "emissive"

typedef unsigned short index_type;

struct tMesh_Bin_Header
{
	unsigned int size_of_verts;
	unsigned int size_of_indicies;
	unsigned int vert_struct_size;
	unsigned int index_size;
	bool isAnimated;
	bool hasTangents;
};

class CMesh
{

	struct tTriangle
	{
		XMFLOAT3 V1;
		XMFLOAT3 V2;
		XMFLOAT3 V3;
		XMFLOAT3 TriangleNormal;
	};

	vector<XMFLOAT3> m_Vertex;
	vector<tTriangle> m_Triangles;
	//vector<XMFLOAT3> tangests;
	//vector<XMFLOAT3> bitangents;

	CComPtr<ID3D11Buffer> m_pVertexBuffer;
	unsigned int m_nVertexSize;

	CComPtr<ID3D11Buffer> m_pIndexBuffer;
	unsigned int m_nIndexSize;

	bool UsesTangents;

public:
	struct tStatic_Verts
	{
		XMFLOAT3 pos;
		XMFLOAT3 norms;
		XMFLOAT2 uvs;
		XMFLOAT3 Filler;
	};

	struct tStatic_Tan_Verts
	{
		XMFLOAT3 pos;
		XMFLOAT3 norms;
		XMFLOAT2 uvs;
		XMFLOAT3 tangent;
	};

	struct tAnimated_Verts
	{
		XMFLOAT3	pos;
		XMFLOAT3	norms;
		XMFLOAT2	uvs;
		XMFLOAT3 tangent;
		unsigned int joint_index[4];
		XMFLOAT4	weights;
	};

	struct tAnimated_Tan_Verts
	{
		XMFLOAT3	pos;
		XMFLOAT3	norms;
		XMFLOAT2	uvs;
		XMFLOAT3 tangent;
		unsigned int joint_index[4];
		XMFLOAT4	weights;
	};

	CMesh();
	~CMesh();

	//Returns the buffer array size for the Vertex Buffer
	unsigned int GetVertexSize() const { return m_nVertexSize; }
	//Returns the buffer array size for the Index Buffer
	unsigned int GetIndexSize() const { return m_nIndexSize; }


	void ShutDown();
	void SetIsUsingTangets(bool usingTan) { UsesTangents = usingTan; }
	bool GetApplyNormalMap() { return UsesTangents; }

	std::vector<XMFLOAT3> GetVertsForAnim() const;

	ID3D11Buffer ** GetVertexBuffer();
	ID3D11Buffer * GetIndexArray();
	//CComPtr<ID3D11Buffer> GetUVs() const;


	bool LoadModelVerts(ID3D11Device * pDevice, vector<byte>& model, vector<byte>& indicies, tMesh_Bin_Header& header);
	//bool LoadModelVerts(ID3D11Device * pDevice, tStatic_Tan_Verts model[], index_type indicies[], unsigned int vert_size, unsigned int index_size);
	//bool LoadModelVerts(ID3D11Device * pDevice, tAnimated_Verts model[], index_type indicies[], unsigned int vert_size, unsigned int index_size);
	//bool LoadModelVerts(ID3D11Device * pDevice, tAnimated_Tan_Verts model[], index_type indicies[], unsigned int vert_size, unsigned int index_size);

	bool CreateStaticMesh(vector<XMFLOAT3> mesh, vector<XMFLOAT3> tangests, vector<XMFLOAT3> normals, vector<XMFLOAT2> uvs, vector<index_type> indicies, ID3D11Device * pDevice);
	bool CreateAnimatedMesh(vector<XMFLOAT3> mesh, vector<XMFLOAT3> tangests, vector<XMFLOAT3> normals, vector<XMFLOAT2> uvs, vector<index_type> indicies, ID3D11Device * pDevice, vector<tJointInfluence> inf);
};

