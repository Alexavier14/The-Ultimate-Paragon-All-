#include "../Application/stdafx.h"

#pragma once

#pragma comment(lib, "libfbxsdk")
#include <fbxsdk.h>

//Header includes
#include "../Object Manager/GameObject.h"
#include "../Object Manager/HUDElement.h"
#include "../Object Manager/Telegraph.h"
#include "../Text Manager/Font.h"
#include "Mesh.h"
#include "DDSTextureLoader.h"
#include <atlcomcli.h>

using namespace std;


//Forward Includes
class CAnimation;
struct tJointInfluence;
struct tBin_Header;
class Emitter;

struct ObjectToLoad
{
	GameObject * pGO;
	string FBX_filename;
	string Texture_filename;
	string SpecTexture_filename;
	string NormTexture_filename;
	string GlowTexture_filename;
	vector<XMFLOAT3> WayPoints;
};
struct HUDtoLoad
{
	//HUDElement * HUD_El;
	GameObject * pGO;
	string TextureFilePath;
};

struct EffectToLoad
{
	//EffectComponent * VisEffect;
	GameObject * pGO;
	string TextureFilePath;
};

struct TelegraphToLoad
{
	//Telegraph * Tele;
	GameObject * pGO;
	string TextureFilePath;
};

struct FontToLoad
{
	Font * pFont;
	string glyphTextureFilePath;
	string outlineTextureFilePath;
};

struct AnimToLoad
{
	string animName;
	string AnimFilePath;

	AnimToLoad() {}
	AnimToLoad(const char * animName, const char * filepath) : animName(animName), AnimFilePath(filepath) {}
};

struct EmitterToLoad
{
	string textureFilePath;
	Emitter* pEmitter;
};

class AssetManager
{
private:
	
	map<string, ID3D11ShaderResourceView *> Texture_List;
	map<string, CMesh *> Mesh_List;
	map<string, CAnimation *> Anim_List;

	map<string, ID3D11ShaderResourceView *> Loading_Texture_List;
	map<string, CMesh *> Loading_Mesh_List;
	map<string, CAnimation *> Loading_Anim_List;

	HWND pWindow;
	ID3D11Device * pDevice;
	FbxManager * pManager;
	CComPtr<ID3D11ShaderResourceView> pDefault_Texture;

	//Helper function to read/write information in binary files.
	bool CreateBinFile(string filename, vector<XMFLOAT3> pos, vector<XMFLOAT3> normals, vector<XMFLOAT2> UVs, vector<XMFLOAT3> tangents, vector<index_type> indicies, bool animated, vector<tJointInfluence> infList);
	bool CreateBinFile(string filename, CAnimation& animation);
	CMesh* LoadMeshBinFile(FILE * file_read);
	CAnimation* LoadAnimBinFile(FILE * file_read);

	bool StoringInLoadMaps;
public:
	void LoadingComplete();
	void SetForLoading();

	int AssetsLoadedCount;
	int AssetsUnloadedCount;

	void Initialize(HWND hWnd, CComPtr<ID3D11Device> theDevice);
	void Shutdown();

	AssetManager();
	~AssetManager();

	bool LoadModel(ObjectToLoad * object);
	bool LoadHudAsset(HUDtoLoad * HTL);
	bool LoadEfftectAsset(EffectToLoad * ETL);
	bool LoadTelegraphAsset(TelegraphToLoad * TTL);
	bool LoadFontAsset(FontToLoad * FTL);
	bool LoadEmitterAsset(EmitterToLoad* ETL);
	bool LoadAnimation(AnimToLoad * anim);
	bool LoadSound(char const * filename);

	//Helper Functions

	//Checks to see if the Asset is there.
	bool IsMeshLoaded(string mesh_name);
	bool IsTextureLoaded(string texture_name);
	bool IsAnimationLoaded(string anim_name);

	//Gets Asset data
	CMesh * GetMesh(string mesh_name);
	CComPtr<ID3D11ShaderResourceView> GetTexture(string texture_name);
	//Gets Animation data
	CAnimation * GetAnimation(string anim_name);

	//Loads mesh data from FBX File
	CMesh* LoadMesh(string filename, FbxScene * pScene, bool bAnimated = false);

	bool LoadTexture(string filename, ID3D11Device * pDevice, ID3D11ShaderResourceView ** new_Texture);

	//Creates the FbxManager to be used for loading the fbx files
	//Should only be called once for each loading screen.
	void CreateFBXManager();

	//Destroys the FbxManager
	//Should only be called once for each loading screen.
	void DestroyFBXManager();

	void ClearAllLoadedAssets();
};