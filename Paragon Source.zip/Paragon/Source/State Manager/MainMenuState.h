#pragma once
#include "GameState.h"
#include "../Asset Manager/AssetManager.h"
#include "../Text Manager/TextBox.h"

#define MAX_LOCATIONS 3
class MainMenuState :
	public GameState
{
	XMFLOAT2 lastMouse;
	int showCursorCount;
	HINSTANCE m_hInstance;
	//TextBox* playBox;
	//TextBox* exitBox;
	//TextBox* optionsBox;
	//TextBox* creditsBox;
	//TextBox* upDownBox;
	//TextBox* enterBox;
	HUDElement* mainMenu;
	HUDElement* menuSelector;
	//HUDElement* lmbClick;
	//HUDElement* returnSelect;
	//HUDElement* loadingScreen;
	//HUDElement* creditsScreen;
	//HUDElement*	arrowsLeftRight;
	//HUDElement* arrowsUpDown;
	//HUDElement*	mouseI;

	HUDElement * playImg;
	HUDElement * playImg2;
	HUDElement * optionsImg;
	HUDElement * optionsImg2;
	HUDElement * creditsImg;
	HUDElement * creditsImg2;
	HUDElement * exitImg;
	HUDElement * exitImg2;
	HUDElement * titleImg;

	GameStateType NextStateAfterTrans;

	std::vector<XMFLOAT2> location;
	XMFLOAT4 defaultOutlineColor;
	XMFLOAT4 defaultFillColor;

	XMFLOAT4 highlightFillColor;
	int m_nCurrSelection;

	public:
	MainMenuState( );
	virtual ~MainMenuState();

	void Initialize(  CoreFacade* pCoreFacade  ) override;
	void Shutdown( CoreFacade* pCoreFacade ) override;
	GameStateType Update(  CoreFacade* pCoreFacade  ) override;
};

