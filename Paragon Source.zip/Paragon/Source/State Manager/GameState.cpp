#include "../Application/stdafx.h"

#include "GameState.h"
#include "../Application/CoreFacade.h"
#include "../Object Manager/HUDElement.h"
#include "../Util/TimeManager.h"
#include <iostream>

GameState::GameState()
{ 
	TransitionNextState = false;
}
GameState::~GameState( ){}

void GameState::CreateTransitionState(CoreFacade* pCoreFacade, string CurrentStateName)
{
	HUDtoLoad hudTransition;
	transitionScreen = new HUDElement(2.0f, 2.0f, 0.0f, 0.0f);
	transitionScreen->m_Color = XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f);
	transitionScreen->m_ColorRatio = 1.1f;

	TransitionScreenGO = new GameObject;
	TransitionScreenGO->SetTypeID(eTRANSITION);
	TransitionScreenGO->SetTag(CurrentStateName + " Screen Transition");
	TransitionScreenGO->SetHUDComponent(transitionScreen);
	hudTransition.pGO = TransitionScreenGO;
	hudTransition.TextureFilePath = "../Assets/Textures/2D_Transition.dds";
	pCoreFacade->LoadHudAsset(&hudTransition);
	pCoreFacade->m_ObjectManager->AddGameObject(TransitionScreenGO);
}

bool GameState::UpdateTransition()
{
	//Fade in
	if (transitionScreen == nullptr)
		return true;

	if (TransitionNextState == false)
	{
		if (transitionScreen->m_ColorRatio > 0.1f)
			transitionScreen->m_ColorRatio -= 1.0f * TimeManager::GetTimeDelta();
		else
			transitionScreen->m_ColorRatio = 0.0f;

		TransitionScreenGO->SetObjectColor(transitionScreen->m_Color, transitionScreen->m_ColorRatio);
		//if ( transitionScreen->m_ColorRatio  > 0.0f)
		///PrintConsole("Transition Ratio = ", transitionScreen->m_ColorRatio);
	}

	//Fade out
	if (TransitionNextState == true)
	{
		if (TimeManager::GetTimeDelta() < 1.0f)
			transitionScreen->m_ColorRatio += 1.0f * TimeManager::GetTimeDelta(); 
		TransitionScreenGO->SetObjectColor(transitionScreen->m_Color, transitionScreen->m_ColorRatio);

		//if (transitionScreen->m_ColorRatio  > 0.0f)
		//PrintConsole("Transition Ratio = ", transitionScreen->m_ColorRatio);


		if (transitionScreen->m_ColorRatio > 1.1f)
			return true;
	}

	return false;
}
void GameState::DisableTransitionScreen()
{
	//this->transitionScreen->isEnabled = false;
	//DO NOT CLEAN UP GAME OBJECTS HERE

}

//void GameState::Initialize( CoreFacade* pCoreFacade )
//{
//}
//
//void GameState::Shutdown( )
//{
//
//}
//
//void GameState::Update( CoreFacade* pCoreFacade )
//{
//}
