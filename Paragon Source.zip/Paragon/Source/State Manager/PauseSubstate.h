#pragma once

#include "GameState.h"

class CoreFacade;
class HUDElement;
class TextBox;

class PauseSubstate
{
	///Members for the pause menu
	HUDElement* m_PauseCursor;
	HUDElement* m_PauseMenu;
	HUDElement* m_PauseOptionMenu;
	HUDElement* m_PauseMenuControls;
	TextBox*	m_SfxVolTxt;
	TextBox*	m_MusicVolTxt;

	///Pause Menu variables
	XMFLOAT2 cursorPos[4];
	float sfxVol, musVol;
	unsigned char m_Pause_state;
	int m_nCurrSelection;

	public:
	PauseSubstate();
	~PauseSubstate();

	void Initialize(CoreFacade * pCoreFacade);
	void Shutdown();

	GameStateType Update(CoreFacade * pCoreFacade);
	unsigned char OptionsMenu(unsigned char key_pressed, CoreFacade * pCoreFacade);
	unsigned char ControlMenu(unsigned char key_pressed);
	unsigned char PauseMenu(unsigned char key_pressed);
	GameStateType StateChange(unsigned char state, CoreFacade * pCoreFacade);
	void Switch(bool menu, bool options, bool controls, CoreFacade * pCoreFacade);
	void Start(CoreFacade * pCoreFacade);
};

