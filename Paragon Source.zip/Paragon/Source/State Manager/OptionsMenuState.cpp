
#include "../Application/stdafx.h"

#include "OptionsMenuState.h"
#include "../Application/CoreFacade.h"
#include "../Asset Manager/AssetManager.h"
#include "../Renderer/RenderController.h"
#include "../State Manager/GameStateMachine.h"
#include "../Object Manager/GameObject.h"
#include "../Sound/SoundManager.h"
#include "../Sound/Wwise_IDs.h"
#include "../Text Manager/TextBox.h"

OptionsMenuState::OptionsMenuState()
{
}


OptionsMenuState::~OptionsMenuState()
{
}

void OptionsMenuState::Initialize(CoreFacade* pCoreFacade)
{
	//Used for Numbers
	wchar_t buffer[10];

	HUDtoLoad hudLoader;
	pCoreFacade->LoadFont("LeagueGothic");
	location.clear();
	m_nCurrSelection = 0;

	sfxVol = pCoreFacade->GetSoundManager()->GetSfxVolume();
	musVol = pCoreFacade->GetSoundManager()->GetMusicVolume();

	location.push_back(XMFLOAT2(-0.75f, 0.45f));//Resolution
	location.push_back(XMFLOAT2(-0.75f, 0.35f));//Window Mode
	location.push_back(XMFLOAT2(-0.75f, 0.25f));//AA Mode
	location.push_back(XMFLOAT2(-0.75f, 0.15f));//Gamma Value

	location.push_back(XMFLOAT2(-0.75f, -0.2f));//Music Value
	location.push_back(XMFLOAT2(-0.75f, -0.3f));//Sfx Value
	location.push_back(XMFLOAT2(-0.75f, -0.55f));//Apply box
	location.push_back(XMFLOAT2(-0.75f, -0.65f));//Return box

	defaultFillColor = XMFLOAT4(0.1f, 0.65f, 0.9f, 1.0f);
	defaultOutlineColor = XMFLOAT4(0.0f, 0.0f, 0.1f, 1.0f);
	highlightFillColor = XMFLOAT4(0.9f, 0.65f, 0.1f, 1.0f);

	// Background
	optionScreen = new HUDElement(2.0f, 2.0f, 0.0f, 0.0f);
	hudLoader.TextureFilePath = "../Assets/Textures/Menu_BackGround.dds";

	GameObject * OptionScreenGO = new GameObject;
	OptionScreenGO->SetTypeID(eHUD);
	OptionScreenGO->SetTag("OptionsScreen");
	OptionScreenGO->SetHUDComponent(optionScreen);
	hudLoader.pGO = OptionScreenGO;
	pCoreFacade->LoadHudAsset(&hudLoader);
	pCoreFacade->m_ObjectManager->AddGameObject(OptionScreenGO);

	// Option Cursor
	optionCursor = new HUDElement(0.12f, 0.26f, location[0].x, location[0].y);
	hudLoader.TextureFilePath = "../Assets/Textures/Sapphire_Pointer.dds";

	GameObject * OptionCursorGO = new GameObject;
	OptionCursorGO->SetTypeID(eHUD);
	OptionCursorGO->SetTag("OptionsCursor");
	OptionCursorGO->SetHUDComponent(optionCursor);
	hudLoader.pGO = OptionCursorGO;
	pCoreFacade->LoadHudAsset(&hudLoader);
	pCoreFacade->m_ObjectManager->AddGameObject(OptionCursorGO);


	//Title and Sections
	Title = new TextBox;
	Title->SetFont(pCoreFacade->GetFont("LeagueGothic"));
	Title->SetTextColor(XMFLOAT4(0.1f, 0.65f, 0.9f, 1.0f), XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));
	Title->SetPosition(-0.25f, 1.0f);
	Title->SetScale(1.0f);
	Title->SetText(L"Options");
	pCoreFacade->AddTextBox(Title);

	VideoSection = new TextBox;
	VideoSection->SetFont(pCoreFacade->GetFont("LeagueGothic"));
	VideoSection->SetTextColor(XMFLOAT4(0.1f, 0.65f, 0.9f, 1.0f), XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));
	VideoSection->SetPosition(-0.75f, 0.65f);
	VideoSection->SetScale(0.6f);
	VideoSection->SetText(L"Video Options:");
	pCoreFacade->AddTextBox(VideoSection);

	SoundSection = new TextBox;
	SoundSection->SetFont(pCoreFacade->GetFont("LeagueGothic"));
	SoundSection->SetTextColor(XMFLOAT4(0.1f, 0.65f, 0.9f, 1.0f), XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));
	SoundSection->SetPosition(-0.75f, 0.0f);
	SoundSection->SetScale(0.6f);
	SoundSection->SetText(L"Sound Options:");
	pCoreFacade->AddTextBox(SoundSection);

	//Resolution Options
	ResolutionOptions = new TextBox;
	ResolutionOptions->SetFont(pCoreFacade->GetFont("LeagueGothic"));
	ResolutionOptions->SetTextColor(XMFLOAT4(0.1f, 0.65f, 0.9f, 1.0f), XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));
	ResolutionOptions->SetPosition(-0.6f, 0.5f);
	ResolutionOptions->SetScale(0.5f);
	ResolutionOptions->SetText(L"Resolution:");
	pCoreFacade->AddTextBox(ResolutionOptions);

	ResolutionSelected = new TextBox;
	ResolutionSelected->SetFont(pCoreFacade->GetFont("LeagueGothic"));
	ResolutionSelected->SetTextColor(XMFLOAT4(0.1f, 0.65f, 0.9f, 1.0f), XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));
	ResolutionSelected->SetPosition(-0.1f, 0.5f);
	ResolutionSelected->SetScale(0.5f);
	pCoreFacade->AddTextBox(ResolutionSelected);

	//Window Options
	WindowOption = new TextBox;
	WindowOption->SetFont(pCoreFacade->GetFont("LeagueGothic"));
	WindowOption->SetTextColor(XMFLOAT4(0.1f, 0.65f, 0.9f, 1.0f), XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));
	WindowOption->SetPosition(-0.6f, 0.4f);
	WindowOption->SetScale(0.5f);
	WindowOption->SetText(L"Fullscreen:");
	pCoreFacade->AddTextBox(WindowOption);

	SelectedMode = new TextBox;
	SelectedMode->SetFont(pCoreFacade->GetFont("LeagueGothic"));
	SelectedMode->SetTextColor(XMFLOAT4(0.1f, 0.65f, 0.9f, 1.0f), XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));
	SelectedMode->SetPosition(-0.1f, 0.4f);
	SelectedMode->SetScale(0.5f);

	if (pCoreFacade->GetSettings().WindowMode != eFULLSCREEN)
	{
		SelectedMode->SetText(L"No");
		m_nModeSelected = false;
	}
	else
	{
		SelectedMode->SetText(L"Yes");
		m_nModeSelected = true;
	}
	pCoreFacade->AddTextBox(SelectedMode);

	//Anti-Aliasing Options
	AAOption = new TextBox;
	AAOption->SetFont(pCoreFacade->GetFont("LeagueGothic"));
	AAOption->SetTextColor(XMFLOAT4(0.1f, 0.65f, 0.9f, 1.0f), XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));
	AAOption->SetPosition(-0.6f, 0.3f);
	AAOption->SetScale(0.5f);
	AAOption->SetIsActive(true);
	AAOption->SetText(L"Anti-Aliasing Mode:");
	pCoreFacade->AddTextBox(AAOption);

	AAValue = new TextBox;
	AAValue->SetFont(pCoreFacade->GetFont("LeagueGothic"));
	AAValue->SetTextColor(XMFLOAT4(0.1f, 0.65f, 0.9f, 1.0f), XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));
	AAValue->SetPosition(-0.1f, 0.3f);
	AAValue->SetScale(0.5f);
	AAValue->SetIsActive(true);
	if (pCoreFacade->GetSettings().AAValue == eAAx1)
	{
		AAValue->SetText(L"FXAA x1");
		m_nAASelected = 1;
	}
	else if (pCoreFacade->GetSettings().AAValue == eAAx4)
	{
		AAValue->SetText(L"FXAA x4");
		m_nAASelected = 2;
	}
	else if (pCoreFacade->GetSettings().AAValue == eAAx8)
	{
		AAValue->SetText(L"FXAA x8");
		m_nAASelected = 3;
	}
	else
	{
		AAValue->SetText(L"Off");
		m_nAASelected = 0;
	}
	pCoreFacade->AddTextBox(AAValue);

	//Gamma Option
	GammaOption = new TextBox;
	GammaOption->SetFont(pCoreFacade->GetFont("LeagueGothic"));
	GammaOption->SetTextColor(XMFLOAT4(0.1f, 0.65f, 0.9f, 1.0f), XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));
	GammaOption->SetPosition(-0.6f, 0.2f);
	GammaOption->SetScale(0.5f);
	GammaOption->SetIsActive(true);
	GammaOption->SetText(L"Gamma:");
	pCoreFacade->AddTextBox(GammaOption);

	GammaValue = new TextBox;
	GammaValue->SetFont(pCoreFacade->GetFont("LeagueGothic"));
	GammaValue->SetTextColor(XMFLOAT4(0.1f, 0.65f, 0.9f, 1.0f), XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));
	GammaValue->SetPosition(-0.1f, 0.2f);
	GammaValue->SetScale(0.5f);
	GammaValue->SetIsActive(true);
	_itow_s((int)pCoreFacade->GetSettings().GammaValue, buffer, 10);
	m_nGammaValue = (int)pCoreFacade->GetSettings().GammaValue;
	GammaValue->SetText(buffer);
	pCoreFacade->AddTextBox(GammaValue);

	//Music Option
	MusicOption = new TextBox;
	MusicOption->SetFont(pCoreFacade->GetFont("LeagueGothic"));
	MusicOption->SetTextColor(XMFLOAT4(0.1f, 0.65f, 0.9f, 1.0f), XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));
	MusicOption->SetPosition(-0.6f, -0.15f);
	MusicOption->SetScale(0.5f);
	MusicOption->SetIsActive(true);
	MusicOption->SetText(L"Music Volume:");
	pCoreFacade->AddTextBox(MusicOption);

	MusicValue = new TextBox;
	MusicValue->SetFont(pCoreFacade->GetFont("LeagueGothic"));
	MusicValue->SetTextColor(XMFLOAT4(0.1f, 0.65f, 0.9f, 1.0f), XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));
	MusicValue->SetPosition(-0.1f, -0.15f);
	MusicValue->SetScale(0.5f);
	MusicValue->SetIsActive(true);
	_itow_s((int)pCoreFacade->GetSettings().fMVolume, buffer, 10);
	m_nMusicValue = (int)pCoreFacade->GetSettings().fMVolume;
	MusicValue->SetText(buffer);
	pCoreFacade->AddTextBox(MusicValue);

	//Sfx Option
	SfxOption = new TextBox;
	SfxOption->SetFont(pCoreFacade->GetFont("LeagueGothic"));
	SfxOption->SetTextColor(XMFLOAT4(0.1f, 0.65f, 0.9f, 1.0f), XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));
	SfxOption->SetPosition(-0.6f, -0.25f);
	SfxOption->SetScale(0.5f);
	SfxOption->SetIsActive(true);
	SfxOption->SetText(L"SFX Volume:");
	pCoreFacade->AddTextBox(SfxOption);

	SfxValue = new TextBox;
	SfxValue->SetFont(pCoreFacade->GetFont("LeagueGothic"));
	SfxValue->SetTextColor(XMFLOAT4(0.1f, 0.65f, 0.9f, 1.0f), XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));
	SfxValue->SetPosition(-0.1f, -0.25f);
	SfxValue->SetScale(0.5f);
	SfxValue->SetIsActive(true);
	_itow_s((int)pCoreFacade->GetSettings().fSFXVolume, buffer, 10);
	m_nSfxValue = (int)pCoreFacade->GetSettings().fSFXVolume;
	SfxValue->SetText(buffer);
	pCoreFacade->AddTextBox(SfxValue);

	//Apply Box
	ApplyBox = new TextBox;
	ApplyBox->SetFont(pCoreFacade->GetFont("LeagueGothic"));
	ApplyBox->SetTextColor(XMFLOAT4(0.1f, 0.65f, 0.9f, 1.0f), XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));
	ApplyBox->SetPosition(-0.6f, -0.5f);
	ApplyBox->SetScale(0.5f);
	ApplyBox->SetIsActive(true);
	ApplyBox->SetText(L"Apply Settings");
	pCoreFacade->AddTextBox(ApplyBox);

	//Return Box
	ReturnBox = new TextBox;
	ReturnBox->SetFont(pCoreFacade->GetFont("LeagueGothic"));
	ReturnBox->SetTextColor(XMFLOAT4(0.1f, 0.65f, 0.9f, 1.0f), XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));
	ReturnBox->SetPosition(-0.6f, -0.6f);
	ReturnBox->SetScale(0.5f);
	ReturnBox->SetIsActive(true);
	ReturnBox->SetText(L"Return to Main Menu");
	pCoreFacade->AddTextBox(ReturnBox);

	//VerrifyOption - This pops up when the user wants to leave but not apply anything. Will be useful for the quit game option;
	VerrifyOptions = new HUDElement(0.15f, 0.15f, 0.0f, 0.0f);
	hudLoader.TextureFilePath = "../Assets/Textures/Sapphire_Pointer.dds";

	GameObject * verifyGO = new GameObject;
	verifyGO->SetTypeID(eHUD);
	verifyGO->SetTag("VerifyBox");
	verifyGO->SetHUDComponent(VerrifyOptions);
	verifyGO->SetActive(false);
	hudLoader.pGO = verifyGO;
	pCoreFacade->LoadHudAsset(&hudLoader);
	pCoreFacade->m_ObjectManager->AddGameObject(verifyGO);

	YesBox = new TextBox;
	YesBox->SetFont(pCoreFacade->GetFont("LeagueGothic"));
	YesBox->SetTextColor(XMFLOAT4(0.1f, 0.65f, 0.9f, 1.0f), XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));
	YesBox->SetPosition(-0.15f, -0.1f);
	YesBox->SetScale(0.5f);
	YesBox->SetIsActive(true);
	YesBox->SetText(L"Yes");
	YesBox->SetIsActive(false);
	pCoreFacade->AddTextBox(YesBox);

	NoBox = new TextBox;
	NoBox->SetFont(pCoreFacade->GetFont("LeagueGothic"));
	NoBox->SetTextColor(XMFLOAT4(0.1f, 0.65f, 0.9f, 1.0f), XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));
	NoBox->SetPosition(0.15f, -0.1f);
	NoBox->SetScale(0.5f);
	NoBox->SetIsActive(true);
	NoBox->SetText(L"No");
	NoBox->SetIsActive(false);
	pCoreFacade->AddTextBox(NoBox);

	lastMouse = pCoreFacade->GetMousePos();

	pCoreFacade->ClearToggles();
	this->CreateTransitionState(pCoreFacade, "Options Menu State");
	pCoreFacade->CreateRenderSets();
	PrintConsole("Creating Options Menu State Render Set");


#pragma region Find all supported resolutions
	//Find all the supported screen sizes.
	DEVMODE dm = { 0 };
	dm.dmSize = sizeof(dm);
	for (int iModeNum = 0; EnumDisplaySettings(NULL, iModeNum, &dm) != 0; iModeNum++)
	{
		_itow_s(dm.dmPelsWidth, buffer, 10);
		wstring window = buffer;
		window += L" x ";
		_itow_s(dm.dmPelsHeight, buffer, 10);
		window += buffer;

		bool repeat = false;
		for (int i = 0; (unsigned int)i < screens_supported.size(); i++)
		{
			if (screens_supported[i] == window)
			{
				repeat = true;
				break;
			}
		}
		if (repeat)
			continue;

		//printf("\nMode #%i = %i x %i", iModeNum, dm.dmPelsWidth, dm.dmPelsHeight);
		XMUINT2 size = { dm.dmPelsWidth, dm.dmPelsHeight };
		screens_supported.push_back(wstring(window.begin(), window.end()));
		screen_sizes.push_back(size);
	}

	//Find which one you are running with currently.
	for (int i = 0; i < (int)screen_sizes.size(); i++)
	{
		if (screen_sizes[i].x == pCoreFacade->GetSettings().ScreenSize.x && screen_sizes[i].y == pCoreFacade->GetSettings().ScreenSize.y)
		{
			m_nCurrResolution = i;
			ResolutionSelected->SetText(screens_supported[i]);
		}
	}
#pragma endregion

}

void OptionsMenuState::Shutdown(CoreFacade* pCoreFacade)
{
	pCoreFacade->UnloadFonts();
	pCoreFacade->ClearAllObjects();
}

GameStateType OptionsMenuState::Update(CoreFacade* pCoreFacade)
{

	FullOnOff = pCoreFacade->GetRenderController()->IsWindowed;

	if (UpdateTransition() == true)
	{
		return GS_MAIN_MENU;
	}
	wstringstream ss, ss2, ssMus, ssFx, ssReturn, ssFullscreen, ssFullSelector;

	ResolutionOptions->SetTextColor(defaultFillColor, defaultOutlineColor);
	WindowOption->SetTextColor(defaultFillColor, defaultOutlineColor);
	AAOption->SetTextColor(defaultFillColor, defaultOutlineColor);
	GammaOption->SetTextColor(defaultFillColor, defaultOutlineColor);
	MusicOption->SetTextColor(defaultFillColor, defaultOutlineColor);
	SfxOption->SetTextColor(defaultFillColor, defaultOutlineColor);
	ApplyBox->SetTextColor(defaultFillColor, defaultOutlineColor);
	ReturnBox->SetTextColor(defaultFillColor, defaultOutlineColor);

	switch (m_nCurrSelection)
	{
	case 0: //Resolution Option
		ResolutionOptions->SetTextColor(highlightFillColor, defaultOutlineColor);
		break;
	case 1: //Window Options
		WindowOption->SetTextColor(highlightFillColor, defaultOutlineColor);
		break;
	case 2: //AA Options
		AAOption->SetTextColor(highlightFillColor, defaultOutlineColor);
		break;
	case 3://Gamma Options
		GammaOption->SetTextColor(highlightFillColor, defaultOutlineColor);
		break;
	case 4://Music Volume
		MusicOption->SetTextColor(highlightFillColor, defaultOutlineColor);
		break;
	case 5://Sfx Volume
		SfxOption->SetTextColor(highlightFillColor, defaultOutlineColor);
		break;
	case 6://Apply 
		ApplyBox->SetTextColor(highlightFillColor, defaultOutlineColor);
		break;
	case 7://Return
		ReturnBox->SetTextColor(highlightFillColor, defaultOutlineColor);
		break;
	}

	if (pCoreFacade->IsToggled(BT_ESC))
	{
		if (m_nCurrSelection == 7)
		{
			////return GS_MAIN_MENU;
			TransitionNextState = true;
			return GS_NO_STATE;
		}
		else
		{
			optionCursor->m_XSceenPos = location[7].x;
			optionCursor->m_YScreenPos = location[7].y;
			m_nCurrSelection = 7;
		}
	}
	if (pCoreFacade->IsToggled(BT_UP))
	{
		pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_SFX_MENU_SCROLL);
		if (m_nCurrSelection - 1 < 0)
			m_nCurrSelection = 7;
		else
			m_nCurrSelection--;

		optionCursor->m_XSceenPos = location[m_nCurrSelection].x;
		optionCursor->m_YScreenPos = location[m_nCurrSelection].y;
	}

	else if (pCoreFacade->IsToggled(BT_DOWN))
	{
		pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_SFX_MENU_SCROLL);
		if (m_nCurrSelection + 1 > 7)
			m_nCurrSelection = 0;
		else
			m_nCurrSelection++;

		optionCursor->m_XSceenPos = location[m_nCurrSelection].x;
		optionCursor->m_YScreenPos = location[m_nCurrSelection].y;
	}

	//else if (abs((pCoreFacade->GetMousePos().x - lastMouse.x)) >= 0.001 || abs((pCoreFacade->GetMousePos().y - lastMouse.y)) >= 0.001)
	//{
	//	lastMouse = pCoreFacade->GetMousePos();
	//	if (pCoreFacade->GetMousePos().y <= 560 && pCoreFacade->GetMousePos().y >= 510 && pCoreFacade->GetMousePos().x <= 390 && pCoreFacade->GetMousePos().x >= 125)
	//	{
	//		if (m_nCurrSelection != 0)
	//			pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_SFX_MENU_SELECT);
	//		m_nCurrSelection = 0;
	//		optionCursor->m_XSceenPos = location[0].x;
	//		optionCursor->m_YScreenPos = location[0].y;
	//	}

	//	else if (pCoreFacade->GetMousePos().y <= 680 && pCoreFacade->GetMousePos().y >= 630 && pCoreFacade->GetMousePos().x <= 390 && pCoreFacade->GetMousePos().x >= 125)
	//	{
	//		if (m_nCurrSelection != 1)
	//			pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_SFX_MENU_SELECT);
	//		m_nCurrSelection = 1;
	//		optionCursor->m_XSceenPos = location[1].x;
	//		optionCursor->m_YScreenPos = location[1].y;
	//	}

	//	else if (pCoreFacade->GetMousePos().y <= 790 && pCoreFacade->GetMousePos().y >= 730 && pCoreFacade->GetMousePos().x <= 390 && pCoreFacade->GetMousePos().x >= 125)
	//	{
	//		if (m_nCurrSelection != 2)
	//			pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_SFX_MENU_SELECT);
	//		m_nCurrSelection = 2;
	//		optionCursor->m_XSceenPos = location[2].x;
	//		optionCursor->m_YScreenPos = location[2].y;
	//	}

	//	else if (pCoreFacade->GetMousePos().y <= 900 && pCoreFacade->GetMousePos().y >= 870 && pCoreFacade->GetMousePos().x <= 390 && pCoreFacade->GetMousePos().x >= 125)
	//	{
	//		if (m_nCurrSelection != 3)
	//			pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_SFX_MENU_RETURN);
	//		m_nCurrSelection = 3;
	//		optionCursor->m_XSceenPos = location[3].x;
	//		optionCursor->m_YScreenPos = location[3].y;
	//	}
	//}
	if (m_nCurrSelection == 0)
	{
		if (pCoreFacade->IsToggled(BT_LEFT))
		{
			m_nCurrResolution--;
			if (m_nCurrResolution < 0)
				m_nCurrResolution = (int)screen_sizes.size() - 1;

			bResChanged = true;
			bUnsavedChanges = true;
		}
		else if (pCoreFacade->IsToggled(BT_RIGHT))
		{
			m_nCurrResolution++;
			if (m_nCurrResolution >= (int)screen_sizes.size())
				m_nCurrResolution = 0;

			bResChanged = true;
			bUnsavedChanges = true;
		}
	}
	else if (m_nCurrSelection == 1)
	{
		if (pCoreFacade->IsToggled(BT_LEFT) || pCoreFacade->IsToggled(BT_RECALL)
			|| pCoreFacade->IsToggled(BT_RIGHT) || pCoreFacade->IsToggled(BT_MOVE)
			|| pCoreFacade->IsToggled(BT_SELECT))
		{
			//if (pCoreFacade->GetRenderController()->IsWindowed)
			//{
			//	pCoreFacade->GetRenderController()->SetResolution(768, 1024, !pCoreFacade->GetRenderController()->IsWindowed);
			//	SetWindowPos(pCoreFacade->GameWindow, 0, 0, 0, 1024, 768, SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE);
			//}
			//else
			//{
			//	pCoreFacade->GetRenderController()->SetResolution(pCoreFacade->SETHEIGHT, pCoreFacade->SETWIDTH, !pCoreFacade->GetRenderController()->IsWindowed);
			//	SetWindowPos(pCoreFacade->GameWindow, 0, 0, 0, pCoreFacade->SETWIDTH, pCoreFacade->SETHEIGHT, SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE);
			//}
			//FullOnOff = pCoreFacade->GetRenderController()->IsWindowed;
			//pCoreFacade->ChangeResolution();

			m_nModeSelected = !m_nModeSelected;
			bModeChanged = true;
			bUnsavedChanges = true;
		}
	}
	if (m_nCurrSelection == 2)
	{
		if (pCoreFacade->IsToggled(BT_LEFT))
		{
			m_nAASelected--;
			if (m_nAASelected < 0)
				m_nAASelected = 3;

			bAAChanged = true;
			bUnsavedChanges = true;
		}
		else if (pCoreFacade->IsToggled(BT_RIGHT))
		{
			m_nAASelected++;
			if (m_nAASelected >= 4)
				m_nAASelected = 0;

			bAAChanged = true;
			bUnsavedChanges = true;
		}




	}
	else if (m_nCurrSelection == 3)
	{
		if (pCoreFacade->IsToggled(BT_LEFT))
		{
			m_nGammaValue--;

			if (m_nGammaValue < 0)
				m_nGammaValue = 0;

			bGammaChanged = true;
			bUnsavedChanges = true;

			pCoreFacade->GetRenderController()->SetGammaValue(float(m_nGammaValue));
		}
		else if (pCoreFacade->IsToggled(BT_RIGHT))
		{
			m_nGammaValue++;

			if (m_nGammaValue > 100)
				m_nGammaValue = 100;

			bGammaChanged = true;
			bUnsavedChanges = true;

			pCoreFacade->GetRenderController()->SetGammaValue(float(m_nGammaValue));
		}

	}
	else if (m_nCurrSelection == 4)
	{
		if (pCoreFacade->IsToggled(BT_LEFT) || pCoreFacade->IsToggled(BT_RECALL))
		{
			if (musVol - 5.0f < 0.0f)
				musVol = 0.0f;

			else
				musVol -= 5.0f;

			m_nMusicValue = int(musVol);
			pCoreFacade->GetSoundManager()->SetMusicVolume(musVol);


			bMusicChanged = true;
			bUnsavedChanges = true;
		}
		else if (pCoreFacade->IsToggled(BT_RIGHT) || pCoreFacade->IsToggled(BT_MOVE))
		{
			if (musVol + 5.0f > 100.0f)
				musVol = 100.0f;

			else
				musVol += 5.0f;

			m_nMusicValue = int(musVol);
			pCoreFacade->GetSoundManager()->SetMusicVolume(musVol);
			//pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_FX_2D_MENUBACKUP);

			bMusicChanged = true;
			bUnsavedChanges = true;
		}
	}

	else if (m_nCurrSelection == 5)
	{
		if (pCoreFacade->IsToggled(BT_LEFT) || pCoreFacade->IsToggled(BT_RECALL))
		{

			if (sfxVol - 5.0f <= 0.0f)
				sfxVol = 0.0f;

			else
				sfxVol -= 5.0f;

			m_nSfxValue = (int)sfxVol;
			pCoreFacade->GetSoundManager()->SetSfxVolume(sfxVol);
			pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_SFX_MENU_RETURN);
			bSfxChanged = true;
			bUnsavedChanges = true;
		}

		else if (pCoreFacade->IsToggled(BT_RIGHT) || pCoreFacade->IsToggled(BT_MOVE))
		{
			if (sfxVol + 5.0f > 100.0f)
				sfxVol = 100.0f;

			else
				sfxVol += 5.0f;


			m_nSfxValue = (int)sfxVol;
			pCoreFacade->GetSoundManager()->SetSfxVolume(sfxVol);
			pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_SFX_MENU_RETURN);
			//pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_FX_2D_MENUBACKUP);
			bSfxChanged = true;
			bUnsavedChanges = true;
		}

		bSfxChanged = true;
		bUnsavedChanges = true;
	}
	else if (m_nCurrSelection == 6)
	{
		if (pCoreFacade->IsToggled(BT_SELECT))
		{
			ApplyNewSettings(pCoreFacade);
			bUnsavedChanges = false;
		}
	}
	else if (m_nCurrSelection == 7)
	{
		if (pCoreFacade->IsToggled(BT_SELECT))
		{
			if (bUnsavedChanges)
				ApplyPreviousSettings(pCoreFacade);

			pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_SFX_MENU_RETURN);
			TransitionNextState = true;
			return GS_NO_STATE;
		}
	}

	wchar_t buffer[10];
	
	ResolutionSelected->SetText(screens_supported[m_nCurrResolution]);

	if (m_nModeSelected == false)
		SelectedMode->SetText(L"No");
	else
		SelectedMode->SetText(L"Yes");

	if (m_nAASelected == 1)
		AAValue->SetText(L"FXAA x1");
	else if (m_nAASelected == 2)
		AAValue->SetText(L"FXAA x4");
	else if (m_nAASelected == 3)
		AAValue->SetText(L"FXAA x8");
	else
		AAValue->SetText(L"Off");

	_itow_s(m_nGammaValue, buffer, 10);
	GammaValue->SetText(buffer);

	_itow_s(m_nSfxValue, buffer, 10);
	SfxValue->SetText(buffer);

	_itow_s(m_nMusicValue, buffer, 10);
	MusicValue->SetText(buffer);

	return GS_NO_STATE;
}


void OptionsMenuState::ApplyNewSettings(CoreFacade* pCoreFacade)
{
	if (bResChanged || bModeChanged)
	{
		pCoreFacade->ApplyScreenSize(screen_sizes[m_nCurrResolution]);
		bResChanged = false;

		if (m_nModeSelected == false)
			pCoreFacade->ApplyWindowMode(eWINDOWED_BORDERLESS);
		else
			pCoreFacade->ApplyWindowMode(eFULLSCREEN);

		bModeChanged = false;
	}
	if (bAAChanged)
	{
		if (m_nAASelected == 0)
			pCoreFacade->ApplyAAValue(eAA_OFF);
		if (m_nAASelected == 1)
			pCoreFacade->ApplyAAValue(eAAx1);
		if (m_nAASelected == 2)
			pCoreFacade->ApplyAAValue(eAAx4);
		if (m_nAASelected == 3)
			pCoreFacade->ApplyAAValue(eAAx8);

		bAAChanged = false;
	}
	if (bGammaChanged)
	{
		pCoreFacade->ApplyGamma(float(m_nGammaValue));
		bGammaChanged = false;
	}
	if (bSfxChanged)
	{
		pCoreFacade->ApplySfxVolume(sfxVol);
		bSfxChanged = false;
	}
	if (bMusicChanged)
	{
		pCoreFacade->ApplyMusicVolume(musVol);
		bMusicChanged = false;
	}

	pCoreFacade->SaveSettings();
	bUnsavedChanges = false;
}
void OptionsMenuState::ApplyPreviousSettings(CoreFacade* pCoreFacade)
{
	if (bGammaChanged)
	{
		pCoreFacade->ApplyGamma(pCoreFacade->GetSettings().GammaValue);
		bGammaChanged = false;
	}
	if (bSfxChanged)
	{
		pCoreFacade->ApplySfxVolume(pCoreFacade->GetSettings().fSFXVolume);
		bSfxChanged = false;
	}
	if (bMusicChanged)
	{
		pCoreFacade->ApplyMusicVolume(pCoreFacade->GetSettings().fMVolume);
		bMusicChanged = false;
	}
}