#include "../Application/stdafx.h"

#include "IntroState.h"
#include "../Application/CoreFacade.h"
#include "../Asset Manager/AssetManager.h"

#include "../Object Manager/GameObject.h"
#include "../Sound/SoundManager.h"
#include "../Util/TimeManager.h"
#include "../Sound/Wwise_IDs.h"

IntroState::IntroState( )
{
}


IntroState::~IntroState( )
{
}

void IntroState::Initialize( CoreFacade* pCoreFacade )
{
	HUDtoLoad hudLoader;
 	pCoreFacade->LoadFont("LeagueGothic");

	// Intro Screen
	introScreen = new HUDElement(2.0f, 2.0f, 0.0f, 0.0f);
	hudLoader.TextureFilePath = "../Assets/Textures/FillerSlide.dds";

	GameObject * IntroScreenGO = new GameObject;
	IntroScreenGO->SetTypeID(eHUD);
	IntroScreenGO->SetTag("IntroScreen");
	IntroScreenGO->SetHUDComponent(introScreen);
	hudLoader.pGO = IntroScreenGO;
	pCoreFacade->LoadHudAsset(&hudLoader);
	pCoreFacade->m_ObjectManager->AddGameObject(IntroScreenGO);

	this->CreateTransitionState(pCoreFacade, "Intro State");

	playBox = new TextBox;
	playBox->SetFont(pCoreFacade->GetFont("LeagueGothic"));
	playBox->SetTextColor(XMFLOAT4(0.1f, 0.65f, 0.9f, 1.0f), XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));
	playBox->SetPosition(-0.30f, -0.22f);
	playBox->SetScale(0.9f);
	playBox->SetIsActive(true);
	pCoreFacade->AddTextBox(playBox);

	// Loading Screen
	//loadingScreen = new HUDElement(2.0f, 2.0f, 0.0f, 0.0f);
	//hudLoader.HUD_El = loadingScreen;
	//hudLoader.TextureFilePath = "../Assets/Textures/LoadingScreen.dds";
	//hudLoader.HUD_El->SetTag("LoadingScreen");
	//pCoreFacade->LoadHudAsset(&hudLoader);
	//pCoreFacade->AddHudElement(hudLoader.HUD_El);

	pCoreFacade->CreateRenderSets();
	PrintConsole("Creating Intro State Render Set");
	

}

void IntroState::Shutdown( CoreFacade* pCoreFacade  )
{
	pCoreFacade->UnloadFonts();
	pCoreFacade->ClearAllObjects();
	
}

GameStateType IntroState::Update( CoreFacade* pCoreFacade )
{
	wstringstream textOut;
	if ( pCoreFacade->IsToggled( BT_RUBY )
		 || pCoreFacade->IsToggled( BT_SAPP )
		 || pCoreFacade->IsToggled( BT_DIAM )
		 || pCoreFacade->IsToggled( BT_ALL )
		 || pCoreFacade->IsToggled( BT_BACK )
		 || pCoreFacade->IsToggled(BT_SELECT)
		 || pCoreFacade->IsToggled(BT_SEND)
		 || pCoreFacade->IsToggled(BT_MOVE))
	{
		//introScreen->isEnabled = false;
		pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_SFX_GEM_PICKUP_02);
		TransitionNextState = true;
	}

	if (UpdateTransition() == true)
		return GS_MAIN_MENU;

	textOut << "Press Any Key";
	playBox->SetText(textOut.str());

	return GS_NO_STATE;
}
