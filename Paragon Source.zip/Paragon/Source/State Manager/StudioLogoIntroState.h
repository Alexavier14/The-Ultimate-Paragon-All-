#pragma once
#include "GameState.h"

#include "../Asset Manager/AssetManager.h"


class StudioLogoIntroState :
	public GameState
{
	float waittimer;
	HUDElement* introScreen;
	HUDElement* loadingScreen;

public:

	StudioLogoIntroState();
	virtual ~StudioLogoIntroState();

	void Initialize(CoreFacade* pCoreFacade) override;
	void Shutdown(CoreFacade* pCoreFacade) override;
	GameStateType Update(CoreFacade* pCoreFacade) override;

};