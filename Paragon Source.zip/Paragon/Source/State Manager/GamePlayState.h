#pragma once
#include "GameState.h"

#include "../Asset Manager/AssetManager.h"
#include "../Util/Clock.h"

#include "PauseSubstate.h"

class AIManager;
class TextBox;
class ObjectManager;

class GamePlayState :
	public GameState
{
	GameStateType NextStateAfterTrans;

	HUDElement* m_HUD_Main_Template;
	HUDElement* m_HealthSegmentsGreen[5];
	HUDElement* m_HealthSegmentsYellow[3];
	HUDElement* m_HealthSegmentsRed[1];
	HUDElement* m_SelectedGeodeFrame;
	HUDElement* m_RubyButtonLock;
	HUDElement* m_DiamondButtonLock;
	HUDElement* m_RubyCraftButton;
	HUDElement* m_SapphireCraftButton;
	HUDElement* m_DiamondCraftButton;

	TextBox*	m_RubyGeodeCount;
	TextBox*    m_SapphireGeodeCount;
	TextBox*    m_DiamondGeodeCount;

	TextBox*	m_RubyGemCount;
	TextBox*    m_SapphireGemCount;
	TextBox*    m_DiamondGemCount;

	TextBox*	m_TimeLeft;
	TextBox*	m_EnemiesKilled;
	TextBox*	m_FpsIndicator;

	//Hit effect
	HUDElement* m_HitIndicator;

	//Screen Transition
	HUDElement* m_Transition;

	//Cutscene Bars
	HUDElement* m_TopCutsceneBar;
	HUDElement* m_BottomCutsceneBar;

	int m_nCurrentLevel;

	float m_GameClock;
	float m_GameOverTimer;
	float m_PlayerDeathTimer;

	int m_GeodesToGoal[3];
	int m_EnemiesLeft;
	AIManager* pAIMan;
	//Cutscene Transition - need to access doors
	float m_CutsceneCurrentTime;

	PauseSubstate pauseMenu;

	public:
	GamePlayState(int Level);
	virtual ~GamePlayState( );

	void Initialize(  CoreFacade* pCoreFacade  ) override;
	void Shutdown(  CoreFacade* pCoreFacade  ) override;
	GameStateType Update( CoreFacade* pCoreFacade ) override;

	bool GameHudOn;
	private:

	bool RubyGeodesUnlocked;
	bool DiamondGeodeUnlocked;

	void CreateHUD( CoreFacade* pCoreFacade );

	//Helper function to turn the text off/on
	void TextSwitch(bool bSwitch);

	void UpdateCounters(CoreFacade* pCoreFacade); // Updates GeodeToGoal and enemies left counters
	void UpdateRockfall(CoreFacade* pCoreFacade); // Updates the rocks falling according to level time
	void UpdateHUD(CoreFacade* pCoreFacade);
	void UpdateCutscene(CoreFacade* pCoreFacade);
	void UpdateFPSCounter(CoreFacade* pCoreFacade);

};

