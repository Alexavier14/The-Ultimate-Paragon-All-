#pragma once
#include "GameState.h"

#include "../Asset Manager/AssetManager.h"
#include "../Text Manager/TextBox.h"


class GPGamesIntroState :
	public GameState
{
	float waittimer;
	HUDElement* introScreen;
	HUDElement* loadingScreen;

public:

	GPGamesIntroState();
	virtual ~GPGamesIntroState();

	void Initialize(CoreFacade* pCoreFacade) override;
	void Shutdown(CoreFacade* pCoreFacade) override;
	GameStateType Update(CoreFacade* pCoreFacade) override;

};


