#include "../Application/stdafx.h"

#include "LoseState.h"
#include "../Application/CoreFacade.h"
#include "../Asset Manager/AssetManager.h"
#include "../Object Manager/HUDElement.h"
#include "../Object Manager/GameObject.h"
#include "../Sound/SoundManager.h"
#include "../Sound/Wwise_IDs.h"
#include "../Resources/resource.h"

CLoseState::CLoseState()
{

}
CLoseState::~CLoseState()
{

}

void CLoseState::Initialize(CoreFacade* pCoreFacade)
{
	//pCoreFacade->BeginAssetLoad();
	HUDtoLoad hudLoader;
	pCoreFacade->LoadFont("LeagueGothic");
	m_nCurrSelection = 0;

	location.clear();

	defaultFillColor = XMFLOAT4(0.1f, 0.65f, 0.9f, 1.0f);
	defaultOutlineColor = XMFLOAT4(0.0f, 0.0f, 0.1f, 1.0f);
	highlightFillColor = XMFLOAT4(0.9f, 0.65f, 0.1f, 1.0f);

	loseScreen = new HUDElement(2.0f, 2.0f, 0.0f, 0.0f);
	hudLoader.TextureFilePath = "../Assets/Textures/LoseScreen.dds";

	GameObject * LoseScreenGO = new GameObject;
	LoseScreenGO->SetTypeID(eHUD);
	LoseScreenGO->SetTag("LoseSreen");
	LoseScreenGO->SetHUDComponent(loseScreen);
	//LoseScreenGO->SetActive(true);
	hudLoader.pGO = LoseScreenGO;
	pCoreFacade->LoadHudAsset(&hudLoader);
	pCoreFacade->m_ObjectManager->AddGameObject(LoseScreenGO);
	//pCoreFacade->EndAssetLoad();


	loadingScreen = new HUDElement(2.0f, 2.0f, 0.0f, 0.0f);
	loadingScreen->isEnabled = false;
	hudLoader.TextureFilePath = "../Assets/Textures/LoadingScreen.dds";

	GameObject * LoadScreenHUDGO = new GameObject;
	LoadScreenHUDGO->SetTag("LoadingScreen");
	LoadScreenHUDGO->SetTypeID(eHUD);
	LoadScreenHUDGO->SetHUDComponent(loadingScreen);
	hudLoader.pGO = LoadScreenHUDGO;
	pCoreFacade->LoadHudAsset(&hudLoader);
	pCoreFacade->m_ObjectManager->AddGameObject(LoadScreenHUDGO);

	playBox = new TextBox;
	playBox->SetFont(pCoreFacade->GetFont("LeagueGothic"));
	playBox->SetTextColor(defaultFillColor, defaultOutlineColor);
	playBox->SetPosition(-0.55f, -0.63f);
	playBox->SetScale(0.6f);
	pCoreFacade->AddTextBox(playBox);

	menuBox = new TextBox;
	menuBox->SetFont(pCoreFacade->GetFont("LeagueGothic"));
	menuBox->SetTextColor(defaultFillColor, defaultOutlineColor);
	menuBox->SetPosition(0.25f, -0.63f);
	menuBox->SetScale(0.6f);
	pCoreFacade->AddTextBox(menuBox);

	menuSelector = new HUDElement(0.05f, 0.05f, -0.6f, -0.68f);
	hudLoader.TextureFilePath = "../Assets/Textures/MenuSelector.dds";

	GameObject * MenuSelectorHUDElementGO = new GameObject;
	MenuSelectorHUDElementGO->SetTag("LoseScreenS");
	MenuSelectorHUDElementGO->SetTypeID(eHUD);
	MenuSelectorHUDElementGO->SetHUDComponent(menuSelector);
	hudLoader.pGO = MenuSelectorHUDElementGO;
	pCoreFacade->LoadHudAsset(&hudLoader);
	pCoreFacade->m_ObjectManager->AddGameObject(MenuSelectorHUDElementGO);

	location.push_back((XMFLOAT2(-0.6f, -0.68f)));
	location.push_back((XMFLOAT2(0.2f, -0.68f)));

	pCoreFacade->ClearToggles();

	HWND hWnd = GetForegroundWindow();
	lastMouse = pCoreFacade->GetMousePos();
	//HINSTANCE hIns = (HINSTANCE)GetWindowLong(hWnd, GWL_HINSTANCE);
	HCURSOR tempCursor = LoadCursor(nullptr, IDC_ARROW);
	//SetCursor(tempCursor);
	SetClassLong(hWnd, GCL_HCURSOR, (LONG)tempCursor);

	this->CreateTransitionState(pCoreFacade, "Lose State");
	pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::STOP_ALL);
	pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_BGM_PARAGON_LOOP_04);
	pCoreFacade->CreateRenderSets();
	PrintConsole("Creating Lose State Render Set");
}

void CLoseState::Shutdown(CoreFacade* pCoreFacade)
{
	pCoreFacade->UnloadFonts();
	pCoreFacade->ClearAllObjects();
}

// Updates the Game state. 
// With its returned GameStateType, it indicates that a switch to the specified type should be made.
GameStateType CLoseState::Update(CoreFacade* pCoreFacade)
{
	if (UpdateTransition() == true)
	{
		return NextTransitionState;
	}
	wstringstream ss;

	switch (m_nCurrSelection)
	{
	case 0:
		playBox->SetTextColor(highlightFillColor, defaultOutlineColor);
		menuBox->SetTextColor(defaultFillColor, defaultOutlineColor);
		break;
	case 1:
		playBox->SetTextColor(defaultFillColor, defaultOutlineColor);
		menuBox->SetTextColor(highlightFillColor, defaultOutlineColor);
		break;
	}

	if (pCoreFacade->IsToggled(BT_ESC))
	{
		if (m_nCurrSelection == 1)
		{
			NextTransitionState = GS_MAIN_MENU;
			this->TransitionNextState = true;
			//return GS_MAIN_MENU;
		}
		else
		{
			pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_SFX_NODE_DESTROYED);
			menuSelector->m_XSceenPos = location[1].x;
			menuSelector->m_YScreenPos = location[1].y;
			m_nCurrSelection = 1;
		}
	}

	else if (pCoreFacade->IsToggled(BT_LEFT))
	{
		pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_SFX_NODE_DESTROYED);

		if (m_nCurrSelection - 1 < 0)
			m_nCurrSelection = 1;
		else
			m_nCurrSelection--;

		menuSelector->m_XSceenPos = location[m_nCurrSelection].x;
		menuSelector->m_YScreenPos = location[m_nCurrSelection].y;
	}

	else if (pCoreFacade->IsToggled(BT_RIGHT))
	{
		pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_SFX_NODE_DESTROYED);
		
		if (m_nCurrSelection + 1 > 1)
			m_nCurrSelection = 0;
		else
			m_nCurrSelection++;

		menuSelector->m_XSceenPos = location[m_nCurrSelection].x;
		menuSelector->m_YScreenPos = location[m_nCurrSelection].y;
	}

	else if (abs((pCoreFacade->GetMousePos().x - lastMouse.x)) >= 0.001 || abs((pCoreFacade->GetMousePos().y - lastMouse.y)) >= 0.001)
	{
		lastMouse = pCoreFacade->GetMousePos();
		if (pCoreFacade->GetMousePos().y <= 960 && pCoreFacade->GetMousePos().y >= 860 && pCoreFacade->GetMousePos().x <= 655 && pCoreFacade->GetMousePos().x >= 425)
		{
			if (m_nCurrSelection != 0)
				pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_SFX_NODE_DESTROYED);
			m_nCurrSelection = 0;
			menuSelector->m_XSceenPos = location[0].x;
			menuSelector->m_YScreenPos = location[0].y;
		}

		else if (pCoreFacade->GetMousePos().y <= 960 && pCoreFacade->GetMousePos().y >= 860 && pCoreFacade->GetMousePos().x <= 1430 && pCoreFacade->GetMousePos().x >= 1180)
		{
			if (m_nCurrSelection != 1)
				pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_SFX_NODE_DESTROYED);
			m_nCurrSelection = 1;
			menuSelector->m_XSceenPos = location[1].x;
			menuSelector->m_YScreenPos = location[1].y;
		}
	}

	if (pCoreFacade->IsToggled(BT_SELECT) || pCoreFacade->IsToggled(BT_SEND) || pCoreFacade->IsToggled(BT_MOVE))
	{
		pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_ADR_GEODE_DIAMOND_VICTORY);
		if (m_nCurrSelection == 0)
		{
			menuSelector->isEnabled = false;
			loseScreen->isEnabled = false;
			menuBox->SetIsActive(false);
			playBox->SetIsActive(false);
			loadingScreen->isEnabled = true;

			HWND hWnd = GetForegroundWindow();
			HINSTANCE hIns = (HINSTANCE)GetWindowLong(hWnd, GWL_HINSTANCE);
			HCURSOR tempCursor = LoadCursor(hIns, MAKEINTRESOURCE(IDC_CURSOR1));
			SetClassLong(hWnd, GCL_HCURSOR, (LONG)tempCursor);
			SetCursorPos(500, 520);
			//ShowCursor(false);

			//return GS_GAMEPLAY;
			pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::STOP_ALL);
			NextTransitionState = GS_LOADING;
			this->TransitionNextState = true;
		}

		else if (m_nCurrSelection == 1)
		{
			//return GS_MAIN_MENU;
			pCoreFacade->CurrentLevel = 1;
			pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::STOP_ALL);
			NextTransitionState = GS_MAIN_MENU;
			this->TransitionNextState = true;
		}
	}

	ss.str(L"");
	ss << "Play Again";
	playBox->SetText(ss.str());

	ss.str(L"");
	ss << "Main Menu";
	menuBox->SetText(ss.str());

	return GS_NO_STATE;
}