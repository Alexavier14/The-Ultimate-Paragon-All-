#include "../Application/stdafx.h"

#include "CreditsState.h"
#include "GamePlayState.h"
#include "GameState.h"
#include "GameStateMachine.h"
#include "IntroState.h"
#include "LoseState.h"
#include "MainMenuState.h"
#include "OptionsMenuState.h"
#include "WinState.h"
#include "LoadingScreenState.h"
#include "GPGamesIntroState.h"
#include "TeamLogoIntroState.h"
#include "StudioLogoIntroState.h"
#include "../Renderer/RenderController.h"
#include "../Sound/SoundManager.h"
#include "../Sound/Wwise_IDs.h"
#include "../Util/Util.h"

#include "../Application/CoreFacade.h"

#include <direct.h>
using namespace DirectX;

#define PARAGON_LEVEL_COUNT 3

GameStateMachine::GameStateMachine(){ CurrentlyLoading = false; m_pCurrGameState = nullptr;  }
GameStateMachine::~GameStateMachine(){}

void GameStateMachine::Initialize(HWND hWnd, HINSTANCE hInstance, int nWidth, int nHeight, bool bIsWindowed)
{
	//Create the core systems facade
	
	m_pCoreFacade = new CoreFacade;
	m_pCoreFacade->Initialize(hWnd, hInstance, nWidth, nHeight, bIsWindowed);

	//Start the state machine with no current state
	if (m_pCurrGameState)
	{
		SAFE_DELETE(m_pCurrGameState);
		PrintConsole("Deleting current game state!");
	}

	//Load the intro state
	m_pCurrGameState = new GPGamesIntroState;
	m_pCurrGameState->Initialize(m_pCoreFacade);

	CurrentLevel = 1;
}

void GameStateMachine::Shutdown()
{
	//ID3D11Debug * DebugThing = nullptr;
	//m_pCoreFacade->GetRenderDevice()->QueryInterface(&DebugThing);

	m_pCurrGameState->Shutdown(m_pCoreFacade);
	m_pCoreFacade->Shutdown();

	//m_pCoreFacade->GetRenderDevice()->QueryInterface(&DebugThing);

	//DebugThing->ReportLiveDeviceObjects(D3D11_RLDO_DETAIL);
	//ReleaseCOM(DebugThing);

	SAFE_DELETE(m_pCurrGameState);
	SAFE_DELETE(m_pCoreFacade);
	m_pCurrGameState = nullptr;
}

void GameStateMachine::Update()
{
	GameStateType typeResult = m_pCurrGameState->Update(m_pCoreFacade);

	if (typeResult == GS_LOADING)
	{
		CurrentlyLoading = true;
	}

	//if (typeResult != GS_LOADING && typeResult != GS_NO_STATE)
	//	CurrentlyLoading = false;

	if (CurrentlyLoading == false)
	{
		m_pCoreFacade->Update();

		//debug restart game 
		if (m_pCoreFacade->IsPressingKey(VK_DECIMAL) && m_pCoreFacade->IsPressingKey(VK_NUMPAD9))
			RestartGame();
		if (m_pCoreFacade->IsPressingKey(VK_MENU) && m_pCoreFacade->IsPressingKey(VK_RETURN))
		{
			if (m_pCoreFacade->GetRenderController()->IsWindowed)
			{
				m_pCoreFacade->GetRenderController()->SetResolution(768, 1024, !m_pCoreFacade->GetRenderController()->IsWindowed);
				SetWindowPos(m_pCoreFacade->GameWindow, 0, 0, 0, 1024, 768, SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE);
			}
			else
			{
				m_pCoreFacade->GetRenderController()->SetResolution(m_pCoreFacade->SETHEIGHT, m_pCoreFacade->SETWIDTH, !m_pCoreFacade->GetRenderController()->IsWindowed);
				SetWindowPos(m_pCoreFacade->GameWindow, 0, 0, 0, m_pCoreFacade->SETWIDTH, m_pCoreFacade->SETHEIGHT, SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE);
			}
		}
	}

	if (typeResult != GS_NO_STATE)
	{
		SwitchState(typeResult);
	}

}



void GameStateMachine::SwitchState(GameStateType gameStateType)
{
	WriteToThreadLog("Switch Game States");

	//Clean up current state if there is a current state
	m_pCurrGameState->Shutdown(m_pCoreFacade);
	SAFE_DELETE(m_pCurrGameState);

	m_pCoreFacade->ClearLoadingCounts();

	CurrentlyLoading = false;

	//Init new state
	switch (gameStateType)
	{
	case GS_GAMEPLAY:
		
		m_pCurrGameState = new GamePlayState(m_pCoreFacade->CurrentLevel);
		break;
	case GS_MAIN_MENU:
		m_pCurrGameState = new MainMenuState;
		CurrentLevel = 1;
		break;
	case GS_OPTIONS_MENU:
		m_pCurrGameState = new OptionsMenuState;
		break;
	case GS_INTRO0:
		m_pCurrGameState = new GPGamesIntroState;
		break;
	case GS_INTRO1:
		m_pCurrGameState = new StudioLogoIntroState;
		break;
	case GS_INTRO2:
		m_pCurrGameState = new TeamLogoIntroState;
		break;
	case GS_INTRO3:
		m_pCurrGameState = new IntroState;
		break;
	case GS_CREDITS_MENU:
		m_pCurrGameState = new CreditsState;
		break;
	case GS_LOSE:
		m_pCurrGameState = new CLoseState;
		break;
	case GS_LOADING:
	{
		m_pCurrGameState = new LoadingScreenState();
		CurrentlyLoading = true;
		break;
	}
	case GS_WIN:
	{
		//Advance level and check for beat game state
		CurrentLevel++;
		if (CurrentLevel > PARAGON_LEVEL_COUNT)
		{
			m_pCurrGameState = new CreditsState;//CWinState;
		}
		else
		{
			m_pCoreFacade->CurrentLevel = CurrentLevel;
			m_pCurrGameState = new LoadingScreenState();
			CurrentlyLoading = true;
		}
		break;
	}
	case GS_NO_STATE:
	default:
		//Invalid Call
		m_pCurrGameState = nullptr;
		break;
	}

	//Initialize new gamestate
	m_pCoreFacade->ClearToggles();
	m_pCurrGameState->Initialize(m_pCoreFacade);
}

//Delete the current state
void GameStateMachine::RestartGame()
{
	if (m_pCurrGameState != nullptr)
	{
		m_pCurrGameState->Shutdown(m_pCoreFacade);
		SAFE_DELETE(m_pCurrGameState);
	}
	else
		PrintConsole("Trying to restart game and the current state is nullptr!");

	m_pCurrGameState = new IntroState;
	m_pCurrGameState->Initialize(m_pCoreFacade);

	CurrentLevel = 1;
}

void GameStateMachine::GetInput(RAWINPUT rawInput)
{
	// This protection is required to safe-guard against early calls from the windowsProc thread.
	if (m_pCoreFacade != nullptr)
		m_pCoreFacade->GetInput(rawInput);
}
