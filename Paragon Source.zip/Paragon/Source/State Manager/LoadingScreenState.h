#pragma once
#include "GameState.h"
#include "../Application/CoreFacade.h"
#include "../Asset Manager/AssetManager.h"
#include "../Text Manager/TextBox.h"
#include <thread>
#include <mutex>
#include <condition_variable>

class RenderController;

class LoadingScreenState : public GameState
{
private:
	//HUD and Text Elements
	HUDElement * he_LoadingScreen;
	HUDElement * he_Dot1;
	HUDElement * he_Dot2;
	HUDElement * he_Dot3;

	//Toggle to switch to next state
	static bool LoadingComplete;
	static bool RenderThreadComplete;
	static bool CanRender;

	void CreateThreads(CoreFacade * CF);
	
	RenderController * RC;

	//std::thread RenderThread;
	std::thread LoadingThread;

	bool ThreadsCreated;
	static condition_variable BlockForComplete;
	float LoadStartTime;
	float LoadEndTime;

public:
	LoadingScreenState();
	~LoadingScreenState();

	void Initialize(CoreFacade* pCoreFacade) override;
	void Shutdown(CoreFacade* pCoreFacade) override;
	GameStateType Update(CoreFacade* pCoreFacade) override;

	static void RenderFunc(RenderController * RC, GameState * TransitionState);

	static std::mutex LoadLock;
	static void SetLoadingComplete();
	static bool GetLoadingComplete();
};

