#include "../Application/stdafx.h"

#pragma once

#include "GameState.h"
class AudioSystemWwise;
class SoundManager;
class CoreFacade;



class GameStateMachine
{
private:
	bool CurrentlyLoading;
	//Enum for the game state

	//The access to the main systems for all game states
	CoreFacade * m_pCoreFacade;

	//A reference to the current game state
	GameState * m_pCurrGameState;

	SoundManager* m_pSoundManager;
	AudioSystemWwise* m_pAudioSystem;

	int CurrentLevel;


public:


	void Initialize(HWND hWnd, HINSTANCE hInstance, int nWidth, int nHeight, bool bIsWindowed);
	void Shutdown();
	void Update();
	void SwitchState(GameStateType gameStateType);
	void RestartGame();
	void GetInput(RAWINPUT rawInput);

	GameStateMachine();
	~GameStateMachine();
};

