#pragma once
#include "GameState.h"

#include "../Asset Manager/AssetManager.h"
#include "../Text Manager/TextBox.h"

class CreditsState :
	public GameState
{
	std::vector<XMFLOAT2> locations;
	HUDElement* creditsScreen;
	HUDElement* creditsBackplate;
	HUDElement* creditsNames;
	HUDElement* creditsSelector;
	TextBox*	returnBox;
	int m_nCurrSelection;

public:
	CreditsState();
	virtual ~CreditsState();

	void Initialize(CoreFacade* pCoreFacade) override;
	void Shutdown(CoreFacade* pCoreFacade) override;
	GameStateType Update(CoreFacade* pCoreFacade) override;
};
