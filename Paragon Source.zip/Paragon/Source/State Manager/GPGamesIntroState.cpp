#include "../Application/stdafx.h"
#include "GPGamesIntroState.h"

#include "../Application/CoreFacade.h"
#include "../Asset Manager/AssetManager.h"

#include "../Object Manager/GameObject.h"
#include "../Sound/SoundManager.h"
#include "../Util/TimeManager.h"
#include "../Sound/Wwise_IDs.h"

GPGamesIntroState::GPGamesIntroState()
{
}


GPGamesIntroState::~GPGamesIntroState()
{
}


void GPGamesIntroState::Initialize(CoreFacade* pCoreFacade)
{
	waittimer = 0;

	HUDtoLoad hudLoader;
	pCoreFacade->LoadFont("LeagueGothic");

	// Intro Screen
	introScreen = new HUDElement(2.0f, 2.0f, 0.0f, 0.0f);
	hudLoader.TextureFilePath = "../Assets/Textures/GPGames_Logo.dds";

	GameObject * IntroScreenGO = new GameObject;
	IntroScreenGO->SetTypeID(eHUD);
	IntroScreenGO->SetTag("GPScreen");
	IntroScreenGO->SetHUDComponent(introScreen);
	hudLoader.pGO = IntroScreenGO;
	pCoreFacade->LoadHudAsset(&hudLoader);
	pCoreFacade->m_ObjectManager->AddGameObject(IntroScreenGO);

	this->CreateTransitionState(pCoreFacade, "GP State");

	// Loading Screen
	//loadingScreen = new HUDElement(2.0f, 2.0f, 0.0f, 0.0f);
	//hudLoader.HUD_El = loadingScreen;
	//hudLoader.TextureFilePath = "../Assets/Textures/LoadingScreen.dds";
	//hudLoader.HUD_El->SetTag("LoadingScreen");
	//pCoreFacade->LoadHudAsset(&hudLoader);
	//pCoreFacade->AddHudElement(hudLoader.HUD_El);

	pCoreFacade->CreateRenderSets();
	PrintConsole("Creating GP Intro State Render Set");
	pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_BGM_PARAGON_LOOP_03);

}

void GPGamesIntroState::Shutdown(CoreFacade* pCoreFacade)
{
	pCoreFacade->UnloadFonts();
	pCoreFacade->ClearAllObjects();

}

GameStateType GPGamesIntroState::Update(CoreFacade* pCoreFacade)
{
	waittimer += TimeManager::GetTimeDelta();
	wstringstream textOut;
	if (waittimer >= 3.0f || (pCoreFacade->IsToggled(BT_ESC) && !pCoreFacade->GetSettings().bFirstTime)) 
	{
		TransitionNextState = true;
	}



	if (UpdateTransition() == true)
		return GS_INTRO1;

	return GS_NO_STATE;
}
