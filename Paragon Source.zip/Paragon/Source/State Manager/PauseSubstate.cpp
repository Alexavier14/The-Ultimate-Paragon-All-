#include "../Application/stdafx.h"
#include "PauseSubstate.h"
#include "../Application/CoreFacade.h"
#include "../Text Manager/TextBox.h"
#include "../Object Manager/HUDElement.h"
#include "../Renderer/RenderController.h"
#include "../State Manager/GameStateMachine.h"
#include "../Sound/SoundManager.h"
#include "../Sound/Wwise_IDs.h"

//Pause Menu States
#define PAUSE_MENU		1
#define PAUSE_OPTIONS	2
#define PAUSE_CONTROL	4
#define PAUSE_RESUME	8
#define PAUSE_QUIT		16

//Only used for pause menu stuff.
#define PAUSE_ESC 1
#define PAUSE_SEL 2
#define PAUSE_UP 4
#define PAUSE_DOWN 8
#define PAUSE_LEFT 16
#define PAUSE_RIGHT 32

PauseSubstate::PauseSubstate()
{
}


PauseSubstate::~PauseSubstate()
{
}


void PauseSubstate::Initialize(CoreFacade* pCoreFacade)
{
	//Get current Volumes for the Music and Sound Effects
	sfxVol = pCoreFacade->GetSoundManager()->GetSfxVolume();
	musVol = pCoreFacade->GetSoundManager()->GetMusicVolume();

	//Set Default Cursor positions
	cursorPos[0] = XMFLOAT2(-0.13f,	 0.05f);
	cursorPos[1] = XMFLOAT2(-0.13f, -0.05f);
	cursorPos[2] = XMFLOAT2(-0.13f, -0.15f);
	cursorPos[3] = XMFLOAT2(-0.13f, -0.25f);

	HUDtoLoad hudLoader;

	m_PauseMenu = pCoreFacade->LoadHudElement("PauseMenu", "pauseMenu.dds", 0.0f,0.0f, 0.8f, 1.0f);
	m_PauseMenu->isEnabled = false;

	m_PauseOptionMenu = pCoreFacade->LoadHudElement("OptionsScreen", "pauseMenuOptions.dds", 0.0f, 0.0f, 0.8f, 1.0f);
	m_PauseOptionMenu->isEnabled = false;

	m_PauseMenuControls = pCoreFacade->LoadHudElement("ControlsScreen", "pauseMenuControls.dds", 0.0f, 0.0f, 0.8f, 1.0f);
	m_PauseMenuControls->isEnabled = false;

	m_PauseCursor = pCoreFacade->LoadHudElement("OptionScreenCursor", "MenuSelector.dds", cursorPos[0].x, cursorPos[0].y, 0.07f, 0.04f);
	m_PauseCursor->isEnabled = false;


	//Text
	XMFLOAT4 textGlyphColor(0.1f, 0.65f, 0.9f, 1.0f);
	XMFLOAT4 textOutlineColor(1.0f, 1.0f, 1.0f, 0.0f);
	float textScale = 0.45f;
	m_SfxVolTxt = pCoreFacade->LoadTextBox( 0.16f,  0.0f, textScale, textGlyphColor, textOutlineColor);
	m_MusicVolTxt = pCoreFacade->LoadTextBox(0.16f, 0.09f, textScale, textGlyphColor, textOutlineColor);

	m_Pause_state = PAUSE_MENU;
}

void PauseSubstate::Shutdown()
{

}


GameStateType PauseSubstate::Update(CoreFacade * pCoreFacade)
{

	unsigned char buttonPressed = 0;
	unsigned char returnValue = 0;

	//Only get one input per frame to prevent multiple commands being triggered once.
	if (pCoreFacade->IsToggled(BT_ESC))
		buttonPressed |= PAUSE_ESC;
	else if (pCoreFacade->IsToggled(BT_SELECT) || pCoreFacade->IsToggled(BT_SEND))
		buttonPressed |= PAUSE_SEL;
	else if (pCoreFacade->IsToggled(BT_UP))
		buttonPressed |= PAUSE_UP;
	else if (pCoreFacade->IsToggled(BT_DOWN))
		buttonPressed |= PAUSE_DOWN;
	else if (pCoreFacade->IsToggled(BT_LEFT))
		buttonPressed |= PAUSE_LEFT;
	else if (pCoreFacade->IsToggled(BT_RIGHT))
		buttonPressed |= PAUSE_RIGHT;

	//Pause States
	switch (m_Pause_state)
	{
	case PAUSE_MENU:
		returnValue = PauseMenu(buttonPressed);
		break;
	case PAUSE_OPTIONS:
		returnValue = OptionsMenu(buttonPressed, pCoreFacade);
		break;
	case PAUSE_CONTROL:
		returnValue = ControlMenu(buttonPressed);
		break;
	default:
		return GS_NO_STATE;
	}

	return StateChange(returnValue, pCoreFacade);
}

void PauseSubstate::Switch(bool menu, bool options, bool controls, CoreFacade * pCoreFacade)
{
	//is the game paused or not?
	if (!menu && !options && !controls)
		pCoreFacade->SetIsPaused(false);
	else
		pCoreFacade->SetIsPaused(true);

	//Pause Menu Stuff
	m_PauseMenu->isEnabled = menu;

	//Options Menu Stuff
	m_PauseOptionMenu->isEnabled = options;
	m_MusicVolTxt->SetIsActive(options);
	m_SfxVolTxt->SetIsActive(options);

	//Control Menu Stuff
	m_PauseMenuControls->isEnabled = controls;
	if (controls || (!menu && !options && !controls))
		m_PauseCursor->isEnabled = false;
	else
		m_PauseCursor->isEnabled = true;

	m_nCurrSelection = 0;
	m_PauseCursor->m_XSceenPos = cursorPos[m_nCurrSelection].x;
	m_PauseCursor->m_YScreenPos = cursorPos[m_nCurrSelection].y;
}
unsigned char PauseSubstate::OptionsMenu(unsigned char key_pressed, CoreFacade * pCoreFacade)
{
	if (key_pressed & PAUSE_UP)
	{
		if (m_nCurrSelection - 1 < 0)
			m_nCurrSelection = 3;
		else
			m_nCurrSelection--;

		m_PauseCursor->m_XSceenPos = cursorPos[m_nCurrSelection].x;
		m_PauseCursor->m_YScreenPos = cursorPos[m_nCurrSelection].y;
	}

	if (key_pressed & PAUSE_DOWN)

	{
		if (m_nCurrSelection + 1 > 3)
			m_nCurrSelection = 0;
		else
			m_nCurrSelection++;

		m_PauseCursor->m_XSceenPos = cursorPos[m_nCurrSelection].x;
		m_PauseCursor->m_YScreenPos = cursorPos[m_nCurrSelection].y;
	}



	wstringstream ss, ss2;
	if (m_nCurrSelection == 0)
	{
		if (key_pressed & PAUSE_RIGHT)
		{
			if (musVol + 5.0f > 100.0f)
				musVol = 100.0f;
			else
				musVol += 5.0f;

			pCoreFacade->GetSoundManager()->SetMusicVolume(musVol);
		}
		else if (key_pressed & PAUSE_LEFT)
		{
			if (musVol - 5.0f < 0.0f)
				musVol = 0.0f;
			else
				musVol -= 5.0f;

			pCoreFacade->GetSoundManager()->SetMusicVolume(musVol);
		}
	}

	if (m_nCurrSelection == 1)
	{
		if (key_pressed & PAUSE_RIGHT)
		{
			if (sfxVol + 5.0f > 100.0f)
				sfxVol = 100.0f;

			else
				sfxVol += 5.0f;

			pCoreFacade->GetSoundManager()->SetSfxVolume(sfxVol);
			pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_SFX_MENU_SELECT);
		}
		else if (key_pressed & PAUSE_LEFT)
		{
			if (sfxVol - 5.0f < 0.0f)
				sfxVol = 0.0f;

			else
				sfxVol -= 5.0f;

			pCoreFacade->GetSoundManager()->SetSfxVolume(sfxVol);
			pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_SFX_MENU_SELECT);
		}
	}

	//if (m_nCurrSelection == 2)
	//{
	//	if (key_pressed & PAUSE_RIGHT || key_pressed & PAUSE_LEFT)
	//	{
	//		pCoreFacade->GetRenderController()->SetResolution(SETHEIGHT, SETWIDTH, !pCoreFacade->GetRenderController()->IsWindowed);
	//		//FullOnOff = pCoreFacade->GetRenderController()->IsWindowed;
	//	}
	//}

	ss << sfxVol;
	m_SfxVolTxt->SetText(ss.str());

	ss2 << musVol;
	m_MusicVolTxt->SetText(ss2.str());

	if (key_pressed & PAUSE_ESC)
	{
		return PAUSE_MENU;
	}

	if (key_pressed & PAUSE_SEL)
	{
		if (m_nCurrSelection == 2)
			return PAUSE_CONTROL;

		if (m_nCurrSelection == 3) // change to 3 when the controls is in.
			return PAUSE_MENU;
	}

	return 0;
}
unsigned char PauseSubstate::ControlMenu(unsigned char key_pressed)
{
	if (key_pressed & (PAUSE_SEL | PAUSE_ESC))
		return PAUSE_OPTIONS;
	return 0;
}
unsigned char PauseSubstate::PauseMenu(unsigned char key_pressed)
{
	if (key_pressed & PAUSE_UP)
	{
		if (m_nCurrSelection - 1 < 0)
			m_nCurrSelection = 2;
		else
			m_nCurrSelection--;

		m_PauseCursor->m_XSceenPos = cursorPos[m_nCurrSelection].x;
		m_PauseCursor->m_YScreenPos = cursorPos[m_nCurrSelection].y;
	}

	if (key_pressed & PAUSE_DOWN)

	{
		if (m_nCurrSelection + 1 > 2)
			m_nCurrSelection = 0;
		else
			m_nCurrSelection++;

		m_PauseCursor->m_XSceenPos = cursorPos[m_nCurrSelection].x;
		m_PauseCursor->m_YScreenPos = cursorPos[m_nCurrSelection].y;
	}

	if (key_pressed & PAUSE_ESC)
		return PAUSE_RESUME;

	if (key_pressed & PAUSE_SEL)
	{
		if (m_nCurrSelection == 0)
			return PAUSE_RESUME;

		if (m_nCurrSelection == 1)
			return PAUSE_OPTIONS;

		if (m_nCurrSelection == 2)
			return PAUSE_QUIT;
	}

	return 0;
}
GameStateType PauseSubstate::StateChange(unsigned char state, CoreFacade * pCoreFacade)
{
	switch (state)
	{
	case PAUSE_MENU:
	{
		Switch(true, false, false, pCoreFacade);
		m_Pause_state = PAUSE_MENU;
	}
		break;
	case PAUSE_OPTIONS:
	{
		Switch(false, true, false, pCoreFacade);
		m_Pause_state = PAUSE_OPTIONS;
	}
		break;
	case PAUSE_CONTROL:
	{
		Switch(false, false, true, pCoreFacade);
		m_Pause_state = PAUSE_CONTROL;
	}
		break;
	case PAUSE_RESUME:
	{
		Switch(false, false, false, pCoreFacade);
	}
		break;
	case PAUSE_QUIT:
	{
		Switch(false, false, false, pCoreFacade);
		return GS_MAIN_MENU;
	}
		break;
	default:
	{
		return GS_NO_STATE;
	}
		break;
	}

	return GS_NO_STATE;
}

void PauseSubstate::Start(CoreFacade * pCoreFacade)
{
	m_Pause_state = PAUSE_MENU;
	Switch(true, false, false, pCoreFacade);
}
