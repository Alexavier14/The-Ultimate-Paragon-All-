#include "../Application/stdafx.h"

#include "CreditsState.h"
#include "../Application/CoreFacade.h"
#include "../Asset Manager/AssetManager.h"

#include "../Object Manager/GameObject.h"
#include "../Sound/SoundManager.h"
#include "../Sound/Wwise_IDs.h"
#include "../Util/TimeManager.h"

CreditsState::CreditsState() :
creditsScreen(NULL),
creditsSelector(NULL)
{
}


CreditsState::~CreditsState()
{
}

void CreditsState::Initialize(CoreFacade* pCoreFacade)
{
	HUDtoLoad hudLoader;
	m_nCurrSelection = 0;
	pCoreFacade->LoadFont("LeagueGothic");
	
	//Back plate
	creditsBackplate = new HUDElement(2.0f, 2.0f, 0.0f, 0.0f);
	hudLoader.TextureFilePath = "../Assets/Textures/CreditsBackPlate.dds";
	GameObject * BackPlateGO = new GameObject;
	BackPlateGO->SetTag("CreditsMenuBackplate");
	BackPlateGO->SetTypeID(eHUD);
	BackPlateGO->SetHUDComponent(creditsBackplate);
	hudLoader.pGO = BackPlateGO;
	pCoreFacade->LoadHudAsset(&hudLoader);
	pCoreFacade->m_ObjectManager->AddGameObject(BackPlateGO);

	//Text
	creditsNames = new HUDElement(8.5f, 1.4f, -0.05f, -5.0f);
	hudLoader.TextureFilePath = "../Assets/Textures/CreditNames.dds";
	GameObject * NamesPlateGO = new GameObject;
	NamesPlateGO->SetTag("CreditsMenuNames");
	NamesPlateGO->SetTypeID(eHUD);
	NamesPlateGO->SetHUDComponent(creditsNames);
	hudLoader.pGO = NamesPlateGO;
	pCoreFacade->LoadHudAsset(&hudLoader);
	pCoreFacade->m_ObjectManager->AddGameObject(NamesPlateGO);

	//Frame
	creditsScreen = new HUDElement(2.0f, 2.0f, 0.0f, 0.0f);
	hudLoader.TextureFilePath = "../Assets/Textures/CreditsMenu.dds";
	GameObject * CreditsMenuGO = new GameObject;
	CreditsMenuGO->SetTag("CreditsMenuHUD");
	CreditsMenuGO->SetTypeID(eHUD);
	CreditsMenuGO->SetHUDComponent(creditsScreen);
	hudLoader.pGO = CreditsMenuGO;
	pCoreFacade->LoadHudAsset(&hudLoader);
	pCoreFacade->m_ObjectManager->AddGameObject(CreditsMenuGO);

	
	creditsSelector = new HUDElement(0.05f, 0.05f, -0.12f, -0.9f);
	hudLoader.TextureFilePath = "../Assets/Textures/MenuSelector.dds";
	GameObject * CreditsScreenGO = new GameObject;
	CreditsScreenGO->SetTypeID(eHUD);
	CreditsScreenGO->SetTag("CreditsScreenS");
	CreditsScreenGO->SetHUDComponent(creditsSelector);
	hudLoader.pGO = CreditsScreenGO;
	pCoreFacade->LoadHudAsset(&hudLoader);
	pCoreFacade->m_ObjectManager->AddGameObject(CreditsScreenGO);

	returnBox = new TextBox;
	returnBox->SetFont(pCoreFacade->GetFont("LeagueGothic"));
	returnBox->SetTextColor(XMFLOAT4(0.1f, 0.65f, 0.9f, 1.0f), XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));
	returnBox->SetPosition(-0.1f, -0.85f);
	returnBox->SetScale(0.6f);
	pCoreFacade->AddTextBox(returnBox);

	pCoreFacade->ClearToggles();
	this->CreateTransitionState(pCoreFacade, "Credits Menu State");
	pCoreFacade->CreateRenderSets();
	PrintConsole("Creating Credits State Render Set");

	pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::STOP_ALL);
	pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_BGM_VICTORY);
}

void CreditsState::Shutdown(CoreFacade* pCoreFacade)
{
	pCoreFacade->UnloadFonts();
	pCoreFacade->ClearAllObjects();
}

GameStateType CreditsState::Update(CoreFacade* pCoreFacade)
{
	wstringstream textOut;

	if (creditsNames != nullptr)
	{
		//Scroll the text upward
		creditsNames->m_YScreenPos += (0.1f * TimeManager::GetTimeDelta());
	}
	if (UpdateTransition() == true)
	{
		return GS_MAIN_MENU;
	}

	if (pCoreFacade->IsToggled(BT_ESC))
	{
		if (m_nCurrSelection == 0)
		{
			TransitionNextState = true;
			return GS_NO_STATE;
		}
		else
		{
			creditsSelector->m_XSceenPos = -0.9f;
			creditsSelector->m_YScreenPos = 0.014f;
			m_nCurrSelection = 0;
		}
	}

	if (m_nCurrSelection == 0)
	{
		returnBox->SetTextColor(XMFLOAT4(0.9f, 0.65f, 0.1f, 1.0f), XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));
	}
	else
	{
		returnBox->SetTextColor(XMFLOAT4(0.1f, 0.65f, 0.9f, 1.0f), XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));
	}
	if (pCoreFacade->IsToggled(BT_SELECT) || pCoreFacade->IsToggled(BT_SEND) || pCoreFacade->IsToggled(BT_MOVE))
	{
		//introScreen->isEnabled = false;
		if (m_nCurrSelection == 0)
		{
			pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_SFX_GEM_PICKUP_01);
			
			TransitionNextState = true;
			return GS_NO_STATE;
			//return GS_MAIN_MENU;
		}
	}

	textOut << "Return";
	returnBox->SetText(textOut.str());

	return GS_NO_STATE;
}
