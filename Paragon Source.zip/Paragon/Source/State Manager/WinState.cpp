#include "../Application/stdafx.h"

#include "WinState.h"
#include "../Application/CoreFacade.h"
#include "../Asset Manager/AssetManager.h"
#include "../Object Manager/HUDElement.h"
#include "../Object Manager/GameObject.h"
#include "../Sound/SoundManager.h"
#include "../Sound/Wwise_IDs.h"

CWinState::CWinState()
{

}

CWinState::~CWinState()
{

}


void CWinState::Initialize(CoreFacade* pCoreFacade)
{
	pCoreFacade->BeginAssetLoad();
	HUDtoLoad loseScreenToLoad;
	HUDElement * loseScreen = new HUDElement(2.0f, 2.0f, 0.0f, 0.0f);
	loseScreenToLoad.TextureFilePath = "../Assets/Textures/YOUWON.dds";

	GameObject * LoseScreenGO = new GameObject;
	LoseScreenGO->SetTypeID(eHUD);
	LoseScreenGO->SetTag("LoseSreen");
	LoseScreenGO->SetHUDComponent(loseScreen);
	loseScreenToLoad.pGO = LoseScreenGO;
	pCoreFacade->LoadHudAsset(&loseScreenToLoad);
	pCoreFacade->EndAssetLoad();

	pCoreFacade->m_ObjectManager->AddGameObject(LoseScreenGO);

	this->CreateTransitionState(pCoreFacade, "Win State");

	pCoreFacade->CreateRenderSets();
	PrintConsole("Creating Win State Render Set");

	pCoreFacade->ClearToggles();
	pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::STOP_ALL);
	pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_BGM_LVL_COMPLETED);
}

void CWinState::Shutdown(CoreFacade* pCoreFacade)
{
	pCoreFacade->UnloadFonts();
	pCoreFacade->ClearAllObjects();
}


// Updates the Game state. 
// With its returned GameStateType, it indicates that a switch to the specified type should be made.
GameStateType CWinState::Update(CoreFacade* pCoreFacade)
{
	if (UpdateTransition() == true)
	{
		pCoreFacade->CurrentLevel = 1;
		pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::STOP_ALL);
		return GS_CREDITS_MENU;
	}

	if (pCoreFacade->IsToggled(BT_RUBY)
		|| pCoreFacade->IsToggled(BT_SAPP)
		|| pCoreFacade->IsToggled(BT_DIAM)
		|| pCoreFacade->IsToggled(BT_ALL)
		|| pCoreFacade->IsToggled(BT_BACK)
		|| pCoreFacade->IsToggled(BT_SELECT)
		|| pCoreFacade->IsToggled(BT_SEND))
	{
		//introScreen->isEnabled = false;
		TransitionNextState = true;
	}
	return GS_NO_STATE;
}
