#pragma once
#include "GameState.h"
#include "../Asset Manager/AssetManager.h"
#include "../Text Manager/TextBox.h"
class OptionsMenuState :
	public GameState
{
	XMFLOAT2 lastMouse;
	HUDElement* optionScreen;
	HUDElement* optionCursor;
	TextBox		*Title, *VideoSection, *SoundSection;
	TextBox		*ResolutionOptions, *ResolutionSelected;
	TextBox		*WindowOption, *SelectedMode;
	TextBox		*AAOption, *AAValue;
	TextBox		*GammaOption, *GammaValue;
	TextBox		*MusicOption, *MusicValue;
	TextBox		*SfxOption, *SfxValue;
	TextBox		*ApplyBox, *ReturnBox;
	XMFLOAT4 defaultFillColor, defaultOutlineColor, highlightFillColor;

	HUDElement* VerrifyOptions;
	TextBox		*YesBox, *NoBox;

	std::vector<XMFLOAT2> location;
	vector<XMUINT2> screen_sizes;
	vector<wstring> screens_supported;

	float sfxVol, musVol;
	bool FullOnOff;

	int m_nCurrSelection;
	int m_nCurrResolution;
	bool m_nModeSelected;
	int m_nAASelected;
	int m_nGammaValue;
	int m_nSfxValue;
	int m_nMusicValue;

	bool bResChanged, bModeChanged, bAAChanged, bGammaChanged, bSfxChanged, bMusicChanged;
	bool bUnsavedChanges;

	void ApplyNewSettings(CoreFacade* pCoreFacade);
	void ApplyPreviousSettings(CoreFacade* pCoreFacade);

public:
	OptionsMenuState();
	virtual ~OptionsMenuState();

	void Initialize(CoreFacade* pCoreFacade) override;
	void Shutdown(CoreFacade* pCoreFacade) override;
	GameStateType Update(CoreFacade* pCoreFacade) override;


};

