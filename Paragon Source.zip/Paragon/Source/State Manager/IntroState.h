#pragma once
#include "GameState.h"

#include "../Asset Manager/AssetManager.h"
#include "../Text Manager/TextBox.h"

class IntroState :
	public GameState
{
	HUDElement* introScreen;
	HUDElement* loadingScreen;
	TextBox*    playBox;

public:

	IntroState( );
	virtual ~IntroState();

	void Initialize(  CoreFacade* pCoreFacade  ) override;
	void Shutdown( CoreFacade* pCoreFacade ) override;
	GameStateType Update(  CoreFacade* pCoreFacade ) override;

};

