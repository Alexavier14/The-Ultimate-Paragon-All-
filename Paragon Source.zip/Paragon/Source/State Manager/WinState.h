#pragma once
#include "GameState.h"

class CoreFacade;

class CWinState : public GameState
{

public:

	CWinState();
	~CWinState();

	virtual void Initialize(CoreFacade* pCoreFacade);
	virtual void Shutdown(CoreFacade* pCoreFacade);

	// Updates the Game state. 
	// With its returned GameStateType, it indicates that a switch to the specified type should be made.
	virtual GameStateType Update(CoreFacade* pCoreFacade);
};