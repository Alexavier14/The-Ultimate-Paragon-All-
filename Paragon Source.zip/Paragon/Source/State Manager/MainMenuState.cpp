#include "../Application/stdafx.h"

#include "MainMenuState.h"
#include "../Application/CoreFacade.h"
#include "../Asset Manager/AssetManager.h"
#include "../Object Manager/GameObject.h"
#include "../Sound/SoundManager.h"
#include "../Sound/Wwise_IDs.h"
#include "../Resources/resource.h"


MainMenuState::MainMenuState(){}
MainMenuState::~MainMenuState(){}

void MainMenuState::Initialize( CoreFacade* pCoreFacade )
{
	HUDtoLoad hudLoader;
	pCoreFacade->LoadFont("LeagueGothic");
	pCoreFacade->LoadFont("SuperNaturalKnight");
	m_nCurrSelection = 0;

	location.clear();

	defaultFillColor = XMFLOAT4(0.1f, 0.65f, 0.9f, 1.0f);
	defaultOutlineColor = XMFLOAT4(0.0f, 0.0f, 0.1f, 1.0f);
	highlightFillColor = XMFLOAT4(0.9f, 0.65f, 0.1f, 1.0f);

	location.push_back(XMFLOAT2(-0.75f, 0.34f));
	location.push_back(XMFLOAT2(-0.75f, 0.12f));
	location.push_back(XMFLOAT2(-0.75f, -0.12f));
	location.push_back(XMFLOAT2(-0.75f, -0.33f));

	mainMenu = new HUDElement(2.0f, 2.0f, 0.0f, 0.0f);
	hudLoader.TextureFilePath = "../Assets/Textures/Menu_Background.dds";

	GameObject * MainScreenHUDGO = new GameObject;
	MainScreenHUDGO->SetTag("MainScreen");
	MainScreenHUDGO->SetTypeID(eHUD);
	MainScreenHUDGO->SetHUDComponent(mainMenu);
	hudLoader.pGO = MainScreenHUDGO;
	pCoreFacade->LoadHudAsset(&hudLoader);
	pCoreFacade->m_ObjectManager->AddGameObject(MainScreenHUDGO);

	menuSelector = new HUDElement(0.12f, 0.26f, location[0].x, location[0].y);
	hudLoader.TextureFilePath = "../Assets/Textures/Sapphire_Pointer.dds";

	GameObject * MenuSelectorHUDElementGO = new GameObject;
	MenuSelectorHUDElementGO->SetTag("MainScreenS");
	MenuSelectorHUDElementGO->SetTypeID(eHUD);
	MenuSelectorHUDElementGO->SetHUDComponent(menuSelector);
	hudLoader.pGO = MenuSelectorHUDElementGO;
	pCoreFacade->LoadHudAsset(&hudLoader);
	pCoreFacade->m_ObjectManager->AddGameObject(MenuSelectorHUDElementGO);

	playImg = new HUDElement(0.14f, 0.5f, -0.4f, 0.34f);
	hudLoader.TextureFilePath = "../Assets/Textures/NewGame_Unselected.dds";

	GameObject * playHUDElementGO = new GameObject;
	playHUDElementGO->SetTag("PlayImg");
	playHUDElementGO->SetTypeID(eHUD);
	playHUDElementGO->SetHUDComponent(playImg);
	hudLoader.pGO = playHUDElementGO;
	pCoreFacade->LoadHudAsset(&hudLoader);
	pCoreFacade->m_ObjectManager->AddGameObject(playHUDElementGO);

	playImg2 = new HUDElement(0.14f, 0.5f, -0.4f, 0.34f);
	hudLoader.TextureFilePath = "../Assets/Textures/NewGame_Selected.dds";

	GameObject * playHUDElementGO2 = new GameObject;
	playHUDElementGO2->SetTag("PlayImg2");
	playHUDElementGO2->SetTypeID(eHUD);
	playHUDElementGO2->SetHUDComponent(playImg2);
	hudLoader.pGO = playHUDElementGO2;
	pCoreFacade->LoadHudAsset(&hudLoader);
	pCoreFacade->m_ObjectManager->AddGameObject(playHUDElementGO2);


	optionsImg = new HUDElement(0.14f, 0.4f, -0.47f, 0.12f);
	hudLoader.TextureFilePath = "../Assets/Textures/Options_Unselected.dds";

	GameObject * optionsHUDElementGO = new GameObject;
	optionsHUDElementGO->SetTag("OptionsImg");
	optionsHUDElementGO->SetTypeID(eHUD);
	optionsHUDElementGO->SetHUDComponent(optionsImg);
	hudLoader.pGO = optionsHUDElementGO;
	pCoreFacade->LoadHudAsset(&hudLoader);
	pCoreFacade->m_ObjectManager->AddGameObject(optionsHUDElementGO);

	optionsImg2 = new HUDElement(0.14f, 0.4f, -0.47f, 0.12f);
	hudLoader.TextureFilePath = "../Assets/Textures/Options_Selected.dds";

	GameObject * optionsHUDElementGO2 = new GameObject;
	optionsHUDElementGO2->SetTag("OptionsImg2");
	optionsHUDElementGO2->SetTypeID(eHUD);
	optionsHUDElementGO2->SetHUDComponent(optionsImg2);
	hudLoader.pGO = optionsHUDElementGO2;
	pCoreFacade->LoadHudAsset(&hudLoader);
	pCoreFacade->m_ObjectManager->AddGameObject(optionsHUDElementGO2);

	creditsImg = new HUDElement(0.18f, 0.4f, -0.47f, -0.12f);
	hudLoader.TextureFilePath = "../Assets/Textures/Credits_Unselected.dds";

	GameObject * creditsHUDElementGO = new GameObject;
	creditsHUDElementGO->SetTag("CreditsImg");
	creditsHUDElementGO->SetTypeID(eHUD);
	creditsHUDElementGO->SetHUDComponent(creditsImg);
	hudLoader.pGO = creditsHUDElementGO;
	pCoreFacade->LoadHudAsset(&hudLoader);
	pCoreFacade->m_ObjectManager->AddGameObject(creditsHUDElementGO);

	creditsImg2 = new HUDElement(0.18f, 0.4f, -0.47f, -0.12f);
	hudLoader.TextureFilePath = "../Assets/Textures/Credits_Selected.dds";

	GameObject * creditsHUDElementGO2 = new GameObject;
	creditsHUDElementGO2->SetTag("CreditsImg2");
	creditsHUDElementGO2->SetTypeID(eHUD);
	creditsHUDElementGO2->SetHUDComponent(creditsImg2);
	hudLoader.pGO = creditsHUDElementGO2;
	pCoreFacade->LoadHudAsset(&hudLoader);
	pCoreFacade->m_ObjectManager->AddGameObject(creditsHUDElementGO2);

	exitImg = new HUDElement(0.18f, 0.25f, -0.53f, -0.33f);
	hudLoader.TextureFilePath = "../Assets/Textures/Exit_UnSelected.dds";

	GameObject * exitHUDElementGO = new GameObject;
	exitHUDElementGO->SetTag("ExitImg");
	exitHUDElementGO->SetTypeID(eHUD);
	exitHUDElementGO->SetHUDComponent(exitImg);
	hudLoader.pGO = exitHUDElementGO;
	pCoreFacade->LoadHudAsset(&hudLoader);
	pCoreFacade->m_ObjectManager->AddGameObject(exitHUDElementGO);

	exitImg2 = new HUDElement(0.18f, 0.25f, -0.53f, -0.33f);
	hudLoader.TextureFilePath = "../Assets/Textures/Exit_Selected.dds";

	GameObject * exitHUDElementGO2 = new GameObject;
	exitHUDElementGO2->SetTag("ExitImg2");
	exitHUDElementGO2->SetTypeID(eHUD);
	exitHUDElementGO2->SetHUDComponent(exitImg2);
	hudLoader.pGO = exitHUDElementGO2;
	pCoreFacade->LoadHudAsset(&hudLoader);
	pCoreFacade->m_ObjectManager->AddGameObject(exitHUDElementGO2);

	titleImg = new HUDElement(0.5f, 1.3f, -0.16f, 0.75f);
	hudLoader.TextureFilePath = "../Assets/Textures/Paragon_Title.dds";

	GameObject * titleHUDElementGO = new GameObject;
	titleHUDElementGO->SetTag("TitleImg");
	titleHUDElementGO->SetTypeID(eHUD);
	titleHUDElementGO->SetHUDComponent(titleImg);
	hudLoader.pGO = titleHUDElementGO;
	pCoreFacade->LoadHudAsset(&hudLoader);
	pCoreFacade->m_ObjectManager->AddGameObject(titleHUDElementGO);

	//loadingScreen = new HUDElement(2.0f, 2.0f, 0.0f, 0.0f);
	//loadingScreen->isEnabled = false;
	//hudLoader.TextureFilePath = "../Assets/Textures/LoadingScreen.dds";
	//
	//GameObject * LoadScreenHUDGO = new GameObject;
	//LoadScreenHUDGO->SetTag("LoadingScreen");
	//LoadScreenHUDGO->SetTypeID(eHUD);
	//LoadScreenHUDGO->SetHUDComponent(loadingScreen);
	//LoadScreenHUDGO->SetActive(true);
	//hudLoader.pGO = LoadScreenHUDGO;
	//pCoreFacade->LoadHudAsset(&hudLoader);
	//pCoreFacade->m_ObjectManager->AddGameObject(LoadScreenHUDGO);

	/*arrowsUpDown = new HUDElement(0.25f, 0.25f, 0.55f, -0.7f);
	hudLoader.TextureFilePath = "../Assets/Textures/MenuArrowUpDown.dds";

	GameObject * arrowsUpDownGO = new GameObject;
	arrowsUpDownGO->SetTag("arrowUpDown");
	arrowsUpDownGO->SetTypeID(eHUD);
	arrowsUpDownGO->SetHUDComponent(arrowsUpDown);
	hudLoader.pGO = arrowsUpDownGO;
	pCoreFacade->LoadHudAsset(&hudLoader);
	pCoreFacade->m_ObjectManager->AddGameObject(arrowsUpDownGO);

	arrowsLeftRight = new HUDElement(0.25f, 0.25f, 0.55f, -0.7f);
	hudLoader.TextureFilePath = "../Assets/Textures/MenuArrowRightLeft.dds";

	GameObject * arrowsLeftRightGO = new GameObject;
	arrowsLeftRightGO->SetTag("arrowLeftRight");
	arrowsLeftRightGO->SetTypeID(eHUD);
	arrowsLeftRightGO->SetHUDComponent(arrowsLeftRight);
	hudLoader.pGO = arrowsLeftRightGO;
	pCoreFacade->LoadHudAsset(&hudLoader);
	pCoreFacade->m_ObjectManager->AddGameObject(arrowsLeftRightGO);

	mouseI = new HUDElement(0.2f, 0.1f, 0.35f, -0.68f);
	hudLoader.TextureFilePath = "../Assets/Textures/MouseInstructions.dds";

	GameObject * mouseIGO = new GameObject;
	mouseIGO->SetTag("mouseInstruct");
	mouseIGO->SetTypeID(eHUD);
	mouseIGO->SetHUDComponent(mouseI);
	hudLoader.pGO = mouseIGO;
	pCoreFacade->LoadHudAsset(&hudLoader);
	pCoreFacade->m_ObjectManager->AddGameObject(mouseIGO);

	returnSelect = new HUDElement(0.125f, 0.125f, 0.14f, -0.68f); //new HUDElement(0.125f, 0.125f, -0.04f, -0.68f);
	hudLoader.TextureFilePath = "../Assets/Textures/returnSelect.dds";

	GameObject * returnSelectGO = new GameObject;
	returnSelectGO->SetTag("returnInstruct");
	returnSelectGO->SetTypeID(eHUD);
	returnSelectGO->SetHUDComponent(returnSelect);
	hudLoader.pGO = returnSelectGO;
	pCoreFacade->LoadHudAsset(&hudLoader);
	pCoreFacade->m_ObjectManager->AddGameObject(returnSelectGO);

	lmbClick = new HUDElement(0.2f, 0.1f, -0.04f, -0.68f); //new HUDElement(0.2f, 0.1f, 0.14f, -0.68f);
	hudLoader.TextureFilePath = "../Assets/Textures/lmbClick.dds";

	GameObject * lmbClickGO = new GameObject;
	lmbClickGO->SetTag("lbmInstruct");
	lmbClickGO->SetTypeID(eHUD);
	lmbClickGO->SetHUDComponent(lmbClick);
	hudLoader.pGO = lmbClickGO;
	pCoreFacade->LoadHudAsset(&hudLoader);
	pCoreFacade->m_ObjectManager->AddGameObject(lmbClickGO); */

	//playBox = new TextBox;
	//playBox->SetFont(pCoreFacade->GetFont("LeagueGothic"));
	//playBox->SetTextColor(XMFLOAT4(0.1f, 0.65f, 0.9f, 1.0f), XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));
	//playBox->SetPosition(-0.85f, 0.083f);
	//playBox->SetScale(0.6f);
	//playBox->SetIsActive(true);
	//pCoreFacade->AddTextBox(playBox);


	//XMFLOAT4 glyphColor(0.1f, 0.65f, 0.9f, 1.0f);
	//XMFLOAT4 outlineColor(0.0f, 0.0f, 0.0f, 1.0f);

	////upDownBox = pCoreFacade->LoadTextBox(0.375f, -0.8f, 0.5f, glyphColor, outlineColor, "LeagueGothic");
	////enterBox = pCoreFacade->LoadTextBox(0, -0.8f, 0.5f, glyphColor, outlineColor, "LeagueGothic");
	//optionsBox = pCoreFacade->LoadTextBox(-0.85f, -0.115f, 0.6f, glyphColor, outlineColor, "LeagueGothic");
	//creditsBox = pCoreFacade->LoadTextBox(-0.85f, -0.314f, 0.6f, glyphColor, outlineColor, "LeagueGothic");
	//exitBox = pCoreFacade->LoadTextBox(-0.85f, -0.514f, 0.6f, glyphColor, outlineColor, "LeagueGothic");

	this->CreateTransitionState(pCoreFacade, "Main Menu");

	pCoreFacade->ClearToggles();

	HWND hWnd = GetForegroundWindow();
	lastMouse = pCoreFacade->GetMousePos();
	//HINSTANCE hIns = (HINSTANCE)GetWindowLong(hWnd, GWL_HINSTANCE);
	HCURSOR tempCursor = LoadCursor(nullptr, IDC_ARROW);
	//SetCursor(tempCursor);
	SetClassLong(hWnd, GCL_HCURSOR, (LONG)tempCursor);
	//SetCursorPos(500, 520);
	//showCursorCount = ShowCursor(true);
	pCoreFacade->CreateRenderSets();
	PrintConsole("Creating Main Menu State Render Set");
	pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::STOP_ALL);
	pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_BGM_PARAGON_LOOP_01);
}

void MainMenuState::Shutdown( CoreFacade* pCoreFacade )
{
	pCoreFacade->ClearAllObjects();
	pCoreFacade->UnloadFonts();
}

void SoundTestfunc(CoreFacade* pCoreFacade);

GameStateType MainMenuState::Update(CoreFacade* pCoreFacade)
{
#if _DEBUG
	SoundTestfunc(pCoreFacade);
#endif
	wstringstream textOut1, textOut2, textOut3, textOut4;
	

	playImg->isEnabled = true;
	playImg2->isEnabled = false;
	optionsImg->isEnabled = true;
	optionsImg2->isEnabled = false;
	creditsImg->isEnabled = true;
	creditsImg2->isEnabled = false;
	exitImg->isEnabled = true;
	exitImg2->isEnabled = false;

	switch (m_nCurrSelection)
	{
	case 0:
		playImg->isEnabled = false;
		playImg2->isEnabled = true;
		//playBox->SetTextColor(highlightFillColor, defaultOutlineColor);
		//optionsBox->SetTextColor(defaultFillColor, defaultOutlineColor);
		//creditsBox->SetTextColor(defaultFillColor, defaultOutlineColor);
		//exitBox->SetTextColor(defaultFillColor, defaultOutlineColor);
		break;
	case 1:
		optionsImg->isEnabled = false;
		optionsImg2->isEnabled = true;
		//playBox->SetTextColor(defaultFillColor, defaultOutlineColor);
		//optionsBox->SetTextColor(highlightFillColor, defaultOutlineColor);
		//creditsBox->SetTextColor(defaultFillColor, defaultOutlineColor);
		//exitBox->SetTextColor(defaultFillColor, defaultOutlineColor);
		break;
	case 2:
		creditsImg->isEnabled = false;
		creditsImg2->isEnabled = true;
		//playBox->SetTextColor(defaultFillColor, defaultOutlineColor);
		//optionsBox->SetTextColor(defaultFillColor, defaultOutlineColor);
		//creditsBox->SetTextColor(highlightFillColor, defaultOutlineColor);
		//exitBox->SetTextColor(defaultFillColor, defaultOutlineColor);
		break;
	case 3:
		exitImg->isEnabled = false;
		exitImg2->isEnabled = true;
		//playBox->SetTextColor(defaultFillColor, defaultOutlineColor);
		//optionsBox->SetTextColor(defaultFillColor, defaultOutlineColor);
		//creditsBox->SetTextColor(defaultFillColor, defaultOutlineColor);
		//exitBox->SetTextColor(highlightFillColor, defaultOutlineColor);
		break;
	}

	if (UpdateTransition() == true)
	{
		menuSelector->isEnabled = false;
		mainMenu->isEnabled = false;
		//exitBox->SetIsActive(false);
		//playBox->SetIsActive(false);
		//optionsBox->SetIsActive(false);
		//creditsBox->SetIsActive(false);
		return NextStateAfterTrans;
	}

	if (pCoreFacade->IsToggled(BT_ESC))
	{
		if (m_nCurrSelection == 3)
		{
			HWND hWnd = GetForegroundWindow();
			PostMessage(hWnd, WM_CLOSE, 0, 0);
			NextStateAfterTrans = GS_NO_STATE;
			this->TransitionNextState = true;
			return GS_NO_STATE;
		}
		else
		{
			menuSelector->m_XSceenPos = location[3].x;
			menuSelector->m_YScreenPos = location[3].y;
			m_nCurrSelection = 3;
		}
	}
	else if (pCoreFacade->IsToggled(BT_UP))
	{
		pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_SFX_MENU_SCROLL);
		
		if (m_nCurrSelection - 1 < 0)
			m_nCurrSelection = MAX_LOCATIONS;
		else
			m_nCurrSelection--;

		menuSelector->m_XSceenPos = location[m_nCurrSelection].x;
		menuSelector->m_YScreenPos = location[m_nCurrSelection].y;
	}

	else if (pCoreFacade->IsToggled(BT_DOWN))
	{
		pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_SFX_MENU_SCROLL);
		if (m_nCurrSelection + 1 > MAX_LOCATIONS)
			m_nCurrSelection = 0;
		else
			m_nCurrSelection++;

		menuSelector->m_XSceenPos = location[m_nCurrSelection].x;
		menuSelector->m_YScreenPos = location[m_nCurrSelection].y;
	}

	else if (abs((pCoreFacade->GetMousePos().x - lastMouse.x)) >= 0.001 || abs((pCoreFacade->GetMousePos().y - lastMouse.y)) >= 0.001)
	{
		lastMouse = pCoreFacade->GetMousePos();
		if (pCoreFacade->GetMousePos().y <= 390 && pCoreFacade->GetMousePos().y >= 350 && pCoreFacade->GetMousePos().x <= 790 && pCoreFacade->GetMousePos().x >= 325)
		{
			if (m_nCurrSelection != 0)
				pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_SFX_MENU_SELECT);
			m_nCurrSelection = 0;
			menuSelector->m_XSceenPos = location[0].x;
			menuSelector->m_YScreenPos = location[0].y;
		}

		else if (pCoreFacade->GetMousePos().y <= 510 && pCoreFacade->GetMousePos().y >= 450 && pCoreFacade->GetMousePos().x <= 690 && pCoreFacade->GetMousePos().x >= 325)
		{
			if (m_nCurrSelection != 1)
				pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_SFX_MENU_SELECT);
			m_nCurrSelection = 1;
			menuSelector->m_XSceenPos = location[1].x;
			menuSelector->m_YScreenPos = location[1].y;
		}

		else if (pCoreFacade->GetMousePos().y <= 630 && pCoreFacade->GetMousePos().y >= 570 && pCoreFacade->GetMousePos().x <= 690 && pCoreFacade->GetMousePos().x >= 325)
		{
			if (m_nCurrSelection != 2)
				pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_SFX_MENU_SELECT);
			m_nCurrSelection = 2;
			menuSelector->m_XSceenPos = location[2].x;
			menuSelector->m_YScreenPos = location[2].y;
		}

		else if (pCoreFacade->GetMousePos().y <= 750 && pCoreFacade->GetMousePos().y >= 680 && pCoreFacade->GetMousePos().x <= 690 && pCoreFacade->GetMousePos().x >= 325)
		{
			if (m_nCurrSelection != 3)
				pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_SFX_MENU_RETURN);
			m_nCurrSelection = 3;
			menuSelector->m_XSceenPos = location[3].x;
			menuSelector->m_YScreenPos = location[3].y;
		}
	}

	if (pCoreFacade->IsToggled(BT_SELECT) || pCoreFacade->IsToggled(BT_SEND) || pCoreFacade->IsToggled(BT_MOVE))
	{
		pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_SFX_MENU_SELECT);
		//introScreen->isEnabled = false;
		if (m_nCurrSelection == 0)
		{
			//menuSelector->isEnabled = false;
			//mainMenu->isEnabled = false;
			//exitBox->SetIsActive(false);
			//playBox->SetIsActive(false);
			//optionsBox->SetIsActive(false);
			//creditsBox->SetIsActive(false);
			//loadingScreen->isEnabled = true;

			HWND hWnd = GetForegroundWindow();
			HINSTANCE hIns = (HINSTANCE)GetWindowLong(hWnd, GWL_HINSTANCE);
			HCURSOR tempCursor = LoadCursor(hIns, MAKEINTRESOURCE(IDC_CURSOR1));
			SetClassLong(hWnd, GCL_HCURSOR, (LONG)tempCursor);
			SetCursorPos(500, 520);
			//ShowCursor(false);
			pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::STOP_ALL);
			NextStateAfterTrans = GS_LOADING;
			this->TransitionNextState = true;
			return GS_NO_STATE;
		}

		if (m_nCurrSelection == 1)
		{
			NextStateAfterTrans = GS_OPTIONS_MENU;
			this->TransitionNextState = true;
			return GS_NO_STATE;
		}

		if (m_nCurrSelection == 2)
		{
			NextStateAfterTrans = GS_CREDITS_MENU;
			this->TransitionNextState = true;
			return GS_NO_STATE;
		}

		if (m_nCurrSelection == 3)
		{
			HWND hWnd = GetForegroundWindow();
			PostMessage(hWnd, WM_CLOSE, 0, 0);
			return GS_NO_STATE;
		}
	}

	else if (pCoreFacade->IsPressingKey(VK_NUMPAD0))
		return GS_LOSE;

	//textOut1 << "Play Game";
	//playBox->SetText(textOut1.str());
	////textOut.clear();

	//textOut2 << "Options";
	//optionsBox->SetText(textOut2.str());
	////textOut.clear();

	//textOut3 << "Credits";
	//creditsBox->SetText(textOut3.str());
	////textOut.clear();

	//textOut4.str(L"");
	//textOut4 << "Exit";
	//exitBox->SetText(textOut4.str());
	//textOut.clear();

	/*textOut4.str(L"");
	textOut4 << "Accept";
	enterBox->SetText(textOut4.str());*/

	/*textOut4.str(L"");
	textOut4 << "Move Cursor";
	upDownBox->SetText(textOut4.str());*/

	return GS_NO_STATE;
}


void SoundTestfunc(CoreFacade* pCoreFacade)
{
	// TODO: Testing function, delete when not used anymore

	static UINT sounds[80] {
	3864097025U,
		3412940309U,
		2068802240U,
		1203171421U,
		1763800590U,
		4126538873U,
		430329040U,
		2337306830U,
		3761829895U,
		969992391U,
		3432959431U,
		3836275424U,
		3110195632U,
		1107108682U,
		425165382U,
		2882299664U,
		4042539875U,
		905521127U,
		1456069603U,
		2067887017U,
		726857588U,
		1728663298U,
		987385568U,
		4123835918U,
		2415006107U,
		696917685U,
		1526375285U,
		4292106387U,
		2078529791U,
		3621386429U,
		4195054897U,
		3637374546U,
		3618765313U,
		2632226688U,
		2666978119U,
		3973443319U,
		2622520724U,
		3135678882U,
		3407866903U,
		3295936277U,
		891453498U,
		3814004282U,
		2046371004U,
		1585471016U,
		73471290U,
		21750526U,
		4050058769U,
		4112129774U,
		3553836542U,
		163704345U,
		3359821848U,
		1070288727U,
		1902835760U,
		1491931047U,
		4023349039U,
		2230580979U,
		2230580976U,
		2230580977U,
		2230580982U,
		2230580983U,
		2230580980U,
		3679762312U,
		2547817U,
		943723731U,
		1262658854U,
		3877919460U,
		4240821802U,
		4219667864U,
		3290877581U,
		3178288442U,
		4017587645U,
		1042256331U,
		3939718988U,
		3286584031U,
		3567964133U,
		3567964134U,
		3567964135U,
		3567964128U,
		3567964129U,
		3567964130U,
};

	//static int count = 0;
	//if (pCoreFacade->IsToggledKey('O'))
	//{
	//	PrintConsole("Counter:",count);
	//	pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::STOP_ALL);
	//	pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent((AkUniqueID)(sounds[count++]));
	//}
	//if (pCoreFacade->IsToggledKey('P'))
	//{
	//	PrintConsole("Counter:",count);
	//	pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::STOP_ALL);
	//	pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent((AkUniqueID)(sounds[count--]));
	//}
	//if (pCoreFacade->IsToggledKey('C'))
	//{
	//	pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::STOP_ALL);
	//	pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_FX_2D_MENUBACKUP);
	//}
	//if (pCoreFacade->IsToggledKey('V'))
	//{
	//	pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::STOP_ALL);
	//	pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_FX_2D_MENUCANCEL);
	//}
	//if (pCoreFacade->IsToggledKey('B'))
	//{
	//	pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::STOP_ALL);
	//	pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_FX_3D_DOOR_CLOSE);
	//}
	//if (pCoreFacade->IsToggledKey('N'))
	//{
	//	pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::STOP_ALL);
	//	pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_FX_3D_EXPLOSION);
	//}
	//if (pCoreFacade->IsToggledKey('M'))
	//{
	//	pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::STOP_ALL);
	//	pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_FX_3D_WEAPONWHOOSH);
	//}
}