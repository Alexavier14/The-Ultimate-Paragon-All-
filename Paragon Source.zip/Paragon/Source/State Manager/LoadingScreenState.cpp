#include "../Application/stdafx.h"
#include "LoadingScreenState.h"
#include "../Renderer/RenderController.h"
#include "../Level Manager/LevelManager.h"

#define MULTITHREAD_LOADING 1
#define LOADING_THREADED 1
#define RENDER_THREADED 0
 
bool LoadingScreenState::LoadingComplete = false;
bool LoadingScreenState::RenderThreadComplete = false;
bool LoadingScreenState::CanRender = true;


std::mutex LoadingScreenState::LoadLock;

const DWORD MS_VC_EXCEPTION = 0x406D1388;
#pragma pack(push,8)
typedef struct tagTHREADNAME_INFO
{
	DWORD dwType; // Must be 0x1000.
	LPCSTR szName; // Pointer to name (in user addr space).
	DWORD dwThreadID; // Thread ID (-1=caller thread).
	DWORD dwFlags; // Reserved for future use, must be zero.
} THREADNAME_INFO;
#pragma pack(pop)

void SetThreadName(DWORD dwThreadID, char* threadName);
//Set Thread Name

LoadingScreenState::LoadingScreenState(){ ThreadsCreated = false; }
LoadingScreenState::~LoadingScreenState(){}

void LoadingScreenState::Initialize(CoreFacade* pCoreFacade)
{
	LoadStartTime = 0.0f;
	LoadEndTime = 0.0f;

	CanRender = true;
	LoadingComplete = false;
	RenderThreadComplete = false;
	pCoreFacade->CreateGameFacade();
	 
	RC = pCoreFacade->GetRenderController();
	HINSTANCE pGameInstace = pCoreFacade->GameInstance;
	HWND pGameWindow = pCoreFacade->GameWindow;
	bool IsWindowed = pCoreFacade->IsWindowed;

	//Init all of the HUD elements and add them to the render sets
	HUDtoLoad hudLoader;
	he_LoadingScreen = new HUDElement(2.0f, 2.0f, 0.0f, 0.0f);
	he_LoadingScreen->isEnabled = true;
	hudLoader.TextureFilePath = "../Assets/Textures/LoadingScreen.dds";

	GameObject * LoadScreenHUDGO = new GameObject;
	LoadScreenHUDGO->SetTag("Loading Screen");
	LoadScreenHUDGO->SetTypeID(eLOADSCREEN);
	LoadScreenHUDGO->SetHUDComponent(he_LoadingScreen);
	LoadScreenHUDGO->SetActive(true);
	hudLoader.pGO = LoadScreenHUDGO;
	pCoreFacade->LoadHudAsset(&hudLoader);
	pCoreFacade->m_ObjectManager->AddGameObject(LoadScreenHUDGO);

	this->CreateTransitionState(pCoreFacade, "Loading Screen State");

	pCoreFacade->CreateRenderSets();
	//pCoreFacade->GetAssetManager()->SetForLoading();
	PrintConsole("Creating Loading Screen State Render Set");

}
void LoadingScreenState::Shutdown(CoreFacade* pCoreFacade)
{
	WriteToThreadLog("Shutting Down Loading Screen State");
	string LoadtimeStr = std::to_string(LoadEndTime - LoadStartTime);
	WriteToThreadLog("Total Load Time = " + LoadtimeStr);

	he_LoadingScreen->isEnabled = false;
	pCoreFacade->m_ObjectManager->GetTransitionScreen()->SetActive(false);
	pCoreFacade->m_ObjectManager->LoadingComplete();
}
GameStateType LoadingScreenState::Update(CoreFacade* pCoreFacade)
{
#if MULTITHREAD_LOADING == 1
	if (this->UpdateTransition() == true)
	{
		return GS_GAMEPLAY;
	}

	if (ThreadsCreated == false)
	{
		ClearThreadLog();
		ThreadsCreated = true;
		pCoreFacade->m_ObjectManager->SetLoadingState(true);
		CreateThreads(pCoreFacade);
	}

#if RENDER_THREADED == 1
	if (GetLoadingComplete() == false)
	{
		CoreFacade::LoadNextLevel(pCoreFacade);
		SetLoadingComplete();
	}
#endif


	//if (GetLoadingComplete() == true)
	//{
#if RENDER_THREADED == 1
		if (RenderThread.joinable() == true )
		{
			TransitionNextState = true;
			WriteToThreadLog("The render thread is currently joinable and is trying to join");
			RenderThread.join();
			WriteToThreadLog("The render thread has joined the main thread");
		}
#endif
#if LOADING_THREADED == 1
		//WriteToThreadLog("Checking if we can the loading thread can join main - Loading flagged as complete");
		if (LoadingThread.joinable() == true)
		{
			TransitionNextState = true;
			WriteToThreadLog("The loading thread is currently joinable and is trying to join");
			LoadingThread.join();
			LoadEndTime = TimeManager::GetElapsedTime();
			WriteToThreadLog("The loading thread has joined the main thread");
			CanRender = true;
			//pCoreFacade->EndAssetLoad();
			//return GS_GAMEPLAY;
		}
#endif
	//}

#if RENDER_THREADED == 1
	if (RC && TransitionNextState == true)
	{
		WriteToThreadLog("Main Thread is now rendering");
		RC->Render();
	}
#endif
#if LOADING_THREADED == 1
	if (RC && CanRender == true)
	{
		RC->Render();
		//pCoreFacade->RenderCurrentSets(pCoreFacade);
	}
#endif

	return GS_NO_STATE;

#else
	if (this->UpdateTransition() == true)
	{
		DisableTransitionScreen();
		return GS_GAMEPLAY;
	}

	if (LoadingComplete == false)
	{
		pCoreFacade->m_ObjectManager->SetLoadingState(true);
		PrintConsole("Loading Next Level");
		CoreFacade::LoadNextLevel(pCoreFacade);
	}

	if (LoadingComplete == true)
	{
		TransitionNextState = true;
	}

	if (RC && LoadingComplete == true)
	{
		RC->Render();
	}

	return GS_NO_STATE;
#endif

}

bool LoadingScreenState::GetLoadingComplete()
{
	LoadLock.lock();
	bool RetVal = LoadingComplete;
	LoadLock.unlock();
	return RetVal;
} 
void LoadingScreenState::SetLoadingComplete()
{
	CanRender = false;

	//LoadLock.lock();
	//LoadingComplete = true;
	//LoadLock.unlock();

	//PrintConsole("LoadingComplete!");
	WriteToThreadLog("-------- Loading Complete has been toggled!!! ------");

	//Block the loading thread
	//BlockForComplete.
}

void LoadingScreenState::CreateThreads(CoreFacade * CF)
{
	//Test Load Time
	LoadStartTime = TimeManager::GetElapsedTime();
#if RENDER_THREADED == 1
	RenderThread = std::thread(LoadingScreenState::RenderFunc, RC, this);
	WriteToThreadLog("Render Thread Launched!");
#endif

#if LOADING_THREADED == 1
	LoadingThread = std::thread(CF->LoadNextLevel, CF);
	ostringstream OSS;
	LoadingThread.get_id()._To_text(OSS);
	string TID = OSS.str();
	int id = atoi(TID.c_str());
	SetThreadName(id, "LoadingThread");
	//LoadingThread.detach();
	WriteToThreadLog("Loading Thread Launched!");
#endif 
}

void LoadingScreenState::RenderFunc(RenderController * pRC, GameState * TransitionState)
{
	while (true)
	{
		if (pRC && GetLoadingComplete() == false)
		{
			LoadLock.lock();
			pRC->Render();
			LoadLock.unlock();
			WriteToThreadLog("Render Pass");
		}
		else
		{
			break;
		}

		TransitionState->UpdateTransition();
	}
	WriteToThreadLog("The Loading Complete broke out of the while loop in the thread render function");

}

void SetThreadName(DWORD dwThreadID, char* threadName)
{
	THREADNAME_INFO info;
	info.dwType = 0x1000;
	info.szName = threadName;
	info.dwThreadID = dwThreadID;
	info.dwFlags = 0;

	__try
	{
		RaiseException(MS_VC_EXCEPTION, 0, sizeof(info) / sizeof(ULONG_PTR), (ULONG_PTR*)&info);
	}
	__except (EXCEPTION_EXECUTE_HANDLER)
	{
	}
}