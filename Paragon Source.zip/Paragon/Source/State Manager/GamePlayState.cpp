#include "../Application/stdafx.h"

#include "GamePlayState.h"

#include "../Application/CoreFacade.h"
#include "../Object Manager/ObjectManager.h"
#include "../Object Manager/GameObject.h"
#include "../Object Manager/PlayerComponent.h"
#include "../Object Manager/PhysicsComponent.h"
#include "../Object Manager/EventComponent.h"
#include "../Object Manager/SpawnerComponent.h"
#include "../Object Manager/AudioComponent.h"
#include "../Particle System/Emitter.h"
#include "../Particle System/ParticleSystem.h"
#include "../Text Manager/TextBox.h"
#include "../Util/TimeManager.h"
#include "../Sound/SoundManager.h"
#include "../Sound/Wwise_IDs.h"
#include "../Physics/Physics.h"
#include "../AI System/AIManager.h"

using namespace Physics;


#define RUBY_TOGOAL 5
#define SAPP_TOGOAL 8
#define DIAM_TOGOAL 1
//#define LEVEL_TIME_LIMIT 540.0f
#define LEVEL_TIME_LIMIT 540.0f

#define ReleaseCOM(x) { if(x){ x->Release(); x = 0; } }

#define TIMEBAR_CENTER 0.18f
#define TIMEBAR_WIDTH 0.6f
#define PLAYER_DEATH_TIMER 3.0f
#define PLAYER_CAVE_IN_TIMER 6.0f



GamePlayState::GamePlayState(int Level)
{
	m_nCurrentLevel = Level;
}


GamePlayState::~GamePlayState()
{

}

// --- Initialize Functions ---
void GamePlayState::Initialize(CoreFacade* pCoreFacade)
{
	m_PlayerDeathTimer = 0.0f;
	RubyGeodesUnlocked = false;
	DiamondGeodeUnlocked = false;
	//pAIMan = new AIManager(pCoreFacade);
	//pAIMan->Initialize(1);

	pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::STOP_ALL);

	if (m_nCurrentLevel == 1)
	{
		pCoreFacade->SetRubyUnlock(false);
		pCoreFacade->SetDiamondUnlock(false);
		pCoreFacade->CurrentLevel = 1;
		pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_BGM_PARAGON_LOOP_02);
	}
	else if (m_nCurrentLevel == 2)
	{
		pCoreFacade->SetRubyUnlock(true);
		pCoreFacade->SetDiamondUnlock(true);
		pCoreFacade->CurrentLevel = 2;
		pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_BGM_PARAGON_LOOP_06);
	}
	else if (m_nCurrentLevel == 3)
	{
		pCoreFacade->SetRubyUnlock(true);
		pCoreFacade->SetDiamondUnlock(true);
		pCoreFacade->CurrentLevel = 3;
		pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_BGM_GAUNTLET);
	}

	pCoreFacade->LoadFont("BookAntiquaBig");
	pCoreFacade->LoadFont("LeagueGothic");
	CreateHUD(pCoreFacade);


	pauseMenu.Initialize(pCoreFacade);

	m_GameClock = LEVEL_TIME_LIMIT;
	TimeManager::ResetDelta();
	//m_SelectedGeode = 0;
	pCoreFacade->SetIsPaused(false);


	this->CreateTransitionState(pCoreFacade, "Game Play State");

	pCoreFacade->CreateRenderSets();
	PrintConsole("Creating Game Play State Render Set");

	//pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::STOP_MX_MUSICLOOP_03);
	

	if (pCoreFacade->m_ObjectManager->GetSpawners().size() > 1)
	{
		for (size_t EnemyIndex = 0; EnemyIndex < pCoreFacade->m_ObjectManager->GetAllEnemies().size(); EnemyIndex++)
		{
			pCoreFacade->m_ObjectManager->GetAllEnemies()[EnemyIndex]->SetActive(false);
			for (size_t SpawnerIndex = 0; SpawnerIndex < pCoreFacade->m_ObjectManager->GetSpawners().size(); SpawnerIndex++)
			{
				if (pCoreFacade->m_ObjectManager->GetSpawners()[SpawnerIndex]->GetObjectTranslation().x == pCoreFacade->m_ObjectManager->GetAllEnemies()[EnemyIndex]->GetObjectTranslation().x
					&& pCoreFacade->m_ObjectManager->GetSpawners()[SpawnerIndex]->GetObjectTranslation().y == pCoreFacade->m_ObjectManager->GetAllEnemies()[EnemyIndex]->GetObjectTranslation().y
					&& pCoreFacade->m_ObjectManager->GetSpawners()[SpawnerIndex]->GetObjectTranslation().z == pCoreFacade->m_ObjectManager->GetAllEnemies()[EnemyIndex]->GetObjectTranslation().z)
				{
					pCoreFacade->m_ObjectManager->GetAllEnemies()[EnemyIndex]->GetPhysicsComponent()->DeactivateCollision();

					if (pCoreFacade->m_ObjectManager->GetAllEnemies()[EnemyIndex]->GetType() == eWORM)
					{
						pCoreFacade->m_ObjectManager->GetAllEnemies()[EnemyIndex]->GetChildEmitterComponent(0)->SetSpawning(false);
						pCoreFacade->m_ObjectManager->GetAllEnemies()[EnemyIndex]->GetChildEmitterComponent(1)->SetSpawning(false);
					}
					else if (pCoreFacade->m_ObjectManager->GetAllEnemies()[EnemyIndex]->GetType() == eGOLEM)
					{
						pCoreFacade->m_ObjectManager->GetAllEnemies()[EnemyIndex]->GetChildEmitterComponent(0)->SetSpawning(false);
						pCoreFacade->m_ObjectManager->GetAllEnemies()[EnemyIndex]->GetChildEmitterComponent(1)->SetSpawning(false);
						pCoreFacade->m_ObjectManager->GetAllEnemies()[EnemyIndex]->GetChildEmitterComponent(2)->SetSpawning(false);
					}
					pCoreFacade->m_ObjectManager->GetSpawners()[SpawnerIndex]->GetSpawnerComponent()->EnemyCache.push_back(pCoreFacade->m_ObjectManager->GetAllEnemies()[EnemyIndex]);
				}

			}
			
		}
	}
}
void GamePlayState::CreateHUD(CoreFacade* pCoreFacade)
{
	//Level Data
	if (pCoreFacade->CurrentLevel > 1)
	{
		RubyGeodesUnlocked = true;
		DiamondGeodeUnlocked = true;
	}

	// Hit Indicator - Special case
	m_HitIndicator = pCoreFacade->LoadHudElement("HitIndicator", "2D_Player_Hit.dds", 0.0f, 0.0f, 2.0f, 2.0f);
	m_HitIndicator->isEnabled = false;

	m_HUD_Main_Template = pCoreFacade->LoadHudElement("Main HUD Template", "Main_HUD_Template.dds", 0.0f, 0.0f, 2.0f, 2.0f);

	//Health bar elements
	m_HealthSegmentsRed[0] = pCoreFacade->LoadHudElement("Health Segment Red", "Red_Health_Bar.dds", -0.243f + 0 * 0.122f, -0.783f, 0.13f, 0.15f);

	for (size_t i = 0; i < 3; i++)
		m_HealthSegmentsYellow[i] = pCoreFacade->LoadHudElement("Health Segment Yellow", "Yellow_Health_Bar.dds", -0.243f + i * 0.122f, -0.783f, 0.13f, 0.15f);

	for (size_t i = 0; i < 5; i++)
		m_HealthSegmentsGreen[i] = pCoreFacade->LoadHudElement("Health Segment Green", "Green_Health_Bar.dds", -0.243f + i * 0.122f, -0.783f, 0.13f, 0.15f);

	//Geode Selection
	m_SelectedGeodeFrame = pCoreFacade->LoadHudElement("Selected Geode Frame", "HUD_Selected_Geode_Frame.dds", -0.26f, -0.885f, 0.13f, 0.18f);

	// Enemies Killed
	m_EnemiesKilled = pCoreFacade->LoadTextBox(-0.48f, -0.85f, 1.0f, XMFLOAT4(0.6f, 0.6f, 0.6f, 1.0f));
	m_EnemiesKilled->SetScale(0.5f);

	//Locked Buttons only on level 1

	m_RubyButtonLock = pCoreFacade->LoadHudElement("Ruby Button Lock", "HUD_ButtonLock.dds", -0.26f + 0.105f, -0.885f, 0.13f, 0.18f);
	m_DiamondButtonLock = pCoreFacade->LoadHudElement("Diamond Button Lock", "HUD_ButtonLock.dds", -0.26f + 0.21f, -0.885f, 0.13f, 0.18f);

	if (this->m_nCurrentLevel != 1)
	{
		m_RubyButtonLock->isEnabled = false;
		m_DiamondButtonLock->isEnabled = false;
	}

	// Time counters
	m_TimeLeft = pCoreFacade->LoadTextBox(0.42f, -0.83f, 0.6f, XMFLOAT4(0.6f, 0.6f, 0.6f, 1.0f));

	// Gem Counters
	m_RubyGemCount = pCoreFacade->LoadTextBox(+0.90f, -0.65f, 1.0f, XMFLOAT4(0.9f, 0.14f, 0.13f, 1.0f));
	m_RubyGemCount->SetScale(0.5f);
	m_RubyGemCount->SetTextAlignment(TAL_RIGHT);
	m_SapphireGemCount = pCoreFacade->LoadTextBox(+0.90f, -0.76f, 1.0f, XMFLOAT4(0.6f, 0.85f, 0.91f, 1.0f));
	m_SapphireGemCount->SetScale(0.5f);
	m_SapphireGemCount->SetTextAlignment(TAL_RIGHT);
	m_DiamondGemCount = pCoreFacade->LoadTextBox(+0.90f, -0.87f, 1.0f, XMFLOAT4(0.3f, 1.56f, 1.69f, 1.0f));
	m_DiamondGemCount->SetScale(0.5f);
	m_DiamondGemCount->SetTextAlignment(TAL_RIGHT);

	//Geode Counters
	m_RubyGeodeCount = pCoreFacade->LoadTextBox(-0.90f, -0.65f, 1.0f, XMFLOAT4(0.9f, 0.14f, 0.13f, 1.0f));
	m_RubyGeodeCount->SetScale(0.5f);
	m_SapphireGeodeCount = pCoreFacade->LoadTextBox(-0.90f, -0.76f, 1.0f, XMFLOAT4(0.6f, 0.85f, 0.91f, 1.0f));
	m_SapphireGeodeCount->SetScale(0.5f);
	m_DiamondGeodeCount = pCoreFacade->LoadTextBox(-0.90f, -0.87f, 1.0f, XMFLOAT4(0.3f, 1.56f, 1.69f, 1.0f));
	m_DiamondGeodeCount->SetScale(0.5f);

	//Crafting Buttons
	m_RubyCraftButton = pCoreFacade->LoadHudElement("Ruby Craft Button", "Ruby_Craft_Button.dds", -0.26f + 0.105f, -0.885f, 0.13f, 0.18f);
	m_RubyCraftButton->isEnabled = false;
	m_SapphireCraftButton = pCoreFacade->LoadHudElement("Sapphire Craft Button", "Sapphire_Craft_Button.dds", -0.26f, -0.885f, 0.13f, 0.18f);
	m_SapphireCraftButton->isEnabled = false;
	m_DiamondCraftButton = pCoreFacade->LoadHudElement("Diamond Craft Button", "Diamond_Craft_Button.dds", -0.26f + 0.21f, -0.885f, 0.13f, 0.18f);
	m_DiamondCraftButton->isEnabled = false;

	// --- FPS Indicator ---
	m_FpsIndicator = pCoreFacade->LoadTextBox(0.65f, 0.97f, 1.0f, XMFLOAT4(0.5f, 0.0f, 0.1f, 1.0f), XMFLOAT4(1.0f, 1.0f, 1.0f, 0.8f));
	m_FpsIndicator->SetScale(0.6f);
	m_FpsIndicator->SetIsActive(false);

	XMFLOAT4 color = { 0.0f, 0.0f, 0.0f, 1.0f };
	m_TopCutsceneBar = pCoreFacade->LoadHudElement("CutsceneBar", "2D_Transition.dds", 0.0f, 0.9f, 2.0f, 0.3f);
	m_TopCutsceneBar->isEnabled = false;
	m_TopCutsceneBar->m_Color = color;
	m_TopCutsceneBar->m_ColorRatio = 0.0f;
	m_BottomCutsceneBar = pCoreFacade->LoadHudElement("CutsceneBar", "2D_Transition.dds", 0.0f, -0.9f, 2.0f, 0.3f);
	m_BottomCutsceneBar->isEnabled = false;
	m_BottomCutsceneBar->m_Color = color;
	m_BottomCutsceneBar->m_ColorRatio = 0.0f;

	m_Transition = pCoreFacade->LoadHudElement("Transition", "2D_Transition.dds", 0.0f, 0.0f, 2.0f, 2.0f);
	m_Transition->m_Color = color;
	m_Transition->isEnabled = true;
}

void GamePlayState::Shutdown(CoreFacade* pCoreFacade)
{
	pauseMenu.Shutdown();
	pCoreFacade->ClearAllObjects();
	pCoreFacade->UnloadFonts();
	pCoreFacade->DestroyGameFacade();
	if (pAIMan != nullptr)
	{
		delete pAIMan;
		pAIMan = nullptr;
	}
	//m_SelectedGeode = 0;
}


// --- Update Functions ---
GameStateType GamePlayState::Update(CoreFacade* pCoreFacade)
{

	if (UpdateTransition() == true)
	{
		//DisableTransitionScreen();
		return NextStateAfterTrans;
	}

#pragma region Pause Update

	if (pCoreFacade->IsToggled(BT_ESC))
	{
		pauseMenu.Start(pCoreFacade);
		pCoreFacade->SetIsPaused(true);
	}

	if (pCoreFacade->IsPaused())
	{
		if (pauseMenu.Update(pCoreFacade) == GS_MAIN_MENU)
		{
			pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::STOP_BGM_PARAGON_LOOP_02);
			NextStateAfterTrans = GS_MAIN_MENU;
			TransitionNextState = true;
		}
		else
			return GS_NO_STATE;
	}


#pragma endregion
	UpdateCounters(pCoreFacade);
	UpdateRockfall(pCoreFacade);
	UpdateCutscene(pCoreFacade);
	UpdateHUD(pCoreFacade);

	//Temporary Hack
	pCoreFacade->GameTime = this->m_GameClock;

	// Check for win
	GameObject* pPlayer = pCoreFacade->m_ObjectManager->GetPlayer();
	PlayerComponent* pPlayerComp = pPlayer->GetPlayerComponent();
	CollisionShape* pPlayerBounds = pPlayer->GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE);

	GameObject* pPressurePlate = pCoreFacade->m_ObjectManager->GetPressurePlate();
	CollisionShape* pPressurPlateScanner = pPressurePlate->GetPhysicsComponent()->GetCollisionShape(SU_SCANNER);
	
	bool WinCondition = pPlayerBounds->Collides( pPressurPlateScanner )  || pCoreFacade->IsToggledKey(VK_F5);

	if( WinCondition )
	{
		pPlayerComp->m_bWinEventStarted = true;
		TransitionNextState = true;
		NextStateAfterTrans = GS_WIN;
	}

	//if (pAIMan != nullptr)
	//	pAIMan->UpdateAI();

	return GS_NO_STATE;
}
void GamePlayState::UpdateCounters(CoreFacade* pCoreFacade)
{
#pragma region Count Geodes Left to Goal

	//Update lock buttons
	if ((pCoreFacade->m_ObjectManager->GetPlayer()->GetPlayerComponent()->GetGemCount(eRUBYGEM) > 0 ||
		pCoreFacade->m_ObjectManager->GetPlayer()->GetPlayerComponent()->GetGeodeCount(eRUBYGEODE) > 0) && m_RubyButtonLock)
	{
		m_RubyButtonLock->isEnabled = false;
		RubyGeodesUnlocked = true;
	}

	if ((pCoreFacade->m_ObjectManager->GetPlayer()->GetPlayerComponent()->GetGemCount(eDIAMONDGEM) > 0 ||
		pCoreFacade->m_ObjectManager->GetPlayer()->GetPlayerComponent()->GetGeodeCount(eDIAMONDGEODE) > 0) && m_DiamondButtonLock)
	{
		m_DiamondButtonLock->isEnabled = false;
		DiamondGeodeUnlocked = true;
	}


	GameObject* pPressusrePlate = pCoreFacade->m_ObjectManager->GetPressurePlate();
	CollisionShape* pPressurPlateScanner = pPressusrePlate->GetPhysicsComponent()->GetCollisionShape(SU_SCANNER);

	vector<GameObject*> Geodes = pCoreFacade->m_ObjectManager->GetGeodes();

	//Total colliding geodes
	m_GeodesToGoal[GS_RUBY] = 0;
	m_GeodesToGoal[GS_SAPPHIRE] = 0;
	m_GeodesToGoal[GS_DIAMOND] = 0;

	for (unsigned int i = 0; i < Geodes.size(); i++)
	{
		CollisionShape* pGeodeBounds = Geodes[i]->GetPhysicsComponent()->GetCollisionShape(SU_BOUNDING_SHAPE);
		if (pPressurPlateScanner->Collides(pGeodeBounds))
		{
			switch (Geodes[i]->GetType())
			{
			case eRUBYGEODE:	   	m_GeodesToGoal[GS_RUBY]++;      break;
			case eSAPPHIREGEODE:   	m_GeodesToGoal[GS_SAPPHIRE]++;	break;
			case eDIAMONDGEODE:	   	m_GeodesToGoal[GS_DIAMOND]++;	break;
			}
		}
	}

	m_GeodesToGoal[GS_RUBY] = max(0, RUBY_TOGOAL - m_GeodesToGoal[GS_RUBY]);
	m_GeodesToGoal[GS_SAPPHIRE] = max(0, SAPP_TOGOAL - m_GeodesToGoal[GS_SAPPHIRE]);
	m_GeodesToGoal[GS_DIAMOND] = max(0, DIAM_TOGOAL - m_GeodesToGoal[GS_DIAMOND]);

#pragma endregion
#pragma region Count Enemies left
	m_EnemiesLeft = 1000;
	for (size_t i = 0; i < pCoreFacade->GetObjectManager()->GetDoors().size(); i++)
	{
		EventComponent* pDoorEvent = pCoreFacade->GetObjectManager()->GetDoors()[i]->GetEventComponent();
		if (!pDoorEvent->finished)
		{
			if (m_EnemiesLeft > pDoorEvent->TargetsRemaining)
				m_EnemiesLeft = pDoorEvent->TargetsRemaining;
		}
	}

	if (m_EnemiesLeft == 1000)
		m_EnemiesLeft = 0;
#pragma endregion
}
void GamePlayState::UpdateRockfall(CoreFacade* pCoreFacade)
{
#define BOULDER_EMITTER 1
#define DUST_EMITTER 2
#define LARGER_BOULDER 3

	GameObject* pPlayer = pCoreFacade->m_ObjectManager->GetPlayer();
	PlayerComponent* pPlayerComp = pPlayer->GetPlayerComponent();
	Emitter* pBoulder_Emitter = pPlayer->GetChildEmitterComponent(BOULDER_EMITTER);
	Emitter* pLargeBoulder_Emitter = pPlayer->GetChildEmitterComponent(LARGER_BOULDER);
	Emitter* pDust_Emitter = pPlayer->GetChildEmitterComponent(DUST_EMITTER);
	XMFLOAT4 particle_Positions;
	//static float boulder_rate = 0.0f;
	bool FinishedGame = false;


	if (m_GameClock <= 1.0f && m_GameClock > 0.0f)
	{
		pPlayer->GetAnimComponent()->SetAnimName(PLAYER_IDLE, true);
		pPlayer->GetPlayerComponent()->StopPlayer(true, 9999.9999f);
		vector<GameObject*> Rocks = pCoreFacade->m_ObjectManager->GetFallRocks();
		bool FirstRock = true;
		for (unsigned int KillerRockIndex = 0; KillerRockIndex < Rocks.size(); KillerRockIndex++)
		{
			if (Rocks[KillerRockIndex]->GetTrapComponent()->GetParent() == pPlayer)
			{
				Rocks[KillerRockIndex]->SetActive(true);
				Rocks[KillerRockIndex]->GetTrapComponent()->SetEnabled(true);
				Rocks[KillerRockIndex]->GetTrapComponent()->SetToMove(true);
				Rocks[KillerRockIndex]->GetTrapComponent()->SetTimerEnabled(false);

				if (FirstRock)
				{
					XMVECTOR RandPos = XMCLoadFloat3(SignedUnitRand() * 10.0f, 50.0f, SignedUnitRand() * 10.0f);
					Rocks[KillerRockIndex]->SetObjectTranslation(XMVectorSetY(pPlayer->GetObjectTranslationVec(), 60.0f));
					Rocks[KillerRockIndex]->SetScale(UnitRand() * 1.5f + 1.0f);

					FirstRock = false;
				}
				else
				{
					XMVECTOR RandPos = XMCLoadFloat3(SignedUnitRand() * 10.0f, 60.0f, SignedUnitRand() * 10.0f);
					Rocks[KillerRockIndex]->SetObjectTranslation(RandPos + pPlayer->GetObjectTranslationVec());
					Rocks[KillerRockIndex]->SetScale(UnitRand() * 1.5f + 1.0f);
				}
			}
		}
	}


	if (m_GameClock <= 0.0f)
	{
		//static int killer_boulder = -1;

		//pPlayer->GetAnimComponent()->SetAnimName(PLAYER_IDLE, false);
		
		//pPlayer->GetAnimComponent()->SetAnimName(PLAYER_IDLE, false);

		bool FirstRockFell = false;
		vector<GameObject*> Rocks = pCoreFacade->m_ObjectManager->GetFallRocks();
		for (unsigned int KillerRockIndex = 0; KillerRockIndex < Rocks.size(); KillerRockIndex++)
		{
			if (Rocks[KillerRockIndex]->GetTrapComponent()->GetParent() == pPlayer)
			{

				if (Rocks[KillerRockIndex]->GetObjectTranslation().y <= 8.0f)
				{
					pPlayer->GetAnimComponent()->SetIsDeathAnim(true);
					pPlayer->GetAnimComponent()->SetAnimName(PLAYER_DEATH, false);
					pPlayer->GetAudioComponent()->PlayAudioFollow(AK::EVENTS::PLAY_ADR_BALIN_DEATH);
				}
				if (Rocks[KillerRockIndex]->GetObjectTranslation().y <= 2.0f)
				{
					Rocks[KillerRockIndex]->GetTrapComponent()->SetToMove(false);
					Rocks[KillerRockIndex]->GetAudioComponent()->PlayAudioFollow(PLAY_SFX_ROCK_LARGE);
					FirstRockFell = true;
				}
				else
					Rocks[KillerRockIndex]->SetObjectTranslation(Rocks[KillerRockIndex]->GetObjectTranslation().x,
					Rocks[KillerRockIndex]->GetObjectTranslation().y - TimeManager::GetTimeDelta() * 40.0f,
					Rocks[KillerRockIndex]->GetObjectTranslation().z);
				break;
			}
		}




		int Counter = 0;
		for (unsigned int KillerRockIndex = 0; KillerRockIndex < Rocks.size(); KillerRockIndex++)
		{
			if (Rocks[KillerRockIndex]->GetTrapComponent()->GetParent() == pPlayer)
			{
				if (Rocks[KillerRockIndex]->GetObjectTranslation().y <= 2.0f)
				{
					Rocks[KillerRockIndex]->GetAudioComponent()->PlayAudioFollow(PLAY_SFX_ROCK_LARGE);
					Rocks[KillerRockIndex]->GetTrapComponent()->SetToMove(false);
					Counter++;
				}
				else if (FirstRockFell && Rocks[KillerRockIndex]->GetTrapComponent()->GetToMove())
					Rocks[KillerRockIndex]->SetObjectTranslation(Rocks[KillerRockIndex]->GetObjectTranslation().x,
					Rocks[KillerRockIndex]->GetObjectTranslation().y - TimeManager::GetTimeDelta() * 30.0f,
					Rocks[KillerRockIndex]->GetObjectTranslation().z);
			}
		}


		if (Counter >= 7)
			FinishedGame = true;
	}

	if (m_GameOverTimer > 0.0f)
		m_GameOverTimer -= TimeManager::GetTimeDelta();
	else if (m_GameOverTimer <= 0.0f && FinishedGame)
	{
		//FinishedGame = true;
		TransitionNextState = true;
		NextStateAfterTrans = GS_LOSE;
	}






	if (m_GameClock > 0.0f)
	{

		float time = LEVEL_TIME_LIMIT - m_GameClock;
		float boulder_rate = (time / 60.0f + 1.0f) * 0.1f; //Spawn Rate = ((Total Level Time - Time Remaining) / 1 minute + 1 second) / 10 seconds 
		if (boulder_rate < 0.0f)
			boulder_rate = 0.0f;
		pBoulder_Emitter->SetSpawnRate(boulder_rate);

	}

	for (size_t i = 0; i < pCoreFacade->GetParticleSystem()->PARTICLE_DENSITY; i++)
	{
		//Do this one for the smaller rocks
		particle_Positions = pBoulder_Emitter->GetParticlePositions(i);
		if (particle_Positions.w == -1.0f)
			continue;

		if (particle_Positions.w == 2.0f)
		{
			pDust_Emitter->SetPosition(XMFLOAT3(particle_Positions.x, particle_Positions.y, particle_Positions.z));
			pDust_Emitter->SpawnParticleSet(1);
			pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_SFX_ROCK_SMALL, XMFLOAT3(particle_Positions.x, particle_Positions.y, particle_Positions.z));
		}

		//Do this for the Larger rocks
		if (pLargeBoulder_Emitter->IsSpawning() == true)
		{
			particle_Positions = pLargeBoulder_Emitter->GetParticlePositions(i);
			if (particle_Positions.w == -1.0f)
				continue;

			if (particle_Positions.w == 2.0f)
			{
				pDust_Emitter->SetPosition(XMFLOAT3(particle_Positions.x, particle_Positions.y, particle_Positions.z));
				pDust_Emitter->SpawnParticleSet(1);
				pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::PLAY_SFX_ROCK_LARGE, XMFLOAT3(particle_Positions.x, particle_Positions.y, particle_Positions.z));
			}
		}
	}
}
void GamePlayState::UpdateCutscene(CoreFacade* pCoreFacade)
{
	if (m_GameClock <= 0.0f)
		return;


	GameHudOn = true;
	bool CutSceneNow = false;
	bool FadeOut = false;
	bool FadeIn = false;

	GameObject * FocusedDoor = nullptr;
	vector<GameObject*>& Doors = pCoreFacade->GetObjectManager()->GetDoors();
	for (size_t i = 0; i < Doors.size(); i++)
	{
		FocusedDoor = Doors[i];
		EventComponent* pDoorEvent = FocusedDoor->GetEventComponent();
		if (FocusedDoor->IsFocused())
		{
			CutSceneNow = true;
			//PrintConsole("FocusOnDoor");
			GameHudOn = false;
			if (pDoorEvent->m_Clock.Watch() > 5.0f &&
				pDoorEvent->m_Clock.Watch() <= 8.0f)
				FadeOut = true;
			break;
		}
		else if (!pDoorEvent->finished)
		{
			if (pDoorEvent->m_Clock.Watch() < 11.0f &&
				pDoorEvent->m_Clock.Watch() > 8.0f)
				FadeIn = true;
		}
	}

	GameObject * FocusedEnemy = nullptr;
	vector<GameObject*>& Enemies = pCoreFacade->GetObjectManager()->GetAllEnemies();
	for (size_t i = 0; i < Enemies.size(); i++)
	{
		if (Enemies[i]->GetTag() == "FirstTrapSpider")
		{
			FocusedEnemy = Enemies[i];
			EventComponent* pEnemyEvent = FocusedEnemy->GetEventComponent();
			if (FocusedEnemy->IsFocused())
			{
				//PrintConsole("FocusOnDoor");
				GameHudOn = false;
				CutSceneNow = true;
				if (pEnemyEvent->m_Clock.Watch() > 5.0f &&
					pEnemyEvent->m_Clock.Watch() <= 8.0f)
					FadeOut = true;
				break;
			}
			else if (!pEnemyEvent->finished)
				if (pEnemyEvent->m_Clock.Watch() < 11.0f &&
					pEnemyEvent->m_Clock.Watch() > 8.0f)
					FadeIn = true;
		}
	}


	//Cutscene Break
	if (pCoreFacade->IsToggledKey(VK_RETURN))
	{
		if (!GameHudOn && FocusedDoor != nullptr)
		{
			//FocusedDoor->GetEventComponent()->finished = true;
			pCoreFacade->ClearToggles();
			FocusedDoor->SetFocused(false);
			FocusedDoor->GetEventComponent()->targeted = true;
		}

		if (!GameHudOn && FocusedEnemy != nullptr)
		{
			pCoreFacade->ClearToggles();
			FocusedEnemy->SetFocused(false);
			//FocusedEnemy->GetEventComponent()->finished = true;
		}
		GameHudOn = true;
		CutSceneNow = false;

	}

	else if (pCoreFacade->IsToggledKey(VK_SPACE))
	{
		if (!GameHudOn && FocusedDoor != nullptr)
		{
			//FocusedDoor->GetEventComponent()->finished = true;
			pCoreFacade->ClearToggles();
			FocusedDoor->SetFocused(false);
			FocusedDoor->GetEventComponent()->targeted = true;
		}
		if (!GameHudOn && FocusedEnemy != nullptr)
		{
			pCoreFacade->ClearToggles();
			FocusedEnemy->SetFocused(false);
			//FocusedEnemy->GetEventComponent()->finished = true;
		}
		GameHudOn = true;
		CutSceneNow = false;

	}

	if (CutSceneNow == true)
	{
		//PrintConsole("BarOn");
		m_TopCutsceneBar->isEnabled = true;
		if (m_TopCutsceneBar->m_ColorRatio < 1.0f)
			m_TopCutsceneBar->m_ColorRatio += 1.0f * TimeManager::GetTimeDelta();
		m_BottomCutsceneBar->isEnabled = true;
		if (m_BottomCutsceneBar->m_ColorRatio < 1.0f)
			m_BottomCutsceneBar->m_ColorRatio += 1.0f * TimeManager::GetTimeDelta();
		GameHudOn = false;

		TextSwitch(false);

		if (FadeOut)
		{
			m_Transition->isEnabled = true;
			if (m_Transition->m_ColorRatio < 1.0f)
				m_Transition->m_ColorRatio += 1.0f * TimeManager::GetTimeDelta();
		}
	}
	else
	{
		//PrintConsole("BarOff");
		m_TopCutsceneBar->isEnabled = false;
		m_TopCutsceneBar->m_ColorRatio = 0.0f;
		m_BottomCutsceneBar->isEnabled = false;
		m_BottomCutsceneBar->m_ColorRatio = 0.0f;

		TextSwitch(true);

		if (FadeIn && m_GameClock > 0.0f)
		{
			m_Transition->isEnabled = true;
			if (m_Transition->m_ColorRatio >= 0.0f)
				m_Transition->m_ColorRatio -= 1.0f * TimeManager::GetTimeDelta();
		}

		/*if (!FadeOut && m_GameClock > 0.0f)
		{
		m_Transition->isEnabled = false;
		m_Transition->m_ColorRatio = 0.0f;
		}*/
	}
}

void GamePlayState::UpdateHUD(CoreFacade* pCoreFacade)
{
	wostringstream ss;

#pragma region Selected Geode
	if (GameHudOn == true)
	{
		switch (pCoreFacade->GetSelectedGeode())
		{
		case GS_RUBY:		m_SelectedGeodeFrame->isEnabled = true; m_SelectedGeodeFrame->m_XSceenPos = -0.26f + 0.105f;	break;
		case GS_SAPPHIRE:	m_SelectedGeodeFrame->isEnabled = true; m_SelectedGeodeFrame->m_XSceenPos = -0.26f;				break;
		case GS_DIAMOND:	m_SelectedGeodeFrame->isEnabled = true; m_SelectedGeodeFrame->m_XSceenPos = -0.26f + 0.21f;		break;
		case GS_NONE:		m_SelectedGeodeFrame->isEnabled = false;
		}
	}
#pragma endregion


	//Update the Crafting buttons
	PlayerComponent * PlayerComp = pCoreFacade->m_ObjectManager->GetPlayer()->GetPlayerComponent();

	bool InRange = PlayerComp->GetPlayerInRangeAnvils(pCoreFacade);
	if (true == InRange && GameHudOn)
	{
		//Ruby
		if (PlayerComp->GetGeodeCount(eRUBYGEODE) < 10 && PlayerComp->GetGemCount(eRUBYGEM) > 0)
		{
			m_RubyCraftButton->isEnabled = true;
		}
		else
			m_RubyCraftButton->isEnabled = false;
		//Sapphire
		if (PlayerComp->GetGeodeCount(eSAPPHIREGEODE) < 10 && PlayerComp->GetGemCount(eSAPPHIREGEM) > 0)
		{
			m_SapphireCraftButton->isEnabled = true;
		}
		else
			m_SapphireCraftButton->isEnabled = false;
		//Diamond
		if (PlayerComp->GetGeodeCount(eDIAMONDGEODE) < 10 && PlayerComp->GetGemCount(eDIAMONDGEM) > 0)
		{
			m_DiamondCraftButton->isEnabled = true;
		}
		else
			m_DiamondCraftButton->isEnabled = false;

	}
	else
	{
		m_DiamondCraftButton->isEnabled = false;
		m_SapphireCraftButton->isEnabled = false;
		m_RubyCraftButton->isEnabled = false;
	}

	//Update time 
	if (m_GameClock > 0.0f)
		m_GameClock -= TimeManager::GetTimeDelta();
	else
		m_GameClock = 0.0f;

	GameObject* pPlayer = pCoreFacade->m_ObjectManager->GetPlayer();

	PlayerComponent* playerComp = pPlayer->GetPlayerComponent();
	USHORT playerHealth = playerComp->GetHealth();


	if (GameHudOn == true)
	{
		for (size_t i = 0; i < 5; i++)
		{
			m_HealthSegmentsGreen[i]->isEnabled = i < playerHealth && playerHealth > 3;
		}

		for (size_t i = 0; i < 3; i++)
		{
			m_HealthSegmentsYellow[i]->isEnabled = i < playerHealth && playerHealth > 1;
		}

		m_HealthSegmentsRed[0]->isEnabled = 0 < playerHealth;
	}


	ss.str(L"");
	ss << /*L"x" << */playerComp->GetGeodeCount(eRUBYGEODE) << L"/" << L"10";
	m_RubyGeodeCount->SetText(ss.str());

	ss.str(L"");
	ss << /*L"x" <<*/ playerComp->GetGeodeCount(eSAPPHIREGEODE) << L"/" << L"10";
	m_SapphireGeodeCount->SetText(ss.str());

	ss.str(L"");
	ss << /*L"x" <<*/ playerComp->GetGeodeCount(eDIAMONDGEODE) << L"/" << L"10";
	m_DiamondGeodeCount->SetText(ss.str());

	ss.str(L"");
	ss << L"x" << playerComp->GetGemCount(eRUBYGEM);
	m_RubyGemCount->SetText(ss.str());

	ss.str(L"");
	ss << L"x" << playerComp->GetGemCount(eSAPPHIREGEM);
	m_SapphireGemCount->SetText(ss.str());

	ss.str(L"");
	ss << L"x" << playerComp->GetGemCount(eDIAMONDGEM);
	m_DiamondGemCount->SetText(ss.str());


	int seconds = (int)floorf(m_GameClock);
	int deciSeconds = (int)((m_GameClock - (float)seconds)*10.0f);
	int minutes = seconds / 60;
	seconds %= 60;

	ss.str(L"");
	ss << L"" << minutes << ":" << FixedFloatToWString((float)seconds, 2, 0) << "." << FixedFloatToWString((float)deciSeconds, 1, 0);
	m_TimeLeft->SetText(ss.str());


	//float sliderInitialX = TIMEBAR_CENTER - (TIMEBAR_WIDTH / 2)*0.95f;
	//float sliderFinalX = TIMEBAR_CENTER + (TIMEBAR_WIDTH / 2)*0.95f;
	//m_TimeSlider->m_XSceenPos = sliderFinalX + (sliderInitialX - sliderFinalX)*m_GameClock / LEVEL_TIME_LIMIT;



	//Checks Lose state and run the death animation
	if (playerComp->GetHealth() == 0 || m_GameClock == 0.0f)
	{
		if (m_PlayerDeathTimer <= 0.0f)
		{
			m_HitIndicator->isEnabled = true;

			m_HitIndicator->m_ColorRatio = 0.5f;
		}

		if (m_PlayerDeathTimer < PLAYER_DEATH_TIMER)
		{
			m_PlayerDeathTimer += TimeManager::GetTimeDelta();
		}
		else
		{
			m_PlayerDeathTimer = 0.0f;
			pCoreFacade->GetSoundManager()->GetAudioSystem()->PostEvent(AK::EVENTS::STOP_BGM_PARAGON_LOOP_02);
			TransitionNextState = true;
			NextStateAfterTrans = GS_LOSE;
		}

		this->TextSwitch(false);
	}

	ss.str(L"");
	ss << m_EnemiesLeft;
	m_EnemiesKilled->SetText(ss.str());


	//Flash the screen to let the player know that he has been hit.
	if (playerComp->GetHealth() != 0)
	{
		if (pPlayer->GetReactionTime() > 0.0f && m_GameOverTimer <= 0.0f)
		{
			m_HitIndicator->isEnabled = true;
			m_GameOverTimer = 0.5f; //Re-Using variable
		}

		if (m_GameOverTimer > 0.0f)
		{
			m_HitIndicator->m_Color = { 0.0f, 0.0f, 0.0f, 0.0f };
			m_HitIndicator->m_ColorRatio = (HIT_TIME - m_GameOverTimer) / 0.5f;
			m_GameOverTimer -= TimeManager::GetTimeDelta();
		}
		else
			m_HitIndicator->isEnabled = false;
	}

	UpdateFPSCounter(pCoreFacade);

}
void GamePlayState::UpdateFPSCounter(CoreFacade* pCoreFacade)
{
	wostringstream ss;

	static unsigned int FrameCounter;
	static float CurrentFPS = 0;
	static float FPSAveraged = 0.0f;
	static float LowestFPS = 0.0f;
	FrameCounter++;
	float fpsNow = 1.0f / (float)TimeManager::GetRawTimeDelta();
	if (FrameCounter >= 50)
	{
		FrameCounter = 0;
		FPSAveraged = CurrentFPS / 50.0f;
		CurrentFPS = 0.0f;
		//LowestFPS = fpsNow;
	}
	LowestFPS = min(fpsNow, LowestFPS);

	if (LowestFPS < fpsNow)
		LowestFPS = fpsNow;
	//Update FPS counter
	CurrentFPS += fpsNow;
	ss << Physics::FloatToWString(FPSAveraged,3 ) << " (" << Physics::FloatToWString(fpsNow, 3) << ")";
	m_FpsIndicator->SetText(ss.str());
	ss.str(L"");

	//Turn On/Off
	if (pCoreFacade->IsToggledKey(VK_F1))
		m_FpsIndicator->SetIsActive(!m_FpsIndicator->IsActive());

}

void GamePlayState::TextSwitch(bool bSwitch)
{

	for (unsigned int i = 0; i < 5; i++)
	{
		m_HealthSegmentsGreen[i]->isEnabled = bSwitch;
	}

	for (unsigned int i = 0; i < 3; i++)
	{
		m_HealthSegmentsYellow[i]->isEnabled = bSwitch;
	}

	m_HealthSegmentsRed[0]->isEnabled = bSwitch;

	m_DiamondButtonLock->isEnabled = bSwitch;
	m_RubyButtonLock->isEnabled = bSwitch;
	m_RubyGeodeCount->SetIsActive(bSwitch);
	m_HUD_Main_Template->isEnabled = bSwitch;
	m_SelectedGeodeFrame->isEnabled = bSwitch;
	m_RubyGemCount->SetIsActive(bSwitch);
	m_SapphireGeodeCount->SetIsActive(bSwitch);
	m_SapphireGemCount->SetIsActive(bSwitch);
	m_DiamondGeodeCount->SetIsActive(bSwitch);
	m_DiamondGemCount->SetIsActive(bSwitch);
	m_EnemiesKilled->SetIsActive(bSwitch);
	m_TimeLeft->SetIsActive(bSwitch);
	m_RubyCraftButton->isEnabled = bSwitch;
	m_SapphireCraftButton->isEnabled = bSwitch;
	m_DiamondCraftButton->isEnabled = bSwitch;


	//Check to see what we are doing with the locks
	if (RubyGeodesUnlocked == true)
		m_RubyButtonLock->isEnabled = false;
	if (DiamondGeodeUnlocked == true)
		m_DiamondButtonLock->isEnabled = false;
}
