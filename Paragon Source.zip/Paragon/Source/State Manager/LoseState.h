#pragma once
#include "GameState.h"
#include "../Asset Manager/AssetManager.h"
#include "../Text Manager/TextBox.h"

class CoreFacade;

class CLoseState : public GameState
{
	int m_nCurrSelection;
	HUDElement* menuSelector, *loadingScreen, *loseScreen;
	TextBox* playBox, *menuBox;
	std::vector<XMFLOAT2> location;

	XMFLOAT2 lastMouse;
	XMFLOAT4 defaultOutlineColor;
	XMFLOAT4 defaultFillColor;
	XMFLOAT4 highlightFillColor;

	GameStateType NextTransitionState;
public:
	CLoseState();
	~CLoseState();

	virtual void Initialize(CoreFacade* pCoreFacade);
	virtual void Shutdown(CoreFacade* pCoreFacade);

	// Updates the Game state. 
	// With its returned GameStateType, it indicates that a switch to the specified type should be made.
	virtual GameStateType Update(CoreFacade* pCoreFacade);
};