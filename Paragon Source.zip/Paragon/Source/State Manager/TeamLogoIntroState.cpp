#include "../Application/stdafx.h"
#include "TeamLogoIntroState.h"

#include "../Application/CoreFacade.h"
#include "../Asset Manager/AssetManager.h"

#include "../Object Manager/GameObject.h"
#include "../Sound/SoundManager.h"
#include "../Util/TimeManager.h"
#include "../Sound/Wwise_IDs.h"

TeamLogoIntroState::TeamLogoIntroState()
{
}


TeamLogoIntroState::~TeamLogoIntroState()
{
}


void TeamLogoIntroState::Initialize(CoreFacade* pCoreFacade)
{
	waittimer = 0;

	HUDtoLoad hudLoader;
	pCoreFacade->LoadFont("LeagueGothic");

	// Intro Screen
	introScreen = new HUDElement(2.0f, 2.0f, 0.0f, 0.0f);
	hudLoader.TextureFilePath = "../Assets/Textures/team_nimbus.dds";

	GameObject * IntroScreenGO = new GameObject;
	IntroScreenGO->SetTypeID(eHUD);
	IntroScreenGO->SetTag("TeamScreen");
	IntroScreenGO->SetHUDComponent(introScreen);
	hudLoader.pGO = IntroScreenGO;
	pCoreFacade->LoadHudAsset(&hudLoader);
	pCoreFacade->m_ObjectManager->AddGameObject(IntroScreenGO);

	this->CreateTransitionState(pCoreFacade, "Team State");

	// Loading Screen
	//loadingScreen = new HUDElement(2.0f, 2.0f, 0.0f, 0.0f);
	//hudLoader.HUD_El = loadingScreen;
	//hudLoader.TextureFilePath = "../Assets/Textures/LoadingScreen.dds";
	//hudLoader.HUD_El->SetTag("LoadingScreen");
	//pCoreFacade->LoadHudAsset(&hudLoader);
	//pCoreFacade->AddHudElement(hudLoader.HUD_El);

	pCoreFacade->CreateRenderSets();
	PrintConsole("Creating Team Intro State Render Set");


}

void TeamLogoIntroState::Shutdown(CoreFacade* pCoreFacade)
{
	pCoreFacade->UnloadFonts();
	pCoreFacade->ClearAllObjects();

}

GameStateType TeamLogoIntroState::Update(CoreFacade* pCoreFacade)
{
	waittimer += TimeManager::GetTimeDelta();
	wstringstream textOut;
	if (waittimer >= 3.0f || (pCoreFacade->IsToggled(BT_ESC) && !pCoreFacade->GetSettings().bFirstTime))
	{
		TransitionNextState = true;
	}

	if (UpdateTransition() == true)
		return GS_INTRO3;

	return GS_NO_STATE;
}
