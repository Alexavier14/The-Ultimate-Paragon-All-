#pragma once

class CoreFacade;
class HUDElement;

enum GameStateType { GS_NO_STATE, GS_GAMEPLAY, GS_MAIN_MENU, GS_OPTIONS_MENU, 
					GS_INTRO0, GS_INTRO1, GS_INTRO2, GS_INTRO3, GS_LOSE, GS_WIN, GS_CREDITS_MENU,
					GS_PAUSE, GS_LOADING, };

class GameState
{
private:
	HUDElement* transitionScreen;

	//DO NOT DELETE
	GameObject * TransitionScreenGO;
public:
	bool TransitionNextState;
	void CreateTransitionState(CoreFacade* pCoreFacade, string CurrentStateName);
	void DisableTransitionScreen();
	bool UpdateTransition();

	virtual void Initialize( CoreFacade* pCoreFacade ) = 0 {}
	virtual void Shutdown( CoreFacade* pCoreFacade ) = 0 {}

	// Updates the Game state. 
	// With its returned GameStateType, it indicates that a switch to the specified type should be made.
	virtual GameStateType Update( CoreFacade* pCoreFacade ) = 0 {}

	GameState( );
	virtual ~GameState( );
};

