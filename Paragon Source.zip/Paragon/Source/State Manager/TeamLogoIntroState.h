#pragma once
#include "GameState.h"

#include "../Asset Manager/AssetManager.h"


class TeamLogoIntroState :
	public GameState
{
	float waittimer;
	HUDElement* introScreen;
	HUDElement* loadingScreen;

public:

	TeamLogoIntroState();
	virtual ~TeamLogoIntroState();

	void Initialize(CoreFacade* pCoreFacade) override;
	void Shutdown(CoreFacade* pCoreFacade) override;
	GameStateType Update(CoreFacade* pCoreFacade) override;

};
