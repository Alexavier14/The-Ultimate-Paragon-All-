//////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2011 Audiokinetic Inc. / All Rights Reserved
//
//////////////////////////////////////////////////////////////////////

// AkTypes.h

/// \file 
/// Data type definitions.

#pragma once

#define AK_ANDROID
#define AK_LFECENTER							///< Internal use
#define AK_REARCHANNELS							///< Internal use

#include <AK/SoundEngine/Platforms/POSIX/AkTypes.h>
